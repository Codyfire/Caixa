sap.ui.define([ "sap/ui/core/mvc/Controller" ], function(C) {
	"use strict";
	return C.extend(
			"sap.grc.acs.aud.finding.display.extended.activity.controller.BaseController", {
				onLinkPress : function(e) {
					var c = sap.ushell.Container
							.getService("CrossApplicationNavigation");
					var a = {
						target : {
							semanticObject : "Finding",
							action : "displayAuditFollowUp"
						},
						params : {
							"DBKey" : e.getSource().getBindingContext()
									.getObject().HostKey
						}
					};
					var s = c.hrefForExternal(a);
					window.open(s, "_self");
				},
				setBoundle : function(b) {
					this.oBoundle = b;
					this.getView().setModel(this.getModel("i18nm").getResourceBundle(), "i18nFinding");
				}
			});
});
