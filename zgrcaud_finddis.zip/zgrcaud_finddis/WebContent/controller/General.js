/*
 * Copyright (C) 2009-2017 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([ "sap/uxap/BlockBase" ], function(B) {
	"use strict";
	return B.extend("sap.grc.acs.aud.finding.block.General", {
		metadata : {
			views : {
				Collapsed : { 
					//viewName : "sap.grc.acs.aud.action.display.extended.view.GeneralCustom",
					viewName : "sap.grc.acs.aud.finding.display.extended.view.GeneralCustom",
					type : "XML"
				},
				Expanded : {
					viewName : "sap.grc.acs.aud.finding.display.extended.view.GeneralCustom",
					//viewName : "sap.grc.acs.aud.action.display.extended.view.GeneralCustom",
					type : "XML"
				}
			}
		}
	});
});
