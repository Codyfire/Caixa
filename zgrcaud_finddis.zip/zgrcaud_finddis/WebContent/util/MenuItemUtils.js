///*
// * Copyright (C) 2009-2017 SAP SE or an SAP affiliate company. All rights reserved.
// */
//sap.ui.define([], function() {
//	"use strict";
//	jQuery.sap.require("sap.grc.acs.lib.aud.utils.Constant");
//	/**
//	 *
//	 */
//	var oMenuItemModelData = {
//		MenuItem: []
//	};
//	var oMenuItemModelNewData = {
//		MenuItem: []
//	};	
//	var aGroupActionsData = {};
//	//get Menu item utility i18n model
//	var rootPath = jQuery.sap.getModulePath("sap.grc.acs.lib");
//	var oI18nModel = new sap.ui.model.resource.ResourceModel({
//		bundleUrl: rootPath + "/aud/i18n/i18n.properties"
//	});
//
//	/* INTERNAL METHODS */
//	var removeDuplicateEntries = function(arr) {
//		var aUniqueArray = [];
//		for (var i in arr) {
//			if (aUniqueArray.indexOf(arr[i]) === -1) {
//				aUniqueArray.push(arr[i]);
//			}
//		}
//		return aUniqueArray;
//	};
//	var addToolBarSpacer = function(sSection, sToolBarSpacerId) {
//		var oAdditionalInfo = {
//			toolBarSpacer: true,
//			toolBarSpacerId: sToolBarSpacerId
//		};
//		oMenuItemModelNewData.MenuItem[sSection].actions.splice(0, 0, oAdditionalInfo);
//	};
//	var addSearchBox = function(sSection, sSearchHandler, sSearchBoxId) {
//		var oAdditionalInfo = {
//			searchBox: true,
//			searchBoxId: sSearchBoxId,
//			searchHandler: sSearchHandler
//		};
//		oMenuItemModelNewData.MenuItem[sSection].actions.splice(0, 0, oAdditionalInfo);
//	};
//	var addTitle = function(sSection, sTitleText) {
//		var oAdditionalInfo = {
//			title: true,
//			labelText: sTitleText
//		};
//		oMenuItemModelNewData.MenuItem[sSection].actions.splice(0, 0, oAdditionalInfo);
//	};
//
//	var getIcon = function(bIsGroup, oAction, oMenuItemConfigData, iIndex) {
//		var sActionKey = "";
//		var sIcon = "";
//		if(bIsGroup){
//			sActionKey = oAction.ActionObjectType+"-"+oAction.GroupID;
//			if(oMenuItemConfigData.Group[sActionKey] && oMenuItemConfigData.Group[sActionKey].icon){
//				sIcon = oMenuItemConfigData.Group[sActionKey].icon;
//			}
//		}
//		else{
//			sActionKey = oAction.ActionObjectType+"-"+oAction.Action;
//			if(iIndex !== undefined) {
//				if(oMenuItemConfigData.Button[sActionKey].relatedButtons 
//				&& oMenuItemConfigData.Button[sActionKey].relatedButtons.length > 0) {
//					if(oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].icon){
//						sIcon = oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].icon;
//					}
//				}
//			}
//			else{
//				if(oMenuItemConfigData.Button[sActionKey] && oMenuItemConfigData.Button[sActionKey].icon){
//					sIcon = oMenuItemConfigData.Button[sActionKey].icon;
//				}
//			}
//		}
//		
//		return sIcon;
//	};
//	
//	var getVisibility = function(oMenuItemConfigData, oAction, iIndex) {
//		    var bIsVisible = true;
//			var sActionKey = "";
//			
//			sActionKey = oAction.ActionObjectType+"-"+oAction.Action;
//			if(iIndex !== undefined) {
//				if(oMenuItemConfigData.Button[sActionKey].relatedButtons 
//				&& oMenuItemConfigData.Button[sActionKey].relatedButtons.length > 0) {
//					if(oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].visible !== undefined){
//						bIsVisible = oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].visible;
//					}
//				}
//			}
//			return bIsVisible;
//	};
//
//	var getButtonId = function(oMenuItemConfigData, oAction, iIndex) {
//			var sButtonId = "";
//			var sActionKey = "";
//			
//			sActionKey = oAction.ActionObjectType+"-"+oAction.Action;
//			if(iIndex !== undefined) {
//				if(oMenuItemConfigData.Button[sActionKey].relatedButtons 
//				&& oMenuItemConfigData.Button[sActionKey].relatedButtons.length > 0) {
//					if(oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].buttonId){
//						sButtonId = oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].buttonId;
//					}
//				}
//			}
//			return sButtonId;
//	};
//
//	var getButtonText = function(oMenuItemConfigData, oAction, oAppI18nModel, iIndex) {
//			var sButtonText = "";
//			var sActionKey = "";
//			
//			sActionKey = oAction.ActionObjectType+"-"+oAction.Action;
//			if(iIndex !== undefined) {
//				if(oMenuItemConfigData.Button[sActionKey].relatedButtons 
//				&& oMenuItemConfigData.Button[sActionKey].relatedButtons.length > 0) {
//					if(oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].textId){
//						sButtonText = oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].textId;
//						sButtonText = oAppI18nModel.getResourceBundle().getText(sButtonText);
//					}
//				}
//			}
//			else {
//				sButtonText = oAction.ActionText;
//			}
//			return sButtonText;
//	};
//
//	var getButtonToolTip = function(oMenuItemConfigData, oAction, oAppI18nModel, iIndex) {
//			var sButtonTooltip = "";
//			var sActionKey = "";
//			
//			sActionKey = oAction.ActionObjectType+"-"+oAction.Action;
//			if(iIndex !== undefined) {
//				if(oMenuItemConfigData.Button[sActionKey].relatedButtons 
//				&& oMenuItemConfigData.Button[sActionKey].relatedButtons.length > 0) {
//					if(oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].tooltipId){
//						sButtonTooltip = oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].tooltipId;
//						sButtonTooltip = oAppI18nModel.getResourceBundle().getText(sButtonTooltip);
//					}
//				}
//			}
//			else {
//				sButtonTooltip = oAction.ActionText;
//			}
//			return sButtonTooltip;
//	};
//
//
//	var getPressHandler = function(oMenuItemConfigData, oAction, iIndex) {
//			var sPressHandler = "";
//			var sActionKey = "";
//			
//			sActionKey = oAction.ActionObjectType+"-"+oAction.Action;
//			sPressHandler = oAction.ActionObjectType+"_"+oAction.Action;
//			if(iIndex !== undefined) {
//				if(oMenuItemConfigData.Button[sActionKey].relatedButtons 
//				&& oMenuItemConfigData.Button[sActionKey].relatedButtons.length > 0) {
//					if(oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].pressHandler){
//						sPressHandler = oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].pressHandler;
//					}
//				}
//			}
//			return sPressHandler;
//	};
//	
//	var setSectionID = function(sSectionID, oMenuItemConfigData) {
//		if (sSectionID === "") {
//			sSectionID = "HEADER";
//		}
//		sSectionID = oMenuItemConfigData.Section[sSectionID];
//
//		return sSectionID;
//	};
//
//	var setActionData = function(oAction, sObjectKey, oMenuItemConfigData, oAppI18nModel, iIndex) {
//		var oActionData = {};
//		var sPressHandler = "";
//		var iSequence = 0;
//		var sActionKey = "";
//
//		sActionKey = oAction.ActionObjectType+"-"+oAction.Action;
//		sPressHandler = oAction.ActionObjectType+"_"+oAction.Action;
//		iSequence = parseInt(oAction.ActionSequence, 0);
//		oActionData = {
//						pressHandler: sPressHandler,
//						actionName:   oAction.Action,
//						actionKey:    sActionKey,
//						groupID:      oAction.GroupID === undefined? "" : oAction.GroupID,
//						groupName:    oAction.GroupName,
//						objectType:   oAction.ObjectType,
//						Enable:       oAction.Enable,
//						objectKey:    sObjectKey,
//						groupIcon:    getIcon(true, oAction, oMenuItemConfigData),
//						icon:		  "",
//						visible:      true,
//						buttonId:     "",
//						buttonText:   oAction.ActionText === '' && oAction.Action === 'VERIFY' ? oAppI18nModel.getResourceBundle().getText('BUTTON_VERIFY_FINDING') :  oAction.ActionText,
//    					tooltip:      oAction.ActionText === '' && oAction.Action === 'VERIFY' ? oAppI18nModel.getResourceBundle().getText('BUTTON_VERIFY_FINDING') :  oAction.ActionText,
//						sequence:     iSequence
//		};
//		if(iIndex !== undefined) {
//			oActionData.icon		 = getIcon(false, oAction, oMenuItemConfigData, iIndex);
//			oActionData.visible      = getVisibility(oMenuItemConfigData, oAction, iIndex);
//			oActionData.buttonId     = getButtonId(oMenuItemConfigData, oAction, iIndex);
//			oActionData.pressHandler = getPressHandler(oMenuItemConfigData, oAction, iIndex);
//			oActionData.buttonText   = getButtonText(oMenuItemConfigData, oAction, oAppI18nModel, iIndex);
//			oActionData.tooltip      = getButtonToolTip(oMenuItemConfigData, oAction, oAppI18nModel, iIndex);
//		}
//		else {
//			oActionData.icon		 = getIcon(false, oAction, oMenuItemConfigData);
//		}
//		
//		return oActionData;
//	};
//	
//	var setMenuItemModelDataSectionData = function(oMenuModelData, oAction, sSectionID, sObjectKey, oMenuItemConfigData, oAppI18nModel, iIndex) {
//		var oActionData = {};
//		if(iIndex !== undefined){
//			oActionData = setActionData(oAction, sObjectKey, oMenuItemConfigData, oAppI18nModel, iIndex);
//		}
//		else{
//			oActionData = setActionData(oAction, sObjectKey, oMenuItemConfigData, oAppI18nModel);
//		}
//		if (oMenuModelData.MenuItem[sSectionID].actions) {
//			oMenuModelData.MenuItem[sSectionID].actions.push(oActionData);
//		} else {
//			oMenuModelData.MenuItem[sSectionID].actions = [oActionData];
//		}		
//		return oMenuModelData;
//	};
//	
//	var addAdditionalInfoToMenuModelData = function(oAdditionalInfo, sSectionID) {
//		if (oAdditionalInfo[sSectionID].bIsSearchBoxRequired) {
//			var sSearchBoxId = oAdditionalInfo[sSectionID].sSearchBoxId;
//			//var bIsSearchBoxEnabled = oAdditionalInfo[sSectionID].bIsSearchBoxRequired;
//			var sSearchBoxHandler = oAdditionalInfo[sSectionID].sSearchHandler;
//			addSearchBox(sSectionID, sSearchBoxHandler, sSearchBoxId);
//		}
//		
//		if (oAdditionalInfo[sSectionID].bIsTitleRequired) {
//			var sTitleText = oAdditionalInfo[sSectionID].titleText;
//			addTitle(sSectionID, sTitleText);
//		}
//		
//		if (oAdditionalInfo[sSectionID].bIsToolBarRequired) {
//			var sToolBarSpacerId = oAdditionalInfo[sSectionID].sToolBarSpacerId;
//			addToolBarSpacer(sSectionID, sToolBarSpacerId);
//		}
//	};
//
//	var createActionDialog = function(addInfo) {
//		var sComment = "";
//		var  oBundle = addInfo.oListener.getOwnerComponent().getModel("i18nm").getResourceBundle();
//		var sText = addInfo.actionName === 'VERIFY' || addInfo.actionName === 'VERIFY_BPI' ? oBundle.getText("LABEL_COMMENT_" + addInfo.actionName + "_FINDING") : oI18nModel.getResourceBundle().getText("labelOptionalNotes");
//		var sTitle = addInfo.buttonText;
//		var sObjectType = addInfo.objectType;
//		var sKey = addInfo.objectKey;
//		var sActionName = addInfo.actionName;
//		var oLabel = new sap.m.Text({
//			text: sText,
//			tooltip: sText
//		});
//		
//        var oTextArea = new sap.m.TextArea({
//				rows: 8,
//				cols: 50,
//				enabled: true,
//				width: "100%",
//				tooltip: sText,
//				layoutData: new sap.ui.layout.ResponsiveFlowLayoutData({
//					weight: 7
//				}),
//				change: function(oEvent) {
//					oData.sComment = oEvent.getParameters().newValue;
//				}
//			});
//
//    var oVbox = new sap.m.VBox({ }); 
//
////		var oI18nmModel = new sap.ui.model.resource.ResourceModel({
////		    bundleUrl: "sap/grc/acs/aud/finding/trackopen/extended/i18n/i18n.properties"
////		});
//    
//
////    var  oI18nmModel = addInfo.oListener.getOwnerComponent().getModel("i18nm");
////	  var  oI18nFindingModel = addInfo.oListener.getOwnerComponent().getModel("i18n");
////	  oI18nFindingModel.enhance({bundleUrl: oI18nmModel.getResourceBundle().oUrlInfo.url });
////	addInfo.oListener.getOwnerComponent().setModel('i18n',oI18nFindingModel);
//	
//        var oData = {
//				sComment: sComment,
//				sKey: sKey,
//				sActionName: sActionName,
//				sObjectType: sap.grc.acs.lib.aud.utils.Constant.ObjectType[sObjectType],
//				Parameter:""
//			};
//
//
//		var oSelect = new  sap.m.Select({
//			text : oBundle.getText("LABEL_SELECT_" + sActionName + "_FINDING"),
//	        tooltip : oBundle.getText("LABEL_SELECT_" + sActionName + "_FINDING"),	
//	        required: true,
//	        change : function(oEvent) {
//	        	oData.Parameter = oEvent.getParameters().selectedItem.getKey();
//	  		} });
//
//		
//		  var oLabelVerify = new sap.m.Text({
//					text : oBundle.getText("LABEL_SELECT_" + sActionName + "_FINDING"),
//					tooltip : oBundle.getText("LABEL_SELECT_" + sActionName + "_FINDING"),
//					labelFor:oSelect
//				});
//
//		
//		
//		/* Inicio de modificaci�n rgalan 07.09.2020 09:30:49
//		*   RTC788093 - Funcionalidades segunda l�nea de defensa BPI
//		*   C�digo nuevo
//		*/
//		var sModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/GRCAUD_SRV/",false);		
//		
//		if(sActionName !== undefined && (sActionName === 'VERIFY' || sActionName === 'VERIFY_BPI') ){
//			
//			var field = sActionName === 'VERIFY' ? 'ZZ_VERIFIED' : 'ZZ_VERIFIED_BPI';
//		    var url = "/GetValueSet?Entity='Finding'&Field='"+field+"'"
//		
////		    fn.Action = object.ActionName;				
//		  
//		  var oUrlParameters = {};
//		  oUrlParameters.Entity = sap.grc.acs.aud.finding.util.constant.ObjectType.Find;
//		  oUrlParameters.Field = sActionName === 'VERIFY' ? 'ZZ_VERIFIED' : 'ZZ_VERIFIED_BPI';
//			//oData.Parameter = oUrlParameters;
//		//	var oVbox = new sap.m.VBox();
//			
//			sModel.read(url, undefined, undefined,
//				    false, jQuery.proxy(
//				      function(data, response) {
//				    	  var bindingInfo = {path: "/results"};
//				    	  var oTemplate;
//				    	  var oModel = new sap.ui.model.json.JSONModel(data);
//				    	  oSelect.setModel(oModel);				      				       				      
//					       
//					       bindingInfo.template = new sap.ui.core.ListItem({
//				       			text: "{Value}",
//				       			key: "{Name}"
//				       		});
//							
//
//							oSelect.bindAggregation("items", bindingInfo);
//							oData.Parameter = oSelect.getSelectedKey();
//				      }, this), jQuery.proxy(function(
//				    	      oError) {
//				    	 }, this));
//			  	
//			
//		      
//		     /** oLabel = new sap.m.Text({
//		    		text : oI18nmModel.getResourceBundle().getText("LABEL_COMMENT_" + object.ActionName + "_FINDING"),
//					tooltip : oI18nmModel.getResourceBundle().getText("LABEL_COMMENT_" + object.ActionName + "_FINDING")
//		  	}).addStyleClass("noteTextBreak");
//		  	if (fn.Descr) {
//		  		this.oLabelDescr = new sap.m.Text({
//		  			text : fn.Descr,
//		  			tooltip : fn.Descr
//		  		});*/
//		  	
//		/**  	oTextArea = new sap.m.TextArea({
//		  		rows : 8,
//		  		cols : 50,
//		  		enabled : true,
//		  		width : "100%",
//		  		tooltip : fn.Text,	  		
//		        required: true,
//	        
//		  		change : function(oEvent) {
//		  			sComment = oEvent.getParameters().newValue;
//		  		}
//		  	});
//		      */
//		  	
//		  	oVbox.addItem(oLabelVerify);
//		  	oVbox.addItem(oSelect);
//		}
//		/*  	if (fn.Descr) {
//				oVbox.addItem(fn.oLabelDescr);
//			}
//			if (fn.oLabel) {
//				oVbox.addItem(fn.oLabel);
//			}
//			if (fn.oTextArea) {
//				oVbox.addItem(fn.oTextArea);
//			}*/
//			
//			/**this.oActionDialog = new sap.m.Dialog({
//				title : fn.Title,
//				content : oVbox,
//				width : "100%",
//				leftButton : new sap.m.Button({
//					text : sap.hpa.grcaud.oBundle.getText("BTN_OK"),
//					tooltip : sap.hpa.grcaud.oBundle.getText("BTN_OK"),
//					press : function() {
//						fn.oActionDialog.close();
//						fn.CallBack({
//							ObjectType : fn.ObjectType,
//							Key : fn.Key,
//							Action : fn.Action,
//							Parameter : fn.Parameter,
//							Comment : fn.comment
//						}, fn.navFn);
//					}
//				}),
//				rightButton : new sap.m.Button({
//					text : sap.hpa.grcaud.oBundle.getText("BTN_CANCEL"),
//					tooltip : sap.hpa.grcaud.oBundle.getText("BTN_CANCEL"),
//					press : function() {
//						fn.oActionDialog.close();
//					}
//				})
//			}).addStyleClass("dialogWidth");*/
//
//		
//			
//
//		/* Fin de modificaci�n  rgalan RTC788093  07.09.2020 09:30:49
//		**/
// 
//		
//				oVbox.addItem(oLabel);					
//				oVbox.addItem(oTextArea);		
//			
// 
//			var oActionDialog = new sap.m.Dialog({
//				title: sTitle,
//				type: "Message",
//				content: oVbox,
//				width: "100%",
//				leftButton: new sap.m.Button({
//					text: oI18nModel.getResourceBundle().getText("btn_ok"),
//					tooltip: oI18nModel.getResourceBundle().getText("btn_ok"),
//					press: function() {
//						oActionDialog.close();
//						// En base de la acci�n, se env�a al m�todo original o al m�todo para verificar o verificaci�n BPI
//						if(oData.sActionName !== undefined && (oData.sActionName === 'VERIFY' || oData.sActionName === 'VERIFY_BPI') )
//							addInfo.oListener.handleVerifyHeaderButtonPress(oData);							
//						else
//							addInfo.oListener.handleHeaderButtonPress(oData);
//					}
//				}),
//				rightButton: new sap.m.Button({
//					text: oI18nModel.getResourceBundle().getText("btn_cancel"),
//					tooltip: oI18nModel.getResourceBundle().getText("btn_cancel"),
//					press: function() {
//						oActionDialog.close();
//					}
//				})
//			});
//			return oActionDialog;
//
//	};
//	return {
//		/* PUBLIC METHODS*/
//		setMenuItemModelData: function(oMenuItemsList, oAppI18nModel, sObjectKey, sObjectType, oMenuItemConfigData, oMenuItemModel, oAdditionalInfo) {
//			oMenuItemModelData = {
//				MenuItem: []
//			};
//			oMenuItemModelNewData = {
//				MenuItem: []
//			};
//			aGroupActionsData = {};
//			var oActions = oMenuItemsList;
//			var aSectionArray = [];
//			var sNewGroupID = "";
//			var sConfigActionName = "";
//
//			for (var i = 0; i < oActions.length; i++) {
//				var oActionData = {};
//				var sSectionID = "";
//				sSectionID = setSectionID(oActions[i].SectionID, oMenuItemConfigData);
//				aSectionArray.push(sSectionID);
//				if (!oMenuItemModelData.MenuItem[sSectionID]) {
//					oMenuItemModelData.MenuItem[sSectionID] = [];
//				}
//				/*set Action Data*/
//				if(oActions[i].Enable ===  ""){
//					continue;
//				}
//				sConfigActionName = oActions[i].ActionObjectType+"-"+oActions[i].Action;
//				oMenuItemModelData = setMenuItemModelDataSectionData(oMenuItemModelData, oActions[i], sSectionID, sObjectKey, oMenuItemConfigData, oAppI18nModel);
//				if(oMenuItemConfigData.Button[sConfigActionName] 
//				&& oMenuItemConfigData.Button[sConfigActionName].relatedButtons) {
//					for(var j = 0; j < oMenuItemConfigData.Button[sConfigActionName].relatedButtons.length;
//							j++) {
//						oMenuItemModelData = setMenuItemModelDataSectionData(oMenuItemModelData, oActions[i], sSectionID, sObjectKey, 
//																		     oMenuItemConfigData, oAppI18nModel, j);
//					}
//				}
//			}
//			aSectionArray = removeDuplicateEntries(aSectionArray);
//			for (var k = 0; k < aSectionArray.length; k++) {
//				var p = 0;
//				/*sort the menu item data according sequence field*/
//				if(oMenuItemModelData.MenuItem[aSectionArray[k]].actions === undefined
//				|| (oMenuItemModelData.MenuItem[aSectionArray[k]].actions !== undefined
//				&& oMenuItemModelData.MenuItem[aSectionArray[k]].actions.length === 0)){
//					continue;
//				}
//				oMenuItemModelData.MenuItem[aSectionArray[k]].actions.sort(this._sortSequence);
//				/*reorg menu item data with group information*/
//				if (!oMenuItemModelNewData.MenuItem[aSectionArray[k]]) {
//						oMenuItemModelNewData.MenuItem[aSectionArray[k]] = {actions: []};
//				}
//				for(var o = 0; o < oMenuItemModelData.MenuItem[aSectionArray[k]].actions.length; o++){
//					/*If one action has a group, then collect all actions of a group into aActionList attribute*/
//					sNewGroupID = oMenuItemModelData.MenuItem[aSectionArray[k]].actions[o].groupID;
//					oActionData = oMenuItemModelData.MenuItem[aSectionArray[k]].actions[o];
//					if(sNewGroupID !== ""){
//						if(!aGroupActionsData[sNewGroupID]) {
//							aGroupActionsData[sNewGroupID] = {aActionList: []};
//							aGroupActionsData[sNewGroupID].aActionList = [oActionData];
//							oMenuItemModelNewData.MenuItem[aSectionArray[k]].actions.push(oActionData);
//							(oMenuItemModelNewData.MenuItem[aSectionArray[k]].actions)[p].aActionList = [];
//							(oMenuItemModelNewData.MenuItem[aSectionArray[k]].actions)[p].aActionList.push(oActionData);
//							p++;
//						}
//						else{
//							aGroupActionsData[sNewGroupID].aActionList.push(oActionData);
//							(oMenuItemModelNewData.MenuItem[aSectionArray[k]].actions)[p - 1].aActionList.push(oActionData);
//						}
//					}
//					else {
//						   oMenuItemModelNewData.MenuItem[aSectionArray[k]].actions.push(oActionData);
//						   p++;
//					}
//				}
//				/*Regarding additional information field, add title, toolbarspacer information and so on*/
//				if (oAdditionalInfo[aSectionArray[k]]) {
//						addAdditionalInfoToMenuModelData(oAdditionalInfo, aSectionArray[k]);
//				}
//			}
//			/*set menu item model data with group actions involved*/
//			oMenuItemModel.setData(oMenuItemModelNewData.MenuItem);
//		},
//		
//		_sortSequence: function(x,y){
//			return x.sequence - y.sequence;
//		},
//
//		btnHandler: function(oEvent, addInfo) {
//			this.oBtnHandleDialog = createActionDialog(addInfo);
//			this.oBtnHandleDialog.open();
//		},
//		
//		groupActionItemClicked: function(oEvent, addInfo) {
//			var oAddInfo = {};
//			var oItemId = oEvent.getParameter("item").getId();
//			var sHandlerMethod = "";
//			oAddInfo = addInfo[oItemId];
//			sHandlerMethod = oAddInfo.fnHandlerMethod;
//			if(oAddInfo.oListener[sHandlerMethod]) {
//				oAddInfo.oListener[sHandlerMethod]();
//			}
//			else{
//				this.btnHandler(oEvent, oAddInfo);
//			}
//		},
//		
//		createButtonTemplate: function(sId, oContext, oController) {
//			var oUIControl      = null;
//			var btnHandler      = this.btnHandler;
//			var sGroupID        = oContext.getProperty("groupID");
//			var sGroupIcon      = oContext.getProperty("groupIcon");
//			var sActionIcon     = oContext.getProperty("icon");
//			var sIcon           = "";
//			var sText           = "";
//			var aPressHandler   = [];
//			var bIsVisible      = oContext.getProperty("visible");
//			var sControlId      = oContext.getProperty("buttonId");
//			var sActionKey      = oContext.getProperty("actionKey");
//			var bIsGroupButton  = false;
//			var oGroupMenuItems = null;
//			var aActionList     = [];
//			var oGroupActions   = {};
//			var oItem           = null;
//
//			this.oListener = oController;
//			if (oController[oContext.getProperty("pressHandler")]) {
//				btnHandler = oController[oContext.getProperty("pressHandler")];
//			}
//			
//			if(sGroupID !== undefined && sGroupID === ""){
//				aPressHandler = [{
//							fnHandlerMethod: oContext.getProperty("pressHandler"),
//							oListener: this.oListener,
//							objectKey: oContext.getProperty("objectKey"),
//							objectType: oContext.getProperty("objectType"),
//							actionName: oContext.getProperty("actionName"),
//							buttonText: oContext.getProperty("buttonText")
//						}, btnHandler, oController];
//				sText = oContext.getProperty("buttonText");
//				sIcon = sActionIcon;
//				bIsGroupButton = false;
//			}
//			else if(sGroupID !== undefined && sGroupID !== ""){
//				aActionList = oContext.getProperty("aActionList");
//				oGroupMenuItems = new sap.m.Menu({
//				
//				}); 
//				for(var i = 0; i < aActionList.length; i++){
//					oGroupActions[aActionList[i].actionKey] = {
//							fnHandlerMethod: aActionList[i].pressHandler,
//							oListener:  this.oListener,
//							objectKey:  aActionList[i].objectKey,
//							objectType: aActionList[i].objectType,
//							actionName: aActionList[i].actionName,
//							buttonText: aActionList[i].buttonText
//					};
//				if(aActionList[i].icon === "") {
//					oItem = new sap.m.MenuItem({
//						id:  aActionList[i].actionKey,
//						text:aActionList[i].buttonText
//					});					
//				}
//				else {
//					oItem = new sap.m.MenuItem({
//						id:  aActionList[i].actionKey,
//						icon:    aActionList[i].icon,
//						tooltip: aActionList[i].buttonText
//					});	
//				}
//				oGroupMenuItems.addItem(oItem);
//			}
//				oGroupMenuItems.attachItemSelected(oGroupActions, this.groupActionItemClicked, this);
//				sText = oContext.getProperty("groupName");
//				sIcon = sGroupIcon;
//				bIsGroupButton = true;
//			}
//			if (oContext.getProperty("toolBarSpacer")) {
//				oUIControl = new sap.m.ToolbarSpacer({});
//			} 
//			else if (oContext.getProperty("searchBox")) {
//				oUIControl = new sap.m.SearchField({
//					width: "20%",
//					search: oController[oContext.getProperty("searchHandler")]
//				});
//			}
//			else if (oContext.getProperty("title")) {
//				oUIControl = new sap.m.Title({
//					text: oContext.getProperty("titleText")
//				});
//			} else {
//				if(bIsGroupButton === false) {
//					if (sIcon === "") {
//						oUIControl = new sap.m.Button({
//							id:      sControlId !== ""? sControlId : sActionKey,
//							text:    sText,
//							tooltip: sText,
//							press:   aPressHandler,
//							visible: bIsVisible
//						});
//					} else {
//						oUIControl = new sap.m.Button({
//							id:      sControlId !== ""? sControlId : sActionKey,
//							icon:	 sIcon,
//							tooltip: sText,
//							press:   aPressHandler,
//							visible: bIsVisible
//						});
//					}					
//				}
//				else {
//					if(sIcon === ""){
//						oUIControl = new sap.m.MenuButton({
//							text:    sText,
//							menu:   [oGroupMenuItems],
//							visible: bIsVisible
//						});	
//					}
//					else {
//						oUIControl = new sap.m.MenuButton({
//							icon:    sIcon,
//							menu:   [oGroupMenuItems],
//							visible: bIsVisible
//						});							
//					}
//				}
//
//			}
//			return oUIControl;
//		}
//	};
//});

/*
 * Copyright (C) 2009-2017 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([], function() {
	"use strict";
	jQuery.sap.require("sap.grc.acs.lib.aud.utils.Constant");
	/**
	 *
	 */
	var oMenuItemModelData = {
		MenuItem: []
	};
	var oMenuItemModelNewData = {
		MenuItem: []
	};	
	var aGroupActionsData = {};
	//get Menu item utility i18n model
	var rootPath = jQuery.sap.getModulePath("sap.grc.acs.lib");
	var oI18nModel = new sap.ui.model.resource.ResourceModel({
		bundleUrl: rootPath + "/aud/i18n/i18n.properties"
	});

	/* INTERNAL METHODS */
	var removeDuplicateEntries = function(arr) {
		var aUniqueArray = [];
		for (var i in arr) {
			if (aUniqueArray.indexOf(arr[i]) === -1) {
				aUniqueArray.push(arr[i]);
			}
		}
		return aUniqueArray;
	};
	var addToolBarSpacer = function(sSection, sToolBarSpacerId) {
		var oAdditionalInfo = {
			toolBarSpacer: true,
			toolBarSpacerId: sToolBarSpacerId
		};
		oMenuItemModelNewData.MenuItem[sSection].actions.splice(0, 0, oAdditionalInfo);
	};
	var addSearchBox = function(sSection, sSearchHandler, sSearchBoxId) {
		var oAdditionalInfo = {
			searchBox: true,
			searchBoxId: sSearchBoxId,
			searchHandler: sSearchHandler
		};
		oMenuItemModelNewData.MenuItem[sSection].actions.splice(0, 0, oAdditionalInfo);
	};
	var addTitle = function(sSection, sTitleText) {
		var oAdditionalInfo = {
			title: true,
			labelText: sTitleText
		};
		oMenuItemModelNewData.MenuItem[sSection].actions.splice(0, 0, oAdditionalInfo);
	};

	var getIcon = function(bIsGroup, oAction, oMenuItemConfigData, iIndex) {
		var sActionKey = "";
		var sIcon = "";
		if(bIsGroup){
			sActionKey = oAction.ActionObjectType+"-"+oAction.GroupID;
			if(oMenuItemConfigData.Group[sActionKey] && oMenuItemConfigData.Group[sActionKey].icon){
				sIcon = oMenuItemConfigData.Group[sActionKey].icon;
			}
		}
		else{
			sActionKey = oAction.ActionObjectType+"-"+oAction.Action;
			if(iIndex !== undefined) {
				if(oMenuItemConfigData.Button[sActionKey].relatedButtons 
				&& oMenuItemConfigData.Button[sActionKey].relatedButtons.length > 0) {
					if(oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].icon){
						sIcon = oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].icon;
					}
				}
			}
			else{
				if(oMenuItemConfigData.Button[sActionKey] && oMenuItemConfigData.Button[sActionKey].icon){
					sIcon = oMenuItemConfigData.Button[sActionKey].icon;
				}
			}
		}
		
		return sIcon;
	};
	
	var getVisibility = function(oMenuItemConfigData, oAction, iIndex) {
		    var bIsVisible = true;
			var sActionKey = "";
			
			sActionKey = oAction.ActionObjectType+"-"+oAction.Action;
			if(iIndex !== undefined) {
				if(oMenuItemConfigData.Button[sActionKey].relatedButtons 
				&& oMenuItemConfigData.Button[sActionKey].relatedButtons.length > 0) {
					if(oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].visible !== undefined){
						bIsVisible = oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].visible;
					}
				}
			}
			return bIsVisible;
	};

	var getButtonId = function(oMenuItemConfigData, oAction, iIndex) {
			var sButtonId = "";
			var sActionKey = "";
			
			sActionKey = oAction.ActionObjectType+"-"+oAction.Action;
			if(iIndex !== undefined) {
				if(oMenuItemConfigData.Button[sActionKey].relatedButtons 
				&& oMenuItemConfigData.Button[sActionKey].relatedButtons.length > 0) {
					if(oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].buttonId){
						sButtonId = oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].buttonId;
					}
				}
			}
			return sButtonId;
	};

	var getButtonText = function(oMenuItemConfigData, oAction, oAppI18nModel, iIndex) {
			var sButtonText = "";
			var sActionKey = "";
			
			sActionKey = oAction.ActionObjectType+"-"+oAction.Action;
			if(iIndex !== undefined) {
				if(oMenuItemConfigData.Button[sActionKey].relatedButtons 
				&& oMenuItemConfigData.Button[sActionKey].relatedButtons.length > 0) {
					if(oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].textId){
						sButtonText = oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].textId;
						sButtonText = oAppI18nModel.getResourceBundle().getText(sButtonText);
					}
				}
			}
			else {
				sButtonText = oAction.ActionText;
			}
			return sButtonText;
	};

	var getButtonToolTip = function(oMenuItemConfigData, oAction, oAppI18nModel, iIndex) {
			var sButtonTooltip = "";
			var sActionKey = "";
			
			sActionKey = oAction.ActionObjectType+"-"+oAction.Action;
			if(iIndex !== undefined) {
				if(oMenuItemConfigData.Button[sActionKey].relatedButtons 
				&& oMenuItemConfigData.Button[sActionKey].relatedButtons.length > 0) {
					if(oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].tooltipId){
						sButtonTooltip = oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].tooltipId;
						sButtonTooltip = oAppI18nModel.getResourceBundle().getText(sButtonTooltip);
					}
				}
			}
			else {
				sButtonTooltip = oAction.ActionText;
			}
			return sButtonTooltip;
	};


	var getPressHandler = function(oMenuItemConfigData, oAction, iIndex) {
			var sPressHandler = "";
			var sActionKey = "";
			
			sActionKey = oAction.ActionObjectType+"-"+oAction.Action;
			sPressHandler = oAction.ActionObjectType+"_"+oAction.Action;
			if(iIndex !== undefined) {
				if(oMenuItemConfigData.Button[sActionKey].relatedButtons 
				&& oMenuItemConfigData.Button[sActionKey].relatedButtons.length > 0) {
					if(oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].pressHandler){
						sPressHandler = oMenuItemConfigData.Button[sActionKey].relatedButtons[iIndex].pressHandler;
					}
				}
			}
			return sPressHandler;
	};
	
	var setSectionID = function(sSectionID, oMenuItemConfigData) {
		if (sSectionID === "") {
			sSectionID = "HEADER";
		}
		sSectionID = oMenuItemConfigData.Section[sSectionID];

		return sSectionID;
	};

	var setActionData = function(oAction, sObjectKey, oMenuItemConfigData, oAppI18nModel, iIndex) {
		var oActionData = {};
		var sPressHandler = "";
		var iSequence = 0;
		var sActionKey = "";

		sActionKey = oAction.ActionObjectType+"-"+oAction.Action;
		sPressHandler = oAction.ActionObjectType+"_"+oAction.Action;
		iSequence = parseInt(oAction.ActionSequence, 0);
		oActionData = {
						pressHandler: sPressHandler,
						actionName:   oAction.Action,
						actionKey:    sActionKey,
						groupID:      oAction.GroupID === undefined? "" : oAction.GroupID,
						groupName:    oAction.GroupName,
						objectType:   oAction.ObjectType,
						Enable:       oAction.Enable,
						objectKey:    sObjectKey,
						groupIcon:    getIcon(true, oAction, oMenuItemConfigData),
						icon:		  "",
						visible:      true,
						buttonId:     "",
						buttonText:   oAction.ActionText === '' && oAction.Action === 'VERIFY' ? oAppI18nModel.getResourceBundle().getText('BUTTON_VERIFY_FINDING') :  oAction.ActionText,
    					tooltip:      oAction.ActionText === '' && oAction.Action === 'VERIFY' ? oAppI18nModel.getResourceBundle().getText('BUTTON_VERIFY_FINDING') :  oAction.ActionText,
						sequence:     iSequence
		};
		if(iIndex !== undefined) {
			oActionData.icon		 = getIcon(false, oAction, oMenuItemConfigData, iIndex);
			oActionData.visible      = getVisibility(oMenuItemConfigData, oAction, iIndex);
			oActionData.buttonId     = getButtonId(oMenuItemConfigData, oAction, iIndex);
			oActionData.pressHandler = getPressHandler(oMenuItemConfigData, oAction, iIndex);
			oActionData.buttonText   = getButtonText(oMenuItemConfigData, oAction, oAppI18nModel, iIndex);
			oActionData.tooltip      = getButtonToolTip(oMenuItemConfigData, oAction, oAppI18nModel, iIndex);
		}
		else {
			oActionData.icon		 = getIcon(false, oAction, oMenuItemConfigData);
		}
		
		return oActionData;
	};
	
	var setMenuItemModelDataSectionData = function(oMenuModelData, oAction, sSectionID, sObjectKey, oMenuItemConfigData, oAppI18nModel, iIndex) {
		var oActionData = {};
		if(iIndex !== undefined){
			oActionData = setActionData(oAction, sObjectKey, oMenuItemConfigData, oAppI18nModel, iIndex);
		}
		else{
			oActionData = setActionData(oAction, sObjectKey, oMenuItemConfigData, oAppI18nModel);
		}
		if (oMenuModelData.MenuItem[sSectionID].actions) {
			oMenuModelData.MenuItem[sSectionID].actions.push(oActionData);
		} else {
			oMenuModelData.MenuItem[sSectionID].actions = [oActionData];
		}		
		return oMenuModelData;
	};
	
	var addAdditionalInfoToMenuModelData = function(oAdditionalInfo, sSectionID) {
		if (oAdditionalInfo[sSectionID].bIsSearchBoxRequired) {
			var sSearchBoxId = oAdditionalInfo[sSectionID].sSearchBoxId;
			//var bIsSearchBoxEnabled = oAdditionalInfo[sSectionID].bIsSearchBoxRequired;
			var sSearchBoxHandler = oAdditionalInfo[sSectionID].sSearchHandler;
			addSearchBox(sSectionID, sSearchBoxHandler, sSearchBoxId);
		}
		
		if (oAdditionalInfo[sSectionID].bIsTitleRequired) {
			var sTitleText = oAdditionalInfo[sSectionID].titleText;
			addTitle(sSectionID, sTitleText);
		}
		
		if (oAdditionalInfo[sSectionID].bIsToolBarRequired) {
			var sToolBarSpacerId = oAdditionalInfo[sSectionID].sToolBarSpacerId;
			addToolBarSpacer(sSectionID, sToolBarSpacerId);
		}
	};

	var createActionDialog = function(addInfo) {
		var sComment = "";
		var  oBundle = addInfo.oListener.getOwnerComponent().getModel("i18nm").getResourceBundle();
		var sText = addInfo.actionName === 'VERIFY' || addInfo.actionName === 'VERIFY_BPI' ? oBundle.getText("LABEL_COMMENT_" + addInfo.actionName + "_FINDING") : oI18nModel.getResourceBundle().getText("labelOptionalNotes");
		var sTitle = addInfo.buttonText;
		var sObjectType = addInfo.objectType;
		var sKey = addInfo.objectKey;
		var sActionName = addInfo.actionName;
		var oLabel = new sap.m.Text({
			text: sText,
			tooltip: sText
		});
		
        var oTextArea = new sap.m.TextArea({
				rows: 8,
				cols: 50,
				enabled: true,
				width: "100%",
				tooltip: sText,
				layoutData: new sap.ui.layout.ResponsiveFlowLayoutData({
					weight: 7
				}),
				change: function(oEvent) {
					oData.sComment = oEvent.getParameters().newValue;
				}
			});

    var oVbox = new sap.m.VBox({ }); 

//		var oI18nmModel = new sap.ui.model.resource.ResourceModel({
//		    bundleUrl: "sap/grc/acs/aud/finding/trackopen/extended/i18n/i18n.properties"
//		});
    

//    var  oI18nmModel = addInfo.oListener.getOwnerComponent().getModel("i18nm");
//	  var  oI18nFindingModel = addInfo.oListener.getOwnerComponent().getModel("i18n");
//	  oI18nFindingModel.enhance({bundleUrl: oI18nmModel.getResourceBundle().oUrlInfo.url });
//	addInfo.oListener.getOwnerComponent().setModel('i18n',oI18nFindingModel);
	
        var oData = {
				sComment: sComment,
				sKey: sKey,
				sActionName: sActionName,
				sObjectType: sap.grc.acs.lib.aud.utils.Constant.ObjectType[sObjectType],
				Parameter:""
			};


		var oSelect = new  sap.m.Select({
			text : oBundle.getText("LABEL_SELECT_" + sActionName + "_FINDING"),
	        tooltip : oBundle.getText("LABEL_SELECT_" + sActionName + "_FINDING"),	
	        required: true,
	        change : function(oEvent) {
	        	oData.Parameter = oEvent.getParameters().selectedItem.getKey();
	  		} });

		
		  var oLabelVerify = new sap.m.Text({
					text : oBundle.getText("LABEL_SELECT_" + sActionName + "_FINDING"),
					tooltip : oBundle.getText("LABEL_SELECT_" + sActionName + "_FINDING"),
					labelFor:oSelect
				});

		
		
		/* Inicio de modificaci�n rgalan 07.09.2020 09:30:49
		*   RTC788093 - Funcionalidades segunda l�nea de defensa BPI
		*   C�digo nuevo
		*/
		var sModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/GRCAUD_SRV/",false);		
		
		if(sActionName !== undefined && (sActionName === 'VERIFY' || sActionName === 'VERIFY_BPI') ){
			
			var field = sActionName === 'VERIFY' ? 'ZZ_VERIFIED' : 'ZZ_VERIFIED_BPI';
		    var url = "/GetValueSet?Entity='Finding'&Field='"+field+"'"
		
//		    fn.Action = object.ActionName;				
		  
		  var oUrlParameters = {};
		  oUrlParameters.Entity = sap.grc.acs.aud.finding.util.constant.ObjectType.Find;
		  oUrlParameters.Field = sActionName === 'VERIFY' ? 'ZZ_VERIFIED' : 'ZZ_VERIFIED_BPI';
			//oData.Parameter = oUrlParameters;
		//	var oVbox = new sap.m.VBox();
			
			sModel.read(url, undefined, undefined,
				    false, jQuery.proxy(
				      function(data, response) {
				    	  var bindingInfo = {path: "/results"};
				    	  var oTemplate;
				    	  var oModel = new sap.ui.model.json.JSONModel(data);
				    	  oSelect.setModel(oModel);				      				       				      
					       
					       bindingInfo.template = new sap.ui.core.ListItem({
				       			text: "{Value}",
				       			key: "{Name}"
				       		});
							

							oSelect.bindAggregation("items", bindingInfo);
							oData.Parameter = oSelect.getSelectedKey();
				      }, this), jQuery.proxy(function(
				    	      oError) {
				    	 }, this));
			  	
			
		      
		     /** oLabel = new sap.m.Text({
		    		text : oI18nmModel.getResourceBundle().getText("LABEL_COMMENT_" + object.ActionName + "_FINDING"),
					tooltip : oI18nmModel.getResourceBundle().getText("LABEL_COMMENT_" + object.ActionName + "_FINDING")
		  	}).addStyleClass("noteTextBreak");
		  	if (fn.Descr) {
		  		this.oLabelDescr = new sap.m.Text({
		  			text : fn.Descr,
		  			tooltip : fn.Descr
		  		});*/
		  	
		/**  	oTextArea = new sap.m.TextArea({
		  		rows : 8,
		  		cols : 50,
		  		enabled : true,
		  		width : "100%",
		  		tooltip : fn.Text,	  		
		        required: true,
	        
		  		change : function(oEvent) {
		  			sComment = oEvent.getParameters().newValue;
		  		}
		  	});
		      */
		  	
		  	oVbox.addItem(oLabelVerify);
		  	oVbox.addItem(oSelect);
		}
		/*  	if (fn.Descr) {
				oVbox.addItem(fn.oLabelDescr);
			}
			if (fn.oLabel) {
				oVbox.addItem(fn.oLabel);
			}
			if (fn.oTextArea) {
				oVbox.addItem(fn.oTextArea);
			}*/
			
			/**this.oActionDialog = new sap.m.Dialog({
				title : fn.Title,
				content : oVbox,
				width : "100%",
				leftButton : new sap.m.Button({
					text : sap.hpa.grcaud.oBundle.getText("BTN_OK"),
					tooltip : sap.hpa.grcaud.oBundle.getText("BTN_OK"),
					press : function() {
						fn.oActionDialog.close();
						fn.CallBack({
							ObjectType : fn.ObjectType,
							Key : fn.Key,
							Action : fn.Action,
							Parameter : fn.Parameter,
							Comment : fn.comment
						}, fn.navFn);
					}
				}),
				rightButton : new sap.m.Button({
					text : sap.hpa.grcaud.oBundle.getText("BTN_CANCEL"),
					tooltip : sap.hpa.grcaud.oBundle.getText("BTN_CANCEL"),
					press : function() {
						fn.oActionDialog.close();
					}
				})
			}).addStyleClass("dialogWidth");*/

		
			

		/* Fin de modificaci�n  rgalan RTC788093  07.09.2020 09:30:49
		**/
 
		
				oVbox.addItem(oLabel);					
				oVbox.addItem(oTextArea);		
			
 
			var oActionDialog = new sap.m.Dialog({
				title: sTitle,
				type: "Message",
				content: oVbox,
				width: "100%",
				leftButton: new sap.m.Button({
					text: oI18nModel.getResourceBundle().getText("btn_ok"),
					tooltip: oI18nModel.getResourceBundle().getText("btn_ok"),
					press: function() {
						oActionDialog.close();
						// En base de la acci�n, se env�a al m�todo original o al m�todo para verificar o verificaci�n BPI
						if(oData.sActionName !== undefined && (oData.sActionName === 'VERIFY' || oData.sActionName === 'VERIFY_BPI') )
							addInfo.oListener.handleVerifyHeaderButtonPress(oData);							
						else
							addInfo.oListener.handleHeaderButtonPress(oData);
					}
				}),
				rightButton: new sap.m.Button({
					text: oI18nModel.getResourceBundle().getText("btn_cancel"),
					tooltip: oI18nModel.getResourceBundle().getText("btn_cancel"),
					press: function() {
						oActionDialog.close();
					}
				})
			});
			return oActionDialog;

	};
	return {
		/* PUBLIC METHODS*/
		setMenuItemModelData: function(oMenuItemsList, oAppI18nModel, sObjectKey, sObjectType, oMenuItemConfigData, oMenuItemModel, oAdditionalInfo) {
			oMenuItemModelData = {
				MenuItem: []
			};
			oMenuItemModelNewData = {
				MenuItem: []
			};
			aGroupActionsData = {};
			var oActions = oMenuItemsList;
			var aSectionArray = [];
			var sNewGroupID = "";
			var sConfigActionName = "";

			for (var i = 0; i < oActions.length; i++) {
				var oActionData = {};
				var sSectionID = "";
				sSectionID = setSectionID(oActions[i].SectionID, oMenuItemConfigData);
				aSectionArray.push(sSectionID);
				if (!oMenuItemModelData.MenuItem[sSectionID]) {
					oMenuItemModelData.MenuItem[sSectionID] = [];
				}
				/*set Action Data*/
				if(oActions[i].Enable ===  ""){
					continue;
				}
				sConfigActionName = oActions[i].ActionObjectType+"-"+oActions[i].Action;
				oMenuItemModelData = setMenuItemModelDataSectionData(oMenuItemModelData, oActions[i], sSectionID, sObjectKey, oMenuItemConfigData, oAppI18nModel);
				if(oMenuItemConfigData.Button[sConfigActionName] 
				&& oMenuItemConfigData.Button[sConfigActionName].relatedButtons) {
					for(var j = 0; j < oMenuItemConfigData.Button[sConfigActionName].relatedButtons.length;
							j++) {
						oMenuItemModelData = setMenuItemModelDataSectionData(oMenuItemModelData, oActions[i], sSectionID, sObjectKey, 
																		     oMenuItemConfigData, oAppI18nModel, j);
					}
				}
			}
			aSectionArray = removeDuplicateEntries(aSectionArray);
			for (var k = 0; k < aSectionArray.length; k++) {
				var p = 0;
				/*sort the menu item data according sequence field*/
				if(oMenuItemModelData.MenuItem[aSectionArray[k]].actions === undefined
				|| (oMenuItemModelData.MenuItem[aSectionArray[k]].actions !== undefined
				&& oMenuItemModelData.MenuItem[aSectionArray[k]].actions.length === 0)){
					continue;
				}
				oMenuItemModelData.MenuItem[aSectionArray[k]].actions.sort(this._sortSequence);
				/*reorg menu item data with group information*/
				if (!oMenuItemModelNewData.MenuItem[aSectionArray[k]]) {
						oMenuItemModelNewData.MenuItem[aSectionArray[k]] = {actions: []};
				}
				for(var o = 0; o < oMenuItemModelData.MenuItem[aSectionArray[k]].actions.length; o++){
					/*If one action has a group, then collect all actions of a group into aActionList attribute*/
					sNewGroupID = oMenuItemModelData.MenuItem[aSectionArray[k]].actions[o].groupID;
					oActionData = oMenuItemModelData.MenuItem[aSectionArray[k]].actions[o];
					if(sNewGroupID !== ""){
						if(!aGroupActionsData[sNewGroupID]) {
							aGroupActionsData[sNewGroupID] = {aActionList: []};
							aGroupActionsData[sNewGroupID].aActionList = [oActionData];
							oMenuItemModelNewData.MenuItem[aSectionArray[k]].actions.push(oActionData);
							(oMenuItemModelNewData.MenuItem[aSectionArray[k]].actions)[p].aActionList = [];
							(oMenuItemModelNewData.MenuItem[aSectionArray[k]].actions)[p].aActionList.push(oActionData);
							p++;
						}
						else{
							aGroupActionsData[sNewGroupID].aActionList.push(oActionData);
							(oMenuItemModelNewData.MenuItem[aSectionArray[k]].actions)[p - 1].aActionList.push(oActionData);
						}
					}
					else {
						   oMenuItemModelNewData.MenuItem[aSectionArray[k]].actions.push(oActionData);
						   p++;
					}
				}
				/*Regarding additional information field, add title, toolbarspacer information and so on*/
				if (oAdditionalInfo[aSectionArray[k]]) {
						addAdditionalInfoToMenuModelData(oAdditionalInfo, aSectionArray[k]);
				}
			}
			/*set menu item model data with group actions involved*/
			oMenuItemModel.setData(oMenuItemModelNewData.MenuItem);
		},
		
		_sortSequence: function(x,y){
			return x.sequence - y.sequence;
		},

		btnHandler: function(oEvent, addInfo) {
			this.oBtnHandleDialog = createActionDialog(addInfo);
			this.oBtnHandleDialog.open();
		},
		
		groupActionItemClicked: function(oEvent, addInfo) {
			var oAddInfo = {};
			var oItemId = oEvent.getParameter("item").getId();
			var sHandlerMethod = "";
			oAddInfo = addInfo[oItemId];
			sHandlerMethod = oAddInfo.fnHandlerMethod;
			if(oAddInfo.oListener[sHandlerMethod]) {
				oAddInfo.oListener[sHandlerMethod]();
			}
			else{
				this.btnHandler(oEvent, oAddInfo);
			}
		},
		
		createButtonTemplate: function(sId, oContext, oController) {
			var oUIControl      = null;
			var btnHandler      = this.btnHandler;
			var sGroupID        = oContext.getProperty("groupID");
			var sGroupIcon      = oContext.getProperty("groupIcon");
			var sActionIcon     = oContext.getProperty("icon");
			var sIcon           = "";
			var sText           = "";
			var aPressHandler   = [];
			var bIsVisible      = oContext.getProperty("visible");
			var sControlId      = oContext.getProperty("buttonId");
			var sActionKey      = oContext.getProperty("actionKey");
			var bIsGroupButton  = false;
			var oGroupMenuItems = null;
			var aActionList     = [];
			var oGroupActions   = {};
			var oItem           = null;

			this.oListener = oController;
			if (oController[oContext.getProperty("pressHandler")]) {
				btnHandler = oController[oContext.getProperty("pressHandler")];
			}
			
			if(sGroupID !== undefined && sGroupID === ""){
				aPressHandler = [{
							fnHandlerMethod: oContext.getProperty("pressHandler"),
							oListener: this.oListener,
							objectKey: oContext.getProperty("objectKey"),
							objectType: oContext.getProperty("objectType"),
							actionName: oContext.getProperty("actionName"),
							buttonText: oContext.getProperty("buttonText")
						}, btnHandler, oController];
				sText = oContext.getProperty("buttonText");
				sIcon = sActionIcon;
				bIsGroupButton = false;
			}
			else if(sGroupID !== undefined && sGroupID !== ""){
				aActionList = oContext.getProperty("aActionList");
				oGroupMenuItems = new sap.m.Menu({
				
				}); 
				for(var i = 0; i < aActionList.length; i++){
					oGroupActions[aActionList[i].actionKey] = {
							fnHandlerMethod: aActionList[i].pressHandler,
							oListener:  this.oListener,
							objectKey:  aActionList[i].objectKey,
							objectType: aActionList[i].objectType,
							actionName: aActionList[i].actionName,
							buttonText: aActionList[i].buttonText
					};
				if(aActionList[i].icon === "") {
					oItem = new sap.m.MenuItem({
						id:  aActionList[i].actionKey,
						text:aActionList[i].buttonText
					});					
				}
				else {
					oItem = new sap.m.MenuItem({
						id:  aActionList[i].actionKey,
						icon:    aActionList[i].icon,
						tooltip: aActionList[i].buttonText
					});	
				}
				oGroupMenuItems.addItem(oItem);
			}
				oGroupMenuItems.attachItemSelected(oGroupActions, this.groupActionItemClicked, this);
				sText = oContext.getProperty("groupName");
				sIcon = sGroupIcon;
				bIsGroupButton = true;
			}
			if (oContext.getProperty("toolBarSpacer")) {
				oUIControl = new sap.m.ToolbarSpacer({});
			} 
			else if (oContext.getProperty("searchBox")) {
				oUIControl = new sap.m.SearchField({
					width: "20%",
					search: oController[oContext.getProperty("searchHandler")]
				});
			}
			else if (oContext.getProperty("title")) {
				oUIControl = new sap.m.Title({
					text: oContext.getProperty("titleText")
				});
			} else {
				if(bIsGroupButton === false) {
					if (sIcon === "") {
						oUIControl = new sap.m.Button({
							id:      sControlId !== ""? sControlId : sActionKey,
							text:    sText,
							tooltip: sText,
							press:   aPressHandler,
							visible: bIsVisible
						});
					} else {
						oUIControl = new sap.m.Button({
							id:      sControlId !== ""? sControlId : sActionKey,
							icon:	 sIcon,
							tooltip: sText,
							press:   aPressHandler,
							visible: bIsVisible
						});
					}					
				}
				else {
					if(sIcon === ""){
						oUIControl = new sap.m.MenuButton({
							text:    sText,
							menu:   [oGroupMenuItems],
							visible: bIsVisible
						});	
					}
					else {
						oUIControl = new sap.m.MenuButton({
							icon:    sIcon,
							menu:   [oGroupMenuItems],
							visible: bIsVisible
						});							
					}
				}

			}
			return oUIControl;
		}
	};
});