/*
 * Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(
 [
  "sap/grc/acs/aud/finding/controller/BaseController",
  "sap/grc/acs/lib/aud/utils/MenuItemUtils",
  "sap/grc/acs/lib/aud/utils/ComponentUtil",
  "sap/grc/acs/lib/aud/utils/MessageUtil",
  "sap/grc/acs/aud/finding/display/extended/block/util/encodingUtils"
 ],
 function(BaseController, MenuItemUtils, ComponentUtil, MessageUtil, Util) {
  "use strict";
  var that;
  return BaseController.extend("sap.grc.acs.aud.finding.display.extended.block.controller.ActionPlanRelated", {
	  

	   /**
	    * Called when a controller is instantiated and its View controls (if available) are already created.
	    * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
	    * @memberOf sap.grc.acs.aud.finding.block.view.general
	    */
	   onInit: function() {
		that = this;
	    this._Component = ComponentUtil.getComponentById(this.getView().getId());
	    sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.find.EventBus", "resetBlockToDisplayMode", this.onRefresh, this);
	    
	    /* INI PLANES DE ACCION RELACIONADOS*/
	    sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.find.EventBus", "setVisibilityRelatedActionPlanDisp", this.onSetVisibilityAction, this);
	    sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.find.EventBus","getActionRelDisp", this.getDataFromOdata, this);
	    this.modelActionRel = this._Component.getModel("MyActionRel");
	    this.getView().byId("tableActionPlanRelated").setModel(this.modelActionRel,"actionRel");
	    this.getDataFromOdata();
	    
	    this.tableContentModel = new sap.ui.model.json.JSONModel();
	    
	    this.sModelData = {
				FindingsData: [],
			};
	    this.tableContentModel.setData(this.sModelData);
	    //sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.find.EventBus", "DataUpdateFinishedMenuButtonRelatedPlan", this._setButtonVisibility, this);
	    /* FIN PLANES DE ACCION RELACIONADOS*/
	    
	   },
	   /* INI PLANES DE ACCION RELACIONADOS*/
	   //Vibilidad de los botones de Planes de Acción Relacionados
	   onSetVisibilityAction: function(){
			if( this.getOwnerComponent() !== undefined && this.getOwnerComponent().getModel("menu").getData() !== undefined && this.getOwnerComponent().getModel("menu").getData().actionSection !== undefined &&  this.getOwnerComponent().getModel("menu").getData().actionSection.actions !== undefined )
			{
	       	this.oMenu = this.getOwnerComponent().getModel("menu").getData().actionSection.actions;
	       	if(this.oMenu[4].Enable === "X")
	       	{
	       		this.getView().byId("btn_addActionRelated").setVisible(true);
	       		this.getView().byId("btn_RemoveActionRelated").setVisible(true);
	       	}
	       	else 
	       	{
	       		this.getView().byId("btn_addActionRelated").setVisible(false);
	       		this.getView().byId("btn_RemoveActionRelated").setVisible(false);
	       	}
			} else{
				if(this.getView().byId("btn_addActionRelated") !== undefined)
					this.getView().byId("btn_addActionRelated").setVisible(false);
				
				if(this.getView().byId("btn_RemoveActionRelated") !== undefined)
					this.getView().byId("btn_RemoveActionRelated").setVisible(false);
			}
	   },
	   
	   //FUNCION DE AÑADIR PLANES DE ACCION RELACIONADOS
	   onAdd_ActionRelated : function(oEvent)
	   {
		   var oSource = oEvent.getSource();
		   
		   var sectionBindingModel = this.getView().getModel("sectionBindingConfig");
		   this.findingKey = this.getView().getBindingContext().getObject().DBKey;
		   
		   
		   if(this.addActionRelatedSmartTable){
				this.addActionRelatedSmartTable.destroy();
			}
		   
		   //Cargamos el fragment
		   this.addActionRelatedSmartTable = sap.ui.xmlfragment("sap.grc.acs.aud.finding.execute.extended.block.fragment.addActionRelated", this);
		   
		   var that = this;
		   
		 //Realizar llamada al back para obtener el listado de findinds relacionados
			var actionModel = new sap.ui.model.odata.v2.ODataModel(
					"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false ////"ZGRCAUD_ENH_SRV"
				
			);
			
			var oData = {},
			aBatchOperations = [];

			//var url = "/AuditSet(guid'" + this.auditKey + "')/AuditToFindRel";
			//Limpiamos los registros seleccionados por si los hubiera de navegaciones anteriores
			try {
				that.getView().getContent()[0].getContent()[1].removeSelections();
			} catch (err) {}

			//limpiamos la tabla por si hubiera registros de consultas anteriores
			that.sModelData.FindingsData = [];
			that.tableContentModel.refresh();
			//actionModel.read("/GRCAUD_CV_Action", {
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.GE, "2017"));
		   actionModel.read("/ZGRCAUD_CV_ACTRELTOFIND", {
			    filters: aFilters,
				success: function (data, response) {
					
					data.results.sort(function(a, b) {
						  if (a.ID < b.ID) {
						    return 1;
						  }
						  if (a.ID > b.ID) {
						    return -1;
						  }
						  return 0;
						});

					if (data && data.results && data.results.length > 0) {				
						that.sModelData.FindingsData = data.results;
						that.tableContentModel.refresh();																											
					} else {
						console.log({ err: "No results" });
					}
					that.oValueHelpDialog.setBusy(false);
				},
				failed: function (oData, response) {
					that.oValueHelpDialog.setBusy(false);
					alert("Failed to get InputHelpValues from service!");
				},
			});
		   
		   
		   this.addActionRelatedSmartTable.setModel(this.tableContentModel);
			var i18nModel = this.getView().getModel( "i18n");
			this.addActionRelatedSmartTable.setModel(i18nModel, "i18n");
			var oController = this;
		   
		   this.oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				title: this.getView().getModel("i18n").getResourceBundle().getText("labelActionPlanRel"),
				supportMultiselect: true,
				supportRanges: false,
				supportRangesOnly: false,
				key: "ID",
				descriptionKey: "Title",
				stretch: sap.ui.Device.system.phone,
				contentHeight:"100%",
				
				ok: function(oOkEvent) {
					var aSelectedTokens = oOkEvent.getParameter("tokens");
					oController.assignActionRelToAudit(aSelectedTokens);
					// this.close();
				},

				cancel: function() {
					this.close();
				},

				afterClose: function() {
					this.destroy();
				}
			});
		   
		   var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterBarExpanded: false,
				showGoOnFB: !sap.ui.Device.system.phone,
				search: function() {
					oController.searchToBeAssignedTable();
				}
			});
		   
		   if (oFilterBar.setBasicSearch) {
				this.oBasicSearch = new sap.m.SearchField({
					id: "basicSearch",
					showSearchButton: sap.ui.Device.system.phone,
					placeholder: this.getView().getModel("i18n").getResourceBundle().getText("labelSearchFindingPlaceHolder"),
					search: function() {
						oController.oValueHelpDialog.getFilterBar().search();
					}
				});
				oFilterBar.setBasicSearch(this.oBasicSearch);
			}
		   
		   //Abertura del dialogo
		   	this.oValueHelpDialog.setFilterBar(oFilterBar);
			this.oValueHelpDialog.setTable(this.addActionRelatedSmartTable);
			this.oValueHelpDialog.setModel(this.tableContentModel);
			oSource.addDependent(this.oValueHelpDialog);
			this.oValueHelpDialog.open();
			this.oValueHelpDialog.setBusy(true);
		   
	   },
	   
	   	//FUNCIONES DE BORRADO PARA PLANES DE ACCIÓN RELACIONADOS
		ACTION_DEL: function(oEvent){
			var aSelectedItems = this.getView().byId("tableActionPlanRelated").getSelectedItems();
			var keyObservacion = oEvent.getSource().getBindingContext().getObject().DBKey.replaceAll("-", "").toUpperCase();
			var that = this;
			var oDataModel = new sap.ui.model.odata.v2.ODataModel(
				"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",
				false
			);
			if(aSelectedItems.length === 0){
				//MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("MSG_SELECT_ONE"));
				return;
			}
			oDataModel.setUseBatch(true);
			oDataModel.setDeferredGroups(["removeFindRel"]);
			
			var sPath =	"/FindActRelSet(Key=binary'" + keyObservacion + "')/AssignmentSet"
			var that = this;
			var oDataModelRel = new sap.ui.model.odata.ODataModel(
					"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",
					false
			);
			
			
			
			oDataModelRel.read(sPath, {
				success: function (data, response) {
					aSelectedItems.forEach(selectedItem => {
						var element = data.results.filter(function (item) {
							//return item.ReferenceKey == selectedItem.getBindingContext("actionRel").getObject().Key;
							return item.ServiceURL == "ActRelSet(guid'" + selectedItem.getBindingContext("actionRel").getObject().DBKey.toUpperCase() + "')";
						});

						if (element.length > 0) {
							var uri = element[0].__metadata.uri;
							
							var pos = uri.indexOf("/AssignmentSet");
							uri = uri.substr(pos,uri.length);
							
							oDataModel.remove(uri, {
								async: true,
								groupId: "removeFindRel"
							});
						}
					});
														
					oDataModel.submitChanges({
						groupId: "removeFindRel",
						success: jQuery.proxy(function() {
									oDataModel.setUseBatch(false);
									that.getDataFromOdata();

						}, this),
						error: jQuery.proxy(function() {
					        	//MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("REMOVE_DIM_TO_AUDIT_FAILED"));
						}, this)
					});
					
				},
				failed: function (oData, response) {
					that.getView().byId("idFindRelAssgnTable").setBusy(false)
				},
			});											
		},

		//FUNCION DE BUSQUEDAD PARA POP-UP DE PLANES DE ACCION RELACIONADOS
	   searchToBeAssignedTable: function() {
			var oController = this;
			var oTableSearchState = [];
			var oTableSearchStateFilter = [];
			var oBindingInfo = {};
			var sSearchString = oController.oBasicSearch.getValue();
			oTableSearchState = [
				new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.Contains, sSearchString),
				new sap.ui.model.Filter("Title", sap.ui.model.FilterOperator.Contains, sSearchString),
				new sap.ui.model.Filter("ActionTypeText", sap.ui.model.FilterOperator.Contains, sSearchString),
				new sap.ui.model.Filter("StatusText", sap.ui.model.FilterOperator.Contains, sSearchString)
			];
			oTableSearchStateFilter = new sap.ui.model.Filter(oTableSearchState, false);
			oBindingInfo = oController.addActionRelatedSmartTable.getTable().getBindingInfo("items");
			oBindingInfo.filters = oTableSearchStateFilter;
			oController.addActionRelatedSmartTable.getTable().bindAggregation("items", oBindingInfo);					
		},
		
		//Función del OK para el Fragment de Planes de Acción Relacionados
		assignActionRelToAudit : function(aSelectedTokens){
			var oController = this;
			var selectedItems = [];
			if(aSelectedTokens.length === 0){
				b.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("MSG_NO_FINDING_SELECTED"));
				return;
			}
			for(var i = 0; i < aSelectedTokens.length; i++) {
				var oObject = aSelectedTokens[i].data("row");
				selectedItems.push(oObject);
			}
			if (!oController.oDataModel) {
				oController.oDataModel = new sap.ui.model.odata.ODataModel(
						"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",
					false
				);
			}
			var aBatchOperations = oController._generateBatchOperations(
					selectedItems,
					oController.oDataModel
			);
			oController.oDataModel.addBatchChangeOperations(aBatchOperations);
			oController.oDataModel.submitBatch(
					jQuery.proxy(function (oData, oResponse, aErrorResponses) {
						if (aErrorResponses.length <= 0) {
							oController.getDataFromOdata()
						} else {
							
						}
					}, this),
					jQuery.proxy(function (oError) {
						/*oController.getView().getContent()[0].getContent()[1].setBusy(false);
						sap.hpa.grcaud.Utility.showODataErrorMsg(
							oError,
							sap.hpa.grcaud.enh_oBundle.getText("MSG_ADD_FINDING_FAIL")
						);*/
					}, this),
					true
				);
			this.oValueHelpDialog.close();
		},
		
		//FUNCIÓN DE GUARDADO DE PLANES DE ACCION RELACIONADOS
		_generateBatchOperations: function (aNewEntryKey, oDataModel) {
			var aBatchOperations = [];
			var findingKey = this.findingKey.replaceAll("-", "").toUpperCase();
			var that = this;
			for (var i = 0; i < aNewEntryKey.length; i++) {
				var oSelectedData = aNewEntryKey[i];
				aBatchOperations.push(
					//oDataModel.createBatchOperation("/AuditFindRelSet(Key=binary'"+auditKey+"')/AuditToFindRelAssignment", "POST", {
					oDataModel.createBatchOperation(
						"/FindActRelSet(Key=binary'" + findingKey + "')/AssignmentSet",
						"POST",
						{
							ReferenceKey: recoverKey(oSelectedData.DBKey),
							Type: "ACTREL",
							//HostKey: recoverKey(sAuditKey),
						}
					)
				);
			}

			return aBatchOperations;
		},
		
		//FUNCIÓN DE REFRESCO DE DATOS LA TABLA PRINCIPAL
		getDataFromOdata:function(){
			this.onSetVisibilityAction();
									
			var that = this;
			
			var oData = {},
				aBatchOperations = [];										
			
			var sFindingKey = sap.ui.getCore().getModel("findingKeyModel").getData().id
			//var sAuditKey = "2c8c9834-3715-4b29-b865-ab9fe729a337";
			var url = "/ZGRCAUD_CV_ACTIONRELBYFINDING(p_find=guid'" + sFindingKey + "')/Set";
			
			//Realizar llamada al back para obtener el listado de findinds relacionados
			var actionRelModel = new sap.ui.model.odata.v2.ODataModel(
					"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
				);
			
			actionRelModel.read(url, {
				success: function (data, response) {
					
					if(that.getView().byId("tableActionPlanRelated")){
					that.getView().byId("tableActionPlanRelated").removeSelections()	
				}
				
						if(that.modelActionRel) {
							that.modelActionRel.setData(data.results);
							that.getView().byId("tableActionPlanRelated").setModel(that.modelActionRel,"actionRel");
							that.modelActionRel.refresh();
						}
						that.editData = [];
						var modelTitleActionRel = {};
						that.editData = [];			
						
						//modelTitleActionRel.title = that._Component.getModel("i18nm").getResourceBundle().getText("ActionRelSectionTitle");
						
						/*if(that.getOwnerComponent() !== undefined && that.getOwnerComponent().getModel("i18nm").getResourceBundle().getText("ActionRelSectionTitle") !== undefined)
						{
							modelTitleActionRel.title = that.getOwnerComponent().getModel("i18nm").getResourceBundle().getText("ActionRelSectionTitle");					
						}
						else
						{
							modelTitleActionRel.title = "Planes de acción relacionados ";
						}*/
						
						modelTitleActionRel.title = that.getOwnerComponent().getModel("i18nm").getResourceBundle().getText("ActionRelSectionTitle");
						
		      			modelTitleActionRel.count = data.results.length;
		      			modelTitleActionRel.title = modelTitleActionRel.title +'('+modelTitleActionRel.count+')';
	  					that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(modelTitleActionRel), "ActionRelTitle");
		      			that.getOwnerComponent().getModel("ActionRelTitle").refresh();
						
				},
				failed: function (oData, response) {
					alert("Failed to get InputHelpValues from service!");
				},
			});
		},
		
	   /* FIN PLANES DE ACCION RELACIONADOS*/

	   /**
	    * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
	    * @memberOf sap.grc.acs.aud.finding.block.view.general
	    */
	   onExit: function() {
	    sap.ui.getCore().getEventBus().unsubscribe("sap.grc.acs.aud.find.EventBus", "resetBlockToDisplayMode", this.onRefresh, this);
	   },

	   onUpdateFinished: function() {
	    if (this.changeSequenceFlag) {
	     this.changeSequenceFlag = false;
	     return;
	    } else {
	     this.changeSequenceFlag = false;
	     this.onRefresh();
	    }
	   },

	   _createActionPlanSequence: function() {
	    var aActions = this.getView().byId("tableActionPlanRelated").getItems();
	    for (var i = 0; i < aActions.length; i++) {
	     var sKey = aActions[i].getBindingContext().getObject().DBKey;
	     var sSeq = aActions[i].getBindingContext().getObject().Sequence;
	     var sStatus = aActions[i].getBindingContext().getObject().Status;
	     if (sStatus === "") {
	      aActions[i].getCells()[2].setEditable(true);
	     } else {
	      aActions[i].getCells()[2].setEditable(false);
	     }
	     this.aExistActionSequence.push({
	      "actionKey": sKey,
	      "sequence": sSeq
	     });
	     this.aOriginalActionSequence.push({
	      "actionKey": sKey,
	      "sequence": sSeq
	     });
	    }
	   },

	   /* INI PLANES DE ACCION RELACIONADOS */
	   // FUNCIÓN DE NAVEGACIÓN
	   onPressRow: function(oEvent) {   
		   
		var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); 
//	    var iStatus = "";
//	    var sAction = "displayAuditFollowUp";
//	    iStatus = oEvent.getSource().getBindingContext().getObject().Status;
//	    if (this._Component.getModel("intentConfig").getData().intent === "Finding-myFinding") {
//		     var oNavigationConfig = this._Component.getModel("navigationConfig").getData();
//		     sAction = oNavigationConfig[iStatus];
//		     if (sAction === undefined) {
//		      sAction = oNavigationConfig.default;
//		     }
//	    } else if (this._Component.getModel("intentConfig").getData().intent === "Finding-displayFindingByMyAction") {
//		     sAction = "myAction";
//		    } else {
//		     if (iStatus === "") {
		var  sAction = "displayAuditFollowUp";
//		     }
//	    }

	    var oExternalTarget = {
	     target: {
	      semanticObject: "Action",
	      action: sAction
	     },
	     params: {
	      "DBKey": oEvent.getSource().mAggregations.cells[6].mProperties.text
	     }
	    };
	    var sHref = oCrossAppNavigator.hrefForExternal(oExternalTarget);
	    window.open(sHref, "_self");
	   },
	   /* FIN PLANES DE ACCION RELACIONADOS */
	   
	   
	   createHeaderButton: function(sId, oContext) {
	    return MenuItemUtils.createButtonTemplate(sId, oContext, this);
	   },

	   ACTION_CREATE_ROOT: function() {
	    var oAudit = this.getView().getBindingContext().getProperty("to_Audit");
	    var oFindingView = this.getView();
	    if (!this._oCreateActionDialog) {
	     this._oCreateActionDialog = sap.ui.getCore().createComponent({
	      name: "sap.grc.acs.aud.action.creation"
	     });
	    }
	    var sIntent = this.getModel("intentConfig").getData().intent;
	    this._oCreateActionDialog.open(oAudit, oFindingView, sIntent);
	   },

	   ACTION_UPDATE_ROOT: function() {
	    this._setButtonVisibility("EDIT");
	    this.aExistActionSequence = [];
	    this.aOriginalActionSequence = [];
	    this._createActionPlanSequence();
	    var oColumnSeq = this.getView().byId("colSequence");
	    oColumnSeq.setVisible(true);
	    this.aChangedData = [];
	    this.aChangedAction = [];
	    this.editActionFlag = true;
	   },

	   _updateEntity: function(oDataModel, oTable, oColumnSeq, oEntityType, i){
	    var sPath = "/" + oEntityType + "(guid'" + this.aChangedData[i].DBKey + "')";
	    oDataModel.update(sPath, {
	     Sequence: this.aChangedData[i].Sequence
	    }, {
	     success: jQuery.proxy(function() {
	      this._setButtonVisibility("DISPLAY");
	      oTable.setBusy(false);
	      MessageUtil.showMsg("msgTypeSuccessful", this.getModel("i18n").getResourceBundle().getText("EDIT_ACTION_SUCCESS"));
	      this.saveActionFlag = true;
	      this.getView().getModel().refresh(true);
	      oColumnSeq.setVisible(false);
	     }, this),
	     error: jQuery.proxy(function() {
	      this._setButtonVisibility("DISPLAY");
	      oTable.setBusy(false);
	      oColumnSeq.setVisible(false);
	     }, this),
	     groupId: "saveSequence",
	     async: true,
	     merge: true
	    });
	   },
	   onSaveBtnPress: function() {
	    var oTable = this.getView().byId("tableActionPlanRelated");
	    var oEntityType = "GRCAUD_CV_ActionByFinding";
	    if(this._Component.getModel("intentConfig").getData().intent === "Finding-myFinding"){
	     oEntityType = "GRCAUD_CV_ActionByMyFinding";
	    }
	    if (this._validationDuplicateSequenceAndError(oTable)) {
	     var oColumnSeq = this.getView().byId("colSequence");
	     //save sequence
	     var oDataModel = this.getView().getModel();
	     if (this.aChangedData.length > 0) {
	      oTable.setBusy(true);
	      for (var i = 0; i < this.aChangedData.length; i++) {
	       this._updateEntity(oDataModel, oTable, oColumnSeq, oEntityType, i);
	      }
	     } else {
	      this._setButtonVisibility("DISPLAY");
	      oColumnSeq.setVisible(false);
	     }

	    }
	   },

	   onCancelBtnPress: function() {
	    var oTable = this.getView().byId("tableActionPlanRelated");
	    var aCurrentActions = oTable.getItems();
	    // reset table
	    for (var i = 0; i < this.aOriginalActionSequence.length; i++) {
	     aCurrentActions[i].getCells()[2].setValue(this.aOriginalActionSequence[i].sequence);
	     aCurrentActions[i].getCells()[2].setValueState(sap.ui.core.ValueState.None);
	    }
	    MessageUtil.showMsg("msgTypeSuccessful", this.getModel("i18n").getResourceBundle().getText("NOTHING_UPDATED"));
	    var oColumnSeq = this.getView().byId("colSequence");
	    this._setButtonVisibility("DISPLAY");
	    // this.getView().getModel().refresh(true);
	    oColumnSeq.setVisible(false);
	   },
	   /* INI PLANES DE ACCION RELACIONADOS */
	   //FUNCIÓN DE REFRESCO DE DATOS
	   onRefresh: function() {
	    //this._setButtonVisibility("DISPLAY");
	    //in action plan edit mode, but refresh the whole model
	    if (this.editActionFlag && !this.saveActionFlag) {
	     var oTable = this.getView().byId("tableActionPlanRelated");
	     var aCurrentActions = oTable.getItems();
	     for (var i = 0; i < this.aOriginalActionSequence.length; i++) {
	      aCurrentActions[i].getCells()[2].setValue(this.aOriginalActionSequence[i].sequence);
	      aCurrentActions[i].getCells()[2].setValueState(sap.ui.core.ValueState.None);
	     }
	    }
	    this.saveActionFlag = false;
	    this.editActionFlag = false;
	    this.getView().byId("colSequence").setVisible(false);
	   },
	   /* FIN PLANES DE ACCION RELACIONADOS */
	   
	   _setButtonVisibility: function(sMode) { 
	    var oHeaderContents = this.getView().byId("actionRelToolbar").getAggregation("content");
	    var oEditButtonControl = null;
	    var oCancelButtonControl = null;
	    var oSaveButtonControl = null;
	    var oAddButtonControl = null;
	    for (var i = 0; i < oHeaderContents.length; i++) {
	     switch (oHeaderContents[i].getId()) {
	      case "btnSave":
	       oSaveButtonControl = oHeaderContents[i];
	       break;
	      case "btnCancel":
	       oCancelButtonControl = oHeaderContents[i];
	       break;
	      case "ACTION-UPDATE_ROOT":
	       oEditButtonControl = oHeaderContents[i];
	       break;
	      case "ACTION-CREATE_ROOT":
	       oAddButtonControl = oHeaderContents[i];
	       break;
	      default:
	       break;
	     }
	    }
	    if (sMode === "EDIT") {
	     if (oEditButtonControl !== null && oAddButtonControl !== null) {
	      oEditButtonControl.setVisible(false);
	      oAddButtonControl.setVisible(false);
	      oCancelButtonControl.setVisible(true);
	      oSaveButtonControl.setVisible(true);
	     }
	    } else if (sMode === "DISPLAY") {
	     if (oEditButtonControl !== null && oAddButtonControl !== null) {
	      oEditButtonControl.setVisible(true);
	      oAddButtonControl.setVisible(true);
	      oCancelButtonControl.setVisible(false);
	      oSaveButtonControl.setVisible(false);
	     }
	    } else {
	     if (oEditButtonControl !== null && oAddButtonControl !== null) {
	      oEditButtonControl.setVisible(false);
	      oAddButtonControl.setVisible(false);
	      oCancelButtonControl.setVisible(false);
	      oSaveButtonControl.setVisible(false);
	     }
	    }
	    if (this.getView().byId("actionRelToolbar").getContent().length !== 0) {
	     this.getView().byId("actionRelToolbar").setVisible(true);
	    } else {
	     this.getView().byId("actionRelToolbar").setVisible(false);
	    }
	   },

	   _setChange: function(sActionKey, i, aExistActionSequence, aChangedAction){
	    aExistActionSequence[i].sequence = null;
	    var oChangedAction = {
	     "index": i,
	     "actionKey": sActionKey
	    };
	    var found = aChangedAction.some(function(el){
	     return el.actionKey === sActionKey; 
	    });
	    if (!found) {
	     aChangedAction.push(oChangedAction);
	    }
	   },
	   editActionSeq: function(oEvent) {
	    this.changeSequenceFlag = true;
	    var sActionKey = oEvent.getSource().getBindingContext().getObject().DBKey;
	    this.saveConfirmTag = true;
	    var oInput = oEvent.getSource();
	    var oValue = oInput.getValue();
	    oInput.setValueState(sap.ui.core.ValueState.None);
	    var sNumberMatch = /^[0-9]\d*$/;
	    if (!oValue.match(sNumberMatch)) {
	     oInput.setValueState(sap.ui.core.ValueState.Error);
	     oInput.setValueStateText(this.getModel("i18n").getResourceBundle().getText("ERROR_NUMBER_INPUT"));
	     this.saveConfirmTag = false;
	     return;
	    }
	    if (oValue === "00000" || oValue === "0000" || oValue === "000" || oValue === "00" || oValue === "0") {
	     oInput.setValueState(sap.ui.core.ValueState.Error);
	     this.saveConfirmTag = false;
	     oInput.setValueStateText(this.getModel("i18n").getResourceBundle().getText("MSG_SEEQUENCE_ZERO"));
	     return;
	    }
	    if (oInput.getValueState() === sap.ui.core.ValueState.None) {
	     oInput.setValueStateText("");
	    }

	    for (var i = 0; i < this.aExistActionSequence.length; i++) {
	     if (this.aExistActionSequence[i].actionKey === sActionKey) {
	      this._setChange(sActionKey, i, this.aExistActionSequence, this.aChangedAction);
	      break;
	     }
	    }

	    for (var j = 0; j < this.aExistActionSequence.length; j++) {
	     if (this.aExistActionSequence[j].actionKey !== sActionKey) {
	      //Duplicated sequence;
	      if (this.aExistActionSequence[j].sequence !== null && parseInt(this.aExistActionSequence[j].sequence, 10) === parseInt(oValue, 10)) {
	       oInput.setValueState(sap.ui.core.ValueState.Error);
	       oInput.setValueStateText(this.getModel("i18n").getResourceBundle().getText("ERROR_SAME_SEQUENCE"));
	       break;
	      }
	     }
	    }

	    this._resetNoMoreDuplicateInput(this.aChangedAction, sActionKey);

	    //if no error, save the new input sequence
	    var bIsUpdated = false;
	    for (var k = 0; k < this.aChangedData.length; k++) {
	     if (this.aChangedData[k].DBKey === sActionKey) {
	      this.aChangedData[k].Sequence = oValue;
	      bIsUpdated = true;
	      break;
	     }
	    }
	    if (!bIsUpdated) {
	     this.aChangedData.push({
	      "DBKey": sActionKey,
	      "Sequence": oValue
	     });
	    }
	   },

	   //after input change, if other input value is not duplicate any more, reset their input state.
	   _resetNoMoreDuplicateInput: function(aChangedAction, sCurrentActionKey) {
	    for (var i = 0; i < aChangedAction.length; i++) {
	     if (aChangedAction[i].actionKey !== sCurrentActionKey) {
	      var oChangedInput = this.getView().byId("tableActionPlanRelated").getItems()[aChangedAction[i].index].getCells()[2];
	      if (oChangedInput.getValueStateText() === this.getModel("i18n").getResourceBundle().getText("ERROR_SAME_SEQUENCE")) {
	       for (var j = 0; j < this.aExistActionSequence.length; j++) {
	        if (aChangedAction[i].actionKey !== this.aExistActionSequence[j].actionKey) {
	         oChangedInput.setValueState();
	         oChangedInput.setValueStateText("");
	         //still error
	         if (this.aExistActionSequence[j].sequence !== null &&
	          parseInt(this.aExistActionSequence[j].sequence, 10) === parseInt(oChangedInput.getValue(), 10)) {
	          oChangedInput.setValueState(sap.ui.core.ValueState.Error);
	          oChangedInput.setValueStateText(this.getModel("i18n").getResourceBundle().getText("ERROR_SAME_SEQUENCE"));
	          break;
	         }
	        }
	       }
	      }
	     }
	    }
	   },

	   _validationDuplicateSequenceAndError: function(oTable) {
	    var aCurrentActions = oTable.getItems();
	    var aValues = [];
	    for (var i = 0; i < aCurrentActions.length; i++) {
	     var sCurrentValue = aCurrentActions[i].getCells()[2].getValue();
	     if (aCurrentActions[i].getCells()[2].getValueState() === sap.ui.core.ValueState.Error) {
	      MessageUtil.showMsg("msgTypeFailed", this.getModel("i18n").getResourceBundle().getText("INCORRECT_NUMBER_INPUT"));
	      return false;
	     }
	     if (aValues.indexOf(sCurrentValue) === -1) {
	      aValues.push(sCurrentValue);
	     }
	    }
	    if (aCurrentActions.length === aValues.length) {
	     return true;
	    } else {
	     MessageUtil.showMsg("msgTypeFailed", this.getModel("i18n").getResourceBundle().getText("ERROR_SAME_SEQUENCE"));
	     return false;
	    }
	   }
	  });
	 }
	);


//   /**
//    * Called when a controller is instantiated and its View controls (if available) are already created.
//    * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
//    * @memberOf sap.grc.acs.aud.finding.block.view.general
//    */
//   onInit: function() {
//    this._Component = ComponentUtil.getComponentById(this.getView().getId());
//    sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.find.EventBus", "resetBlockToDisplayMode", this.onRefresh, this);
//    
//    /* INI PLANES DE ACCION RELACIONADOS*/
////    if(this.getOwnerComponent().getModel("menu").getData().actionSection.actions)
////	{
////    	this.oMenu = this.getOwnerComponent().getModel("menu").getData().actionSection.actions;
////    	if(this.oMenu[4].Enable === "X")
////    	{
////    		this.getView().byId("btn_addActionRelated").setVisible(true);
////    		this.getView().byId("btn_RemoveActionRelated").setVisible(true);
////    	}
////    	else 
////    	{
////    		this.getView().byId("btn_addActionRelated").setVisible(false);
////    		this.getView().byId("btn_RemoveActionRelated").setVisible(false);
////    	}
////	}
//	
//    this.modelActionRel = this._Component.getModel("MyActionRel");
//    this.getView().byId("tableActionPlanRelated").setModel(this.modelActionRel,"actionRel");
//    this.getDataFromOdata();
//    
//    this.tableContentModel = new sap.ui.model.json.JSONModel();
//    
//    this.sModelData = {
//			FindingsData: [],
//		};
//    this.tableContentModel.setData(this.sModelData);
//    /* FIN PLANES DE ACCION RELACIONADOS*/
//    
//   },
//   
//   toolbarActionRel: function()
//   {
//	   
//   },
//   
//   /* INI PLANES DE ACCION RELACIONADOS*/
////   onAdd_ActionRelated : function(oEvent)
////   {
////	   var oSource = oEvent.getSource();
////	   
////	   var sectionBindingModel = this.getView().getModel("sectionBindingConfig");
////	   this.auditKey = this.getView().getBindingContext().getObject().DBKey;
////	   
////	   
////	   if(this.addActionRelatedSmartTable){
////			this.addActionRelatedSmartTable.destroy();
////		}
////	   
////	   //Cargamos el fragment
////	   this.addActionRelatedSmartTable = sap.ui.xmlfragment("sap.grc.acs.aud.finding.execute.extended.block.fragment.addActionRelated", this);
////	   
////	   var that = this;
////	   
////	 //Realizar llamada al back para obtener el listado de findinds relacionados
////		var actionModel = new sap.ui.model.odata.v2.ODataModel(
////				"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false ////"ZGRCAUD_ENH_SRV"
////			
////		);
////		
////		var oData = {},
////		aBatchOperations = [];
////
////		//var url = "/AuditSet(guid'" + this.auditKey + "')/AuditToFindRel";
////		//Limpiamos los registros seleccionados por si los hubiera de navegaciones anteriores
////		try {
////			that.getView().getContent()[0].getContent()[1].removeSelections();
////		} catch (err) {}
////
//////		//limpiamos la tabla por si hubiera registros de consultas anteriores
////		/*this.sModelData = {
////				FindingsData: [],
////			};
////		
////		this.tableContentModel.setData(this.sModelData);*/
////		
////		/*that.sModelData.FindingsData = [];
////		that.tableContentModel.refresh();*/
////		//actionModel.read("/GRCAUD_CV_Action", {
////		var aFilters = [];
////		aFilters.push(new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.GE, "2017"));
////	   actionModel.read("/ZGRCAUD_CV_ACTRELTOFIND", {
////		    filters: aFilters,
////			success: function (data, response) {
////
////				if (data && data.results && data.results.length > 0) {
////					
////					//Reordeno las fechas para que se vea la más reciente primero
////					/*data.results.sort(function(a, b){
////						if (a.ID < b.ID) {
////						    return 1;
////						  }
////						  if (a.ID > b.ID) {
////						    return -1;
////						  }
////						  return 0;
////					})*/
////					
////					
////					that.sModelData.FindingsData = data.results;
////					that.tableContentModel.refresh();																											
////				} else {
////					console.log({ err: "No results" });
////				}
////				that.oValueHelpDialog.setBusy(false);
////			},
////			failed: function (oData, response) {
////				that.oValueHelpDialog.setBusy(false);
////				alert("Failed to get InputHelpValues from service!");
////			},
////		});
////	   
////	   
////	   this.addActionRelatedSmartTable.setModel(this.tableContentModel);
////		var i18nModel = this.getView().getModel( "i18n");
////		this.addActionRelatedSmartTable.setModel(i18nModel, "i18n");
////		var oController = this;
////	   
////	   this.oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
////			title: this.getView().getModel("i18n").getResourceBundle().getText("labelActionPlanRel"),
////			supportMultiselect: true,
////			supportRanges: false,
////			supportRangesOnly: false,
////			key: "Id",
////			descriptionKey: "Title",
////			stretch: sap.ui.Device.system.phone,
////			contentHeight:"100%",
////			
////			ok: function(oOkEvent) {
////				var aSelectedTokens = oOkEvent.getParameter("tokens");
////				oController.assignActionRelToAudit(aSelectedTokens);
////				// this.close();
////			},
////
////			cancel: function() {
////				this.close();
////			},
////
////			afterClose: function() {
////				this.destroy();
////			}
////		});
////	   
////	   var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
////			advancedMode: true,
////			filterBarExpanded: false,
////			showGoOnFB: !sap.ui.Device.system.phone,
////			search: function() {
////				oController.searchToBeAssignedTable();
////			}
////		});
////	   
////	   if (oFilterBar.setBasicSearch) {
////			this.oBasicSearch = new sap.m.SearchField({
////				id: "basicSearch",
////				showSearchButton: sap.ui.Device.system.phone,
////				placeholder: this.getView().getModel("i18n").getResourceBundle().getText("labelSearchFindingPlaceHolder"),
////				search: function() {
////					oController.oValueHelpDialog.getFilterBar().search();
////				}
////			});
////			oFilterBar.setBasicSearch(this.oBasicSearch);
////		}
////	   
////	   //Abertura del dialogo
////	   	this.oValueHelpDialog.setFilterBar(oFilterBar);
////		this.oValueHelpDialog.setTable(this.addActionRelatedSmartTable);
////		this.oValueHelpDialog.setModel(this.tableContentModel);
////		oSource.addDependent(this.oValueHelpDialog);
////		this.oValueHelpDialog.open();
////		this.oValueHelpDialog.setBusy(true);
////	   
////   },
////   
////	onDel_ActionRel: function (oEvent) {
////		var aSelectedItems = this.getView().byId("tableActionPlanRelated").getSelectedItems();
////		if(aSelectedItems.length === 0){
////			MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("MSG_SELECT_ONE"));
////			return;
////		}
////		//Key de la Observación con mayúsculas y sin guiones
////		var keyObservacion = oEvent.getSource().getBindingContext().getObject().DBKey.replaceAll("-", "").toUpperCase();
////		var oController = this;
////		this.auditKey = this.getView().getBindingContext().getObject().DBKey;
////		this.getView().byId("tableActionPlanRelated").setBusy(true)
////		aSelectedItems.forEach(selectedItem => {
////			oController._deleteActionRel(selectedItem, keyObservacion);
////		});																					
////	},
////   
////	_deleteActionRel: function(selectedItem, keyObservacion){										
////		var itemData = selectedItem.getBindingContext("actionRel").getObject();
////		
////		//Key de linea seleccionada en la tabla
////		var refKey = itemData.ref_key.replaceAll("-", "").toUpperCase();
////		//var keyComparacion = itemData.DBKey.toUpperCase();
////		var keyComparacion = "ActRelSet(guid'" + itemData.DBKey.toUpperCase() + "')";
////		var KeyPrueba = ""
////		
////		var that = this;
////		var oDataModel = new sap.ui.model.odata.v2.ODataModel(
////				"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",
////				false
////		);
////		
////		//LLamada para traer la información de la entidad Assignment
////		oDataModel.read("/FindActRelSet(Key=binary'" + keyObservacion + "')/AssignmentSet", {
////			success: function (data, response) {
////				var element = data.results.filter(function (item) {
////					return item.ServiceURL == keyComparacion;
////					//return item.ReferenceKey == itemData.Key;
////				});
////				
////				if (element.length > 0) {
////					var sPath = element[0].__metadata.uri;
////					var result = that._deleteAssignmentActionRel(
////						sPath,
////						element[0],
////						selectedItem,
////						itemData
////					);
////				}
////				
////				
////			},
////			failed: function (oData, response) {
////				that.getView().byId("tableActionPlanRelated").setBusy(false)
////			},
////			
////		});
//		
//		
//		
//		
//		/*oDataModel.remove("/AssignmentSet(Key=g'" + refKey + "')",
//		{
//			method: "DELETE",
//			success: function(data)
//			{
//				var data = data;
//				alert("funciona");
//			},
//			error: function(e)
//			{
//				alert("error");
//			}
//		
//		});*/
//		
//		
////	},
//	
////	_deleteAssignmentActionRel: function (sPath, data, selectedItem, itemData) {
////		var that = this;
////		var aBatchOperations = [];
////		var oDataModel = new sap.ui.model.odata.ODataModel(
////			"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",
////			false
////		);
////
////		aBatchOperations.push(
////			oDataModel.createBatchOperation(data.__metadata.uri, "DELETE")
////		);
////		oDataModel.addBatchChangeOperations(aBatchOperations);
////		//oDataModel.refreshSecurityToken();
////		oDataModel.submitBatch(function (oData, oResponse, aErrorResponse) {
////			if (aErrorResponse.length > 0) { // failed
////				that.getView().byId("tableActionPlanRelated").setBusy(false);												
////			} else { // Borrado OK
////				that.getDataFromOdata();
////				that.getView().byId("tableActionPlanRelated").setBusy(false);
////			}
////		});
////	},
//	
//
//
//	
////   searchToBeAssignedTable: function() {
////		var oController = this;
////		var oTableSearchState = [];
////		var oTableSearchStateFilter = [];
////		var oBindingInfo = {};
////		var sSearchString = oController.oBasicSearch.getValue();
////		oTableSearchState = [
////			new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.Contains, sSearchString),
////			new sap.ui.model.Filter("Title", sap.ui.model.FilterOperator.Contains, sSearchString),
////			new sap.ui.model.Filter("TypeDescr", sap.ui.model.FilterOperator.Contains, sSearchString),
////			new sap.ui.model.Filter("CategoryDescr", sap.ui.model.FilterOperator.Contains, sSearchString)
////		];
////		oTableSearchStateFilter = new sap.ui.model.Filter(oTableSearchState, false);
////		oBindingInfo = oController.addActionRelatedSmartTable.getTable().getBindingInfo("items");
////		oBindingInfo.filters = oTableSearchStateFilter;
////		oController.addActionRelatedSmartTable.getTable().bindAggregation("items", oBindingInfo);					
////	},
////	
////	//Función del OK para el Fragment de Planes de Acción Relacionados
////	assignActionRelToAudit : function(aSelectedTokens){
////		var oController = this;
////		var selectedItems = [];
////		if(aSelectedTokens.length === 0){
////			b.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("MSG_NO_FINDING_SELECTED"));
////			return;
////		}
////		for(var i = 0; i < aSelectedTokens.length; i++) {
////			var oObject = aSelectedTokens[i].data("row");
////			selectedItems.push(oObject);
////		}
////		if (!oController.oDataModel) {
////			oController.oDataModel = new sap.ui.model.odata.ODataModel(
////					"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",
////				false
////			);
////		}
////		var aBatchOperations = oController._generateBatchOperations(
////				selectedItems,
////				oController.oDataModel
////		);
////		oController.oDataModel.addBatchChangeOperations(aBatchOperations);
////		oController.oDataModel.submitBatch(
////				jQuery.proxy(function (oData, oResponse, aErrorResponses) {
////					if (aErrorResponses.length <= 0) {
////						oController.getDataFromOdata()
////					} else {
////						
////					}
////				}, this),
////				jQuery.proxy(function (oError) {
////					/*oController.getView().getContent()[0].getContent()[1].setBusy(false);
////					sap.hpa.grcaud.Utility.showODataErrorMsg(
////						oError,
////						sap.hpa.grcaud.enh_oBundle.getText("MSG_ADD_FINDING_FAIL")
////					);*/
////				}, this),
////				true
////			);
////		this.oValueHelpDialog.close();
////	},
//	
//	//Para guardar el plan de acción relacionado
//	_generateBatchOperations: function (aNewEntryKey, oDataModel) {
//		var aBatchOperations = [];
//		var auditKey = this.auditKey.replaceAll("-", "").toUpperCase();
//		var that = this;
//		for (var i = 0; i < aNewEntryKey.length; i++) {
//			var oSelectedData = aNewEntryKey[i];
//			aBatchOperations.push(
//				//oDataModel.createBatchOperation("/AuditFindRelSet(Key=binary'"+auditKey+"')/AuditToFindRelAssignment", "POST", {
//				oDataModel.createBatchOperation(
//					"/FindActRelSet(Key=binary'" + auditKey + "')/AssignmentSet",
//					"POST",
//					{
//						ReferenceKey: recoverKey(oSelectedData.DBKey),
//						Type: "ACTREL",
//						//HostKey: recoverKey(sAuditKey),
//					}
//				)
//			);
//		}
//
//		return aBatchOperations;
//	},
//	
//	//Llamada de cargar y refresco para Planes de Accion Relacionados
//	getDataFromOdata:function(){
//		var that = this;
//		
//		var oData = {},
//			aBatchOperations = [];										
//		debugger
//		var sFindingKey = sap.ui.getCore().getModel("findingKeyModel").getData().id
//		//var sAuditKey = "2c8c9834-3715-4b29-b865-ab9fe729a337";
//		var url = "/ZGRCAUD_CV_ACTIONRELBYFINDING(p_find=guid'" + sFindingKey + "')/Set";
//		
//		//Realizar llamada al back para obtener el listado de findinds relacionados
//		var actionRelModel = new sap.ui.model.odata.v2.ODataModel(
//				"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
//			);
//		
//		actionRelModel.read(url, {
//			success: function (data, response) {
//				
//				if(that.getView().byId("tableActionPlanRelated")){
//				that.getView().byId("tableActionPlanRelated").removeSelections()	
//			}
//			
//					if(that.modelActionRel) {
//						that.modelActionRel.setData(data.results);
//						that.getView().byId("tableActionPlanRelated").setModel(that.modelActionRel,"actionRel");
//						that.modelActionRel.refresh();
//					}
//					that.editData = [];
//					var modelTitleActionRel = {};
//					that.editData = [];														      			      		
//	      			modelTitleActionRel.title = that.getOwnerComponent().getModel("i18nm").getResourceBundle().getText("ActionRelSectionTitle");
//	      			modelTitleActionRel.count = data.results.length;
//	      			modelTitleActionRel.title = modelTitleActionRel.title +'('+modelTitleActionRel.count+')';
//  					that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(modelTitleActionRel), "ActionRelTitle");
//	      			that.getOwnerComponent().getModel("ActionRelTitle").refresh();
//					
//			},
//			failed: function (oData, response) {
//				alert("Failed to get InputHelpValues from service!");
//			},
//		});
//	},
//	
//   /* FIN PLANES DE ACCION RELACIONADOS*/
//
//   /**
//    * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
//    * (NOT before the first rendering! onInit() is used for that one!).
//    * @memberOf sap.grc.acs.aud.finding.block.view.general
//    */
//   // onBeforeRendering: function() {
//   //
//   // },
//
//   /**
//    * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
//    * This hook is the same one that SAPUI5 controls get after being rendered.
//    * @memberOf sap.grc.acs.aud.finding.block.view.general
//    */
//   // onAfterRendering: function() {
//   //
//   // },
//
//   /**
//    * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
//    * @memberOf sap.grc.acs.aud.finding.block.view.general
//    */
//   onExit: function() {
//    sap.ui.getCore().getEventBus().unsubscribe("sap.grc.acs.aud.find.EventBus", "resetBlockToDisplayMode", this.onRefresh, this);
//   },
//
//   onUpdateFinished: function() {
//    if (this.changeSequenceFlag) {
//     this.changeSequenceFlag = false;
//     return;
//    } else {
//     this.changeSequenceFlag = false;
//     this.onRefresh();
//    }
//   },
//
//   _createActionPlanSequence: function() {
//    var aActions = this.getView().byId("tableActionPlanRelated").getItems();
//    for (var i = 0; i < aActions.length; i++) {
//     var sKey = aActions[i].getBindingContext().getObject().DBKey;
//     var sSeq = aActions[i].getBindingContext().getObject().Sequence;
//     var sStatus = aActions[i].getBindingContext().getObject().Status;
//     if (sStatus === "") {
//      aActions[i].getCells()[2].setEditable(true);
//     } else {
//      aActions[i].getCells()[2].setEditable(false);
//     }
//     this.aExistActionSequence.push({
//      "actionKey": sKey,
//      "sequence": sSeq
//     });
//     this.aOriginalActionSequence.push({
//      "actionKey": sKey,
//      "sequence": sSeq
//     });
//    }
//   },
//
//   //navigate to the action rel app
//   onPressRow: function(oEvent) {   
//	   
//	var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); 
//    var iStatus = "";
//    var sAction = "displayAuditFollowUp";
//    iStatus = oEvent.getSource().getBindingContext().getObject().Status;
//    if (this._Component.getModel("intentConfig").getData().intent === "Finding-myFinding") {
//	     var oNavigationConfig = this._Component.getModel("navigationConfig").getData();
//	     sAction = oNavigationConfig[iStatus];
//	     if (sAction === undefined) {
//	      sAction = oNavigationConfig.default;
//	     }
//    } else if (this._Component.getModel("intentConfig").getData().intent === "Finding-displayFindingByMyAction") {
//	     sAction = "myAction";
//	    } else {
//	     if (iStatus === "") {
//	      sAction = "display";
//	     }
//    }
//
//    var oExternalTarget = {
//     target: {
//      semanticObject: "Action",
//      action: sAction
//     },
//     params: {
//      "DBKey": oEvent.getSource().mAggregations.cells[6].mProperties.text
//     }
//    };
//    var sHref = oCrossAppNavigator.hrefForExternal(oExternalTarget);
//    window.open(sHref, "_self");
//   },
//
//   createHeaderButton: function(sId, oContext) {
//    return MenuItemUtils.createButtonTemplate(sId, oContext, this);
//   },
//
//   ACTION_CREATE_ROOT: function() {
//    var oAudit = this.getView().getBindingContext().getProperty("to_Audit");
//    var oFindingView = this.getView();
//    if (!this._oCreateActionDialog) {
//     this._oCreateActionDialog = sap.ui.getCore().createComponent({
//      name: "sap.grc.acs.aud.action.creation"
//     });
//    }
//    var sIntent = this.getModel("intentConfig").getData().intent;
//    this._oCreateActionDialog.open(oAudit, oFindingView, sIntent);
//   },
//
//   ACTION_UPDATE_ROOT: function() {
//    this._setButtonVisibility("EDIT");
//    this.aExistActionSequence = [];
//    this.aOriginalActionSequence = [];
//    this._createActionPlanSequence();
//    var oColumnSeq = this.getView().byId("colSequence");
//    oColumnSeq.setVisible(true);
//    this.aChangedData = [];
//    this.aChangedAction = [];
//    this.editActionFlag = true;
//   },
//
//   _updateEntity: function(oDataModel, oTable, oColumnSeq, oEntityType, i){
//    var sPath = "/" + oEntityType + "(guid'" + this.aChangedData[i].DBKey + "')";
//    oDataModel.update(sPath, {
//     Sequence: this.aChangedData[i].Sequence
//    }, {
//     success: jQuery.proxy(function() {
//      this._setButtonVisibility("DISPLAY");
//      oTable.setBusy(false);
//      MessageUtil.showMsg("msgTypeSuccessful", this.getModel("i18n").getResourceBundle().getText("EDIT_ACTION_SUCCESS"));
//      this.saveActionFlag = true;
//      this.getView().getModel().refresh(true);
//      oColumnSeq.setVisible(false);
//     }, this),
//     error: jQuery.proxy(function() {
//      this._setButtonVisibility("DISPLAY");
//      oTable.setBusy(false);
//      oColumnSeq.setVisible(false);
//     }, this),
//     groupId: "saveSequence",
//     async: true,
//     merge: true
//    });
//   },
//   onSaveBtnPress: function() {
//    var oTable = this.getView().byId("tableActionPlanRelated");
//    var oEntityType = "GRCAUD_CV_ActionByFinding";
//    if(this._Component.getModel("intentConfig").getData().intent === "Finding-myFinding"){
//     oEntityType = "GRCAUD_CV_ActionByMyFinding";
//    }
//    if (this._validationDuplicateSequenceAndError(oTable)) {
//     var oColumnSeq = this.getView().byId("colSequence");
//     //save sequence
//     var oDataModel = this.getView().getModel();
//     if (this.aChangedData.length > 0) {
//      oTable.setBusy(true);
//      for (var i = 0; i < this.aChangedData.length; i++) {
//       this._updateEntity(oDataModel, oTable, oColumnSeq, oEntityType, i);
//      }
//     } else {
//      this._setButtonVisibility("DISPLAY");
//      oColumnSeq.setVisible(false);
//     }
//
//    }
//   },
//
//   onCancelBtnPress: function() {
//    var oTable = this.getView().byId("tableActionPlanRelated");
//    var aCurrentActions = oTable.getItems();
//    // reset table
//    for (var i = 0; i < this.aOriginalActionSequence.length; i++) {
//     aCurrentActions[i].getCells()[2].setValue(this.aOriginalActionSequence[i].sequence);
//     aCurrentActions[i].getCells()[2].setValueState(sap.ui.core.ValueState.None);
//    }
//    MessageUtil.showMsg("msgTypeSuccessful", this.getModel("i18n").getResourceBundle().getText("NOTHING_UPDATED"));
//    var oColumnSeq = this.getView().byId("colSequence");
//    this._setButtonVisibility("DISPLAY");
//    // this.getView().getModel().refresh(true);
//    oColumnSeq.setVisible(false);
//   },
//
//   onRefresh: function() {
//    this._setButtonVisibility("DISPLAY");
//    //in action plan edit mode, but refresh the whole model
//    if (this.editActionFlag && !this.saveActionFlag) {
//     var oTable = this.getView().byId("tableActionPlanRelated");
//     var aCurrentActions = oTable.getItems();
//     for (var i = 0; i < this.aOriginalActionSequence.length; i++) {
//      aCurrentActions[i].getCells()[2].setValue(this.aOriginalActionSequence[i].sequence);
//      aCurrentActions[i].getCells()[2].setValueState(sap.ui.core.ValueState.None);
//     }
//    }
//    this.saveActionFlag = false;
//    this.editActionFlag = false;
//    this.getView().byId("colSequence").setVisible(false);
//   },
//
//   _setButtonVisibility: function(sMode) { 
//	var headersActions = this.oMenu;
//    var oHeaderContents = headersActions;
//    var oHeaderContents = this.getView().byId("actionRelToolbar").getAggregation("content");
//    var oEditButtonControl = null;
//    var oCancelButtonControl = null;
//    var oSaveButtonControl = null;
//    var oAddButtonControl = null;
//    for (var i = 0; i < oHeaderContents.length; i++) {
//     switch (oHeaderContents[i].getId()) {
//      case "btnSave":
//       oSaveButtonControl = oHeaderContents[i];
//       break;
//      case "btnCancel":
//       oCancelButtonControl = oHeaderContents[i];
//       break;
//      case "ACTION-UPDATE_ROOT":
//       oEditButtonControl = oHeaderContents[i];
//       break;
//      case "ACTION-CREATE_ROOT":
//       oAddButtonControl = oHeaderContents[i];
//       break;
//      default:
//       break;
//     }
//    }
//    if (sMode === "EDIT") {
//     if (oEditButtonControl !== null && oAddButtonControl !== null) {
//      oEditButtonControl.setVisible(false);
//      oAddButtonControl.setVisible(false);
//      oCancelButtonControl.setVisible(true);
//      oSaveButtonControl.setVisible(true);
//     }
//    } else if (sMode === "DISPLAY") {
//     if (oEditButtonControl !== null && oAddButtonControl !== null) {
//      oEditButtonControl.setVisible(true);
//      oAddButtonControl.setVisible(true);
//      oCancelButtonControl.setVisible(false);
//      oSaveButtonControl.setVisible(false);
//     }
//    } else {
//     if (oEditButtonControl !== null && oAddButtonControl !== null) {
//      oEditButtonControl.setVisible(false);
//      oAddButtonControl.setVisible(false);
//      oCancelButtonControl.setVisible(false);
//      oSaveButtonControl.setVisible(false);
//     }
//    }
//    if (this.getView().byId("actionRelToolbar").getContent().length !== 0) {
//     this.getView().byId("actionRelToolbar").setVisible(true);
//    } else {
//     this.getView().byId("actionRelToolbar").setVisible(false);
//    }
//   },
//
//   _setChange: function(sActionKey, i, aExistActionSequence, aChangedAction){
//    aExistActionSequence[i].sequence = null;
//    var oChangedAction = {
//     "index": i,
//     "actionKey": sActionKey
//    };
//    var found = aChangedAction.some(function(el){
//     return el.actionKey === sActionKey; 
//    });
//    if (!found) {
//     aChangedAction.push(oChangedAction);
//    }
//   },
//   editActionSeq: function(oEvent) {
//    this.changeSequenceFlag = true;
//    var sActionKey = oEvent.getSource().getBindingContext().getObject().DBKey;
//    this.saveConfirmTag = true;
//    var oInput = oEvent.getSource();
//    var oValue = oInput.getValue();
//    oInput.setValueState(sap.ui.core.ValueState.None);
//    var sNumberMatch = /^[0-9]\d*$/;
//    if (!oValue.match(sNumberMatch)) {
//     oInput.setValueState(sap.ui.core.ValueState.Error);
//     oInput.setValueStateText(this.getModel("i18n").getResourceBundle().getText("ERROR_NUMBER_INPUT"));
//     this.saveConfirmTag = false;
//     return;
//    }
//    if (oValue === "00000" || oValue === "0000" || oValue === "000" || oValue === "00" || oValue === "0") {
//     oInput.setValueState(sap.ui.core.ValueState.Error);
//     this.saveConfirmTag = false;
//     oInput.setValueStateText(this.getModel("i18n").getResourceBundle().getText("MSG_SEEQUENCE_ZERO"));
//     return;
//    }
//    if (oInput.getValueState() === sap.ui.core.ValueState.None) {
//     oInput.setValueStateText("");
//    }
//
//    for (var i = 0; i < this.aExistActionSequence.length; i++) {
//     if (this.aExistActionSequence[i].actionKey === sActionKey) {
//      this._setChange(sActionKey, i, this.aExistActionSequence, this.aChangedAction);
//      break;
//     }
//    }
//
//    for (var j = 0; j < this.aExistActionSequence.length; j++) {
//     if (this.aExistActionSequence[j].actionKey !== sActionKey) {
//      //Duplicated sequence;
//      if (this.aExistActionSequence[j].sequence !== null && parseInt(this.aExistActionSequence[j].sequence, 10) === parseInt(oValue, 10)) {
//       oInput.setValueState(sap.ui.core.ValueState.Error);
//       oInput.setValueStateText(this.getModel("i18n").getResourceBundle().getText("ERROR_SAME_SEQUENCE"));
//       break;
//      }
//     }
//    }
//
//    this._resetNoMoreDuplicateInput(this.aChangedAction, sActionKey);
//
//    //if no error, save the new input sequence
//    var bIsUpdated = false;
//    for (var k = 0; k < this.aChangedData.length; k++) {
//     if (this.aChangedData[k].DBKey === sActionKey) {
//      this.aChangedData[k].Sequence = oValue;
//      bIsUpdated = true;
//      break;
//     }
//    }
//    if (!bIsUpdated) {
//     this.aChangedData.push({
//      "DBKey": sActionKey,
//      "Sequence": oValue
//     });
//    }
//   },
//
//   //after input change, if other input value is not duplicate any more, reset their input state.
//   _resetNoMoreDuplicateInput: function(aChangedAction, sCurrentActionKey) {
//    for (var i = 0; i < aChangedAction.length; i++) {
//     if (aChangedAction[i].actionKey !== sCurrentActionKey) {
//      var oChangedInput = this.getView().byId("tableActionPlanRelated").getItems()[aChangedAction[i].index].getCells()[2];
//      if (oChangedInput.getValueStateText() === this.getModel("i18n").getResourceBundle().getText("ERROR_SAME_SEQUENCE")) {
//       for (var j = 0; j < this.aExistActionSequence.length; j++) {
//        if (aChangedAction[i].actionKey !== this.aExistActionSequence[j].actionKey) {
//         oChangedInput.setValueState();
//         oChangedInput.setValueStateText("");
//         //still error
//         if (this.aExistActionSequence[j].sequence !== null &&
//          parseInt(this.aExistActionSequence[j].sequence, 10) === parseInt(oChangedInput.getValue(), 10)) {
//          oChangedInput.setValueState(sap.ui.core.ValueState.Error);
//          oChangedInput.setValueStateText(this.getModel("i18n").getResourceBundle().getText("ERROR_SAME_SEQUENCE"));
//          break;
//         }
//        }
//       }
//      }
//     }
//    }
//   },
//
//   _validationDuplicateSequenceAndError: function(oTable) {
//    var aCurrentActions = oTable.getItems();
//    var aValues = [];
//    for (var i = 0; i < aCurrentActions.length; i++) {
//     var sCurrentValue = aCurrentActions[i].getCells()[2].getValue();
//     if (aCurrentActions[i].getCells()[2].getValueState() === sap.ui.core.ValueState.Error) {
//      MessageUtil.showMsg("msgTypeFailed", this.getModel("i18n").getResourceBundle().getText("INCORRECT_NUMBER_INPUT"));
//      return false;
//     }
//     if (aValues.indexOf(sCurrentValue) === -1) {
//      aValues.push(sCurrentValue);
//     }
//    }
//    if (aCurrentActions.length === aValues.length) {
//     return true;
//    } else {
//     MessageUtil.showMsg("msgTypeFailed", this.getModel("i18n").getResourceBundle().getText("ERROR_SAME_SEQUENCE"));
//     return false;
//    }
//   }
//  });
// }
//);
