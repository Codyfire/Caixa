sap.ui.define(["sap/ui/core/mvc/Controller",
	"sap/grc/acs/lib/aud/extension/utils/FieldExtensibilityUtil",
	"sap/grc/acs/aud/finding/model/formatter",
	"sap/grc/acs/lib/aud/utils/ComponentUtil",
	"sap/ui/model/json/JSONModel",
	"sap/grc/acs/lib/aud/utils/MessageUtil"
],

function (Controller, FieldExtensibilityUtil, formatter, ComponentUtil, JSONModel, MessageUtil) {
    "use strict";

    return Controller.extend("sap.grc.acs.aud.finding.display.extended.block.generalCustom", {

formatter: formatter,
oMode: {
	Display: "DISPLAY",
	Edit: "EDIT",
	DisableEdit: "DISABLE_EDIT"
},
/**
 * Called when a controller is instantiated and its View controls (if available) are already created.
 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
 * @memberOf sap.grc.acs.aud.finding.block.view.general
 */
onInit: function () {
	this.oFindingDataInServer = {};
	this._findInfo = {};
	this.oViewModel = new JSONModel({
		bEditFlag: false
	});
	this.getView().setModel(this.oViewModel, "generalView");
	this._oComponent = ComponentUtil.getComponentById(this.getView().getId());
	this._oComponent.getModel().metadataLoaded().then(function () {
		this._createExtensionGroup();
	}.bind(this));
	if (this._oComponent.getModel("intentConfig").getData().intent === "Finding-myFinding" || this._oComponent.getModel("intentConfig")
		.getData().intent === "Finding-displayFindingByMyAction") { 
		this._bDisplayMode = true; 
		this.getView().byId("auditId").attachInnerControlsCreated(this.setAuditTitleValue, this);
		//	this.getView().byId("findOrg").attachInnerControlsCreated(this.setFindOrgValue, this);
	} else {
		this.getView().byId("auditId").attachPress(this.onAuditPress, this);
		this.getView().byId("findOrg").attachPress(this.onFindingOrgPress, this);
	}
	this.aDropDownGroupIndex = [];
	this.aDropDownEdit = [];
	this.bTimestampTransformFlag = false;
	sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.find.EventBus", "resetBlockToDisplayMode", this.onRefresh, this);
	sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.find.EventBus", "extensionModelDataUpdateFinished", this.setHeaderToolBarVisibility,
		this);
    sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.find.EventBus", "formatExtensionFields", this.onFormatExtensionFields, this);
    
},

onFormatExtensionFields:function(){
	   var oExtensionGroup = this.getView().byId("extensionGroup");
	   var oSmartForm = this.getView().byId("smartForm");
	   console.log('Estoy en general Custom');
},

_createExtensionGroup: function () {
	var oExtensionGroup = this.getView().byId("extensionGroup");
	FieldExtensibilityUtil.createExtensionGroup("Finding", oExtensionGroup, this._oComponent);
},
setAuditTitleValue: function () {
	var oAuditField = this.getView().byId("auditId");
	if (oAuditField.getInnerControls() && oAuditField.getInnerControls()[0]) {
		if (typeof(oAuditField.getInnerControls()[0].setText) === "function") {
			oAuditField.getInnerControls()[0].setText(oAuditField.getValue());
		} else {
			oAuditField.getInnerControls()[0].setValue(oAuditField.getValue());
		}
	}
},
setFindOrgValue: function () {
	var oFindOrgField = this.getView().byId("findOrg");
	oFindOrgField.setValue(this.getView().getBindingContext().getObject().FindingOrganizationName);
},
setValueHelpFieldsEditable: function () {
	var oExtensionGroup = this.getView().byId("extensionGroup");
	var oExtensionModelData = this.getView().getModel("extensionModel").getData();
	this.aDropDownGroupIndex = [];
	FieldExtensibilityUtil.setValueHelpFieldsEditable(oExtensionGroup, oExtensionModelData, this.aDropDownGroupIndex, this.aDropDownEdit);
},
setDropDownFieldsEditableToFalse: function () {
	for (var i = 0; i < this.aDropDownGroupIndex.length; i++) {
		this.getView().byId("extensionGroup").removeGroupElement(this.getView().byId("extensionGroup").getGroupElements()[this.aDropDownGroupIndex[
			i].index]);
		this.getView().byId("extensionGroup").insertGroupElement(this.aDropDownGroupIndex[i].element, this.aDropDownGroupIndex[i].index);
	}

},
_checkRequiredCdfNonSmartField: function(){
	var bIsFieldRequired = false;
	var oExtensionGroup = this.getView().byId("extensionGroup");
	var oGroupElements = oExtensionGroup.getGroupElements();
	for(var k = 0;k<oGroupElements.length;k++){
		for(var j=0; j<oGroupElements[k].getFields().length;j++){
			for (var i = 0; i < oGroupElements[k].getFields()[j].getCustomData().length; i++) {
				if ( oGroupElements[k].getFields()[j].getCustomData()[i].getKey() === "richText"){
					if(oGroupElements[k].getFields()[j].getRequired()
					&& oGroupElements[k].getFields()[j].getEditable()){
					if(  oGroupElements[k].getFields()[j].getValue() === "") {
						bIsFieldRequired = true;
					}
					}
				}
			}
		}
	}
	// if(bIsFieldRequired){
	// 	oRichTextAreaControl.setValueState(sap.ui.core.ValueState.Error);
	// }
	// else{
	// 	oRichTextAreaControl.setValueState(sap.ui.core.ValueState.None);
	// }
	return bIsFieldRequired;
},
_saveData: function () {
	var oSmartForm = this.getView().byId("smartForm");
	var bIsRequiredCdfNonSmartField =  this._checkRequiredCdfNonSmartField();
	var bIsErrorExecutiveResponsible = this._checkErrorChangedExecutiveResponsible();
	if (oSmartForm.check().length > 0 || bIsRequiredCdfNonSmartField || bIsErrorExecutiveResponsible) {
		//Show Error
		MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("msgErrorInput"));
		return;
	}
	//get the selected executive responsible
	this._getChangedExecutiveResponsible(false, false);
	
	var oUpdateDataModel = this.getView().getModel();

	oUpdateDataModel.setUseBatch(true);
	oUpdateDataModel.setDeferredGroups(["updateFinding"]);

	var oChange = {};
	oChange.bExistChange = false;
	var oData = {};
	//collect general data
	var oExtensionModelData = this.getView().getModel("extensionModel").getData();
	oData = FieldExtensibilityUtil.saveSmartForm(oSmartForm, oExtensionModelData);
	
	this.getView().setBusy(true);
	//collect executive responisible
	this._changeExecutiveResponsible(oUpdateDataModel,oChange);
	
	//collect general data
	var bTagEditable = oExtensionModelData.Tag.editable;
	this._updateAllFieldsIncludingTagsAndCDF(oUpdateDataModel, oData, bTagEditable,oChange);
	if (oExtensionModelData.Reference.editable === true){
		//collect reference
		this._updateReference(oUpdateDataModel,oChange);
	}
	if(oExtensionModelData.FindOrg.editable === true){
		//collect organization
		this._updateOrganization(oUpdateDataModel,oChange);
	}
	
	if (oChange.bExistChange === true) {
		oChange.bExistChange = false;
		oUpdateDataModel.setRefreshAfterChange(false); 
		oUpdateDataModel.submitChanges({
			groupId: "updateFinding",
			success: jQuery.proxy(function (oResponseData) {
					if (oResponseData.__batchResponses[0].message) {
						if(oResponseData.__batchResponses[0].response.statusCode === "412"){
							MessageUtil.showODataErrorMsg(oResponseData.__batchResponses[0].response,
								this.getView().getModel("i18n").getResourceBundle().getText("msgEtagCheckFail"));
							
						}
						this.getView().setBusy(false);
						return;
					}else{
						oUpdateDataModel.setDeferredGroups(oUpdateDataModel.getDeferredGroups().concat(["changes"]));
						MessageUtil.showMsg("msgTypeSuccessful", this.getView().getModel("i18n").getResourceBundle().getText(
							"MSG_UPDATE_FINDING_SUCCESS"));
						this.getView().setBusy(false);
						this.getView().getModel().refresh(true, true);
						this.onCancelBtnPress();
					}
			}, this),
			error: jQuery.proxy(function (oError) {
				oUpdateDataModel.setDeferredGroups(oUpdateDataModel.getDeferredGroups().concat(["changes"]));
				this.getView().setBusy(false);
				MessageUtil.showMsg(oError, this.getView().getModel("i18n").getResourceBundle().getText("MSG_UPDATE_FINDING_FAIL"));
			}, this)
		});
	} else {
		//Nothing changed
		this.onCancelBtnPress();
		this.getView().setBusy(false);
		MessageUtil.showMsg("msgTypeSuccessful", this.getView().getModel("i18n").getResourceBundle().getText(
			"MSG_UPDATE_FINDING_SUCCESS"));
	}
},
_updateAllFieldsIncludingTagsAndCDF: function(oUpdateDataModel, oData, bTagEditable,oChange){
	var sPath = this.getView().getBindingContext().sPath;
	var oGeneralData = this._compareData(this.oFindingDataInServer, oData);
	if(bTagEditable === true){
		//collect tags and include the tags into general info request(oGeneralData)
		var Tags = [];
		var aTokens = this.getView().byId("multiinput").getTokens();
		for (var i = 0; i < aTokens.length; i++) {
			Tags.push(aTokens[i].getText());
		}
		if(Tags.length !== 0){
			oGeneralData.Tags = Tags.join(";");
		}else{
			oGeneralData.Tags = "";
		}
	}

	 if (!jQuery.isEmptyObject(oGeneralData)) {
		oUpdateDataModel.update(
				sPath, 
				oGeneralData, {
				groupId: "updateFinding",
				refreshAfterChange: false
			});
		oChange.bExistChange = true;
	 }
	
},
_updateReference: function(oUpdateDataModel,oChange){
	var sReferCurrentValue = this.getView().byId("reference").getValue();
	if(sReferCurrentValue === ""){
		if((this._findInfo.Reference !== undefined) && (this._findInfo.Reference !== "dummy")){
			//post
			var sPostPath = "/GRCAUD_CV_ScopeReference";
			var oPostBody = {
				ScopeKey: this._findInfo.Reference,
				ParentKey: this.oFindingDataInServer.DBKey,
				RootKey: this.oFindingDataInServer.AuditKey
			};
			oUpdateDataModel.create(sPostPath, oPostBody, {
				groupId: "updateFinding"
			});
			oChange.bExistChange = true;
		}
	}else{
		var sReferDBkey = this.getView().getBindingContext().getProperty("to_Reference").DBKey;
		if(this._findInfo.Reference === "dummy"){
			//delete
			var sDeletePath = "/GRCAUD_CV_ScopeReference(guid'" + sReferDBkey + "')";
			oUpdateDataModel.remove(sDeletePath, {
				groupId: "updateFinding"
			});
			oChange.bExistChange = true;
		}else if((this._findInfo.Reference !== undefined) && (this._findInfo.Reference !== "dummy")){
			//merge
			var sMergePath = "/GRCAUD_CV_ScopeReference(guid'" + sReferDBkey + "')";
			var oMergeBody = {
				ScopeKey: this._findInfo.Reference
			};
			oUpdateDataModel.update(
				sMergePath,
				oMergeBody,
				{
					groupId: "updateFinding",
					refreshAfterChange: false
				}
			);
			oChange.bExistChange = true;
		}
	}
},
_updateOrganization: function(oUpdateDataModel,oChange){
	var sOrgCurrentValue = this.getView().byId("findOrg").getValue();
	if(jQuery.isEmptyObject(sOrgCurrentValue)){
		if((this._findInfo.Organization !== undefined) && (this._findInfo.Organization !== "dummy")){
			//post
			var sPostPath = "/GRCAUD_CV_OrgByFinding";
			var oPostBody = {
				OrgKey: this._findInfo.Organization,
				ParentKey: this.oFindingDataInServer.DBKey,
				RootKey: this.oFindingDataInServer.AuditKey
			};
			oUpdateDataModel.create(sPostPath, oPostBody, {
				groupId: "updateFinding"
			});
			oChange.bExistChange = true;
		}
	}else{
		var sOrgDBkey = this.getView().getBindingContext().getProperty("to_FindingOrganization").DBKey;
		var sOrgPath = "/GRCAUD_CV_OrgByFinding(guid'" + sOrgDBkey + "')";
		if(this._findInfo.Organization === "dummy"){
			oUpdateDataModel.remove(sOrgPath, {
				groupId: "updateFinding"
			});
			oChange.bExistChange = true;
		}else if((this._findInfo.Organization !== undefined) && (this._findInfo.Organization !== "dummy")){
			//merge
			var oOrgAssignment = {
				OrgKey: this._findInfo.Organization
			};
			oUpdateDataModel.update(
				sOrgPath,
				oOrgAssignment,
				{
					groupId: "updateFinding",
					refreshAfterChange: false
			});
			oChange.bExistChange = true;
		}
	}
},
_setSmartFormToDisplayMode: function () {
	this.oViewModel.setProperty("/bEditFlag", false);
	this._setReferenceSelectInvisible();
	this._setOrganizationSelectInvisible();
	this._setTagEditable(false);
	this._getChangedExecutiveResponsible(true, true);
	this.setDropDownFieldsEditableToFalse();
	this._setButtonVisibility("DISPLAY");
	this.getView().byId("smartForm").setEditable(false);
	this._findInfo = {};
	//this.getView().getModel().refresh(true);
	var oExtensionGroup = this.getView().byId("extensionGroup");
	var oExtensionModelData = this.getView().getModel("extensionModel").getData();
	FieldExtensibilityUtil.setCdfNonSmartFieldsStatus(oExtensionGroup, oExtensionModelData,"display");
},

_changeExecutiveResponsibleControl: function () {
	var oSmartForm = this.getView().byId("smartForm");
	if (oSmartForm.getGroups()) {
		if (oSmartForm.getGroups()[0].getFormElements()) {
			for (var j = 0; j < oSmartForm.getGroups()[0].getFormElements().length; j++) {
				if (oSmartForm.getGroups()[0].getFormElements()[j].getFields()[0].getBindingPath("value") === undefined) {
					continue;
				}
				var sKey = oSmartForm.getGroups()[0].getFormElements()[j].getFields()[0].getBindingPath("value");
				var oElement, sCurrentValue;
				if (sKey === "to_ExecutiveResponsible") {
					oElement = oSmartForm.getGroups()[0].getFormElements()[j];
					sCurrentValue = oElement.getFields()[0].getValue();
					this.oRemovedField = oElement.getFields()[0];
					oElement.removeAllFields();
					this.oSelectExecutiveResponsible = new sap.m.Select({
						forceSelection: false
					});

					//to adpat acs.lib
					this.oSelectExecutiveResponsible.addCustomData(new sap.ui.core.CustomData({
						key:"excutiveResponsible",
						value:"to_ExecutiveResponsible"
					}));

					oElement.addField(this.oSelectExecutiveResponsible);
					//get all executiveResonsiblePerson
					this._getExecutiveResponsibleCandidate(this.oSelectExecutiveResponsible, sCurrentValue);
					break;
				}
			}
		}
	}
},

_changeReferenceControl: function(){
	var referSelect = this.getView().byId("referSelect");
	var sCurrentValue;
	if(this.getView().getBindingContext().getProperty("to_Reference") !== null){
		sCurrentValue = this.getView().getBindingContext().getProperty("to_Reference").Code;
	}
	this._setReferenceBindingProperty(referSelect, sCurrentValue);
	
},

_changeOrganizationControl: function(){
	var orgSelect = this.getView().byId("orgSelect");
	var sCurrentValue;
	if(this.getView().getBindingContext().getProperty("to_FindingOrganization") !== null){
		sCurrentValue = this.getView().getBindingContext().getProperty("to_FindingOrganization").OrgKey;
	}
	this._setOrganizationBindingProperty(orgSelect, sCurrentValue);
	
},
_setTagEditable: function(bEditable){
	this.getView().byId("tagEditGrpElem").setVisible(bEditable);
	this.getView().byId("tagDisplayGrpElem").setVisible(!bEditable);
	
},
_setTokens: function () {
	this.getView().byId("multiinput").removeAllTokens();
	this.getView().byId("multiinput").setValue();
	var oldTokens = this.getView().byId("tokenDisplay").getTokens();
	var oldTagData = [];
	for(var i = 0; i < oldTokens.length; i++){
		oldTagData.push({
			TagName: oldTokens[i].getText(),
			TagKey: oldTokens[i].getKey()
		});	
	}
	
	var len = oldTagData.length;
	var oldTagText = [];
	for (var j = 0; j < len; j++) {
		var token = new sap.m.Token({
			text: oldTagData[j].TagName,
			key: oldTagData[j].TagKey
		});
		this.getView().byId("multiinput").addToken(token);
		oldTagText.push(oldTagData[j].TagName);
	}
	this.oFindingDataInServer.Tags = oldTagText.join(";");
},
_getExecutiveResponsibleCandidate: function (oSelect, sName) {
	var oDataModel = this.getView().getModel();
	var sPath = this.getView().getBindingContext() + "/to_AuditExecutiveResponsive";
	oDataModel.setUseBatch(false);
	oDataModel.read(sPath, {
		success: jQuery.proxy(function (data) {
			var oTemplate = new sap.ui.core.ListItem({
				text: "{FullName}",
				key: "{UserID}"
			});
			data.results.splice(0, 0, {
				FullName: "",
				UserID: "NONE_USER_SELECTED"
			});
			var oModel = new sap.ui.model.json.JSONModel(data.results);
			oSelect.setModel(oModel);
			oSelect.bindItems("/", oTemplate);
			if (sName) {
				this._setExecutiveResponsible(oSelect, sName);
			} else {
				oSelect.setSelectedKey("NONE_USER_SELECTED");
				this.sOldUid = "NONE_USER_SELECTED";
			}

		}, this),
		async: true
	});
},

_setExecutiveResponsible: function (oSelect, sName) {
	var aItems = oSelect.getItems();
	for (var i = 0; i < aItems.length; i++) {
		if (aItems[i].getText() === sName) {
			oSelect.setSelectedKey(aItems[i].getKey());
			this.sOldUid = aItems[i].getKey();
		}
	}
	// old user is not a audit executive person any more
	if(sName !== "" && this.sOldUid === undefined){
		oSelect.setValueState(sap.ui.core.ValueState.Error);
	}else{
		oSelect.setValueState(sap.ui.core.ValueState.None);
	}
},

_getChangedExecutiveResponsible: function (bIsCancel, bIsResetControl) {
	var oSmartForm = this.getView().byId("smartForm");
	if (!this.oRemovedField) {
		return;
	}
	if (oSmartForm.getGroups()) {
		if (oSmartForm.getGroups()[0].getFormElements()) {
			for (var j = 0; j < oSmartForm.getGroups()[0].getFormElements().length; j++) {
				if (oSmartForm.getGroups()[0].getFormElements()[j].getFields()[0].getCustomData()[0] === undefined) {
					continue;
				}
				var sKey = oSmartForm.getGroups()[0].getFormElements()[j].getFields()[0].getCustomData()[0].getValue();
				if (sKey === "to_ExecutiveResponsible") {
					if (bIsCancel === false) {
						if(oSmartForm.getGroups()[0].getFormElements()[j].getFields()[0].getSelectedItem() !== null){
							this.sSelectedUid = oSmartForm.getGroups()[0].getFormElements()[j].getFields()[0].getSelectedItem().getKey();
						}
					}
					if (bIsResetControl === true) {
						oSmartForm.getGroups()[0].getFormElements()[j].removeAllFields();
						oSmartForm.getGroups()[0].getFormElements()[j].addField(this.oRemovedField);
					}
					break;
				}
			}
		}
	}
},
_checkErrorChangedExecutiveResponsible: function () {
	var oSmartForm = this.getView().byId("smartForm");
	if (!this.oRemovedField) {
		return false;
	}
	if (oSmartForm.getGroups()) {
		if (oSmartForm.getGroups()[0].getFormElements()) {
			for (var j = 0; j < oSmartForm.getGroups()[0].getFormElements().length; j++) {
				if (oSmartForm.getGroups()[0].getFormElements()[j].getFields()[0].getCustomData()[0] === undefined) {
					continue;
				}
				var sKey = oSmartForm.getGroups()[0].getFormElements()[j].getFields()[0].getCustomData()[0].getValue();
				if (sKey === "to_ExecutiveResponsible") {
					if(oSmartForm.getGroups()[0].getFormElements()[j].getFields()[0].getSelectedItem() === null){
						oSmartForm.getGroups()[0].getFormElements()[j].getFields()[0].setValueState(sap.ui.core.ValueState.Error);
						return true;
					}else{
						oSmartForm.getGroups()[0].getFormElements()[j].getFields()[0].setValueState(sap.ui.core.ValueState.None);
						return false;
					}
				}
			}
		}
	}
},
_changeExecutiveResponsible: function (oUpdateDataModel,oChange) {
	var sPath = "";
	// var oSmartForm = this.getView().byId("smartForm");
	if (this.sOldUid !== "NONE_USER_SELECTED") {
		sPath = "/" + this.getView().getBindingContext().getProperty("to_ExecutiveResponsible")[0];
	}
	//create
	if (this.sOldUid === "NONE_USER_SELECTED" && this.sSelectedUid !== "NONE_USER_SELECTED") {
		
		sPath = this.getView().getBindingContext().getPath() + "/to_ExecutiveResponsible";
		var newExecutiveResponsible = {};
		newExecutiveResponsible.UserID = this.sSelectedUid;
		newExecutiveResponsible.RoleID = "EXE_RESP";
		newExecutiveResponsible.HostKey = this.getView().getBindingContext().getObject().DBKey;
		oUpdateDataModel.create(sPath, newExecutiveResponsible, {
			groupId: "updateFinding"
		});
		oChange.bExistChange = true;
		//delete
	} else if (this.sOldUid !== "NONE_USER_SELECTED" && this.sSelectedUid === "NONE_USER_SELECTED") {
		oUpdateDataModel.remove(sPath, {
			groupId: "updateFinding"
		});
		oChange.bExistChange = true;
	} else {
		//not change
		if (this.sOldUid === this.sSelectedUid) {
			// this.getView().getModel().refresh(true);
			// oSmartForm.setBusy(false);
			// return;
		} else {
			//update
			oUpdateDataModel.update(sPath, {
				UserID: this.sSelectedUid
			}, {
				groupId: "updateFinding",
				refreshAfterChange: false
			});
			oChange.bExistChange = true;
		}
	}
//	return aBatch;
},

_formatAudit: function (sAuditId, sAuditTitle) {
	return sAuditId + " " + sAuditTitle;
},

onAuditPress: function (oEvent) {
	var oCrossAppNavigator = this.getOwnerComponent().getCrossAppNavigator();
	var oAuditIntentConfig = this.getView().getModel("intentConfig").getData().auditIntent;
	var args = {
		target: {
			semanticObject: oAuditIntentConfig.semanticObject,
			action: oAuditIntentConfig.action
		},
		params: {
			"DBKey": oEvent.getSource().getBindingContext().getObject().AuditKey
		}
	};
	var shref = oCrossAppNavigator.hrefForExternal(args);
	window.open(shref, "_self");				
},

onPersonPress: function (oEvent) {
	if (this._oPersonQuickView) {
		this._oPersonQuickView.destroy();
	}
	var oOpeningControl = oEvent.getSource();
	var oPersonQuickView = sap.ui.xmlfragment("sap.grc.acs.lib.aud.person.quickView", this);
	this._oPersonQuickView = oPersonQuickView;
	oPersonQuickView.attachAfterClose(function () {
		oPersonQuickView.destroy();
	});
	oOpeningControl.addDependent(oPersonQuickView);
	jQuery.sap.delayedCall(0, this, function () {
		this._oPersonQuickView.openBy(oOpeningControl);
	});
},

onExecutivePersonPress: function (oEvent) {
	if (this._oPersonQuickView) {
		this._oPersonQuickView.destroy();
	}
	var oOpeningControl = oEvent.getSource();
	var oPersonQuickView = sap.ui.xmlfragment("sap.grc.acs.lib.aud.person.quickView", this);

	var oDataModel = this.getView().getModel();
	var sPath = this.getView().getBindingContext() + "/to_ExecutiveResponsible";
	oDataModel.read(sPath, {
		success: jQuery.proxy(function (oData) {
			var oPerson = oData.results[0];
			if (oPerson) {
				var oModel = new sap.ui.model.json.JSONModel(oPerson);
				oPersonQuickView.setModel(oModel);
				oPersonQuickView.bindElement("/");
			}
			this._oPersonQuickView = oPersonQuickView;
			oPersonQuickView.attachAfterClose(function () {
				oPersonQuickView.destroy();
			});
			oOpeningControl.addDependent(oPersonQuickView);
			jQuery.sap.delayedCall(0, this, function () {
				this._oPersonQuickView.openBy(oOpeningControl);
			});
		}, this),
		async: false
	});
	this._oPersonQuickView = oPersonQuickView;
	oPersonQuickView.attachAfterClose(function () {
		oPersonQuickView.destroy();
	});
	oOpeningControl.addDependent(oPersonQuickView);
	jQuery.sap.delayedCall(0, this, function () {
		this._oPersonQuickView.openBy(oOpeningControl);
	});
},

onFindingOrgPress: function () {
	var oFindOrg = this.getView().getBindingContext().getProperty("to_FindingOrganization");
	if (this.bTimestampTransformFlag === false) {
		oFindOrg.Timestamp = this._transformTimestamp(oFindOrg.Timestamp);
	}
	var sHref = "/sap/bc/ui5_ui5/sap/fra_shell/index.html?hpashell-fiori=true#/organizations?lpdrole=HPA&lpdinst=AUD&objectKey=" +
		oFindOrg.OrgKey + "&isRoot=&tab=info&readOnly=true&timestamp=" + oFindOrg.Timestamp;
	window.open(sHref);
},

//transform Timestamp string to ISOString format
_transformTimestamp: function (sTimestamp) {
	var sNewTimestamp;
	if (sTimestamp.length === 14) {
		var sYear, sMonth, sDate, sHour, sMinute, sSecond;
		sYear = sTimestamp.substring(0, 4);
		sMonth = sTimestamp.substring(4, 6);
		sDate = sTimestamp.substring(6, 8);
		sHour = sTimestamp.substring(8, 10);
		sMinute = sTimestamp.substring(10, 12);
		sSecond = sTimestamp.substring(12, 14);
		sNewTimestamp = new Date(sYear, sMonth - 1, sDate, sHour, sMinute, sSecond);
		this.bTimestampTransformFlag = true;
	} else {
		sNewTimestamp = new Date();
	}
	return sNewTimestamp.toISOString();
},

formatExecutiveResponsible: function (sPath) {
	var oSmartForm = this.getView().byId("smartForm");
	if (sPath && sPath !== null && sPath.length !== 0) {
		var oExecutiveResponsibleExecutive = this.getView().getBindingContext().getObject("/" + sPath[0]);
		oSmartForm.setBusy(false);
		if (oExecutiveResponsibleExecutive) {
			return oExecutiveResponsibleExecutive.FullName;
		} else {
			return "";
		}

	} else {
		oSmartForm.setBusy(false);
		return "";
	}
},

_setButtonVisibility: function (sMode) {
	if (sMode === "EDIT") {
		this.getView().byId("btnEdit").setVisible(false);
		this.getView().byId("btnSave").setVisible(true);
		this.getView().byId("btnCancel").setVisible(true);
	} else if (sMode === "DISPLAY") {
		this.getView().byId("btnEdit").setVisible(true);
		this.getView().byId("btnSave").setVisible(false);
		this.getView().byId("btnCancel").setVisible(false);
	} else {
		this.getView().byId("btnEdit").setVisible(false);
		this.getView().byId("btnSave").setVisible(false);
		this.getView().byId("btnCancel").setVisible(false);
	}
},

onRefresh: function () {
	this.onCancelBtnPress();
},

onCancelBtnPress: function (oEvent) {
	//clear all collected information
	this._findInfo = {};
	this.oViewModel.setProperty("/bEditFlag", false);
	this._getChangedExecutiveResponsible(true, true);
	this.getView().byId("smartForm").setEditable(false);
	if (this.getView().byId("smartForm").getEditable() === false) {
		if (!this._bDisplayMode) { 
			this.getView().getModel().resetChanges();
		}
		this.setDropDownFieldsEditableToFalse();
		this._setReferenceSelectInvisible();
		this._setOrganizationSelectInvisible();
		this._setTagEditable(false);
		this._setButtonVisibility("DISPLAY");
	}
	var oExtensionGroup = this.getView().byId("extensionGroup");
	var oExtensionModelData = this.getView().getModel("extensionModel").getData();
	FieldExtensibilityUtil.setCdfNonSmartFieldsStatus(oExtensionGroup, oExtensionModelData,"display");
	//
},
_setReferenceSelectInvisible: function(){
	var referGrp = this.getView().byId("refSelectGrpElem");
	var referSelect = this.getView().byId("referSelect");
	var reference = this.getView().getModel("extensionModel").getData().Reference;

	referGrp.setVisible(false);
	referSelect.setEnabled(false);
	reference.visible = true;
},

_setOrganizationSelectInvisible: function(){
	var orgGrp = this.getView().byId("orgSelectGrpElem");
	var orgSelect = this.getView().byId("orgSelect");

	orgGrp.setVisible(false);
	orgSelect.setEnabled(false);
	this.getView().getModel("extensionModel").getData().FindOrg.visible = true;
},

onSaveBtnPress: function () {
	//Save action
	this._saveData();
},

onEditFormPress: function (oEvent) {
	this._setButtonVisibility("EDIT");
	this.getView().byId("smartForm").setEditable(true);
	this.oViewModel.setProperty("/bEditFlag", true);
	this.oFindingDataInServer = this.getView().getBindingContext().getObject();
	if (this.getView().getModel("extensionModel").getData().executiveResponsible.editable) {
		this.getView().byId("executiveResponsible").setEditable(true);
	}
	this._changeExecutiveResponsibleControl();
	this._changeReferenceControl();
	this._changeOrganizationControl();
	
	this.getView().byId("multiinput").addValidator(function(args){
		var text = args.text;
		if (text.indexOf(";") !== -1) {
			MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("TAGS_MSG_FORBIDDEN_CHAR"));
			return sap.m.MultiInput.WaitForAsyncValidation;
		}
		return new sap.m.Token({key: text, text: text});
	}.bind(this));

	this._setTokens();
	this._setTagEditable(true);
	
	this.setValueHelpFieldsEditable();
	this._resetFormFieldValueState();
	
	var oExtensionGroup = this.getView().byId("extensionGroup");
	var oExtensionModelData = this.getView().getModel("extensionModel").getData();
	FieldExtensibilityUtil.setCdfNonSmartFieldsStatus(oExtensionGroup, oExtensionModelData,"editable");
},

onUpdateReference: function(oEvent){
	var oReference = oEvent.getSource();
	this._findInfo.Reference = oReference.getSelectedKey();
},
onUpdateOrganization: function(oEvent){
	var oOrganization = oEvent.getSource();
	this._findInfo.Organization = oOrganization.getSelectedKey();
},
onUpdateRecommendation: function(oEvent){
	var oReco = oEvent.getSource();
	var sValue = oReco.getValue();
	
	if(sValue === ""){
		oReco.setValueState(sap.ui.core.ValueState.Error);
		oReco.setValueStateText(this.getView().getModel("i18n").getResourceBundle().getText("emptyNotAllowed"));
		return;
	}
	
	//collect changed information
	this._findInfo.Recommendation = sValue;
},
onExit: function () {
	FieldExtensibilityUtil.destoryElements(this.aDropDownEdit);
	sap.ui.getCore().getEventBus().unsubscribe("sap.grc.acs.aud.find.EventBus", "resetBlockToDisplayMode", this.onRefresh, this);
	sap.ui.getCore().getEventBus().unsubscribe("sap.grc.acs.aud.find.EventBus", "extensionModelDataUpdateFinished", this.setHeaderToolBarVisibility,
		this);
},

setHeaderToolBarVisibility: function () {
	if (this.getView().getModel("extensionModel").getData().SmartForm.editable) {
		this.getView().byId("smartFormToolbar").setVisible(true);
	}
	if (this._bDisplayMode) {
		this.getView().getModel().resetChanges();
		this.setAuditTitleValue();
	}
},

_compareData: function (oOldData, oNewData) {
	var oReturnData = {};
	var sNew, sOld;
	for (var oField in oNewData) {
		sNew = oNewData[oField];
		sOld = oOldData[oField];
		if (oNewData[oField] && oOldData[oField] && typeof oNewData[oField] === "object" && typeof oOldData[oField] === "object" &&
			oNewData[oField].toISOString() && oOldData[oField].toISOString()) {
			//Both are Time
			sNew = oNewData[oField].toISOString().substring(0, 19);
			sOld = oOldData[oField].toISOString().substring(0, 19);
		} else if (oOldData[oField] && typeof oNewData[oField] !== "object" && typeof oOldData[oField] === "object" && oOldData[oField].toISOString()) {
			sOld = oOldData[oField].toISOString().substring(0, 19);
		} else if (oNewData[oField] && typeof oNewData[oField] === "object" && typeof oOldData[oField] !== "object" && oNewData[oField].toISOString()) {
			sNew = oNewData[oField].toISOString().substring(0, 19);
		}
		if (sNew !== sOld) {
			oReturnData[oField] = oNewData[oField];
		}
	}
	return oReturnData;
},
_resetFormFieldValueState: function () {
	var aErrorField = this.getView().byId("smartForm").check();
	for (var i = 0; i < aErrorField.length; i++) {
		sap.ui.getCore().byId(aErrorField[i]).setValueState("None");
	}
},

_setOrganizationBindingProperty: function(sControl, sCurrentValue){
	var oAudit = this.getView().getBindingContext().getObject();
	var sPath = "/GRCAUD_CV_OrganizationByAudit";
	var sSelectionKey = "OrgKey";
	var sSelectionText = "OrgID";
	var sAdditionalText = "OrgName";

	var aFilters = [new sap.ui.model.Filter("DBKey",
			sap.ui.model.FilterOperator.EQ,
			oAudit.AuditKey)];
	this._bindSelectField(sControl, "org", sPath, sSelectionKey, sSelectionText, aFilters, sAdditionalText, sCurrentValue, true);
},
_setReferenceBindingProperty: function(sControl, sCurrentValue){
	var oAudit = this.getView().getBindingContext().getObject();
	var sPath = "/GRCAUD_CV_AssignedScopeHier";
	var sSelectionKey = "DBKey";
	var sSelectionText = "Code";
	var sAdditionalText = "Name";

	var aFilters = [new sap.ui.model.Filter("AuditKey",
			sap.ui.model.FilterOperator.EQ,
			oAudit.AuditKey),
		new sap.ui.model.Filter("DrillState",
			sap.ui.model.FilterOperator.EQ,
			"leaf")
	];
	this._bindSelectField(sControl, "ref", sPath, sSelectionKey, sSelectionText, aFilters, sAdditionalText, sCurrentValue, true);

},
_bindSelectField: function (sControl, sObjectType, sPath, sSelectionKey, sSelectionText, aFilters, sAdditionalText, sCurrentValue, bShowEmptyItem) {
	var oDataModel = this.getView().getModel();
	oDataModel.setUseBatch(false);
	oDataModel.read(sPath, {
		sorters: [new sap.ui.model.Sorter(sSelectionKey)],
		filters: aFilters,
		success: jQuery.proxy(function (data, response) {
			var oTemplate;
			var aItemList = data.results;
			if(bShowEmptyItem){
				var oEmptyItem = {};
				oEmptyItem[sSelectionKey] = "dummy";
				oEmptyItem[sSelectionText] = "";
				oEmptyItem[sAdditionalText] = "";
				var aEmptyResult = [oEmptyItem];
				aItemList = aEmptyResult.concat(data.results);
			}
			if (sAdditionalText) {
				oTemplate = new sap.ui.core.ListItem({
					key: "{" + sSelectionKey + "}",
					text: "{" + sSelectionText + "}",
					additionalText: "{" + sAdditionalText + "}"
				});
			} else {
				oTemplate = new sap.ui.core.ListItem({
					key: "{" + sSelectionKey + "}",
					text: "{" + sSelectionText + "}"
				});
			}
			var oModel = new sap.ui.model.json.JSONModel(aItemList);
			sControl.setModel(oModel);
			sControl.bindItems("/", oTemplate);
			if (!sCurrentValue) {
				sControl.setSelectedKey("dummy");
				return;
			}
			//set selected key
			var aItems = sControl.getItems();
			if (sObjectType === "ref") {
				
				for (var i = 0; i < aItems.length; i++) {
					//compare Reference Code
					if (aItems[i].getText() === sCurrentValue) {
						sControl.setSelectedKey(aItems[i].getKey());
					}
				}
			}else if(sObjectType === "org"){
				for(var j = 0; j < aItems.length; j++){
					if(aItems[j].getKey() === sCurrentValue){
						sControl.setSelectedKey(aItems[j].getKey());
					}
				}
			}

		}, this),
		async: true
	});
},
/**
 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
 * (NOT before the first rendering! onInit() is used for that one!).
 * @memberOf sap.grc.acs.aud.finding.block.view.general
 */
// onBeforeRendering: function() {
// 
// }

/**
 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
 * This hook is the same one that SAPUI5 controls get after being rendered.
 * @memberOf sap.grc.acs.aud.finding.block.view.general
 */
	onAfterRendering: function() {
		sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.find.EventBus", "formatExtensionFields", this.onFormatExtensionFields, this);
	},

/**
 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
 * @memberOf sap.grc.acs.aud.finding.block.view.general
 */
//	onExit: function() {
//
//	}

});
}

);

