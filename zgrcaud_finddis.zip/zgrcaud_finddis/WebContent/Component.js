/*
 * Copyright (C) 2009-2017 SAP SE or an SAP affiliate company. All rights reserved.
 */
jQuery.sap.declare("sap.grc.acs.aud.finding.display.extended.Component");

sap.ui.component.load({
 	name:"sap.grc.acs.aud.finding.display",
 	url: "/sap/bc/ui5_ui5/sap/grcaud_finddisp"
 		 
 }); 

sap.ui.define(
				[ "sap/ui/core/UIComponent", "sap/ui/Device",
				   "sap/grc/acs/aud/finding/app/Component" ],
				function(U, D, F) {
					"use strict";
					return F.extend("sap.grc.acs.aud.finding.display.extended.Component",
									{
										metadata : {
											manifest : "json",
											"customizing" : {
												"sap.ui.controllerExtensions" : {

													"sap.grc.acs.aud.finding.controller.Object" : {
														"controllerName" : "sap.grc.acs.aud.finding.display.extended.controller.ObjectExtended",
													},
													"sap.grc.acs.aud.finding.block.controller.General" : {
														"controllerName" : "sap.grc.acs.aud.finding.display.extended.block.generalCustom",
													},
													"sap.grc.acs.aud.finding.controller.Worklist" : {
														"controllerName" : "sap.grc.acs.aud.finding.display.extended.controller.Worklist"
											
													}, 
												},

												
												 "sap.ui.viewReplacements" : {
											            "sap.grc.acs.aud.finding.block.view.ActionPlan" : {
											              "viewName" : "sap.grc.acs.aud.finding.display.extended.block.view.ActionPlan",
											              "type" : "XML"
											            },
											            "sap.grc.acs.aud.finding.view.Object": {    
										                  "viewName": "sap.grc.acs.aud.finding.display.extended.view.Object",            
										                     "type": "XML"
										                 }
											          },
												 
 
											}  
										},
									     _handleAppToAppNavigation: function() {
									    	 debugger
									            var d = this._getStartupParameter("FindingKey") || this._getStartupParameter("DBKey")
									              , g = new sap.ui.model.odata.type.Guid();
									            if (d) {
									                var f = g.parseValue(d, "string");
									                jQuery.sap.log.info("app was started with FindingKey parameter");
									                this.getRouter().navTo("object", {
									                    objectId: f,
									                    intentService: this.getModel("intentConfig").getData().service || "GRCAUD_CV_TrackOpenFinding"
									                }, true);
									            }
									        }
										
								
									});
				});