sap.ui.define([ "sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	return Controller.extend("sap.grc.acs.aud.audit.execute.extended.block.AdditionalInfo",{
		onInit: function () {
			this.auditKey = sap.ui.getCore().getModel("auditKeyModel").getData().id
			this.empTable = this.getView().byId("empTable");
			this.clieTable = this.getView().byId("clieTable");
			this.centerTable = this.getView().byId("centerTable");	            
			this.oCheckNA = this.getView().byId("oCheckNA");
			this.toogleBtn = this.getView().byId("toogleBtn");
			this.oInputEmp = this.getView().byId("input_emp");
			this.oInputNIF = this.getView().byId("input_nif");
			this.oInputName = this.getView().byId("input_name");
			this.oInputCenter = this.getView().byId("input_cent");
			this.oForm = this.getView().byId("formAdditionalInfo");
			this.oBtnAddClie = this.getView().byId("btnAddClie");
			this.oBtnAddCent = this.getView().byId("btnAddCent");
			this.oBtnAddEmp = this.getView().byId("btnAddEmp");
			this.oPanel = this.getView().byId("panelAdditionalInfo");
			this.oSelectPartic = this.getView().byId("input_partic");
			//INICIO PRL 05.05.2022 PPM098522 - Añadimos los nuevos elementos
			this.oInputDateRec = this.getView().byId("input_daterec");
  	  		this.oInputAmountRec = this.getView().byId("input_amountrec");
  	  		this.oBtnAddRec = this.getView().byId("btnAddRec");
  	  		this.recTable = this.getView().byId("recTable");
			//FIN PRL 05.05.2022 PPM098522	
  	  		//INI MMM ACC PPM100076336
  	  		this.oInput_cateInf = this.getView().byId("input_cateInf");
  	  		this.oTableCateInf = this.getView().byId("tableCateInf");
  	  		this.oBtnAddCateInf = this.getView().byId("btnAddCateInf");

  	  		//FIN MMM ACC PPM100076336
			this.setEditable();		
			
			
			//PRL 30/11/2021
			//Cod old
			//this.onInitState(); 
			//this.loadData();
			//this.setParticipa();
			//cod new
			this.initializeInfo();
			// Creamos bus para inicializar datos
			sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.audit.EventBus","initInfoaditionalExe", this.initializeInfo, this);
			//PRL 30/11/2021	 			
			sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.audit.EventBus","refreshInfoAditional", this.setEditable, this);
			
		},
		onAfterRendering:function(){
			this.setEditable();
		
		},
		
		/*
		  * event method for emp
		  */
		oModel : {
			  inputEmpFlag : true,
			  valueHelpType : "",
			  valueHelpSource : "",
			  valueModel : "",
			  valueHelpModel : new sap.ui.model.json.JSONModel()
		},
		
		empValueHelp : function(oEvent) {
			  this.oModel.valueHelpType = "emp";
			  this.oModel.valueModel = "/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/";
			  this.oModel.valueHelpSource = "/RoleSet(RoleId='AUD',RoleDepId='')/Users"; //"/DataElementSet('LAND1')/NameValuePairs";
			  if (this.oValueHelpDialog) {
				  this.oValueHelpDialog.destroy();
			  }
			  this._createValueHelpDialog();
			  this.oValueHelpDialog.open();
		 },
		 
		 centerValueHelp : function(oEvent) {
			  this.oModel.valueHelpType = "cent";
			  this.oModel.valueModel = "/sap/opu/odata/sap/GRCAUD_SRV/",
			  this.oModel.valueHelpSource = "/DimensionSet";//?$orderby=ID desc&$select=ID,Title,Key";
			  if (this.oValueHelpDialog) {
				  this.oValueHelpDialog.destroy();
			  }
			  this._createValueHelpDialog();
			  this.oValueHelpDialog.open();
		 },
		 //INI MMM ACC PPM100076336
		 categoryValueHelp : function(oEvent) {
			  this.oModel.valueHelpType = "cateInf";
			  this.oModel.valueModel = "/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/";
			  this.oModel.valueHelpSource = "/FraudCategReportSet"; //"/DataElementSet('LAND1')/NameValuePairs";
			  if (this.oValueHelpDialog) {
				  this.oValueHelpDialog.destroy();
			  }
			  this._createValueHelpDialog();
			  this.oValueHelpDialog.open();
		 },
		//FIN MMM ACC PPM100076336
		 
	//   /*
	//   * build value help dialog
	//   */
		 _createValueHelpDialog : function() {
			var that = this;
			var o18nmModel = this.getView().getModel('i18nm');
			// press search button
			var searchPress = function(oEvent) {
			  	var sInput = oEvent.getSource().getParent().getContent()[0].getValue();
			   	// var sSearchPath = this.oModel.valueHelpSource + "?$filter=FullName eq " + sInput.toUpperCase();//' and Value eq '*" + sInput + "*'"; 
			    // !!CAUTION: condition uses 'and', back end implements in or'
			    var aFilters = [];
			    var aSorters = [];
			    if (that.oModel.valueHelpType === "emp") {
			    	aFilters.push(new sap.ui.model.Filter("FullName",sap.ui.model.FilterOperator.EQ, "*" + sInput.toUpperCase() + "*"));
			    } else  if (that.oModel.valueHelpType === "cent") {
			    	aFilters.push(new sap.ui.model.Filter("Title",sap.ui.model.FilterOperator.EQ, "*" + sInput.toUpperCase() + "*" ));
			    	aFilters.push(new sap.ui.model.Filter("Type",sap.ui.model.FilterOperator.EQ, "5DEP" ));
			    	aFilters.push(new sap.ui.model.Filter("Timestamp",sap.ui.model.FilterOperator.EQ, "2099-12-30T23:00:00" ));
			    	aSorters.push(new sap.ui.model.Sorter("ID",true));
			    }
				
			    var conModel = new sap.ui.model.odata.ODataModel(this.oModel.valueModel, false);
				 //sap.ui.getCore().setModel(con.Model,"con");
				    
			    var oTable = oEvent.getSource().getParent().getParent();
			    //var oODataModel = sap.hpa.grcaud.oODataModelPool.get();

			    this.oModel.valueHelpModel.oData.results = undefined;
			    this.oModel.valueHelpModel.refresh(true); 
			    oTable.setBusy(true); //TODO: No se pone el busy en la tabla de añadir empleado
			    
			    // Read Z
			    conModel.read(this.oModel.valueHelpSource, {
					filters : aFilters,
					sorters: aSorters,
					
					async: false,
					success : function (oData, oDataResp) {
						this.oModel.valueHelpModel.setData(oData);
				        oTable.setBusy(false);
			       }.bind(this),
			       error: function (oError) {
			       	oTable.setBusy(false);
			       }.bind(this)
				});
			    			
		};	
		
		// select an item
	    var itemSelected = function(oEvent) {
	     var selectedItem = oEvent.oSource.getSelectedItem().getModel().getProperty(oEvent.oSource.getSelectedItem().getBindingContext().getPath());
	     if (this.oModel.valueHelpType === "emp") {
	    	 this.oInputEmp.setValue(selectedItem.FullName);
	    	 this.oInputEmp.getCustomData().forEach(function(data) {
	 	           if (data.getKey() == "UserId") {
	 	            data.setValue(selectedItem.UserId);
	 	           }
	 	      });
	    	 this.oInputEmp.setValueState(sap.ui.core.ValueState.None);
	 	      this.oValueHelpDialog.close();
	     } else if (this.oModel.valueHelpType === "cent") {
	    	  this.getView().byId("input_cent").setValue(selectedItem.Title);
	    	  this.getView().byId("input_cent").getCustomData().forEach(function(data) {
		           if (data.getKey() == "Id") {
		            data.setValue(selectedItem.ID);
		           }
		      });
	    	  this.getView().byId("input_cent").setValueState(sap.ui.core.ValueState.None);
		      this.oValueHelpDialog.close();
		 //INI MMM ACC PPM100076336
	     } else if (this.oModel.valueHelpType === "cateInf") {
	    	  this.getView().byId("input_cateInf").setValue(selectedItem.CategDesc);
	    	  this.getView().byId("input_cateInf").getCustomData().forEach(function(data) {
		           if (data.getKey() == "CategId") {
		        	   //INI MMM ACC ARREGLO EXPRESS 18/01/2023   
		        	   data.setValue({CategId:selectedItem.CategId, Text: selectedItem.Text});
		        	   //FIN MMM ACC ARREGLO EXPRESS 18/01/2023
		           }
		      });
	    	  this.getView().byId("input_cateInf").setValueState(sap.ui.core.ValueState.None);
		      this.oValueHelpDialog.close();
	     }
	     //FIN MMM ACC PPM100076336
	     
	    };
	  //INI MMM ACC EXPRESS 18/01/2023
	    var columna;
	    if(that.oModel.valueHelpType === "cateInf"){
	    	columna = [ 
                new sap.m.Column({
				      width : "100%",
				      vAlign : sap.ui.core.VerticalAlign.Middle,
				      header : new sap.m.Label({text: o18nmModel.getResourceBundle().getText("COL_VH_CATEG")}),
				     }) 
				     ];
	    }else{
	    	columna = [ 
                new sap.m.Column({
				      width : "35%",
				      vAlign : sap.ui.core.VerticalAlign.Middle,
				      header : new sap.m.Label({}),
				     }), 
				 new sap.m.Column({
				      width : "65%",
				      vAlign : sap.ui.core.VerticalAlign.Middle,
				      header : new sap.m.Label({}),
				     }), 
				     ];
	    }
	    //FIN MMM ACC EXPRESS 18/01/2023 
		// search table to be put into value help dialog
	    var oSearchTable = new sap.m.Table({
		     inset : true,
		     mode : sap.m.ListMode.SingleSelectMaster,
		     growing : true,
		     growingThreshold : 50,
		     growingScrollToLoad : true,
		     headerToolbar : new sap.m.Toolbar({
			     content : [
					        new sap.m.Input({ width : "300px", change : [ searchPress, this ]}),
					        new sap.m.ToolbarSpacer({width : "1em"}),
					        new sap.m.Button({  type : sap.m.ButtonType.Emphasized, 
					        					text : o18nmModel.getResourceBundle().getText("BUTTON_SEARCH"), //sap.hpa.grcaud.oBundle.getText("BUTTON_SEARCH"), TODO: Meterlo en el i18n
					        					press : [ searchPress, this ]})
				  ],
		     }),
		   //INI MMM ACC EXPRESS 18/01/2023
		     columns : columna,
		     //FIN MMM ACC EXPRESS 18/01/2023
		     select : [ itemSelected, this ],
	    });

	    if (that.oModel.valueHelpType === "emp") {
	    	 oSearchTable.bindItems("/results",
	        	     new sap.m.ColumnListItem({
	    	    	      cells : [ 
	    	    	                new sap.m.Text({text : "{UserId}"}), 
	    	    	                new sap.m.Text({text : "{FullName}"}), 
	    	    	      ],
	        	     }));
	    } else  if (that.oModel.valueHelpType === "cent") {
	    	 oSearchTable.bindItems("/results",
	        	     new sap.m.ColumnListItem({
	    	    	      cells : [ 
	    	    	                new sap.m.Text({text : "{ID}"}), 
	    	    	                new sap.m.Text({text : "{Title}"}), 
	    	    	      ],
	        	     }));
	    	//INI MMM ACC PPM100076336
	    } else  if (that.oModel.valueHelpType === "cateInf") {
	    	 oSearchTable.bindItems("/results",
	        	     new sap.m.ColumnListItem({
	    	    	      cells : [ 
	    	    	                new sap.m.Text({text : "{CategDesc}"})
	    	    	      ],
	        	     }));
	    	
	    }
	    
	    	//FIN MMM ACC PPM100076336
	   
	    
	    oSearchTable.setModel(this.oModel.valueHelpModel);
		   
		 // create value help dialog
		 this.oValueHelpDialog = new sap.m.Dialog({
		    title : o18nmModel.getResourceBundle().getText("LABEL_SEARCH_TITLE"), //sap.hpa.grcaud.oBundle.getText("LABEL_SEARCH_TITLE"), TODO: Meterlo en el i18n
		    stretchOnPhone:true,
		    //  stretch : jQuery.device.is.phone, // when it is phone,stretch the search box to full screen
		    contentWidth : "600px",
		    contentHeight:"300px",
		    horizontalScrolling : false,
		    rightButton : new sap.m.Button({
		    						text : o18nmModel.getResourceBundle().getText("BTN_CANCEL") ,// sap.hpa.grcaud.oBundle.getText("BTN_CANCEL"), TODO: Meterlo en el i18n
		    						press : jQuery.proxy(function() { this.oValueHelpDialog.close(); }, this),
		    			  }),
		    content : [ oSearchTable ],
//			beforeOpen : [ this._dialogBeforeOpen, this ],
			afterClose : [ this._dialogAfterClose, this ],
			afterOpen : [ this, this._dialogAfterOpen ],
		  }); 
	  },
	  
	  	_dialogAfterClose : function(oEvent) {
		    this.oModel.valueHelpModel.oData.results = undefined;
		    this.oModel.valueHelpModel.refresh(true);
		    this.oValueHelpDialog.getContent()[0].removeSelections(true);
		    this.oValueHelpDialog.getContent()[0].getHeaderToolbar().getContent()[0].setValue("");
		 },
		 
		_dialogAfterOpen : function(oEvent, oControl) {
		    var that = this;
		    document.getElementById(that.getContent()[0].getHeaderToolbar().getContent()[2].getId()).focus();
		 },
		 
		 onAddEmp: function(oEvent) {
		 	var component = this;
	  		if(component && this.oInputEmp.getValue() != "" ) {
	  			var empTable = component.empTable;
	  	  		var empInput = component.oInputEmp;
	  	  		
//	  	  		if(!empTable.getModel()) {
	  	  	if(!empTable.getModel('dataModel')){
	  	  			var oModel = new sap.ui.model.json.JSONModel();
	  	  			var data = [];
	  	  			data.results =  {};
	  	  			oModel.setData(data);
	  	  			empTable.setModel(oModel,'dataModel');
	  	  		}
	  	  		
	  	  		var model = empTable.getModel('dataModel');
	  	  		var data = model.getData();
	  	  	
	  	  		var userId = empInput.getCustomData()[0] ? empInput.getCustomData()[0].getValue() : "";
//	  	  		
//	  	  		var duplicate = $.grep(data.results, function(n,i) { return n.UserId == userId} )
	  	  	var duplicate = [];
            
//            if(data){
               duplicate = $.grep(data.results, function(n,i) { return n.UserId == userId} )
//  	  		}  else{
//  	  			data = [];
//  	  			data.results = [];
//  	  		}

	  	  		
	  	  		if(duplicate.length > 0) {
	  	  			alert("El empleado seleccionado ya ha sido añadido previamente");
	  	  		} else {
		  	  		if(data.results) {
		  	  			data.results.push({"UserId": userId, "FullName" : empInput.getValue(), "Resolucion": "", "Editable": true});
		  	  		} else {
		  	  			data.results = [];
		  	  			data.results.push({"UserId": userId, "FullName" : empInput.getValue(), "Resolucion": "", "Editable": true});
		  	  		}
		  	  		
		  	  	//empTable.setModel(data);
		  	  	var oModel = new sap.ui.model.json.JSONModel();
		  	  	oModel.setData(data);
  	  				empTable.setModel(oModel,'dataModel');
		  	  		empTable.updateBindings(true);
		  	  		
		  	  		component.oInputEmp.setValue("");
	  	  		}

	  		} else {
	  			alert("No se ha seleccionado ningún empleado");
	  			component.oInputEmp.setValue("");
	  		}  		
	  	},
	  	
	  	validateDNI: function(oEvent) {
	  		if(oEvent.getParameter("value") != undefined && oEvent.getParameter("value") != ""){
	  			return this.validateNif(oEvent) || this.validateNie(oEvent) || this.validateCif(oEvent);
	  		} else {
	  			oEvent.getSource().setValueState(sap.ui.core.ValueState.Error); 
	  			return false;
	  		}
	  	},
	  	
	  	validateNif:  function(oEvent) {
	  		if(oEvent.getParameter("value") != undefined && oEvent.getParameter("value") != ""){
	  		  var dni = oEvent.getParameter("value");
	  		  var numero;
	  		  var letr;
	  		  var letra;
	  		  var expresion_regular_dni = /^\d{8}[a-zA-Z]$/;
	  		 
	  		  if(expresion_regular_dni.test(dni) == true){
	  		     numero = dni.substr(0,dni.length-1);
	  		     letr = dni.substr(dni.length-1,1);
	  		     numero = numero % 23;
	  		     letra='TRWAGMYFPDXBNJZSQVHLCKET';
	  		     letra=letra.substring(numero,numero+1);
	  		    if (letra!=letr.toUpperCase()) {
	  		    	oEvent.getSource().setValueStateText("Error");
	  		    	oEvent.getSource().setValueState(sap.ui.core.ValueState.Error); 
	  		    	return false;
	  		     }else{
	  		       oEvent.getSource().setValueState(sap.ui.core.ValueState.Success);
	  		       return true;
	  		     }
	  		  }else{
	  			 oEvent.getSource().setValueStateText("Error");
	  		     oEvent.getSource().setValueState(sap.ui.core.ValueState.Error); 
	  		     return false;
	  		   }
	  		 }else{
	  			 oEvent.getSource().setValueStateText("Error");
	  			 oEvent.getSource().setValueState(sap.ui.core.ValueState.Error); 
	  			 return false;
	  		 }
	  	},
	  	
	  	validateNie: function(oEvent) {
	  		if(oEvent.getParameter("value") != undefined && oEvent.getParameter("value") != ""){
	  		  var dni = oEvent.getParameter("value");
	  		  var validChars = 'TRWAGMYFPDXBNJZSQVHLCKET';
	  		  var nieRexp = /^[XYZ]{1}[0-9]{7}[TRWAGMYFPDXBNJZSQVHLCKET]{1}$/i;
	  		  var str = dni.toString().toUpperCase();

	  		  if (!nieRexp.test(str)) {
	  			  oEvent.getSource().setValueStateText("Error");
	  			  oEvent.getSource().setValueState(sap.ui.core.ValueState.Error); 
	  			  return false;
	  		  }

	  		  var nie = str.replace(/^[X]/, '0').replace(/^[Y]/, '1').replace(/^[Z]/, '2');

	  		  var letter = str.substr(-1);
	  		  var charIndex = parseInt(nie.substr(0, 8)) % 23;

	  		  if (validChars.charAt(charIndex) === letter) {
	  			  oEvent.getSource().setValueState(sap.ui.core.ValueState.Success);
	  			  return true;
	  		  }

	 		  return false;
	  		}
	  	},
	  	
	  	// Función de validación de CIF
	  	validateCif:function(oEvent){
	  		if( oEvent.getParameter("value").length == 9) {
	  			var cif = oEvent.getParameter("value");
	  			var letters = ['J', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I'];
	  			var digits = cif.substr(1, cif.length - 2);
	  			var letter = cif.substr(0, 1);
	  			var control = cif.substr(cif.length - 1);
	  			var sum = 0;
	  		  	var i;
	  			var digit;
	  		     
	  		     // Si la primera letra no es una letra
	  			if (!letter.match(/[A-Z]/)) {
	  				oEvent.getSource().setValueStateText("Error");
	  		  		oEvent.getSource().setValueState(sap.ui.core.ValueState.Error); 
	  				return false;
	  			}

	  			for (i = 0; i < digits.length; ++i) {
	  				digit = parseInt(digits[i]);

	  				if (isNaN(digit)) {
	  					oEvent.getSource().setValueStateText("Error");
	  		  			oEvent.getSource().setValueState(sap.ui.core.ValueState.Error); 
	  					return false;
	  				}

	  				if (i % 2 === 0) {
	  					digit *= 2;
	  					if (digit > 9) {
	  						digit = parseInt(digit / 10) + (digit % 10);
	  					}

	  					sum += digit;
	  				} else {
	  					sum += digit;
	  				}
	  			}

	  			sum %= 10;
	  			if (sum !== 0) {
	  				digit = 10 - sum;
	  			} else {
	  				digit = sum;
	  			}

	  			if (!letter.match(/[ABCDEFGHJNPQRSUVW]/)) {
	  				oEvent.getSource().setValueStateText("Error");
			  		oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
			  		return false;
	  			}
	  			
	  			
	  			if( String(digit) === control || letters[digit] === control){
	  				oEvent.getSource().setValueState(sap.ui.core.ValueState.Success);
	  			return true;	
	  			}
	  			
	  		}  		

	  	},
	  	
	  	onAddClie: function(oEvent) {
	  		var component = this;
	  		
	  		if(component.oInputNIF.getValueState() == sap.ui.core.ValueState.Error)
	  		{
	  			alert(this.getView().getModel("i18n").getResourceBundle().getText("incorrect_nif"));
	  			return;
	  		}

	  		if(component && component.oInputName.getValue() != "" && component.oInputNIF.getValue() != "" && component.oSelectPartic.getSelectedKey() != "") {
	  			var clieTable = component.clieTable;
	  			var clieTableTemp = component.clieTableTemplate;
	  	  		var nameInput = component.oInputName;
		  	  	var nifInput = component.oInputNIF;
		  	  	var particInput = component.oSelectPartic;
		  	  	var selItem = particInput.getSelectedItem();
	  	  		
	  	  		if(!clieTable.getModel('dataModel')) {
	  	  			var oModel = new sap.ui.model.json.JSONModel();
//	  	  			clieTable.setModel(oModel);
	  	  		clieTable.setModel(oModel,'dataModel');
	  	  		}
	  	  		
	  	  		var model = clieTable.getModel('dataModel');
	  	  		var data = model.getData();
	  	  		var particId = particInput.getSelectedKey();
	  	  		
	  	  		if(data.results) {
	  	  			data.results.push({"Nombre" : nameInput.getValue(), "Nif": nifInput.getValue().toUpperCase(), "Participacion": particId, "ParticipacionSt" : selItem ? selItem.getText() : ""});
	  	  		} else {
	  	  			data.results = [];
	  	  			data.results.push({"Nombre" : nameInput.getValue(), "Nif": nifInput.getValue().toUpperCase(), "Participacion": particId, "ParticipacionSt" : selItem ? selItem.getText() : ""});
	  	  		}
	  	  		
	  	  		clieTable.getModel('dataModel').setData(data);
	  	  		clieTable.updateBindings(true);
	  	  		
	  	  		component.oInputName.setValue("");
	  	  		component.oInputNIF.setValue("");
	  	  		component.oInputNIF.setValueState(sap.ui.core.ValueState.None); 
	  	  		component.oSelectPartic.setSelectedKey("");
	  		} else {
	  			alert(this.getView().getModel("i18n").getResourceBundle().getText("blank_fields"));
	  		}  		
	  	},
	  	
	  	onAddCenter: function(oEvent) {
	  		var component = this;
	  		
	  		if(component && component.oInputCenter.getValue() != "") {
	  			var centerTable = component.centerTable;
	  	  		var centerInput = component.oInputCenter;
	  	  		
	  	  		if(!centerTable.getModel('dataModel')) {
	  	  			var oModel = new sap.ui.model.json.JSONModel();
//	  	  			centerTable.setModel(oModel);
	  	  		centerTable.setModel(oModel,'dataModel');
	  	  		}
	  	  		
	  	  		var model = centerTable.getModel('dataModel');
	  	  		var data = model.getData();
	  	  		
	  	  		var centerId = centerInput.getCustomData()[0] ? centerInput.getCustomData()[0].getValue() : "";

	  	  		if(data.results) {
	  	  			data.results.push({"CentroId" : centerId, "Name": centerInput.getValue().toUpperCase()});
	  	  		} else {
	  	  			data.results = [];
	  	  			data.results.push({"CentroId" : centerId, "Name": centerInput.getValue().toUpperCase()});
	  	  		}
	  	  		
			  	centerTable.getModel('dataModel').setData(data);
			  	centerTable.updateBindings(true);
	  	  		
	  	  		component.oInputCenter.setValue("");

	  		} else {
	  			alert("No se han rellenado todos los campos");
	  		}  		
	  	},
	  	//INI PPM100076336 - Categorización Informe
	  	onAddCateInf: function(oEvent) {
	  		var component = this;
	  		
	  		if(component && component.oInput_cateInf.getValue() != "") {
	  			var oTableCateInf = component.oTableCateInf;
	  	  		var cateInput = component.oInput_cateInf;
	  	  		
	  	  		if(!oTableCateInf.getModel('dataModel')) {
	  	  			var oModel = new sap.ui.model.json.JSONModel();
	  	  			oTableCateInf.setModel(oModel,'dataModel');
	  	  		}
	  	  		
	  	  		var model = oTableCateInf.getModel('dataModel');
	  	  		var data = model.getData();
	  	  		
	  	  		//INI MMM ACC ARREGLO EXPRESS 18/01/2023
	  	  		var CategId = cateInput.getCustomData()[0] ? cateInput.getCustomData()[0].getValue().CategId : "";
	  	  		var CategText = cateInput.getCustomData()[0] ? cateInput.getCustomData()[0].getValue().Text : ""; 
  	  			//FIN MMM ACC ARREGLO EXPRESS 18/01/2023
		  	  	var duplicate = [];
	            
		  	  	if(data){
		  	  		duplicate = $.grep(data.results, function(n,i) { return n.CategId == CategId} )
		  		}  else{
		  			data = [];
		  			data.results = [];
		  		}

	  	  		if(duplicate.length > 0) {
	  	  			let msgCategoriaAnadida = this.getView().getModel("i18n").getResourceBundle().getText("msgCategoriaAnadida");
	  	  			alert(msgCategoriaAnadida);
	  	  		} else {
	  	  			//INI MMM ACC ARREGLO EXPRESS 18/01/2023
		  	  		if(data.results) {
		  	  			data.results.push({"CategId": CategId, "CategDesc" : cateInput.getValue(), "Text" : CategText});
		  	  		} else {
		  	  			data.results = [];
		  	  			data.results.push({"CategId": CategId, "CategDesc" : cateInput.getValue(), "Text" : CategText});
		  	  		}
		  	  		//FIN MMM ACC ARREGLO EXPRESS 18/01/2023
		  	  	}
	  	  		
	  	  		oTableCateInf.getModel('dataModel').setData(data);
	  	  		oTableCateInf.updateBindings(true);
	  	  		
	  	  		component.oInput_cateInf.setValue("");

	  		} else {
	  			let msgCamposVacios = this.getView().getModel("i18n").getResourceBundle().getText("msgCamposVacios");
	  			alert(msgCamposVacios);
	  		}  		
	  	},
	  	//FIN PPM100076336 - Categorización Informe
		  //INICIO PRL 05.05.2022 PPM098522
		  //Pulsamos el botón de añadir recuperación
		  	onAddRec: function(oEvent) {
		  		var component = this;
		  		
		  		if(component && component.oInputDateRec.getValue() != ""
		  			&& component.oInputAmountRec.getValue() != "") {
		  			var recTable = component.recTable;
		  	  		var inputDateRec = component.oInputDateRec;
		  	  		var inputAmountRec = component.oInputAmountRec;
		  	  		if(!recTable.getModel('dataModel')) {
		  	  			var oModel = new sap.ui.model.json.JSONModel();
		  	  		recTable.setModel(oModel,'dataModel');
		  	  		}
		  	  		
		  	  		var model = recTable.getModel('dataModel');
		  	  		var data = model.getData();
		  	  		var formatRec = inputAmountRec.getValue().replace(",", ".")
		  	  		if(data.results) {
		  	  			data.results.push({"FechaRec" : inputDateRec.getValue(), "ImporteRec": formatRec, "Currency":"EUR" });
		  	  		} else {
		  	  			data.results = [];
		  	  		data.results.push({"FechaRec" : inputDateRec.getValue(), "ImporteRec": formatRec, "Currency":"EUR" });
		  	  		}
		  	  		
				  	recTable.getModel('dataModel').setData(data);
				  	recTable.updateBindings(true);
		  	  		
		  	  		component.oInputDateRec.setValue("");
		  	  		component.oInputAmountRec.setValue("");

		  		} else {
		  			alert("No se han rellenado todos los campos");
		  		}  		
		  	},	
		  //FIN PRL 05.05.2022 PPM098522	  	
	  	onDeleteItem: function(oEvent) {
	  		var selItem = oEvent.getParameter("listItem");
	  		var table = oEvent.getSource();
	  	//INI MMM ACC PPM100076336
	  		var that = this;
	  	//FIN MMM ACC PPM100076336
	  		var dialog = new sap.m.Dialog({
				title: 'Advertencia',
				type: 'Message',
				state: 'Warning',
					content: new sap.m.Text({
						text: '¿Está seguro que desea eliminar el registro seleccionada?'
					}),
				state: sap.ui.core.ValueState.Warning,
				beginButton: new sap.m.Button({
					text: 'Aceptar',
					press: function () {
						dialog.close();
//						var bindingContext = selItem.getBindingContext().sPath;
						var bindingContext = selItem.oBindingContexts.dataModel.sPath;
						var index = bindingContext.substring(bindingContext.lastIndexOf("/")+1);
						var data = table.getModel('dataModel').getData();
//						var data = table.getModel.oData.dataModel;
						if(data.results)
							//INI MMM ACC PPM100076336
							if(data.results[index].CategId){
								var categId = data.results[index].CategId;
								if(categId === that.byId("textoHTML").data("CategId")){
									that.byId("textoHTML").setContent("");
									that.byId("textoHTML").setContent("");
								}
							}
							//FIN MMM ACC PPM100076336
							data.results.splice(index,1);
						table.getModel('dataModel').setData(data);
						table.updateBindings(true);
						
						
					}
				}),
				endButton: new sap.m.Button({
					text: 'Cancelar',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});

			dialog.open();
	  	},
	  	
	  	liveInputNameClient : function(oEvent){
	  		oEvent.getSource().setValue(oEvent.getSource().getValue().toUpperCase());
	  	},
	  	
	  	onPressEditToolbar : function(oEvent){
	  		if(this.toogleBtn.getPressed()) {
			   this.onEdit();
			   this.toogleBtn.setIcon("sap-icon://save");
		   } else {
			   this.onSave(oEvent);
		   }
	  	},
	  	
	  	onEdit: function() {
	  		var component = this;
	  		if(component){
	  			// Habilitamos los campos de editables
				this.lookupButtons(component, true);
				this.enableDisableBtns(component, true, sap.m.ListMode.Delete);
				// Habilitamos el campo Resolución en table empleados
				var oModel = component.empTable.getModel('dataModel');
//				var data = oModel ? oModel.getData().results ? oModel.getData().results : undefined : undefined;
				var data = oModel && oModel.getData() ? oModel.getData() ? oModel.getData().results : undefined : undefined;
				if(data){
					$.each(data,function(i,n){
						n.Editable = true; 
					})
					
					//component.empTable.bindAggregation("", "/results", component.empTableTemplate);
				    
					component.empTable.updateBindings(true);					
					oModel.updateBindings(true)
				}
				
	  		}
	  	},
	  	
	  	checkTerritorial: function(component) {
	  		// Si:
	  		// --> No esta seleccionado el check de N/A
	  		// --> Es de departamento/grupo territorial
	  		// ------> Debe tener un empleado añadido mínimo
	  		if(!component.oCheckNA.getSelected() && 
	  				(	component.currAuditHeader.ZzDepartment == "09423" /* Territoriales*/ ||
	  					component.currAuditHeader.AudGroup.startsWith("09423" /* Territoriales*/))
	  				) {
	  			var empTable = component.empTable;
		  		var empTableModel = empTable ? empTable.getModel('dataModel') : undefined;
		  		var empTableData = empTableModel ? empTableModel.getData() : undefined;
		  		var empTableDataRes = empTableData ? empTableModel.getData().results : undefined;
		  		
		  		if(empTableDataRes && empTableDataRes.length == 0)
		  			return false;
		  		else return true;
	  		}
	  		
	  		return true;
	  	},
	  	
	  	checkFraude: function(component) {
	  		// Si:
	  		// --> No esta seleccionado el check de N/A
	  		// --> Es de departamento/grupo fraude
	  		// ------> Debe tener un empleado añadido mínimo
	  		if(!component.oCheckNA.getSelected() && 
	  				(	component.currAuditHeader.ZzDepartment == "16581" /*Fraude*/ ||
	  					component.currAuditHeader.AudGroup.startsWith("16581" /*Fraude*/))
	  				) {
	  			var empTable = component.empTable;
		  		var empTableModel = empTable ? empTable.getModel('dataModel') : undefined;
		  		var empTableData = empTableModel ? empTableModel.getData() : undefined;
		  		var empTableDataRes = empTableData ? empTableModel.getData().results : undefined;
		  		
		  		if(empTableDataRes && empTableDataRes.length == 0)
		  			return false;
		  		else return true;
	  		}
	  		
	  		return true;
	  	},
	  	
	  	saveFraudFields: function(component) {
	  		//var component = sap.ui.getCore().getComponent("aum0028Comp");
	  		var oData = {};
	  		//oData = component.currAuditHeader;
	  		oData.Key = component.auditKey
		    // Se guara el campo N/A para Empleados
	  		oData.ZzNoaplicaEmp = component.oCheckNA.getSelected();
		    
			if(oData.ZzNoaplicaEmp){ // si el check esta marcado, se envia un registro vacio
				oData.FraudUserResolution = [{}];
			} else {
			  		
		  		// Tabla empleados
		  		var empTable = component.empTable;
		  		var empTableModel = empTable ? empTable.getModel('dataModel') : undefined;
		  		var empTableData = empTableModel ? empTableModel.getData() : undefined;
		  		var empTableDataRes = empTableData ? empTableModel.getData().results : undefined
		  		var employee = [];
		  		
		  		$.each(empTableDataRes, function(i,n){
	
		  			if(n.Key)
		  				employee.push({"Key": n.Key, "ParentKey" : oData.Key, "UserId" : n.UserId , "Resolucion" : n.Resolucion });
		  			else
		  				employee.push({"ParentKey" : oData.Key, "UserId" : n.UserId , "Resolucion" : n.Resolucion });
		  		});
		
		  		oData.FraudUserResolution = employee.length > 0 ? employee : [{}];
	  		}
	  		
		  	// Tabla clientes
		  		
	  		var clieTable = component.clieTable;
	  		var clieTableModel = clieTable ? clieTable.getModel('dataModel') : undefined;
	  		var clieTableData = clieTableModel ? clieTableModel.getData() : undefined;
	  		var clieTableDataRes = clieTableData ? clieTableModel.getData().results : undefined
	  		var clients = [];
	  		
	  		$.each(clieTableDataRes, function(i,n){
	  			if(n.Key)
	  				clients.push({"Key": n.Key, "ParentKey" : oData.Key, "Nombre" : n.Nombre , "Nif" : n.Nif, "Participacion" : n.Participacion });
	  			else 
	  				clients.push({"ParentKey" : oData.Key, "Nombre" : n.Nombre , "Nif" : n.Nif, "Participacion" : n.Participacion });
	  		});
	  		
	  		
	  		oData.FraudClientes = clients.length > 0 ? clients : [{}];
	  		 

		  	// Tabla centros
	  		
	  		var centerTable = component.centerTable;
	  		var centerTableModel = centerTable ? centerTable.getModel('dataModel') : undefined;
	  		var centerTableData = centerTableModel ? centerTableModel.getData() : undefined;
	  		var centerTableDataRes = centerTableData ? centerTableModel.getData().results : undefined
	  		var centers = [];
	  		
	  		$.each(centerTableDataRes, function(i,n){
  						
	  			if(n.Key)
	  				centers.push({"Key": n.Key, "ParentKey" : oData.Key, "CentroId" : n.CentroId , "Name" : n.Name});
	  			else 
	  				centers.push({"ParentKey" : oData.Key, "CentroId" : n.CentroId , "Name" : n.Name });
	  		});
	  		
	  		oData.FraudCentros = centers.length > 0 ? centers : [{}];
		  	//INICIO PRL 05.05.2022 PPM098522
	  		//Tabla recuperaciones
	  		var recTable = component.recTable;
	  		var recTableModel = recTable ? recTable.getModel('dataModel') : undefined;
	  		var recTableData = recTableModel ? recTableModel.getData() : undefined;
	  		var recTableDataRes = recTableData ? recTableModel.getData().results : undefined
	  		var rec = [];
	  		$.each(recTableDataRes, function(i,n){ 
	  			var date = new Date(n.FechaRec.substring(6,10) +'/'+n.FechaRec.substring(3,5)+'/'+n.FechaRec.substring(0,2));
	  			var currDate = new Date();
	  			var hour = currDate.getHours();
	  			var min = currDate.getMinutes();
	  			var sec = currDate.getSeconds();
	  			date.setHours(hour);
	  			date.setMinutes(min);
	  			date.setSeconds(sec);
	  			rec.push({"ParentKey" : oData.Key,"FechaRec":date, "ImporteRec" : n.ImporteRec, "Currency": "EUR" });
	  		});
	  		
	  		oData.FraudRecuperaciones = rec.length > 0 ? rec : [{}];
	  		//FIN PRL 05.05.2022 PPM098522	
	  		//INI PPM100076336 - Categorización Informe
	  		// Tabla Categorización informe
	  		var cateInfTable = component.oTableCateInf;
	  		var cateInfTableModel = cateInfTable ? cateInfTable.getModel('dataModel') : undefined;
	  		var cateInfTableData = cateInfTableModel ? cateInfTableModel.getData() : undefined;
	  		var cateInfTableDataRes = cateInfTableData ? cateInfTableModel.getData().results : undefined
	  		var cateInf = [];

	  		
	  		$.each(cateInfTableDataRes, function(i,n){
  						
	  			if(n.Key)
	  				cateInf.push({"Key": n.Key, "ParentKey" : oData.Key, "CategId" : n.CategId, "CategDesc" : n.CategDesc, "Text" : n.Text});
	  			else 
	  				cateInf.push({"ParentKey" : oData.Key, "CategId" : n.CategId, "CategDesc" : n.CategDesc, "Text" : n.Text });
	  		});
	  		
	  		oData.FraudCategReport = cateInf.length > 0 ? cateInf : [{}];
	  		//FIN PPM100076336 - Categorización Informe
	  		// SAVE
	  		var conModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/", false);
		    
		    conModel.create("/AuditDeepSet", oData, {
				async: true,
				success : function (oData, oDataResp) {
					sap.m.MessageToast.show("Campos guardados correctamente", {duration: 1200});
					
					// Volvemos a cargar la info actual de Backend
					component.loadData();
					
					// Deshabilitamos todos los campos editables
					this.enableDisableBtns(component, false, sap.m.ListMode.None);
					this.lookupButtons(component, false);
					
					// Deshabilitamos el campo Resolución en table empleados
					if(empTableDataRes){
						$.each(empTableDataRes,function(i,n){
							n.Editable = false;
						})
						
						//empTable.bindAggregation("", "/results", component.empTableTemplate);
						//that.empTable.setModel(oModel);
						empTable.updateBindings(true);
					}
					
					// Cambiamos el icono del botón
					component.getView().byId(this.btnId).setIcon("sap-icon://edit");
					
					component.oPanel.setBusy(false);
					
					sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.audit.EventBus","getEncuestas");
			  		
		       }.bind(this),
		       error: function (oError) {
		    	   component.oPanel.setBusy(false);
		    	   sap.m.MessageToast.show("Error al guardar los campos", {duration: 1200});
		       }.bind(this)
			});
	  	},
	  	
	  	onSave: function(oEvent) {
	  		var that = this;
	  		this.btnId = oEvent.getSource().sId;
	  		var component = this;

	  		if(component){
	  			component.oPanel.setBusyIndicatorDelay(0);
	  			component.oPanel.setBusy(true);
	  			// Se comprueba si la auditoria es de territorial y tiene empleados
	  			if(that.checkTerritorial(component))
		  		{ 
	  				if(that.checkFraude(component))
		  			{
		  			
	  				var conModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/", false);
	  				
	  			
		  			// Se recuperan los datos de la auditoria
					var url = "/AuditSet(guid'" + component.auditKey + "')";
					this.saveFraudFields(component);
		  			} else {
		  				component.oPanel.setBusy(false);
		  				alert("Para auditorias del departamento '16581 - Auditoria Del Fraude-Investigaciones Esp' es necesario informar un empleado o seleccionar la opción de N/A");
						oEvent.getSource().setPressed(true);
						oEvent.getSource().setIcon("sap-icon://save");
		  			}
	  			} else {
	  				component.oPanel.setBusy(false);
	  				alert("Para auditorias del departamento '09423 - Auditoria Territorial Y Negocio' es necesario informar un empleado o seleccionar la opción de N/A");
					oEvent.getSource().setPressed(true);
					oEvent.getSource().setIcon("sap-icon://save");
	  			}
	  			
	  		}

	  	},
	  	
	  	lookupButtons: function(comp, boolValue) {
	  		var btnClass = sap.m.Button.getMetadata()._sClassName;
	  		var hboxClass = sap.m.HBox.getMetadata()._sClassName;
	  		
	  		var containers = comp.oForm.getFormContainers()
	  		$.each(containers, function(i,n) {
	  			var element = n.getFormElements()[0]; // Así evitamos recorrer las tablas
				var fields = element.getFields();
				$.each(fields, function(k,l){
					if(l.getMetadata()._sClassName == btnClass) {
						l.setEnabled(boolValue);
					} else if (l.getMetadata()._sClassName == hboxClass) {
						var items = l.getItems();
						$.each(items,function(x,y){
							if(y.getMetadata()._sClassName == btnClass) {
								y.setEnabled(boolValue);
							}
						})
						
					}
				})
	  		});
	  	},
	  	
	  	enableDisableBtns: function(component, value, mode) {
	  		if(!component.oCheckNA.getSelected()){
	  			component.oInputEmp.setEnabled(value);
	  			component.empTable.setMode(mode);
	  		}else{
	  			component.oInputEmp.setEnabled(false);
	  			component.empTable.setMode(sap.m.ListMode.None);
	  		}
	  		component.oCheckNA.setEnabled(value);
	  		component.oInputCenter.setEnabled(value);
	  		component.centerTable.setMode(mode);
	  		if(component.currAuditHeader.Status != "08"){
	  			component.oBtnAddClie.setEnabled(value);
	  			component.oInputName.setEnabled(value);
	  			component.oInputNIF.setEnabled(value);
	  			component.oSelectPartic.setEnabled(value);
	  			component.clieTable.setMode(mode);
	  			component.oBtnAddCent.setEnabled(value);
	  			component.oInputCenter.setEnabled(value);
	  	  		component.centerTable.setMode(mode);
	  		  	//INICIO PRL 05.05.2022 PPM098522
	  		  	//Habilitamos los nuevos campos
	  		  	component.oInputDateRec.setEnabled(value);
	  		  	component.oInputAmountRec.setEnabled(value);
	  		  	component.oBtnAddRec.setEnabled(value);
	  		  	component.recTable.setMode(mode)
	  		  	//FIN PRL 05.05.2022 PPM098522
	  		  	//INICIO PPM PPM100076336 ACC MMM
	  		  	component.oInput_cateInf.setEnabled(value);
	  		  	component.oTableCateInf.setMode(mode)
	  		  	component.oBtnAddCateInf.setEnabled(value);
	  		  	//FIN PPM PPM100076336 ACC MMM
	  		}else{
	  			component.oBtnAddClie.setEnabled(false);
	  			component.oInputName.setEnabled(false);
	  			component.oInputNIF.setEnabled(false);
	  			component.oSelectPartic.setEnabled(false);
	  			component.empTable.setMode(sap.m.ListMode.None);
	  			component.clieTable.setMode(sap.m.ListMode.None);
	  			component.oBtnAddCent.setEnabled(false);
	  			component.oInputCenter.setEnabled(false);
	  	  		component.centerTable.setMode(sap.m.ListMode.None);
		  	  	//INICIO PRL 05.05.2022 PPM098522
	  		  	//Deshabilitamos los nuevos campos
	  		  	component.oInputDateRec.setEnabled(false);
	  		  	component.oInputAmountRec.setEnabled(false);
	  		  	component.oBtnAddRec.setEnabled(false);
	  		  	component.recTable.setMode(sap.m.ListMode.None)
	  		  	//FIN PRL 05.05.2022 PPM098522	  	 
	  		  	//INICIO PPM PPM100076336 ACC MMM
	  		  	component.oInput_cateInf.setEnabled(false);
	  		  	component.oTableCateInf.setMode(sap.m.ListMode.None)
	  		  	component.oBtnAddCateInf.setEnabled(false);
	  		  	//FIN PPM PPM100076336 ACC MMM
	  		  	
	  		}
	  	},
	  	
	  	onSelectNA: function(oEvent) {
	  		var component = this;
	  		if(component){
	  			// Recuperamos el estado del check
	  			var isSelected = oEvent.getSource().getSelected();
	  			
	  			// Activamos/desactivamos el input
	  			component.oInputEmp.setEnabled(!isSelected);
	  			component.oBtnAddEmp.setEnabled(!isSelected);
	  			
	  			// Habilitamos los campos de editables
	  			component.empTable.setMode(isSelected ? sap.m.ListMode.None : sap.m.ListMode.Delete);
	  			
	  			// Habilitamos el campo Resolución en table empleados
	  			var empTableTemplate  = new sap.m.ColumnListItem({
	  				vAlign: sap.ui.core.VerticalAlign.Middle,
	  	            cells : [  
	  		                    new sap.m.Text({ text : "{FullName}", }), 
	  		               		new sap.m.TextArea({ value : "{Resolucion}", editable: "{Editable}" }),
	  	                    ]
	  			});
				var oModel = component.empTable.getModel('dataModel');
				var data = oModel ? oModel.getData().results ? oModel.getData().results : undefined : undefined;
				if(data){
					$.each(data,function(i,n){
						n.Editable = !isSelected;
					})
					
					component.empTable.bindAggregation("", 'dataModel>/results', empTableTemplate);
					component.empTable.updateBindings(true);
				}
				
				// Se ocultan / muestran los valores
				if(isSelected) {
					component.empTable.unbindAggregation("");
				} else {
					component.empTable.bindAggregation("", 'dataModel>/results', empTableTemplate);
					component.empTable.updateBindings(true);
				}
				
	  		} 
	  	},
		
		_getCurrentUser: function() {
			//return window.oShell.getUser();
			return sap.ushell.Container.getService("UserInfo").getUser(); 
		},
		
		loadData : function (){
			var that = this;
			var conModel = new sap.ui.model.odata.ODataModel(
					"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
			);
			
			var url = "/AuditSet(guid'" + this.auditKey + "')";
			this.empTable.setBusy(true);
			// Read Z
		    conModel.read(url, {
				async: true,
				success : function (oData, oDataResp) {
					that.oCheckNA.setSelected(JSON.parse(oData.ZzNoaplicaEmp));					
					that.currAuditHeader = oData;
		       }.bind(this),
		       error: function (oError) {
		    	   that.empTable.setBusy(false);
		       }.bind(this)
			});
			
		    //Cargar datos para la tabla de empleados
			var url = "/AuditSet(guid'" + this.auditKey + "')?$expand=AuditToFraudUserResolution";
			that.empTable.setBusy(true);
		    conModel.read(url, {
				async: true,
				success : function (oData, oDataResp) {
					var oModel = new sap.ui.model.json.JSONModel();
					var fraudEmpData = oData.AuditToFraudUserResolution;
					//La propiedad Editable esta bindeada al TextArea de los items de la tabla
					$.each(fraudEmpData.results, function(i,n) {
						n.Editable = false;
					});
					
					oModel.setData(fraudEmpData);
					that.empTable.setModel(oModel,'dataModel');
					that.empTable.updateBindings(true);
					that.empTable.setBusy(false);
		       }.bind(this),
		       error: function (oError) {
		    	   that.empTable.setBusy(false);
		       }.bind(this)
			});
		    
		    //Cargar datos para la tabla de clientes
		    url = "AuditSet(guid'" + this.auditKey + "')?$expand=AuditToFraudClientes";
		    that.clieTable.setBusy(true);
		    conModel.read(url, {
				async: true,
				success : function (oData, oDataResp) {
					var oModel = new sap.ui.model.json.JSONModel();
					var fraudClieData = oData.AuditToFraudClientes;
					oModel.setData(fraudClieData);
										
					that.clieTable.setModel(oModel, "dataModel");
					that.clieTable.updateBindings(true);
					that.clieTable.setBusy(false);
		       }.bind(this),
		       error: function (oError) {
		    	   that.clieTable.setBusy(false);
		       }.bind(this)
			});
		    
		   //Cargar datos para la tabla de centros
		    url = "AuditSet(guid'" + this.auditKey + "')?$expand=AuditToFraudCentros";
		    that.centerTable.setBusy(true);
		    conModel.read(url, {
				async: true,
				success : function (oData, oDataResp) {
					var oModel = new sap.ui.model.json.JSONModel();
					var fraudCentrosData = oData.AuditToFraudCentros;
					oModel.setData(fraudCentrosData);
										
					that.centerTable.setModel(oModel, "dataModel");
					that.centerTable.updateBindings(true);
					that.centerTable.setBusy(false);
		       }.bind(this),
		       error: function (oError) {
		    	   that.centerTable.setBusy(false);
		       }.bind(this)
			});
		    //INICIO PRL 05.05.2022 PPM098522
			  //Cargar datos para la tabla de recuperaciones
			    url = "AuditSet(guid'" + this.auditKey + "')?$expand=AuditToFraudRecuperaciones";
			    that.recTable.setBusy(true);
			    conModel.read(url, { 
					async: true,
					success : function (oData, oDataResp) { 
						var oModel = new sap.ui.model.json.JSONModel();
						var fraudRecData = oData.AuditToFraudRecuperaciones;
						// Se formatea la fecha
						$.each(fraudRecData.results, function(i,n) {
							n.FechaRec = sap.ui.core.format.DateFormat.getDateInstance({
			                    pattern: "dd.MM.yyyy"
			                }).format(new Date(n.FechaRec));
						});
						oModel.setData(fraudRecData);										
						that.recTable.setModel(oModel, "dataModel");
						that.recTable.updateBindings(true);
						that.recTable.setBusy(false);
			       }.bind(this),
			       error: function (oError) {
			    	   that.recTable.setBusy(false);
			       }.bind(this)
				}); 
			  //FIN PRL 05.05.2022 PPM098522
			  //INI PPM ACC MMM PPM100076336
			    url = "AuditSet(guid'" + this.auditKey + "')?$expand=AuditToFraudCategReport";
			    that.oTableCateInf.setBusy(true);
			    conModel.read(url, { 
					async: true,
					success : function (oData, oDataResp) { 
						var oModel = new sap.ui.model.json.JSONModel();
						var fraudCategData = oData.AuditToFraudCategReport;
						oModel.setData(fraudCategData);										
						that.oTableCateInf.setModel(oModel, "dataModel");
						that.oTableCateInf.updateBindings(true);
						that.oTableCateInf.setBusy(false);
			       }.bind(this),
			       error: function (oError) {
			    	   that.oTableCateInf.setBusy(false);
			       }.bind(this)
				});
			  //FIN PPM ACC MMM PPM100076336
		},
		
		setParticipa: function() {
			var select = this.oSelectPartic;
			var oModel = new sap.ui.model.json.JSONModel();
		    var conModel = new sap.ui.model.odata.ODataModel(
					"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
			);
			// Se recuperan los datos a mostrar en el select
		    conModel.read("/ParticipacionSet", {
				async: false,
				success : function (oData, oDataResp) {
					oModel.setData(oData);
					select.setModel(oModel);
		       }.bind(this),
		       error: function (oError) {
		       	
		       }.bind(this)
			});
	    
		},
		
		_getInTeam: function(auditKey) {
			
			if(auditKey){
				// Find current user in Team
				var inTeam = false;
				var currUser = this._getCurrentUser();
				var oModel = new sap.ui.model.odata.ODataModel(
						"/sap/opu/odata/sap/GRCAUD_SRV",false
				);
				oModel.read("/AuditSet(guid'"+ auditKey + "')/UserRoles", { async: false, success: success, error: error }); //TODO Da error la llamada parece que el oModel no esta bien
				
				function success(oData,oDataRes)
				{
					var users = $.grep(oData.results,function(n){ return (n.UserID == currUser.getId()); });
					inTeam = users.length > 0 ? true : false;
				}
				
				function error(error) {
					console.log("Error retrieving Team members");
					inTeam = false;
				}
				
				return inTeam;
			} else return false;
		},
		
		setEditable: function() {			
			// Se comprueba si esta en el team para poder editar o no
			if(this._getInTeam(this.auditKey)) {
				this.toogleBtn.setVisible(true);
			} else {
				this.toogleBtn.setVisible(false);
			}	
		},
		
		onInitState: function() {
			var that = this;
			
			// Se guarda la key actual de la auditoria
			this.auditKey = sap.ui.getCore().getModel("auditKeyModel").getData().id
			
			// Guardamos el controlador del IconTabContainer
			this.tabContainerController = this;
			
			var conModel = new sap.ui.model.odata.ODataModel(
					"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
			);
			
			var url = "/AuditSet(guid'" + this.auditKey + "')";
			that.empTable.setBusy(true);
			// Read Z
		    conModel.read(url, {
				async: false,
				success : function (oData, oDataResp) {
					that.oCheckNA.setSelected(JSON.parse(oData.ZzNoaplicaEmp));
					that.currAuditHeader = oData;
					that.empTable.setBusy(false);
		       }.bind(this),
		       error: function (oError) { 
		    	   that.empTable.setBusy(false);
		       }.bind(this)
			});
			// Volvemos el botón al estado inicial
			this.toogleBtn.setPressed(false);
			this.toogleBtn.setIcon("sap-icon://edit");
		
			// Deshabilitamos todos los campos editables
			this.enableDisableBtns(this, false, sap.m.ListMode.None);
			this.lookupButtons(this, false);
			
			// Deshabilitamos el campo Resolución en table empleados
			var oModel = this.empTable.getModel('dataModel');
			var data = oModel ? oModel.getData().results ? oModel.getData().results : undefined : undefined;
			if(data){
				$.each(data,function(i,n){
					n.Editable = false;
				})
				
				that.empTable.setModel(oModel);
				this.empTable.updateBindings(true);
			}
	  	},
	  	
//PRL 30/11/2021
//Método que se llamara con eventbus para inicializar los datos en caso de que entremos a otra auditoría sin salir del tile, ya que no entra en onInit
		initializeInfo: function() {
			
			// INICIO 100076336
			if(this.byId("textoHTML")){
				this.byId("textoHTML").setContent("");
				this.byId("textoHTML").setContent("");
			}
			// FIN 100076336
			this.onInitState(); 
			this.loadData();
			this.setParticipa();	
		},
//PRL 30/11/2021
		//INICIO PRL 09.05.2022 PPM098522 - Comprobamos el importe de recuperación
		onRecAmountChange: function(oEvent){
			var fieldIdMessageKeyMap = new Map([
				["input_amountrec", "MSG_RECOVERY_AMOUNT_FIELD"]
			]);
			var oFloatFormatter = sap.ui.core.format.NumberFormat.getFloatInstance({
				maxFractionDigits: 2,
				parseAsString: false,
				emptyString: 0
			});
			var decimals = 0;
			var fieldNumber = oFloatFormatter.parse(oEvent.getParameters().newValue);
			var split = oEvent.getParameters().newValue.split(",");
			if (split.length >=2 ){
				decimals = split[1].length;
			}
			if(Math.sign(fieldNumber) === -1 || isNaN(Math.sign(fieldNumber)) || decimals > 2){
				this.getView().byId("input_amountrec").setValueStateText(this.getView().getModel("i18n").getResourceBundle().getText(fieldIdMessageKeyMap.get("input_amountrec"))).setValueState(sap.ui.core.ValueState.Error);
				this.oBtnAddRec.setEnabled(false);
			}else if(Math.sign(fieldNumber) !== -1) {
				this.getView().byId("input_amountrec").setValueState(sap.ui.core.ValueState.None);
				this.oBtnAddRec.setEnabled(true);
			}
		},
		//FIN PRL 09.05.2022 PPM098522 - Comprobamos el importe de recuperación	
		//INICIO PPM ACC MMM PPM100076336
		onItemPress: function(oEvent){
			//oEvent;
			this.byId("textoHTML").setContent("");
			var textoHTML = oEvent.getSource().getBindingContext("dataModel").getObject().Text;
			var categId = oEvent.getSource().getBindingContext("dataModel").getObject().CategId;
			this.byId("textoHTML").setContent(textoHTML);
			this.byId("textoHTML").data("CategId", categId);
		}
		//FIN PPM ACC MMM PPM100076336
	});
});