/*
 * Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(
 [
  "sap/grc/acs/aud/finding/controller/BaseController",
  "sap/grc/acs/lib/aud/utils/MenuItemUtils",
  "sap/grc/acs/lib/aud/utils/ComponentUtil",
  "sap/grc/acs/lib/aud/utils/MessageUtil",
  "sap/grc/acs/aud/audit/execute/extended/block/util/encodingUtils",
  "sap/ui/core/format/NumberFormat",
  "sap/m/MessageBox"
 ],
 function(BaseController, MenuItemUtils, ComponentUtil, MessageUtil, Util, NumberFormat, MessageBox) {
  "use strict";

  return BaseController.extend("sap.grc.acs.aud.audit.execute.extended.block.controller.ClasificacionIE", { 
	  
	  
	  onInit: function() {
		  
		  // INI Generamos todos los componentes de la vista en variables del controlador para evitar errores en los routing con publish / subscribe
		  // Inicializamos variables
		  this.comboResponsableIncidencia = this.getView().byId("comboResponsableIncidencia");
		  this.inputImpacto = this.getView().byId("inputImpacto");
		  this.comboIncidencia = this.getView().byId("comboIncidencia");
		  this.tableClasificacionIE = this.getView().byId("tableClasificacionIE");
		  this.btn_addClasificacionIE = this.getView().byId("btn_addClasificacionIE");
		  this.btnGuardado = this.getView().byId("btnGuardado");
		  this.radioBtn_ClasificacionIE = this.getView().byId("radioBtn_ClasificacionIE");
		  this.btn_RemoveClasificacionIE = this.getView().byId("btn_RemoveClasificacionIE");
		  // FIN
		  
		  this._Component = ComponentUtil.getComponentById(this.getView().getId());
		  this.modelClasificacionIE = this._Component.getModel("MyClasificacionIE");
		  this.tableClasificacionIE.setModel(this.modelClasificacionIE,"clasificacionIE");
		  
		  this.tableContentModel = new sap.ui.model.json.JSONModel();
		  this.sModelData = {
				  ClasificacionIEData: [],
		  	};
		  this.tableContentModel.setData(this.sModelData);
		  
		// Carga de datos necesarios
		  //this.getData();
		  
		  sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.audit.EventBus","getDataIE_audexe", this.initialize, this);
		  this.initialize(this);
	  },
	  
	  initialize: function(oController) {
			
			//Inicio PRL 16.09.2021: Solo informamos el objectBinding si se ha cargado el contexto
			var that = this;
			if(this.getOwnerComponent()){
			this.getOwnerComponent().mAggregations.rootControl.mAggregations.content[0].mAggregations.pages.forEach(function(e,i,a){
				if(e.sId.indexOf('object') !== -1){
				var binding = e.getBindingContext();				
				if(binding != undefined){
					that.objectBinding = e.getBindingContext().getObject();
				}	
			//Fin PRL 16.09.2021		
            }
			})};
			this.grcaudController = oController;  
			
			// Fetching Distribution List
			this.getData();
			//sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.audit.EventBus","getInTeamLists", this._checkEnabledTeamAdd, this);
			
		},
	  
	  getData: function() {
		//Carga del combo responsable de incidencias
		  this.getComboIncidencias();
		  
		//Carga de la tabla principal
		  this.getDataFromOdata();
		  
		//Visibilidad Botones
		  this.onVisiblidadBotones();
	  },
	  
	  //FUNCION PARA COMBO DE RESPONSABLE DE LA INCIDENCIA
	  getComboIncidencias: function(){
		
		  var that = this;
		  
		  var ClasificacionIEModel = new sap.ui.model.odata.v2.ODataModel(
					"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false ////"ZGRCAUD_ENH_SRV"
				
			);
		  
		  ClasificacionIEModel.read("/ZGRCAUD_CV_RINC", {
					success: function (data, response) {						
						
					that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(data.results), "cmbResponsableIncidencias");
		      		that.getOwnerComponent().getModel("cmbResponsableIncidencias").refresh();		      		
					},
					failed: function (oData, response) {
						alert("Failed to get InputHelpValues from service!");
					},
				});
		  
	  },
	  
	  //FUNCION DE AÑADIR NUEVOS ELEMENTOS AL POP-UP DE CLASIFICACION IE
	  onAdd_ClasificacionIE: function(oEvent){
		   
		   var oSource = oEvent.getSource();
		   
		   var sectionBindingModel = this.getView().getModel("sectionBindingConfig");
		   this.findingKey = this.getView().getBindingContext().getObject().DBKey;
		   
		   
		   if(this.addClasificacionIESmartTable){
				this.addClasificacionIESmartTable.destroy();
			}
		   
		   //Cargamos el fragment 
		   this.addClasificacionIESmartTable = sap.ui.xmlfragment("sap.grc.acs.aud.audit.execute.extended.block.fragment.addClasificacionIE", this);
		   
		   var that = this;
		   
		 //Realizar llamada al back para obtener el listado de findinds relacionados
			var ClasificacionIEModel = new sap.ui.model.odata.v2.ODataModel(
					"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false ////"ZGRCAUD_ENH_SRV"
				
			);
			
			var oData = {},
			aBatchOperations = [];
	
			//Limpiamos los registros seleccionados por si los hubiera de navegaciones anteriores
			try {
				that.getView().getContent()[0].getContent()[1].removeSelections();
			} catch (err) {}
	
			//limpiamos la tabla por si hubiera registros de consultas anteriores
			that.sModelData.ClasificacionIEData = [];
			that.tableContentModel.refresh();
			
			var aFilters = [];
			//aFilters.push(new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.GE, "2017"));
			//ClasificacionIEModel.read("/ZGRCAUD_CV_IE", {
			ClasificacionIEModel.read("/ZGRCAUD_CV_IEBYAUDIT(p_audit=guid'"+ this.findingKey +"')/Set", {
			//actionModel.read("/ZGRCAUD_CV_ACTRELTOFIND(p_find=guid'" + this.findingKey + "')/Set", {
			    //filters: aFilters,
				success: function (data, response) {
					
					data.results.sort(function(a, b) {
						  if (a.ID < b.ID) {
						    return 1;
						  }
						  if (a.ID > b.ID) {
						    return -1;
						  }
						  return 0;
						});
	
					if (data && data.results && data.results.length > 0) {				
						that.sModelData.ClasificacionIEData = data.results;
						that.tableContentModel.refresh();																											
					} else {
						console.log({ err: "No results" });
					}
					that.oValueHelpDialog.setBusy(false);
				},
				failed: function (oData, response) {
					that.oValueHelpDialog.setBusy(false);
					alert("Failed to get InputHelpValues from service!");
				},
			});
		   
		   
		   //this.addClasificacionIESmartTable.setModel(this.tableContentModel);
			var i18nModel = this.getView().getModel( "i18n");
			this.addClasificacionIESmartTable.setModel(i18nModel, "i18n");
			var oController = this;
		   
		   this.oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				//title: this.getView().getModel("i18n").getResourceBundle().getText("labelLimitations"),
			   	title: "Clasificacion IE",
				supportMultiselect: true,
				supportRanges: false,
				supportRangesOnly: false,
				key: "subtopic_text",
				descriptionKey: "topic_text",
				stretch: sap.ui.Device.system.phone,
				contentHeight:"100%",
				
				ok: function(oOkEvent) {
					var aSelectedTokens = oOkEvent.getParameter("tokens");
					//oController.assignClasificacionIEToAudit(aSelectedTokens);
					that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(aSelectedTokens), "aSelectedTokens");
					var modeloTabla = that.tableClasificacionIE.getModel("clasificacionIE").getData();
					
					//Hacemos esto para poder mostrarlos por pantalla
					for(var i = 0; i < aSelectedTokens.length; i++)
					{
						for(var j = 0; j < aSelectedTokens[i].mAggregations.customData.length; j++)
						{
							if(aSelectedTokens[i].mAggregations.customData[j] !== undefined)
							{
								var Tema = aSelectedTokens[i].mAggregations.customData[j].mProperties.value.topic_text;
								var Subtema = aSelectedTokens[i].mAggregations.customData[j].mProperties.value.subtopic_text;
								var idTema = aSelectedTokens[i].mAggregations.customData[j].mProperties.value.topic;
								var idSubTema = aSelectedTokens[i].mAggregations.customData[j].mProperties.value.subtopic;
							}
							
							//Validación Temas Repetidos
							for(var a = 0; a < modeloTabla.length; a++)
							{
								if(idSubTema === modeloTabla[a].Subtopic)
								{
									MessageUtil.showMsg("msgTypeFailed", that.getView().getModel("i18n").getResourceBundle().getText("msgTemaRepetido"));
									return;
								}
							}
							
							if(Tema !== undefined && Subtema !== undefined && idTema !== undefined && idSubTema !== undefined && Tema !== "" && Subtema !== "" && idTema !== "" && idSubTema !== "")
								that.tableClasificacionIE.getModel("clasificacionIE").getData().push({TopicText: Tema, SubtopicText: Subtema, Topic: idTema, Subtopic: idSubTema});
						}
						
					}
					
					/*var Tema = aSelectedTokens[1].mAggregations.customData[0].mProperties.value.topic_text
					var Subtema = aSelectedTokens[1].mAggregations.customData[0].mProperties.value.subtopic_text*/
					//var objeto = {TopicText: Tema, SubtopicTextt: Subtema};
					//that.tableClasificacionIE.getModel("clasificacionIE").getData().push({TopicText: Tema, SubtopicText: Subtema});
					that.byId("tableClasificacionIE").getBinding("items").refresh()
					that.oValueHelpDialog.close();
					// this.close();
				},
	
				cancel: function() {
					this.close();
				},
	
				afterClose: function() {
					this.destroy();
				}
			});
		   
		   var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterBarExpanded: false,
				showGoOnFB: !sap.ui.Device.system.phone,
				search: function() {
					oController.searchToBeAssignedTable();
				}
			});
		   
		   if (oFilterBar.setBasicSearch) {
				this.oBasicSearch = new sap.m.SearchField({
					id: "basicSearch",
					showSearchButton: sap.ui.Device.system.phone,
					//placeholder: this.getView().getModel("i18n").getResourceBundle().getText("labelSearchFindingPlaceHolder"),
					placeholder: "Buscar Clasificaciones",
					search: function() {
						oController.oValueHelpDialog.getFilterBar().search();
					}
				});
				oFilterBar.setBasicSearch(this.oBasicSearch);
			}
		   
		   //Abertura del dialogo
		   	this.oValueHelpDialog.setFilterBar(oFilterBar);
			this.oValueHelpDialog.setTable(this.addClasificacionIESmartTable);
			this.oValueHelpDialog.setModel(this.tableContentModel);
			oSource.addDependent(this.oValueHelpDialog);
			this.oValueHelpDialog.open();
			//DESCOMENTAR DESPUES PARA CLASIFICACION IE CUANDO EXITEN LAS FUNCIONES
			this.oValueHelpDialog.setBusy(true);
		   
	  },
	  
	  //FUNCION DE BUSQUEDAD PARA POP-UP DE PLANES DE ACCION RELACIONADOS
	  searchToBeAssignedTable: function() {
			var oController = this;
			var oTableSearchState = [];
			var oTableSearchStateFilter = [];
			var oBindingInfo = {};
			var sSearchString = oController.oBasicSearch.getValue();
			oTableSearchState = [
				new sap.ui.model.Filter("topic_text", sap.ui.model.FilterOperator.Contains, sSearchString),
				new sap.ui.model.Filter("subtopic_text", sap.ui.model.FilterOperator.Contains, sSearchString),
				new sap.ui.model.Filter("ActionTypeText", sap.ui.model.FilterOperator.Contains, sSearchString),
				new sap.ui.model.Filter("StatusText", sap.ui.model.FilterOperator.Contains, sSearchString)
			];
			oTableSearchStateFilter = new sap.ui.model.Filter(oTableSearchState, false);
			oBindingInfo = oController.addClasificacionIESmartTable.getTable().getBindingInfo("items");
			oBindingInfo.filters = oTableSearchStateFilter;
			oController.addClasificacionIESmartTable.getTable().bindAggregation("items", oBindingInfo);					
	  },
	  
	//Función de guardado para clasificacion IE
	  assignClasificacionIEToAudit : function(aSelectedTokens){
		  	//Validamos para ver si están todos los campos rellenos
		  	var validacion = this.validateData();
		  	if(validacion === false) return;
		  	
		  	var aSelectedTokens = this.getOwnerComponent().getModel("aSelectedTokens").getData();
			var oController = this;
			var selectedItems = [];
			if(aSelectedTokens.length === 0){
				b.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("MSG_NO_FINDING_SELECTED"));
				return;
			}
			for(var i = 0; i < aSelectedTokens.length; i++) {
				var oObject = aSelectedTokens[i].data("row");
				selectedItems.push(oObject);
			}
			if (!oController.oDataModel) {
				oController.oDataModel = new sap.ui.model.odata.ODataModel(
						"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",
					false
				);
			}
			var aBatchOperations = oController._generateBatchOperations(
					selectedItems,
					oController.oDataModel
			);
			oController.oDataModel.addBatchChangeOperations(aBatchOperations);
			oController.oDataModel.submitBatch(
					jQuery.proxy(function (oData, oResponse, aErrorResponses) {
						if (aErrorResponses.length <= 0) {
							oController.getDataFromOdata()
						} else {
							
						}
					}, this),
					jQuery.proxy(function (oError) {
						/*oController.getView().getContent()[0].getContent()[1].setBusy(false);
						sap.hpa.grcaud.Utility.showODataErrorMsg(
							oError,
							sap.hpa.grcaud.enh_oBundle.getText("MSG_ADD_FINDING_FAIL")
						);*/
					}, this),
					true
				);
			//this.oValueHelpDialog.close();
		},
		
	//FUNCIÓN DE GUARDADO DE CLASIFICACION IE
	  //_generateBatchOperations: function (aNewEntryKey, oDataModel) {
		ClasificacionIE_SAVE: function () {
		  	var validacion = "SAVE";
		  	if(this.validateData(validacion) === false)	return; //Validación de Campos
			var aBatchOperations = [];
			var oDataModel = new sap.ui.model.odata.ODataModel(
					"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",
				false
			);
			this.findingKey = this.getView().getBindingContext().getObject().DBKey;
			var findingKey = this.findingKey.replaceAll("-", "").toUpperCase();
			var that = this;
			var Incidencia = this.comboIncidencia.getValue();
			var ResponsableIncidencia = this.comboResponsableIncidencia.getSelectedKey();
			var Impacto = this.inputImpacto.getValue();
			
			var itemsTabla = this.tableClasificacionIE.getItems();
			var Topics_IE = [];				
			
			for (var i = 0; i < itemsTabla.length; i++) {
				var aux2 = {};
				aux2.ParentKey = this.findingKey;
				aux2.Topic = itemsTabla[i].getCells()[4].getText();
				aux2.Subtopic = itemsTabla[i].getCells()[5].getText();
				aux2.Main = itemsTabla[i].getCells()[2].getSelected();
				Topics_IE.push(aux2);	
			}
			
			//CONSTRUCCIÓN DE 0
			/*var Topics_IE = [];
			for (var i = 0; i < aNewEntryKey.length; i++) {
							
				var aux2 = {};
				aux2.ParentKey = this.findingKey;
				aux2.Topic = aNewEntryKey[i].topic;
				aux2.Subtopic = aNewEntryKey[i].subtopic;
				aux2.Main = false;
				Topics_IE.push(aux2);
				
			}*/
			var ImpactoLong;
			var Incident_IE = [];
			var aux = {};
			aux.ParentKey = this.findingKey;
			aux.Incident = (Incidencia === "Si") ? "Y" : "N";
			aux.ResInc = ResponsableIncidencia;
			ImpactoLong = (Impacto === "") ? "0" : Impacto.toString().replace(/\./g,'');
			aux.Impact = (ImpactoLong === "") ? "0" : ImpactoLong.toString().replace(/\,/g,'.');
			Incident_IE.push(aux);
			
			var objeto = {};
			objeto.Key = this.findingKey;
			objeto.Incident_IE = Incident_IE;
			objeto.Topics_IE = Topics_IE;
			
			oDataModel.create("/IESet", objeto, {
				async: true,
				success : function (oData) {
			  		this.getDataFromOdata();
			  		//MessageUtil.showMsg("msgTypeSuccessful", "Tema guardado correctamente");
			  		MessageUtil.showMsg("msgTypeSuccessful", this.getView().getModel("i18n").getResourceBundle().getText("msgGuardadoTema"));
		       }.bind(this),
		       error: function (oError) {
		    	   that._oDataError(oError);
		       }.bind(this)
			});	

			return aBatchOperations;
		},
		
		//FUNCIÓN DE REFRESCO DE DATOS LA TABLA PRINCIPAL
		getDataFromOdata:function(){
			
			//this.onSetVisibilityAction();	
			var that = this;
			
			//Damos formato para los números del impacto
			var formatOptions = {
				maxFractionDigits: 2,
				maxIntegerDigits: 29,
				minFractionDigits: 0,
				minIntegerDigits: 0
			}
			var oFloatFormat = NumberFormat.getFloatInstance(formatOptions);
			
			var oData = {},
				aBatchOperations = [];										
			
			var sauditKey = sap.ui.getCore().getModel("auditKeyModel").getData().id
			//var url = "/IESet(Key=guid'" + sauditKey + "')";
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, sauditKey));
			var url = "/IESet";
			var Expand = ["Incident_IE", "Topics_IE"];
			
			//Realizar llamada al back para obtener el listado de findinds relacionados
			var clasificacionIEModel = new sap.ui.model.odata.v2.ODataModel(
					"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
				);
			
			clasificacionIEModel.read(url, {
				filters: aFilters,
				urlParameters: {$expand: Expand},
				success: function (data, response) {
					
					if(that.tableClasificacionIE){
					that.tableClasificacionIE.removeSelections();
				}
				
						if(that.modelClasificacionIE) {
							//that.modelClasificacionIE.setData(data.results);
							that.modelClasificacionIE.setData(data.results[0].Topics_IE.results);
							that.comboResponsableIncidencia.setSelectedKey(data.results[0].Incident_IE.ResInc);
							var impactoFormateado = oFloatFormat.format(data.results[0].Incident_IE.Impact);
							that.inputImpacto.setValue(impactoFormateado);
							that.comboIncidencia.setSelectedKey(data.results[0].Incident_IE.Incident);
							that.tableClasificacionIE.setModel(that.modelClasificacionIE,"clasificacionIE");
							that.modelClasificacionIE.refresh();
						}
						that.editData = [];
						var modelTitleClasificacionIE = {};
						that.editData = [];														      			      		
		      			modelTitleClasificacionIE.title = that.getOwnerComponent().getModel("i18n").getResourceBundle().getText("clasificacionIESectionTitle");
	  					that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(modelTitleClasificacionIE), "clasificacionIETitle");
		      			that.getOwnerComponent().getModel("clasificacionIETitle").refresh();
		      			
		      		//Volvemos a revisar la visibilidad de los botones e integrantes de la tabla
		      			that.onVisiblidadBotones();
						
				},
				failed: function (oData, response) {
					alert("Failed to get InputHelpValues from service!");
				},
			});
		},
		
	   	//FUNCIONES DE BORRADO PARA CLASIFICACION IE SIN TERMINAR
		ClasificacionIE_DEL: function(oEvent){
			var validacion = "DEL";
			if(this.validateData(validacion) === false)	return; //Validación de Campos
			var that = this;
			var keyObservacion = oEvent.getSource().getBindingContext().getObject().DBKey
			//var oDataModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false);
			
			var oDataModel = new sap.ui.model.odata.ODataModel(
					"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",
				false
			);
			
			var Incidencia = this.comboIncidencia.getValue();
			var ResponsableIncidencia = this.comboResponsableIncidencia.getSelectedKey();
			var Impacto = this.inputImpacto.getValue();
			
			var id = oEvent.getParameters().id;
			var numTabla = id.substr(id.length - 1);
			var itemsTabla = this.tableClasificacionIE.getItems();
			var Topics_IE = [];
			
			//Validamos que el tema seleccionado no sea borrado si es principal
			if(itemsTabla[numTabla].getCells()[2].getSelected() === true)
			{
				//MessageUtil.showMsg("msgTypeFailed", "No es posible borrar el Tema/Subtema principal");
				MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("msgBorradoUltimoTema"));
				
				return false;
			}
						
			for (var i = 0; i < itemsTabla.length; i++) 
			{			
				if(itemsTabla[i] !== itemsTabla[numTabla])
				{
					var aux2 = {};
					aux2.ParentKey = keyObservacion;
					aux2.Topic = itemsTabla[i].getCells()[4].getText();
					aux2.Subtopic = itemsTabla[i].getCells()[5].getText();
					aux2.Main = itemsTabla[i].getCells()[2].getSelected();
					Topics_IE.push(aux2);	
				}
				
			}
			var ImpactoLong;
			var Incident_IE = [];
			var aux = {};
			aux.ParentKey = keyObservacion;
			aux.Incident = (Incidencia === "Si") ? "Y" : "N";
			aux.ResInc = ResponsableIncidencia;
			ImpactoLong = (Impacto === "") ? "0" : Impacto.toString().replace(/\./g,'');
			aux.Impact = (ImpactoLong === "") ? "0" : ImpactoLong.toString().replace(/\,/g,'.');
			Incident_IE.push(aux);
			
			var objeto = {};
			objeto.Key = keyObservacion;
			objeto.Incident_IE = Incident_IE;
			objeto.Topics_IE = Topics_IE;
			
			oDataModel.create("/IESet", objeto, {
				async: true,
				success : function (oData) {
			  		this.getDataFromOdata();
			  		//MessageUtil.showMsg("msgTypeSuccessful", "Tema borrado correctamente");
			  		MessageUtil.showMsg("msgTypeSuccessful", this.getView().getModel("i18n").getResourceBundle().getText("msgBorradoTema"));
		       }.bind(this),
		       error: function (oError) {
		    	   that._oDataError(oError);
		       }.bind(this)
			});	
												
		},
		
		//FUNCION PARA VALIDAR LOS CAMPOS ANTES DE ENVIAR O BORRAR
		validateData: function(Params)
		{
			var Incidencia = this.comboIncidencia.getValue();
			var ResponsableIncidencia = this.comboResponsableIncidencia.getSelectedKey();
			var Impacto = this.inputImpacto.getValue();
			var tablaPrincipal = this.tableClasificacionIE.getModel("clasificacionIE").getData();
			var error = 1;
			
			//Comprobamos si los campos de Incidencia, Responsable, Impacto, Temas están rellenos y que haya un principal.
			//TEMAS Y PRINCIPAL
			for(var i = 0; i < tablaPrincipal.length; i++)
			{
				//TEMA
				if(tablaPrincipal[i] === undefined || tablaPrincipal[i] === 0)
				{
					//MessageUtil.showMsg("msgTypeFailed", "Seleccione un tema");
					MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("msgTema"));
					return false;
				}
				//PRINCIPAL
				if(error !== 0)
				{
					if(tablaPrincipal[i].Main !== true)	error = 1;
					else error = 0;
				}
				
			}
			
			//INCIDENCIA
			if(Incidencia === "")
			{
				//MessageUtil.showMsg("msgTypeFailed", "Seleccione una incidencia");
				MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("msgIncidencia"));
				return false;
			}

			//RESPONSABLE INCIDENCIA
			if(ResponsableIncidencia === "")
			{
				//MessageUtil.showMsg("msgTypeFailed", "Seleccione un responsable de incidencia");
				MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("msgRespIncidencia"));
				return false;
			}
			
			//PRINCIPAL
			if(error === 1)
			{
				//MessageUtil.showMsg("msgTypeFailed", "Seleccione un tema como principal");
				MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("msgTemaPrincipal"));
				return false;
			}

		},
		
		//FUNCION DE VISIBILIDAD PARA LOS BOTONES
		onVisiblidadBotones: function(){
			//var itemsTabla = this.tableClasificacionIE.getItems();
			var createEnabled,deleteEnabled;
			var that = this;
			var dbKey = sap.ui.getCore().getModel("auditKeyModel").getData().id;
			var sPath = "/GRCAUD_CV_MyOngoingAudit(guid'"+dbKey+"')/to_MenuItems";
			this.getOwnerComponent().getModel().read(sPath, {
			success: function (data, response) {
		
					var elements = []; 
					elements = data.results.filter( item => item.SectionID == 'IE');
					
					if (elements !== undefined & elements.length > 0) {
						Array.prototype.forEach.call(elements, item=>{
							if(item.Action === 'CRE_TOPIC_TO_AUDIT_ASMNT'){
								
									createEnabled = item.Enable;																
								
							}else if(item.Action === 'DEL_TOPIC_TO_AUDIT_ASMNT'){
								deleteEnabled = item.Enable;
							}													
						});													
					}
					
					if(that.btn_addClasificacionIE){					
						if( createEnabled == "X"){
							that.btn_addClasificacionIE.setVisible(true);
							that.btn_addClasificacionIE.setEnabled(true);
							that.btnGuardado.setVisible(true);
							that.btnGuardado.setEnabled(true);
							that.radioBtn_ClasificacionIE.setEnabled(true);
							that.comboIncidencia.setEnabled(true);
							that.comboResponsableIncidencia.setEnabled(true);
							that.inputImpacto.setEnabled(true);
							for(var i = 0; i < that.tableClasificacionIE.getItems().length; i++)
							{
								if(that.tableClasificacionIE.getItems()[i] && that.tableClasificacionIE.getItems()[i] !== undefined)
									{
										that.tableClasificacionIE.getItems()[i].getCells()[2].setEnabled(true);
									}
							}
						}else{
							that.btn_addClasificacionIE.setVisible(false);
							that.btn_addClasificacionIE.setEnabled(false);
							that.btnGuardado.setVisible(false);
							that.btnGuardado.setEnabled(false);
							//that.radioBtn_ClasificacionIE.setEnabled(false);
							that.comboIncidencia.setEnabled(false);
							that.comboResponsableIncidencia.setEnabled(false);
							that.inputImpacto.setEnabled(false);
							for(var i = 0; i < that.tableClasificacionIE.getItems().length; i++)
							{
								if(that.tableClasificacionIE.getItems()[i] && that.tableClasificacionIE.getItems()[i] !== undefined)
									{
										that.tableClasificacionIE.getItems()[i].getCells()[2].setEnabled(false);
									}
							}
						};
						};
						if(that.btn_RemoveClasificacionIE){	
						if( deleteEnabled == "X"){
							if(that.tableClasificacionIE.getColumns().length !== 0)
							{
								that.tableClasificacionIE.getColumns()[3].setVisible(true);
							}
							that.btn_RemoveClasificacionIE.setVisible(true);
							that.btn_RemoveClasificacionIE.setEnabled(true);
						}else{
							if(that.tableClasificacionIE.getColumns().length !== 0)
							{
								that.tableClasificacionIE.getColumns()[3].setVisible(false);
							}
							that.btn_RemoveClasificacionIE.setVisible(false);
							that.btn_RemoveClasificacionIE.setEnabled(false);
						};
						};
			},
			failed: function (oData, response) {
				that.tableClasificacionIE.setBusy(false)
			}
		
		});
	},
	
	//Funcion de error
	_oDataError: function (oError, fFunction) {
		var message, data;

		try {
			// lo formateamos a JSON
			data = $.parseJSON(oError.responseText);
			message = "";

			// obtengo el nombre del servicio
			// if(data.error.innererror.application) {  /*JPM*/
			// 	service = data.error.innererror.application.service_id;  /*JPM*/
			// }  /*JPM*/
			// obtengo el mensaje de error
			if (data.error.innererror.errordetails && data.error.innererror.errordetails.length > 0) {
				for (var i = 0; i < data.error.innererror.errordetails.length; i++) {
					if (data.error.innererror.errordetails[i].code !== "/IWBEP/CX_SD_GEN_DPC_BUSINS") {
						// message += data.error.innererror.errordetails[i].code + " - " + data.error.innererror.errordetails[i].message + "\n";  /*JPM*/
						message += data.error.innererror.errordetails[i].message + "\n";
					}
				}
			} else {
				message += data.error.message.value;
			}
		} catch (err) {
			// si el formateo a JSON falla, lo intentamos formatear a XML
			data = $.parseXML(oError.responseText);
			var $xml = $(data);
			var $message = $xml.find("innererror").find("message");
			if (!$message.text()) {
				$message = $xml.find("message");
			}
			//var $service = $xml.find( "service_id" ); /*JPM*/
			message = $message.text();
			//service = $service.text(); /*JPM*/
		}

		// quitamos el busy de espera
		if (this.getView()) {
			this.getView().setBusy(false);
		}

		// Mostramos el mensaje de error por pantalla
		MessageBox.alert(message, {
			icon: MessageBox.Icon.ERROR,
			/*title: "Error on service " + service,*/
			title: "Error",
			/*JPM*/
			onClose: function () {
				// si existe se ejecuta la funcion pasada como parametro
				if (fFunction) {
					fFunction();
				}
			}
		});
	},
 

  
  });
  })