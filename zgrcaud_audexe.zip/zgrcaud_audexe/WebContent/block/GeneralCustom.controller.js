/*
 * Copyright (C) 2009-2020 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui
		.define(
				[
					"sap/grc/acs/aud/audit/block/controller/General.controller",
					"sap/grc/acs/lib/aud/extension/utils/FieldExtensibilityUtil",
					"sap/grc/acs/aud/audit/model/formatter",
					"sap/grc/acs/lib/aud/utils/ComponentUtil",
					"sap/ui/model/json/JSONModel",
					"sap/grc/acs/lib/aud/utils/MessageUtil" ],
				function(C, F, f, a, J, M) {
					"use strict";
					return C 
							.extend(
									"sap.grc.acs.aud.audit.execute.extended.block.controller.generalCustom",
									{
										formatter : f,
										onInit : function() {
											this.aDropDownGroupIndex = [];
											this.aDropDownEdit = [];
											this.sActualEffort = "";
											this.sEstimatedEffort = "";
											this.oViewModel = new J(
													{
														bActualTimePeriodDisplay : true,
														bPlannedTimePeriodDisplay : true,
														bTagDisplay : true,
														bFormDisplay : true,
														bCompanyEdit : false,
														bCountryEdit : false
													});
											this.getView().setModel(
													this.oViewModel,
													"generalView");
											this.oMultiInput = this.getView()
													.byId("multiinput");
											this._oComponent = a
													.getComponentById(this
															.getView().getId());
											this._oComponent
													.getModel()
													.metadataLoaded()
													.then(
															function() {
																this
																		._createExtensionGroup();
															}.bind(this));
											sap.ui
													.getCore()
													.getEventBus()
													.subscribe(
															"sap.grc.acs.aud.audit.EventBus",
															"resetBlockToDisplayMode",
															this.setSmartFormToDisplayMode,
															this);
										},
										// Incidencia Visualización grupo de auditoría INI
										   onSmartFieldInnerControlsCreated: function(oEvent) {
										    this.getView().getModel().setSizeLimit(9999);
										    var oControl = oEvent.getSource().getInnerControls()[0];
										    var sFieldName = oEvent.getSource().getBindingInfo("value").parts[0].path;
										    var sFieldTextName = sFieldName + "Text";
										    var oBindingObject = oControl.getBindingContext().getObject();
										    if(oBindingObject) {
										     oControl.setValue(oBindingObject[sFieldTextName] || oBindingObject[sFieldName]);
										    }
										   },
										   // Incidencia Visualización grupo de auditoría FIN
										setActualEffortValue : function(e) {
											if (this.getView().getModel(
													"extensionModel").getData().EstimatedEffort.visible) {
												this.getView().byId(
														"EstimatedEffortText")
														.setVisible(true);
											}
											if (this.getView().getModel(
													"extensionModel").getData().ActualEffort.visible) {
												this.getView().byId(
														"ActualEffortText")
														.setVisible(true);
											}
										},
										_createExtensionGroup : function() {
											var e = this.getView().byId(
													"extensionGroup");
											F.createExtensionGroup("Audit", e,
													this._oComponent);
										},
										onTypeChange : function(e) {
											var o = this.getView()
													.getBindingContext()
													.getObject(), O = o.Status, A = e
													.getParameter("value"), I = this
													.getOwnerComponent()
													.getModel("intentConfig")
													.getData().intent;
											F
													.destoryElements(this.aDropDownEdit);
											F
													.destoryElements(this.aDropDownGroupIndex);
											var E = this.getView().getModel(
													"extensionModel");
											var m = this.getOwnerComponent()
													.getModel("menuItemConfig")
													.getData();
											var b = false;
											if (this.getOwnerComponent().isFromFlexibleColumnLayout
													&& O === "00") {
												b = true;
											}
											E
													.setData(
															F
																	.getExtensionFieldsStatus(
																			"Audit",
																			A,
																			O,
																			this
																					.getView()
																					.getModel()
																					.getServiceMetadata(),
																			m,
																			this
																					.getOwnerComponent(),
																			I,
																			b),
															true);
											var c = this.getView().byId(
													"extensionGroup");
											this.getView().byId(
													"extensionGroup")
													.destroyGroupElements();
											this.aDropDownGroupIndex = [];
											this.aDropDownEdit = [];
											var d = this.aDropDownGroupIndex, D = this.aDropDownEdit;
											this._oComponent.oDeferred = jQuery
													.Deferred();
											this._oComponent.oDeferredCount = 0;
											F.createExtensionGroup("Audit", c,
													this._oComponent);
											F.setCdfNonSmartFieldsStatus(c,
													this.getView().getModel(
															"extensionModel")
															.getData(),
													"editable");
											var g = this.getView().getModel(
													"extensionModel").getData();
											this._oComponent.oDeferred
													.done(function() {
														F
																.setValueHelpFieldsEditable(
																		c, g,
																		d, D);
													});
											var h = this.getView().getModel();
											h.setUseBatch(true);
											h
													.read(
															"/GRCAUD_IV_AuditType",
															{
																success : jQuery
																		.proxy(
																				function(
																						r) {
																					for (var i = 0; i < r.results.length; i++) {
																						if (r.results[i].AuditType === A) {
																							if (r.results[i].CostAssignType === "IO") {
																								this
																										.getView()
																										.byId(
																												"orderNumber")
																										.setVisible(
																												true);
																								break;
																							} else {
																								this
																										.getView()
																										.byId(
																												"orderNumber")
																										.setVisible(
																												false);
																								break;
																							}
																						}
																					}
																				},
																				this)
															}, this);
//Ini - Editabilidad campo Informe - ANB - 25/08/2021
											//Cuando cambia el valor del campo Sociedad, se llama al método para habilitar/deshabilitar el campo 'Informe'
											//Se llama al método que comprueba la editabilidad del campo zz_report_id
											   this.toggleReportIdEnable(this,"zz_report_id", "A001", this.getView().byId("inputCompany"),O,A);
//Fin - Editabilidad campo Informe - ANB - 25/08/2021
										},
										onEditFormPress : function() {
											this.getView().getModel()
													.setDeferredGroups(
															[ "changes" ]);
											if (this.getView().getModel(
													"extensionModel").getData().PlannedStartDate.editable) {
												this.oViewModel
														.setProperty(
																"/bPlannedTimePeriodDisplay",
																false);
											}
											if (this.getView().getModel(
													"extensionModel").getData().Company.editable) {
												this.oViewModel.setProperty(
														"/bCompanyEdit", true);
											}
											if (this.getView().getModel(
													"extensionModel").getData().Country.editable) {
												this.oViewModel.setProperty(
														"/bCountryEdit", true);
											}
											this._setButtonVisibility("EDIT");
											this.oMultiInput
													.addValidator(this._multiInputValidator
															.bind(this));
											this.resetFormFieldValueState();
											this.setValueHelpFieldsEditable();
											var e = this.getView().byId(
													"extensionGroup");
											var E = this.getView().getModel(
													"extensionModel").getData();
											F.setCdfNonSmartFieldsStatus(e, E,
													"editable");
											this.oAuditDataInServer = this
													.getView()
													.getBindingContext()
													.getObject();
											this.setTokens();
//Ini - Editabilidad campo Informe - ANB - 25/08/2021	
											//Cuando cambia el valor del campo Sociedad, se llama al método para habilitar/deshabilitar el campo 'Informe'
										    this.cdfEditable();
//Fin - Editabilidad campo Informe - ANB - 25/08/2021	
										},
//Ini - Editabilidad campo Informe - ANB - 25/08/2021											
										   // Función que trata los campos de departamento y grupo de auditoría, así como si el campo zz_report_id está habilitado o no
										   cdfEditable: function (oEvent) {
											   var oObject = this.getView().getBindingContext().getObject(), 
												sObjectStatus = oObject.Status;
										
												// Se comprueba si se habilita el campo zz_report_id
												this.toggleReportIdEnable(this,"zz_report_id", "A001", this.getView().byId("inputCompany"),sObjectStatus,this.getView().byId("type").getContent().getSelectedKey());										   											   
											},											
										//Este método habilita o deshabilita el campo 'Informe' según el estado de la auditoría y su sociedad
										//Numeración, notas, título y conclusiones del informe 
									    toggleReportIdEnable : function(oController, sField, sValue, sCompany, sStatusKey, sAuditType) {
							                sCompany = sCompany.mAggregations.customData[0].mProperties.value;
									  				  	    // En estos estados no es necesario realizar nada
										  	    if(sStatusKey != undefined) {
										  	      var notValidStatus = ["07", "08", "09", "18"];
										  	        var status = $.grep(notValidStatus, function(n,i){ if(n == sStatusKey) return n; })
										  	        if(status.length > 0) return; 
										  	    }

										  	  
										  	      var enabled = false;

										  	      // Tipo Visita Oficina == true -> manual (habilitar)
										  	      if (sAuditType.indexOf("VO") > -1) {
										  	        enabled = true;
										  	      } else {
										  	        if(sCompany) {
										  	          if ( sCompany.toUpperCase() === sValue ) //  Sociedad A001 == true -> automatica (deshabilitar)
										  	          {
										  	            enabled = false; 

										  	          } else { // ELSE -> manual (habilitar)
										  	            enabled = true;
										  	          }
										  	        }
										  	      }

										  	      if(oController.getView().byId('smartForm') != undefined) {
										  	    	  var formContainers = oController.getView().byId('smartForm').getAggregation('content').getAggregation('formContainers');
										  	              
										  	          if(formContainers) {
										  	          $.each(formContainers,function(i,n) {
										  	            var elements = n.getFormElements();
										  	           $.each(elements, function(j,m){
										  	             var fields = m.getFields();
										  	             $.each(fields, function(k,l){
										  	               if(l.sId.indexOf(sField) != -1){
										  	                 if(enabled) {
										  	                   l.setEnabled(true);
										  	                 } else {
										  	                   l.setEnabled(false);
										  	                   if (sStatusKey == undefined || sStatusKey == null || sStatusKey == "00" )
										  	                   {
										  	                     l.setValue(""); 
										  	                   }
										  	                 }
										  	               }
										  	             });
										  	           }); 
										  	          });
										  	        }
										  	      } else {
										  	        if(enabled) {
										  	          this.getView().byId('extensionGroupElementzz_department').setEnabled(true);
										  	       } else {
										  	         if (sStatusKey == undefined || sStatusKey == null || sStatusKey == "00" )
										  	         {
										  	        	this.getView().byId('extensionGroupElementzz_department').setValue("");
										  	         }
										  	       this.getView().byId('extensionGroupElementzz_department').setEnabled(false);
										  	       }

										  	      }
										  	    //  }
										  	},	
//Fin - Editabilidad campo Informe - ANB - 25/08/2021		 										
										setValueHelpFieldsEditable : function() {
											var e = this.getView().byId(
													"extensionGroup");
											var E = this.getView().getModel(
													"extensionModel").getData();
											this.aDropDownGroupIndex = [];
											F.setValueHelpFieldsEditable(e, E,
													this.aDropDownGroupIndex,
													this.aDropDownEdit);
										},
										resetFormFieldValueState : function() {
											var e = this.getView().byId(
													"smartForm").check();
											for (var i = 0; i < e.length; i++) {
												sap.ui
														.getCore()
														.byId(e[i])
														.setValueState(
																sap.ui.core.ValueState.None);
											}
											this
													.getView()
													.byId("plannedTimePeriod")
													.setValueState(
															sap.ui.core.ValueState.None);
											this
													.getView()
													.byId("actualTimePeriod")
													.setValueState(
															sap.ui.core.ValueState.None);
										},
										onSaveBtnPress : function(e) {
											var i = false, I = false, b = false;
											I = this
													._checkPlannedTimePeriodField();
											i = this
													._checkRequiredSelectField();
											b = this
													._checkRequiredCdfNonSmartField();
											if (this.getView()
													.byId("smartForm").check().length > 0
													|| i || I || b) {
												M
														.showMsg(
																"msgTypeFailed",
																this
																		.getView()
																		.getModel(
																				"i18n")
																		.getResourceBundle()
																		.getText(
																				"MSG_CORRECT_HIGHLIGHTED_FIELDS"));
												return;
											} else {
												this._saveGeneralData(e);
											}
//Ini - Editabilidad campo Informe - ANB - 25/08/2021	
											//Cuando cambia el valor del campo Sociedad, se llama al método para habilitar/deshabilitar el campo 'Informe'
											var oObject = this.getView().getBindingContext().getObject(), 
											sObjectStatus = oObject.Status;
											//Se llama al método que comprueba la editabilidad del campo zz_report_id										   
											this.toggleReportIdEnable(this,"zz_report_id", "A001", this.getView().byId("inputCompany"),sObjectStatus,this.getView().byId("type").getContent().getSelectedKey());
//Fin - Editabilidad campo Informe - ANB - 25/08/2021											
										},
										_checkPlannedTimePeriodField : function() {
											var i = false;
											var p = this.getView().byId(
													"plannedTimePeriod");
											if (this.getView().getModel(
													"extensionModel").getData().PlannedStartDate.mandatory
													&& this.getView().getModel(
															"extensionModel")
															.getData().PlannedStartDate.editable) {
												if (p.getDateValue() === null
														|| p
																.getSecondDateValue() === null) {
													i = true;
												}
											}
											if (i) {
												p
														.setValueState(sap.ui.core.ValueState.Error);
											} else {
												p
														.setValueState(sap.ui.core.ValueState.None);
											}
											return i;
										},
										_checkRequiredSelectField : function() {
											var I = false;
											for (var i = 0; i < this.aDropDownEdit.length; i++) {
												var b = this.aDropDownEdit[i].element
														.getLabel()
														.getRequired();
												var c = this.aDropDownEdit[i].element
														.getFields()[0];
												if (b
														&& !(c.getSelectedKey() || c
																.getValue())) {
													c
															.setValueState(sap.ui.core.ValueState.Error);
													I = true;
												} else {
													c
															.setValueState(sap.ui.core.ValueState.None);
												}
											}
											return I;
										},
										_checkRequiredCdfNonSmartField : function() {
											var I = false;
											var e = this.getView().byId(
													"extensionGroup");
											var g = e.getGroupElements();
											for (var k = 0; k < g.length; k++) {
												for (var j = 0; j < g[k]
														.getFields().length; j++) {
													for (var i = 0; i < g[k]
															.getFields()[j]
															.getCustomData().length; i++) {
														if (g[k].getFields()[j]
																.getCustomData()[i]
																.getKey() === "richText") {
															if (g[k]
																	.getFields()[j]
																	.getRequired()
																	&& g[k]
																			.getFields()[j]
																			.getEditable()) {
																if (g[k]
																		.getFields()[j]
																		.getValue() === "") {
																	I = true;
																}
															}
														}
													}
												}
											}
											return I;
										},
										_saveGeneralData : function() {
											if (this._validateUI()) {
												var d = this.getView()
														.getModel();
												d.setUseBatch(false);
												this.getView().setBusy(true);
												var p = this.getView()
														.getBindingContext()
														.getPath();
												if (!jQuery
														.isEmptyObject(this.oSaveData)) {
													d
															.update(
																	p,
																	this.oNewAuditData,
																	{
																		merge : true,
																		success : jQuery
																				.proxy(
																						function() {
																							d
																									.refresh();
																							d
																									.setUseBatch(true);
																							this
																									.getView()
																									.setBusy(
																											false);
																							M
																									.showMsg(
																											"msgTypeSuccessful",
																											this
																													.getView()
																													.getModel(
																															"i18n")
																													.getResourceBundle()
																													.getText(
																															"EDIT_AUDIT_SUCCESS"));
																							this
																									.setSmartFormToDisplayMode();
																						},
																						this),
																		error : jQuery
																				.proxy(
																						function(
																								r) {
																							if (r.statusCode === 412) {
																								M
																										.showMsg(
																												"msgTypeFailed",
																												this
																														.getView()
																														.getModel(
																																"i18n")
																														.getResourceBundle()
																														.getText(
																																"msgEtagCheckFail"));
																							} else {
																								M
																										.showMsg(
																												"msgTypeFailed",
																												this
																														.getView()
																														.getModel(
																																"i18n")
																														.getResourceBundle()
																														.getText(
																																"EDIT_AUDIT_FAIL"));
																							}
																							d
																									.setUseBatch(true);
																							this
																									.getView()
																									.setBusy(
																											false);
																						},
																						this),
																		refreshAfterChange : false
																	});
												} else {
													d.setUseBatch(true);
													this.getView().setBusy(
															false);
													this
															.setSmartFormToDisplayMode();
												}
											}
										},
										_validateUI : function() {
											var b = false;
											this.oNewAuditData = {};
											var s = this.getView().byId(
													"smartForm");
											var e = this.getView().getModel(
													"extensionModel").getData();
											this.oNewAuditData = F
													.saveSmartForm(s, e);
											var o = sap.ui.core.format.NumberFormat
													.getFloatInstance({
														maxFractionDigits : 2,
														parseAsString : true
													});
											if (this.getView().byId(
													"estimatedCost").getValue() !== null) {
												this.oNewAuditData.EstimatedCost = o
														.parse(this
																.getView()
																.byId(
																		"estimatedCost")
																.getValue());
											}
											if (this.getView().byId(
													"actualCost").getValue() !== null) {
												this.oNewAuditData.ActualCost = o
														.parse(this
																.getView()
																.byId(
																		"actualCost")
																.getValue());
											}
											if (this.getView().getModel(
													"extensionModel").getData().Company.editable) {
												this.oNewAuditData.Company = this
														.getView().byId(
																"inputCompany")
														.getCustomData()[0]
														.getValue("key");
											}
											if (this.getView().getModel(
													"extensionModel").getData().Country.editable) {
												this.oNewAuditData.Country = this
														.getView().byId(
																"inputCountry")
														.getCustomData()[0]
														.getValue("key");
											}
											if (this.getView().getModel(
													"extensionModel").getData().EstimatedEffort.editable) {
												if (this.getView().byId(
														"esitmatedEffort")
														.getValue() === "") {
													this.oNewAuditData.EstimatedEffort = o
															.format(this
																	.getView()
																	.byId(
																			"esitmatedEffort")
																	.getValue());
												} else {
													this.oNewAuditData.EstimatedEffort = o
															.parse(this
																	.getView()
																	.byId(
																			"esitmatedEffort")
																	.getValue());
												}
											}
											if (this.getView().getModel(
													"extensionModel").getData().ActualEffort.editable) {
												if (this.getView().byId(
														"actualEffort")
														.getValue() === "") {
													this.oNewAuditData.ActualEffort = o
															.format(this
																	.getView()
																	.byId(
																			"actualEffort")
																	.getValue());
												} else {
													this.oNewAuditData.ActualEffort = o
															.parse(this
																	.getView()
																	.byId(
																			"actualEffort")
																	.getValue());
												}
											}
											if (this.getView().getModel(
													"extensionModel").getData().ActualStartDate.editable) {
												this.oNewAuditData.ActualStartDate = this
														._buildDateTypeFields(this
																.getView()
																.byId(
																		"actualTimePeriod")
																.getDateValue());
												this.oNewAuditData.ActualEndDate = this
														._buildDateTypeFields(this
																.getView()
																.byId(
																		"actualTimePeriod")
																.getSecondDateValue());
											}
											if (this.getView().getModel(
													"extensionModel").getData().PlannedStartDate.editable) {
												this.oNewAuditData.PlannedStartDate = this
														._buildDateTypeFields(this
																.getView()
																.byId(
																		"plannedTimePeriod")
																.getDateValue());
												this.oNewAuditData.PlannedEndDate = this
														._buildDateTypeFields(this
																.getView()
																.byId(
																		"plannedTimePeriod")
																.getSecondDateValue());
											}
											this.newTags = [];
											var t = this.getView().byId(
													"multiinput").getTokens();
											for (var i = 0; i < t.length; i++) {
												this.newTags.push(t[i]
														.getText());
											}
											this.oNewAuditData.Tags = this.newTags
													.join(";");
											this.oSaveData = this._compareData(
													this.oAuditDataInServer,
													this.oNewAuditData);
											if (this.getView().getModel(
													"extensionModel").getData().Title.editable) {
												if (!this.oNewAuditData.Title
														|| this.oNewAuditData.Title === "") {
													this
															.getView()
															.byId("title")
															.setValueState(
																	sap.ui.core.ValueState.Error);
													b = true;
												}
											}
											if (b) {
												M
														.showMsg(
																"msgTypeFailed",
																this
																		.getView()
																		.getModel(
																				"i18n")
																		.getResourceBundle()
																		.getText(
																				"MSG_REQUIRED_FIELD"));
												return false;
											}
											return true;
										},
										_formatTimePeriod : function(s, e) {
											if (s !== null && e !== null) {
												s = f.formatRecordDate(s);
												e = f.formatRecordDate(e);
												return f.formatDate(s) + " - "
														+ f.formatDate(e);
											}
											return "";
										},
										_buildDateTypeFields : function(v) {
											if (v !== null) {
												var y = v.getFullYear()
														.toString();
												var m = (v.getMonth() + 1)
														.toString();
												var d = v.getDate().toString();
												v = y
														+ "-"
														+ (m[1] ? m : "0"
																+ m[0])
														+ "-"
														+ (d[1] ? d : "0"
																+ d[0])
														+ "T00:00:00";
												return v;
											}
											return null;
										},
										_compareData : function(o, n) {
											var r = {};
											var N, O;
											if (o !== undefined) {
												for ( var b in n) {
													N = n[b];
													O = o[b];
													if (n[b]
															&& o[b]
															&& typeof n[b] === "object"
															&& typeof o[b] === "object"
															&& n[b]
																	.toISOString()
															&& o[b]
																	.toISOString()) {
														N = n[b].toISOString()
																.substring(0,
																		19);
														O = o[b].toISOString()
																.substring(0,
																		19);
													} else if (o[b]
															&& typeof n[b] !== "object"
															&& typeof o[b] === "object"
															&& o[b]
																	.toISOString()) {
														O = o[b].toISOString()
																.substring(0,
																		19);
													} else if (n[b]
															&& typeof n[b] === "object"
															&& typeof o[b] !== "object"
															&& n[b]
																	.toISOString()) {
														N = n[b].toISOString()
																.substring(0,
																		19);
													}
													if (N !== O) {
														r[b] = n[b];
													}
												}
												return r;
											}
											return n;
										},
										setSmartFormToDisplayMode : function() {
											this
													.setDropDownFieldsEditableToFalse();
											var e = this.getView().byId(
													"extensionGroup");
											var E = this.getView().getModel(
													"extensionModel").getData();
											F.setCdfNonSmartFieldsStatus(e, E,
													"display");
											this
													._setButtonVisibility("DISPLAY");
											this.getView().getModel()
													.resetChanges();
										},
										onCancelBtnPress : function() {
											if (this.getView().getModel(
													"extensionModel").getData().SmartForm.editable === true) {
												this.getView().getModel()
														.resetChanges();
												this
														.setDropDownFieldsEditableToFalse();
												var e = this.getView().byId(
														"extensionGroup");
												var E = this
														.getView()
														.getModel(
																"extensionModel")
														.getData();
												F.setCdfNonSmartFieldsStatus(e,
														E, "display");
												this
														._setButtonVisibility("DISPLAY");
												this.oMultiInput
														.removeAllTokens();
												this.oMultiInput.setValue();
											}
											this
													.getView()
													.byId("actualEffort")
													.setValueState(
															sap.ui.core.ValueState.None);
											this
													.getView()
													.byId("esitmatedEffort")
													.setValueState(
															sap.ui.core.ValueState.None);
										},
										setDropDownFieldsEditableToFalse : function() {
											for (var i = 0; i < this.aDropDownGroupIndex.length; i++) {
												this
														.getView()
														.byId("extensionGroup")
														.removeGroupElement(
																this
																		.getView()
																		.byId(
																				"extensionGroup")
																		.getGroupElements()[this.aDropDownGroupIndex[i].index]);
												this
														.getView()
														.byId("extensionGroup")
														.insertGroupElement(
																this.aDropDownGroupIndex[i].element,
																this.aDropDownGroupIndex[i].index);
											}
										},
										_setButtonVisibility : function(m) {
											if (m === "EDIT") {
												this.oViewModel.setProperty(
														"/bFormDisplay", false);
												if (this.getView().getModel(
														"extensionModel")
														.getData().ActualStartDate.editable) {
													this.oViewModel
															.setProperty(
																	"/bActualTimePeriodDisplay",
																	false);
												}
												this.oViewModel.setProperty(
														"/bTagDisplay", false);
											} else if (m === "DISPLAY") {
												this.oViewModel.setProperty(
														"/bCompanyEdit", false);
												this.oViewModel.setProperty(
														"/bCountryEdit", false);
												this.oViewModel
														.setProperty(
																"/bPlannedTimePeriodDisplay",
																true);
												this.oViewModel
														.setProperty(
																"/bActualTimePeriodDisplay",
																true);
												this.oViewModel.setProperty(
														"/bTagDisplay", true);
												this.oViewModel.setProperty(
														"/bFormDisplay", true);
											} else {
												this.oViewModel.setProperty(
														"/bCompanyEdit", false);
												this.oViewModel.setProperty(
														"/bCountryEdit", false);
												this.oViewModel
														.setProperty(
																"/bPlannedTimePeriodDisplay",
																true);
												this.oViewModel
														.setProperty(
																"/bActualTimePeriodDisplay",
																true);
												this.oViewModel.setProperty(
														"/bTagDisplay", true);
												this.oViewModel.setProperty(
														"/bFormDisplay", true);
											}
										},
										_restoreSelectFieldStatus : function() {
											for (var i = 0; i < this.aDropDownEdit.length; i++) {
												var c = this.aDropDownEdit[i].element
														.getFields()[0];
												c
														.setValueState(sap.ui.core.ValueState.None);
											}
										},
										setTokens : function() {
											this.oMultiInput.removeAllTokens();
											this.oMultiInput.setValue();
											var o = this.getView().byId(
													"tokenDisplay").getTokens();
											var b = [];
											for (var i = 0; i < o.length; i++) {
												b.push({
													TagName : o[i].getText(),
													TagKey : o[i].getKey()
												});
											}
											var l = b.length;
											var c = [];
											for (var j = 0; j < l; j++) {
												var t = new sap.m.Token({
													text : b[j].TagName,
													key : b[j].TagKey
												});
												this.oMultiInput.addToken(t);
												c.push(b[j].TagName);
											}
											this.oAuditDataInServer.Tags = c
													.join(";");
										},
										_multiInputValidator : function(b) {
											var t = b.text;
											if (t.indexOf(";") !== -1) {
												M
														.showMsg(
																"msgTypeFailed",
																this
																		.getView()
																		.getModel(
																				"i18n")
																		.getResourceBundle()
																		.getText(
																				"TAGS_MSG_FORBIDDEN_CHAR"));
												return sap.m.MultiInput.WaitForAsyncValidation;
											}
											return new sap.m.Token({
												key : t,
												text : t
											});
										},
										onChangeCheck : function(e) {
											if (e.getSource().getProperty(
													"textLabel") === "Title"
													&& e.getParameters().newValue === "") {
												this
														.getView()
														.byId("title")
														.setValueStateText(
																this
																		.getView()
																		.getModel(
																				"i18n")
																		.getResourceBundle()
																		.getText(
																				"MSG_REQUIRED_TITLE_FIELD"));
											} else if (e.getSource()
													.getProperty("textLabel") === "Title"
													&& e.getParameters().newValue !== "") {
												this
														.getView()
														.byId("title")
														.setValueState(
																sap.ui.core.ValueState.None);
											}
										},
										onEstimatedEffortCheck : function(e) {
											this._negativeNumberCheck(e,
													"esitmatedEffort");
										},
										onEstimatedCostCheck : function(e) {
											this._negativeNumberCheck(e,
													"estimatedCost");
										},
										onActualEffortCheck : function(e) {
											this._negativeNumberCheck(e,
													"actualEffort");
										},
										onActualCostCheck : function(e) {
											this._negativeNumberCheck(e,
													"actualCost");
										},
										_negativeNumberCheck : function(e, b) {
											var c = new Map(
													[
															[
																	"esitmatedEffort",
																	"MSG_REQUIRED_EFFORT_FIELD" ],
															[ "actualEffort",
																	"MSG_REQUIRED_EFFORT_FIELD" ],
															[ "estimatedCost",
																	"MSG_REQUIRED_COST_FIELD" ],
															[ "actualCost",
																	"MSG_REQUIRED_COST_FIELD" ] ]);
											var o = sap.ui.core.format.NumberFormat
													.getFloatInstance({
														maxFractionDigits : 2,
														parseAsString : false,
														emptyString : 0
													});
											var d = o
													.parse(e.getParameters().newValue);
											if (Math.sign(d) === -1
													|| isNaN(Math.sign(d))) {
												this
														.getView()
														.byId(b)
														.setValueStateText(
																this
																		.getView()
																		.getModel(
																				"i18n")
																		.getResourceBundle()
																		.getText(
																				c
																						.get(b)))
														.setValueState(
																sap.ui.core.ValueState.Error);
											} else if (Math.sign(d) !== -1) {
												this
														.getView()
														.byId(b)
														.setValueState(
																sap.ui.core.ValueState.None);
											}
										},
										handleCountryValueHelp : function(e) {
											this.inputId = e.getSource()
													.getId();
											this._openValueHelpDialog("LAND1");
										},
										handleCompanyValueHelp : function(e) {
											this.inputId = e.getSource()
													.getId();
											this
													._openValueHelpDialog("GRCAUD_COMPANY_CODE");
										},
										_openValueHelpDialog : function(v) {
											var i = "/DataElementSet('" + v
													+ "')/NameValuePairs";
											if (this._ValueHelpDialog) {
												this._ValueHelpDialog.destroy();
											}
											this._ValueHelpDialog = new sap.m.SelectDialog(
													{
														title : "{i18n>generalSearchDialog}",
														items : {
															path : i,
															template : new sap.m.StandardListItem(
																	{
																		title : "{Name}",
																		description : "{Value}"
																	})
														},
														growingThreshold : 20,
														search : this.handleSearch
																.bind(this),
														cancel : this.handleValueHelpClose
																.bind(this),
														confirm : this.handleValueHelpClose
																.bind(this)
													});
											this.getView().addDependent(
													this._ValueHelpDialog);
											this._ValueHelpDialog.open();
										},
										onLiveChange : function(e) {
											var n = e.getSource().getValue();
											if (n === "") {
												var i = this.getView().byId(
														e.getSource().getId());
												i.setValue(n);
												i.removeAllCustomData();
												i
														.addCustomData(new sap.ui.core.CustomData(
																{
																	key : "key",
																	value : n
																}));
												i
														.setValueState(sap.ui.core.ValueState.None);
											}
//Ini - Editabilidad campo Informe - ANB - 25/08/2021
											//Cuando cambia el valor del campo Sociedad, se llama al método para habilitar/deshabilitar el campo 'Informe'
											// Si el campo modificado es company, se comprueba la editabilidad del campo zz_report_id
											if(i.sId.indexOf('inputCompany') !== -1){
												var oObject = this.getView().getBindingContext().getObject(), 
												sObjectStatus = oObject.Status;
												this.toggleReportIdEnable(this,"zz_report_id", "A001", i,sObjectStatus,this.getView().byId("type").getContent().getSelectedKey());
											}
//Fin - Editabilidad campo Informe - ANB - 25/08/2021											
										},
										handleSearch : function(e) {
											var q = e.getParameter("value");
											var b = [];
											b
													.push(new sap.ui.model.Filter(
															"Name",
															sap.ui.model.FilterOperator.Contains,
															q));
											b
													.push(new sap.ui.model.Filter(
															"Value",
															sap.ui.model.FilterOperator.Contains,
															q));
											e
													.getSource()
													.getBinding("items")
													.filter(
															b,
															sap.ui.model.FilterType.Application);
										},
										handleValueHelpClose : function(e) {
											var s = e
													.getParameter("selectedItem");
											if (s) {
												var i = this.getView().byId(
														this.inputId);
												i.setValue(s.getDescription());
												i.removeAllCustomData();
												i
														.addCustomData(new sap.ui.core.CustomData(
																{
																	key : "key",
																	value : s
																			.getTitle()
																}));
												i
														.setValueState(sap.ui.core.ValueState.None);
											}
											e.getSource().getBinding("items")
													.filter([]);
//Ini - Editabilidad campo Informe - ANB - 25/08/2021	
											//Cuando cambia el valor del campo Sociedad, se llama al método para habilitar/deshabilitar el campo 'Informe'
											// Si el campo modificado es company, se comprueba la editabilidad del campo zz_report_id
											if(i.sId.indexOf('inputCompany') !== -1){
												var oObject = this.getView().getBindingContext().getObject(), 
												sObjectStatus = oObject.Status;
												this.toggleReportIdEnable(this,"zz_report_id", "A001", i,sObjectStatus,this.getView().byId("type").getContent().getSelectedKey());
											}	
//Fin - Editabilidad campo Informe - ANB - 25/08/2021											
										},
										onSuggestionItemSelected : function(e) {
											var s = e
													.getParameter("selectedItem");
											if (s) {
												e.getSource().setValue(
														s.getAdditionalText());
												e.getSource()
														.removeAllCustomData();
												e
														.getSource()
														.addCustomData(
																new sap.ui.core.CustomData(
																		{
																			key : "key",
																			value : s
																					.getKey()
																		}));
												e
														.getSource()
														.setValueState(
																sap.ui.core.ValueState.None);
											}
										},
										handleSuggest : function(e) {
											var t = e
													.getParameter("suggestValue");
											var b = [];
											var o = {};
											if (t) {
												b
														.push(new sap.ui.model.Filter(
																"Name",
																sap.ui.model.FilterOperator.Contains,
																t));
												b
														.push(new sap.ui.model.Filter(
																"Value",
																sap.ui.model.FilterOperator.Contains,
																t));
												o = new sap.ui.model.Filter(b,
														false);
											}
											e.getSource().getBinding(
													"suggestionItems").filter(
													[ o ]);
										},
										onExit : function() {
											sap.ui
													.getCore()
													.getEventBus()
													.unsubscribe(
															"sap.grc.acs.aud.audit.EventBus",
															"resetBlockToDisplayMode",
															this.setSmartFormToDisplayMode,
															this);
											F
													.destoryElements(this.aDropDownEdit);
											var e = this.getView().byId(
													"extensionGroup");
											F.destoryNonSmartFieldElements(e);
										}
									});
				});
