sap.ui.define(["sap/uxap/BlockBase"],
	function (BlockBase) {
		"use strict";

		return BlockBase.extend("sap.grc.acs.aud.audit.track.extended.FindRel.CompFindRel", {
			metadata: {
				views: {
					Collapsed: {
						viewName: "sap.grc.acs.aud.audit.track.extended.findRel.view.Finding",
						type: "XML"
					},
					Expanded: {
						viewName: "sap.grc.acs.aud.audit.track.extended.findRel.view.Finding",
						type: "XML"
					} 
				}
			}
		});

	});
