/*
 * Copyright (C) 2009-2020 SAP SE or an SAP affiliate company. All rights reserved.
 */
//PPM100076335 - Pestaña Encuestas 03/10/2022
sap.ui.define([ "sap/uxap/BlockBase" ], function(B) {
	"use strict";
	return B.extend("sap.grc.acs.aud.audit.track.extended.block.Encuestas", {
		metadata : {
			views : {
				Collapsed : {
					viewName : "sap.grc.acs.aud.audit.track.extended.block.view.Encuestas",
					type : "XML"
				}, 
				Expanded : {
					viewName : "sap.grc.acs.aud.audit.track.extended.block.view.Encuestas",
					type : "XML"
				}
			}
		}
	});
});
