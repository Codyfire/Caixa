sap.ui.define([ "sap/uxap/BlockBase" ], function(B) {
	"use strict";
	return B.extend("sap.grc.acs.aud.audit.block.General", {
		metadata : {
			views : {
				Collapsed : {
					viewName : "sap.grc.acs.aud.audit.track.extended.block.view.GeneralCustom",
					type : "XML"
				},
				Expanded : {
					viewName : "sap.grc.acs.aud.audit.track.extended.block.view.GeneralCustom",
					type : "XML"
				}
			}
		}
	});
});
