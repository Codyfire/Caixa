/*
 * Copyright (C) 2009-2020 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui
		.define(
				[ "sap/ui/core/mvc/Controller", "sap/ui/model/Filter",
						"sap/grc/acs/lib/aud/utils/MenuItemUtils",
						"sap/grc/acs/lib/aud/utils/ComponentUtil",
						"sap/grc/acs/lib/aud/utils/MessageUtil",
						"sap/ui/model/Sorter" ],
				function(C, F, M, a, b, S) {
					"use strict";
					return C
							.extend(
									"sap.grc.acs.aud.audit.track.extended.block.FindRel",
									{
										onInit : function() {
											this._oComponent = a.getComponentById(this.getView().getId());
											//Modificación PRL 28/07/2021 - Obtener si debe mostrarse los botones de creado y borrado
											this.setVisibility();
											sap.ui.getCore().getEventBus().subscribe("sap.grc.aud.audit.EventBus","setObsRelVisibilitytrack",this.setVisibility,this);
											//Fin Modificación PRL 28/07/2021 - Obtener si debe mostrarse los botones de creado y borrado

											this.tableContentModel = new sap.ui.model.json.JSONModel();
											this.sModelData = {
												FindingsData: [], 
											};
											this.tableContentModel.setData(this.sModelData);
											this.getView().setModel(this.tableContentModel, "findingRelacionados");
											sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.audit.EventBus","resetBlockToDisplayMode",this.onRefresh,	this);
											this.modelFindRel = this._oComponent.getModel("MyFindingRel");
								            this.getView().byId("idFindRelAssgnTable").setModel(this.modelFindRel,"findRel");								         
								            this.getDataFromOdata(); 
								            // Ini mod RGB 01/12/2021
								            sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.audit.EventBus","getFindRelTrk", this.getDataFromOdata, this);								             
								            // fin mod RGB 01/12/2021
										},
										onExit : function() {
											sap.ui.getCore().getEventBus().unsubscribe("sap.grc.acs.aud.audit.EventBus","resetBlockToDisplayMode",this.onRefresh,this);
										},
										setVisibility:function(){
											//Modificación PRL 28/07/2021 - Obtener si debe mostrarse los botones de creado y borrado
											var currentUser = sap.ushell.Container.getService("UserInfo").getId();
											var dbKey = sap.ui.getCore().getModel("auditKeyModel").getData().id;
											var spath1 ="/GRCAUD_IV_AuditSectionMenuItem(DBKey=guid'"+dbKey+"',ObjectType=" +
											"'AUDIT',ScenarioID='AuditEngagement-track',SectionID='FIND',Action='CREATE_FINDING',UserID='"+currentUser+"')";
											var spath2 = "/GRCAUD_IV_AuditSectionMenuItem(DBKey=guid'"+dbKey+"',ObjectType=" +
											"'AUDIT',ScenarioID='AuditEngagement-track',SectionID='FIND',Action='DELETE_FINDING',UserID='"+currentUser+"')";
											//Modificación PRL 21/09/2021 - Por defecto ponemos los botones ocultos
											if(this.getView().byId("btn_addFndRel")){
											this.getView().byId("btn_addFndRel").setVisible(false);
											this.getView().byId("btn_addFndRel").setEnabled(false);
											}
											if(this.getView().byId("btn_delFndRel")){
											this.getView().byId("btn_delFndRel").setVisible(false);
											this.getView().byId("btn_delFndRel").setEnabled(false);
											}
																						
											//Fin Modificación PRL 21/09/2021 - Por defecto ponemos los botones ocultos
											
											var deleteEnabled,createEnabled;
											
											if (this.getOwnerComponent() !== undefined){
											if (this.getOwnerComponent().getModel().getObject(spath1) !== undefined &&
													this.getOwnerComponent().getModel().getObject(spath2) !== undefined ){
												
											
											createEnabled = this.getOwnerComponent().getModel().getObject(spath1).Enable;
											deleteEnabled = this.getOwnerComponent().getModel().getObject(spath2).Enable;
											
											if(this.getView().byId("btn_addFndRel")){					
												if( createEnabled == "X"){
													this.getView().byId("btn_addFndRel").setVisible(true);
													this.getView().byId("btn_addFndRel").setEnabled(true);
												}else{
													this.getView().byId("btn_addFndRel").setVisible(false);
													this.getView().byId("btn_addFndRel").setEnabled(false);
												};
												};
												if(this.getView().byId("btn_delFndRel")){	
												if( deleteEnabled == "X"){
													this.getView().byId("btn_delFndRel").setVisible(true);
													this.getView().byId("btn_delFndRel").setEnabled(true);
												}else{
													this.getView().byId("btn_delFndRel").setVisible(false);
													this.getView().byId("btn_delFndRel").setEnabled(false);
												};
												};
											} else {
											/**
											 * ******** INI PRUEBA BOTONES DESHABILITADOS ****
											*/
												var that = this;
												var sPath = "/GRCAUD_CV_TrackOngoingAudit(guid'"+dbKey+"')/to_MenuItems"
												this.getOwnerComponent().getModel().read(sPath, {
												success: function (data, response) {
//													var elements = data.results.filter(function (item) {
//														if(item.SectionID === 'FIND')
//														return item;
//													});
													var elements = []; 
													elements = data.results.filter( item => item.SectionID == 'FIND');
													

													if (elements.length > 0) {
														Array.prototype.forEach.call(elements, item=>{
															if(item.Action === 'CREATE_FINDING'){
																
																	createEnabled = item.Enable;																	
																
															}else if(item.Action === 'DELETE_FINDING'){
																deleteEnabled = item.Enable;
															}													
														});													
													}
													if(that.getView().byId("btn_addFndRel")){					
														if( createEnabled == "X"){
															that.getView().byId("btn_addFndRel").setVisible(true);
															that.getView().byId("btn_addFndRel").setEnabled(true);
														}else{
															that.getView().byId("btn_addFndRel").setVisible(false);
															that.getView().byId("btn_addFndRel").setEnabled(false);
														};
														};
														if(that.getView().byId("btn_delFndRel")){	
														if( deleteEnabled == "X"){
															that.getView().byId("btn_delFndRel").setVisible(true);
															that.getView().byId("btn_delFndRel").setEnabled(true);
														}else{
															that.getView().byId("btn_delFndRel").setVisible(false);
															that.getView().byId("btn_delFndRel").setEnabled(false);
														};
														};	
												},
												failed: function (oData, response) {
													that.getView().byId("idFindRelAssgnTable").setBusy(false)
												}
											
											});
																								
											}
											
											/**
											 * ******** FIN PRUEBA BOTONES DESHABILITADOS ****
											*/
											
											};
											//Fin Modificación PRL 28/07/2021 - Obtener si debe mostrarse los botones de creado y borrado
											},
										createHeaderButton : function(i, c) {
											return M.createButtonTemplate(i, c,
													this);
										},
										onBeforeRebindTable : function(e) {
											e.getParameter("bindingParams").sorter
													.push(new S("ID"));
										},
										onUpdateFinished : function() {
											if (this.changeSequenceFlag) {
												this.changeSequenceFlag = false;
												return;
											} else {
												this.changeSequenceFlag = false;
												this.getView().byId(
														"colSequence")
														.setVisible(false);
											}
										},
										onSearch : function(e) {
											var t = [];
											var q = e.getParameter("query");
											var T = [];
											t = [
													new F(
															"ID",
															sap.ui.model.FilterOperator.Contains,
															q),
													new F(
															"Title",
															sap.ui.model.FilterOperator.Contains,
															q) ];
											T = new sap.ui.model.Filter(t,
													false);
											this
													.getView()
													.byId("idFindRelAssgnTable")
													.getBinding("items")
													.filter(
															T,
															sap.ui.model.FilterType.Application);
										},
										
										onPressRow: function (e) {
											
											
											var c = sap.ushell.Container.getService("CrossApplicationNavigation");
									var f = this.getView().getModel(
											"intentConfig").getData().findingIntent;
									var d = {
										target : {
											semanticObject : f.semanticObject,
											action : f.action
										},
										params : {
											"DBKey" :  this._convertFindingKey(e.getSource().mAggregations.cells[8].mProperties.text)
										}
									};
									var s = c.hrefForExternal(d);
									window.open(s, "_self");				
									},
									
									_convertFindingKey:function(input){
										var output = new Array();
										var chr1, chr2, chr3;
										var enc1, enc2, enc3, enc4;
										var i = 0;

										var orig_input = input;
										input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
										if (orig_input != input)
											console.error(
												"Warning! Characters outside Base64 range in input string ignored."
											);
										if (input.length % 4) {
											console.error("Error: Input length is not a multiple of 4 bytes.");
											return "";
										}
										var keyStr =
											"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
										var j = 0;
										while (i < input.length) {
											enc1 = keyStr.indexOf(input.charAt(i++));
											enc2 = keyStr.indexOf(input.charAt(i++));
											enc3 = keyStr.indexOf(input.charAt(i++));
											enc4 = keyStr.indexOf(input.charAt(i++));

											chr1 = (enc1 << 2) | (enc2 >> 4);
											chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
											chr3 = ((enc3 & 3) << 6) | enc4;

											output[j++] = chr1;
											if (enc3 != 64) output[j++] = chr2;
											if (enc4 != 64) output[j++] = chr3;
										}


									var key =	Array.from(output, function (byte) {
									return ("0" + (byte & 0xff).toString(16)).slice(-2);
									}).join("").replace(/(.{8})(.{4})(.{4})(.{4})(.{12})/, "$1-$2-$3-$4-$5");			
									
									return key;
									},

									
										onPressPersonalization : function() {
											var p = this.getView().byId(
													"findSmartTable")._oPersController;
											if (!p._oDialog) {
												p.openDialog();
												var P = p._oDialog;
												var f = this;
												P.attachOk(function() {
													f.getView().byId(
															"findSmartTable")
															.rebindTable(true);
												});
											}
										},
										
										onDel_findrel: function (oEvent) {
											var aSelectedItems = this.getView().byId("idFindRelAssgnTable").getSelectedItems();
											if(aSelectedItems.length === 0){
												b.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("MSG_SELECT_ONE"));
												return;
											}
											var oController = this;
											this.auditKey = this.getView().getBindingContext().getObject().DBKey;
											this.getView().byId("idFindRelAssgnTable").setBusy(true)
//Inicio - ANB - 27.08.2021	- Quitar el foreach para IE 11	
											/*aSelectedItems.forEach(selectedItem => {
												oController._deleteFinding(selectedItem);
											});	*/
											for( var i = 0; i> aSelectedItems.length;i++){
												oController._deleteFinding(aSelectedItems[i])	
											};
//Fin - ANB - 27.08.2021	- Quitar el foreach para IE 11											
										},
										
										_deleteFinding: function(selectedItem){										
											/*var itemData = selectedItem
											.getModel("findRel")
											.getProperty(selectedItem.getBindingContext("findRel").getPath());*/
											var itemData = selectedItem.getBindingContext("findRel").getObject();
											
											var auditKey = this.auditKey.replaceAll("-", "").toUpperCase();
											var sPath =
												"/AuditFindRelSet(Key=binary'" + auditKey + "')/FindRelAssignments";
											var that = this;
											var oDataModel = new sap.ui.model.odata.ODataModel(
													"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",
													false
											);
											
											oDataModel.read(sPath, {
												success: function (data, response) {
													var element = data.results.filter(function (item) {
														return item.ReferenceKey == itemData.Key;
													});

													if (element.length > 0) {
														var sPath = element[0].__metadata.uri;
														var result = that._deleteAssignmentFindRel(
															sPath,
															element[0],
															selectedItem,
															itemData
														);
													}
												},
												failed: function (oData, response) {
													that.getView().byId("idFindRelAssgnTable").setBusy(false)
												},
											});
											
											/*this._deleteAssignmentFindRel(
												aSelectedItems[0].getBindingContext().getObject().__metadata.id,
												aSelectedItems[0].getBindingContext().getObject()
											);*/
										},
										
										_deleteAssignmentFindRel: function (sPath, data, selectedItem, itemData) {
											var that = this;
											var aBatchOperations = [];
											var oDataModel = new sap.ui.model.odata.ODataModel(
												"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",
												false
											);

											aBatchOperations.push(
												oDataModel.createBatchOperation(data.__metadata.uri, "DELETE")
											);
											oDataModel.addBatchChangeOperations(aBatchOperations);
											//oDataModel.refreshSecurityToken();
											oDataModel.submitBatch(function (oData, oResponse, aErrorResponse) {
												if (aErrorResponse.length > 0) { // failed
													that.getView().byId("idFindRelAssgnTable").setBusy(false);												
												} else { // Borrado OK
													that.getDataFromOdata();
													that.getView().byId("idFindRelAssgnTable").setBusy(false);
												}
											});
										},
										
										AUDIT_DEL_DIM_TO_AUDIT_ASMNT: function(){
											var aSelectedItems = this.getView().byId("idFindRelAssgnTable").getSelectedItems();
											//var sPath = "";
											var that = this;
											var oDataModel = new sap.ui.model.odata.v2.ODataModel(
												"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",
												false
											);
											if(aSelectedItems.length === 0){
												//MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("MSG_SELECT_ONE"));
												return;
											}
											oDataModel.setUseBatch(true);
											oDataModel.setDeferredGroups(["removeFindRel"]);
											
											var auditKey = sap.ui.getCore().getModel("auditKeyModel").getData().id
											auditKey = auditKey.replaceAll("-", "").toUpperCase();
											var sPath =
												"/AuditFindRelSet(Key=binary'" + auditKey + "')/FindRelAssignments";
											var that = this;
											var oDataModelRel = new sap.ui.model.odata.ODataModel(
													"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",
													false
											);
											
											oDataModelRel.read(sPath, {
												success: function (data, response) {
//Inicio - ANB - 27.08.2021	- Quitar el foreach para IE 11		
													aSelectedItems.forEach(selectedItem => {
														var element = data.results.filter(function (item) {
															return item.ReferenceKey == selectedItem.getBindingContext("findRel").getObject().Key;
														});

														if (element.length > 0) {
															var uri = element[0].__metadata.uri;
															
															var pos = uri.indexOf("/AssignmentSet");
															uri = uri.substr(pos,uri.length);
															
															oDataModel.remove(uri, {
																async: true,
																groupId: "removeFindRel"
															});
														}
													});
																						
													oDataModel.submitChanges({
														groupId: "removeFindRel",
														success: jQuery.proxy(function() {
																	oDataModel.setUseBatch(false);
																	that.getDataFromOdata();

														}, this),
														error: jQuery.proxy(function() {
													        	//MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("REMOVE_DIM_TO_AUDIT_FAILED"));
														}, this)
													});
													
												},
												failed: function (oData, response) {
													that.getView().byId("idFindRelAssgnTable").setBusy(false)
												},
											});											
										},
										
										onAdd_findrel : function(oEvent) {
											var oSource = oEvent.getSource();
											var oDataModel = this.getView().getModel();
											var sectionBindingModel = this.getView().getModel("sectionBindingConfig");
											this.auditKey = this.getView().getBindingContext().getObject().DBKey;
											
											if(this.toBeAddFindRelSmartTable){
												this.toBeAddFindRelSmartTable.destroy();
											}
											
											this.toBeAddFindRelSmartTable = sap.ui.xmlfragment("sap.grc.acs.aud.audit.track.extended.block.fragment.ToBeAddFindRel", this);
											
										
											var that = this;
											//Realizar llamada al back para obtener el listado de findinds relacionados
											var findModel = new sap.ui.model.odata.v2.ODataModel(
													"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false ////"ZGRCAUD_ENH_SRV"
												
											);

											//findModel.refreshSecurityToken();
											//sAuditKey = oEvent.data.Audit.Key;

											var oData = {},
												aBatchOperations = [];										
												
											var url = "/AuditSet(guid'" + this.auditKey + "')/AuditToFindRel";
											//Limpiamos los registros seleccionados por si los hubiera de navegaciones anteriores
											try {
												that.getView().getContent()[0].getContent()[1].removeSelections();
											} catch (err) {}

//											//limpiamos la tabla por si hubiera registros de consultas anteriores
											that.sModelData.FindingsData = [];
											that.tableContentModel.refresh();
											
											findModel.read(url, {
												success: function (data, response) {

													if (data && data.results && data.results.length > 0) {
														that.sModelData.FindingsData = data.results;
														that.tableContentModel.refresh();																											
													} else {
														console.log({ err: "No results" });
													}
													that.oValueHelpDialog.setBusy(false);
												},
												failed: function (oData, response) {
													that.oValueHelpDialog.setBusy(false);
													alert("Failed to get InputHelpValues from service!");
												},
											});

											
											this.toBeAddFindRelSmartTable.setModel(this.tableContentModel);
											var i18nModel = this.getView().getModel( "i18n");
											this.toBeAddFindRelSmartTable.setModel(i18nModel, "i18n");
											//this.toBeAddFindRelSmartTable.setTableBindingPath(url);
											var oController = this;
											this.oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
												title: this.getView().getModel("i18n").getResourceBundle().getText("labelFindings"),
												supportMultiselect: true,
												supportRanges: false,
												supportRangesOnly: false,
												key: "Id",
												descriptionKey: "Title",
												stretch: sap.ui.Device.system.phone,
												contentHeight:"100%",
												
												ok: function(oOkEvent) {
													var aSelectedTokens = oOkEvent.getParameter("tokens");
													oController.assignFindRelToAudit(aSelectedTokens);
													// this.close();
												},

												cancel: function() {
													this.close();
												},

												afterClose: function() {
													this.destroy();
												}
											});
											
											var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
												advancedMode: true,
												filterBarExpanded: false,
												showGoOnFB: !sap.ui.Device.system.phone,
												search: function() {
													oController.searchToBeAssignedTable();
												}
											});

											if (oFilterBar.setBasicSearch) {
												this.oBasicSearch = new sap.m.SearchField({
													id: "basicSearch",
													showSearchButton: sap.ui.Device.system.phone,
													placeholder: this.getView().getModel("i18n").getResourceBundle().getText("labelSearchFindingPlaceHolder"),
													search: function() {
														oController.oValueHelpDialog.getFilterBar().search();
													}
												});
												oFilterBar.setBasicSearch(this.oBasicSearch);
											}

											this.oValueHelpDialog.setFilterBar(oFilterBar);
											this.oValueHelpDialog.setTable(this.toBeAddFindRelSmartTable);
											this.oValueHelpDialog.setModel(this.tableContentModel);
											oSource.addDependent(this.oValueHelpDialog);
											this.oValueHelpDialog.open();
											this.oValueHelpDialog.setBusy(true);
											//this.toBeAddFindRelSmartTable.rebindTable();
											
										},
										getDataFromOdata:function(){
											var that = this;
											//Realizar llamada al back para obtener el listado de findinds relacionados
											var findModel = new sap.ui.model.odata.v2.ODataModel(
													"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false ////"ZGRCAUD_ENH_SRV"
											);

											var oData = {},
												aBatchOperations = [];										
											
											var auditKey = sap.ui.getCore().getModel("auditKeyModel").getData().id
											var url = "/AuditSet(guid'" + auditKey + "')/AuditToMyFindRel";
											
											findModel.read(url, {
												success: function (data, response) {
													
													if(that.getView().byId("idFindRelAssgnTable")){
													that.getView().byId("idFindRelAssgnTable").removeSelections()	
												}
												
														if(that.modelFindRel) {
															that.modelFindRel.setData(data.results);
															that.modelFindRel.refresh();
														}
														that.editData = [];
														var modelTitleFindRel = {};
														that.editData = [];														      			      		
										      			modelTitleFindRel.title = that.getOwnerComponent().getModel("i18nm").getResourceBundle().getText("findingRelSectionTitle");
										      			modelTitleFindRel.count = data.results.length;
										      			modelTitleFindRel.title = modelTitleFindRel.title +'('+modelTitleFindRel.count+')';
								      					that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(modelTitleFindRel), "findRelTitle");
										      			that.getOwnerComponent().getModel("findRelTitle").refresh();
														
												},
												failed: function (oData, response) {
													alert("Failed to get InputHelpValues from service!");
												},
											});
										},
										
										assignFindRelToAudit : function(aSelectedTokens){
											var oController = this;
											var selectedItems = [];
											if(aSelectedTokens.length === 0){
												b.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("MSG_NO_FINDING_SELECTED"));
												return;
											}
											for(var i = 0; i < aSelectedTokens.length; i++) {
												var oObject = aSelectedTokens[i].data("row");
												selectedItems.push(oObject);
											}
											if (!oController.oDataModel) {
												oController.oDataModel = new sap.ui.model.odata.ODataModel(
														"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",
													false
												);
											}
											var aBatchOperations = oController._generateBatchOperations(
													selectedItems,
													oController.oDataModel
											);
											oController.oDataModel.addBatchChangeOperations(aBatchOperations);
											oController.oDataModel.submitBatch(
													jQuery.proxy(function (oData, oResponse, aErrorResponses) {
														if (aErrorResponses.length <= 0) {
															oController.getDataFromOdata()
														} else {
															
														}
													}, this),
													jQuery.proxy(function (oError) {
														/*oController.getView().getContent()[0].getContent()[1].setBusy(false);
														sap.hpa.grcaud.Utility.showODataErrorMsg(
															oError,
															sap.hpa.grcaud.enh_oBundle.getText("MSG_ADD_FINDING_FAIL")
														);*/
													}, this),
													true
												);
											this.oValueHelpDialog.close();
										},
										
										_generateBatchOperations: function (aNewEntryKey, oDataModel) {
											var aBatchOperations = [];
											var auditKey = this.auditKey.replaceAll("-", "").toUpperCase();
											for (var i = 0; i < aNewEntryKey.length; i++) {
												var oSelectedData = aNewEntryKey[i];
												aBatchOperations.push(
													//oDataModel.createBatchOperation("/AuditFindRelSet(Key=binary'"+auditKey+"')/AuditToFindRelAssignment", "POST", {
													oDataModel.createBatchOperation(
														"/AuditFindRelSet(Key=binary'" + auditKey + "')/FindRelAssignments",
														"POST",
														{
															ReferenceKey: oSelectedData.Key,
															Type: "FNDREL",
															//HostKey: recoverKey(sAuditKey),
														}
													)
												);
											}

											return aBatchOperations;
										},
										
										formatFindingData: function (data) {
//											var path = sap.hpa.grcaud.oODataLink.get(
//												sap.hpa.grcaud.constant.Entry.Findings,
//												arrayToGuidString(convertToGuid(data.Key))
//											);
											// this._pushFindingSeq(data.Seq);
											var findingData = {
												Key: data.Key,
												ID: data.Id,
												Title: data.Title,
												TypeDescription: data.TypeDescr,
												Status: data.Status,
												CategoryDescription: data.CategoryDescr,
												RankingDescription: data.RankingDescr,
												StatusDescription: data.StatusDescr,
												ActionCount: data.ActionCount,
//												ServiceURL:
//													data.__metadata.id.split(
//														sap.hpa.grcaud.Enhancements.constants.con.enh
//													)[0] + path,
												eTag: data.__metadata.etag,
												//Path: path,
												//findingPath: path,
												Seq: data.Seq,
												lastChangeDateTime: data.lastChangeDateTime,
											};
											return findingData;
										},
										
										searchToBeAssignedTable: function() {
											var oController = this;
											var oTableSearchState = [];
											var oTableSearchStateFilter = [];
											var oBindingInfo = {};
											var sSearchString = oController.oBasicSearch.getValue();
											oTableSearchState = [
												new sap.ui.model.Filter("Id", sap.ui.model.FilterOperator.Contains, sSearchString),
												new sap.ui.model.Filter("Title", sap.ui.model.FilterOperator.Contains, sSearchString),
												new sap.ui.model.Filter("TypeDescr", sap.ui.model.FilterOperator.Contains, sSearchString),
												new sap.ui.model.Filter("CategoryDescr", sap.ui.model.FilterOperator.Contains, sSearchString)
											];
											oTableSearchStateFilter = new sap.ui.model.Filter(oTableSearchState, false);
											oBindingInfo = oController.toBeAddFindRelSmartTable.getTable().getBindingInfo("items");
											oBindingInfo.filters = oTableSearchStateFilter;
											oController.toBeAddFindRelSmartTable.getTable().bindAggregation("items", oBindingInfo);					
										},
										
										FIND_UPDATE_FINDING : function(e, A) {
											this._storeSequenceValue();
											this._setButtonVisibility("EDIT");
											this.getView().byId("colSequence")
													.setVisible(true);
											this._setInputEditable(true);
										},
										FIND_DELETE_FINDING : function(e, A) {
											var s = this.getView().byId(
													"idFindRelAssgnTable")
													.getSelectedItems();
											var p = "";
											var d = this.getView().getModel();
											if (s.length === 0) {
												b
														.showMsg(
																"msgTypeFailed",
																this
																		.getView()
																		.getModel(
																				"i18n")
																		.getResourceBundle()
																		.getText(
																				"msgSelectOne"));
												return;
											}
											for (var i = 0; i < s.length; i++) {
												var c = s[i]
														.getBindingContext()
														.getObject().Status;
												if (!(c === "")) {
													b
															.showMsg(
																	"msgTypeFailed",
																	this
																			.getView()
																			.getModel(
																					"i18n")
																			.getResourceBundle()
																			.getText(
																					"msgSelectDraftFinding"));
													return;
												}
											}
											d.setUseBatch(true);
											d
													.setDeferredGroups([ "deleteFinding" ]);
											for (i = 0; i < s.length; i++) {
												p = s[i].getBindingContext()
														.getPath();
												d.remove(p, {
													async : true,
													groupId : "deleteFinding"
												});
											}
											d
													.submitChanges({
														groupId : "deleteFinding",
														success : jQuery
																.proxy(
																		function() {
																			b
																					.showMsg(
																							"msgTypeSuccessful",
																							this
																									.getView()
																									.getModel(
																											"i18n")
																									.getResourceBundle()
																									.getText(
																											"msgDeleteFindingSuccess"));
																			d
																					.refresh();
																			this.sFocusButton = "FIND-DELETE_FINDING";
																			if (this
																					.getView()
																					.byId(
																							"findingToolbar")) {
																				this
																						.getView()
																						.byId(
																								"findingToolbar")
																						.getContent()[3].onAfterRendering = function() {
																					if (this.sFocusButton === "FIND-DELETE_FINDING") {
																						this
																								.getView()
																								.byId(
																										"findingToolbar")
																								.getContent()[3]
																								.focus();
																						this.sFocusButton = "";
																					}
																				}
																						.bind(this);
																			}
																			d
																					.setUseBatch(false);
																		}, this),
														error : jQuery
																.proxy(
																		function() {
																			b
																					.showMsg(
																							"msgTypeFailed",
																							this
																									.getView()
																									.getModel(
																											"i18n")
																									.getResourceBundle()
																									.getText(
																											"msgDeleteFindingFailed"));
																		}, this)
													});
										},
										onSaveBtnPress : function() {
											var t = this.getView().byId(
													"idFindRelAssgnTable");
											var f = this.getView().byId(
													"idFindRelAssgnTable").getItems();
											if (f.length === 0) {
												this.getView().byId(
														"colSequence")
														.setVisible(false);
												this._setInputEditable(false);
												this
														._setButtonVisibility("DISPLAY");
												return;
											}
											var s = [];
											for (var j = 0; j < f.length; j++) {
												var c = f[j].getCells()[1]
														.getValue();
												if (s.indexOf(c) !== -1) {
													b
															.showMsg(
																	"msgTypeFailed",
																	this
																			.getView()
																			.getModel(
																					"i18n")
																			.getResourceBundle()
																			.getText(
																					"msgEditFindingSequenceFailed"));
													s = [];
													return;
												} else {
													s.push(c);
												}
											}
											t.setBusy(true);
											for (var i = 0; i < f.length; i++) {
												var p = f[i]
														.getBindingContext()
														.getPath();
												var d = this.getView()
														.getModel();
												var e = f[i]
														.getBindingContext()
														.getObject().Status;
												if (e === "") {
													var g = f[i].getCells()[1]
															.getValue();
													d
															.update(
																	p,
																	{
																		Sequence : g
																	},
																	{
																		success : this._saveSuccessHandle
																				.bind(this),
																		error : this._saveErrorHandle
																				.bind(this),
																		groupId : "saveSequence",
																		async : true,
																		merge : true
																	});
												}
											}
										},
										_saveSuccessHandle : function() {
											var t = this.getView().byId("idFindRelAssgnTable");
											var c = this.getView().byId("colSequence");
											b.showMsg("msgTypeSuccessful",this.getView().getModel("i18n").getResourceBundle().getText("msgEditFindingSequenceSuccess"));
											this._storeSequenceValue();
											t.setBusy(false);
											c.setVisible(false);
											this._setInputEditable(false);
											this._setButtonVisibility("DISPLAY");
										},
										_saveErrorHandle : function() {
											var t = this.getView().byId("idFindRelAssgnTable");
											var c = this.getView().byId("colSequence");
											t.setBusy(false);
											c.setVisible(true);
											this._setInputEditable(true);
											this._setButtonVisibility("EDIT");
										},
										onCancelBtnPress : function(e) {
											this._resetSequenceValue();
											this._setInputEditable(false);
											this._setButtonVisibility("DISPLAY");
											this.getView().byId("colSequence").setVisible(false);
											b.showMsg("msgTypeSuccessful",
															this.getView().getModel("i18n").getResourceBundle().getText("msgNothingUpdated"));
										},
										onKeyPressValidation : function(e) {
											var i = e.getSource();
											var v = i.getValue();
											var r = /^[0-9]\d*$/;
											if (!v.match(r) && v !== "") {
												i.setValueState(sap.ui.core.ValueState.Error);
												i.setValueStateText(this.getView().getModel("i18n").getResourceBundle().getText("msgNatualNumber"));
											} else {
												i.setValueState(sap.ui.core.ValueState.None);
												i.setValueStateText("");
											}
										},
										onUnfocusValidation : function(e) {
											this.changeSequenceFlag = true;
											var i = e.getSource();
											var v = i.getValue();
											if (i.getValueState() === sap.ui.core.ValueState.Error) {
												return;
											}
											if (v === "") {
												i.setValueState(sap.ui.core.ValueState.Error);
												i.setValueStateText(this.getView().getModel("i18n").getResourceBundle().getText("msgEmptyNotAllowed"));
												return;
											}
											if (parseInt(v, 10) === 0) {
												i.setValueState(sap.ui.core.ValueState.Error);
												i.setValueStateText(this.getView().getModel("i18n").getResourceBundle().getText("msgZeroNotAllowed"));
												return;
											}
											i.setValueState(sap.ui.core.ValueState.None);
											i.setValueStateText("");
										},
										onRefresh : function() {
											this._setButtonVisibility("DISPLAY");
											var t = this.getView().byId("idFindRelAssgnTable");
//											var c = t.getItems();
//											for (var i = 0; i < this._aOriginalFindSequences.length; i++) {
//												c[i].getCells()[1].setValue(this._aOriginalFindSequences[i].sequence);
//												c[i].getCells()[1].setValueState(sap.ui.core.ValueState.None);
//											}
											this.getView().byId("colSequence").setVisible(false);
											this._setInputEditable(false);
										},
										_setInputEditable : function(e) {
											var f = this.getView().byId("idFindRelAssgnTable").getItems();
											for (var i = 0; i < f.length; i++) {
												var s = f[i]
														.getBindingContext().getObject().Status;
												if (s === "") {
													f[i].getCells()[1].setEditable(e);
													f[i].getCells()[1].setEnabled(e);
												}
											}
										},
										_storeSequenceValue : function() {
											this._aOriginalFindSequences = [];
											var f = this.getView().byId("idFindRelAssgnTable").getItems();
											for (var i = 0; i < f.length; i++) {
												var d = f[i].getBindingContext().getObject().DBKey;
												var s = f[i].getBindingContext().getObject().Sequence;
												this._aOriginalFindSequences.push({"findDbKey" : d,"sequence" : s});
											}
										},
										_resetSequenceValue : function() {
											var f = this.getView().byId("idFindRelAssgnTable").getItems();
											for (var i = 0; i < this._aOriginalFindSequences.length; i++) {
												for (var j = 0; j < f.length; j++) {
													if (!(f[j].getBindingContext().getObject().DBKey === this._aOriginalFindSequences[i].findDbKey)) {
														continue;
													}
													f[j].getCells()[1].setValue(this._aOriginalFindSequences[i].sequence);
													f[j].getCells()[1].setValueState(sap.ui.core.ValueState.None);
												}
											}
										},
										_setButtonVisibility : function(m) {
											var h = this.getView().byId("findRelToolbar").getAggregation("content");
											var e = null;
											var c = null;
											var s = null;
											var A = null;
											var p = null;
											var d = null;
											for (var i = 0; i < h.length; i++) {
												switch (h[i].getId()) {
												case "btnSave":
													s = h[i];
													break;
												case "btnCancel":
													c = h[i];
													break;
												case "FIND-DELETE_FINDING":
													d = h[i];
													break;												
												case "FIND-ADD_FINDING":
													A = h[i];
													break;
												case "auditFindingBlockPersonalization":
													p = h[i];
													break;
												default:
													break;
												}
											}
											if (m === "EDIT") {
												if (e !== null && A !== null) {
													e.setVisible(false);
													A.setVisible(true);
													c.setVisible(true);
													s.setVisible(true);
													p.setVisible(false);
													d.setVisible(false);
												}
											} else if (m === "DISPLAY") {
												if (e !== null && A !== null) {
													e.setVisible(true);
													A.setVisible(true);
													c.setVisible(false);
													s.setVisible(false);
													p.setVisible(true);
													d.setVisible(true);
												}
											} else {
												if (e !== null && A !== null) {
													e.setVisible(false);
													A.setVisible(false);
													c.setVisible(false);
													s.setVisible(false);
													p.setVisible(true);
													d.setVisible(true);
												}
											}
											if (this.getView().byId("findRelToolbar").getContent().length !== 0) {
												this.getView().byId("findRelToolbar").setVisible(true);
											} else {
												this.getView().byId("findRelToolbar").setVisible(false);
											}
										}
									});
				});
