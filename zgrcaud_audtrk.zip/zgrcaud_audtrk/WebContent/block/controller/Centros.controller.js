sap.ui.define([ "sap/ui/core/mvc/Controller",
	"sap/grc/acs/aud/audit/track/extended/block/util/listsUtils",
	"sap/grc/acs/aud/audit/track/extended/block/model/oDataGeneratorList",
	"sap/grc/acs/aud/audit/track/extended/block/util/Enhancements",
	"sap/grc/acs/aud/audit/track/extended/block/searchComponent/Component",
], function(Controller,UtilList,Model,oComp) {
	"use strict";
	return Controller.extend("sap.grc.acs.aud.audit.track.extended.block.controller.Centros",{
		onInit: function () {
			console.log("En Centros controller");		
			//refrescarEstilsTaula(this.getView().byId("treeTableCentros"));
			
		},
		formatTextCentro : function(Company, Department, DepartmentName) {
            return Company + Department + " " + DepartmentName
        },
        formatTextName : function(FullNameResp1,DelUserResp1){
	    	if(FullNameResp1 != null && FullNameResp1 != undefined && FullNameResp1 != "") {
	    		if(DelUserResp1 == "false") {
	    			this.getParent().getAggregation("items")[1].removeStyleClass("lineThrough");
	    		}else if (DelUserResp1 == "true") {
	    			this.getParent().getAggregation("items")[1].addStyleClass("lineThrough");
	    		}
	    		//this.getParent().setVisible(true);
	    		return FullNameResp1;
	    	}else {
	    		this.getParent().setVisible(false);
	    		return "";
	    	}
	    },
	    updateCentrosStyles:function(oEvent){
	    	
	    	//refrescarEstilsTaula(centrosView.byId('treeTableCentros'));
	    	refrescarEstilsTaula(this.getView().byId("treeTableCentros"));
	    },
	    formatTextNameResponsable2 : function(FullNameResp2,DelUserResp2){
	    	if(FullNameResp2 != null && FullNameResp2 != undefined && FullNameResp2 != "") {
	    		if(DelUserResp2 == "false") {
	    			this.getParent().getAggregation("items")[1].removeStyleClass("lineThrough");
	    		}else if (DelUserResp2 == "true") {
	    			this.getParent().getAggregation("items")[1].addStyleClass("lineThrough");
	    		}
	    		//this.getParent().setVisible(true);
	    		return FullNameResp2;
	    	}else{
	    		//this.getParent().setVisible(false);
	    		return "";
	    	}
	     },
	     
	    onPressDeleteResponsable: function(oEvent){
        	var bindingContext = oEvent.getSource().getBindingContext().sPath;
            //var viewName = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getId();
        	var viewName = oEvent.getSource().getParent().getParent().getParent().getParent().getParent();
            //var UserId = sap.ui.getCore().byId(viewName).table.getModel().getProperty(bindingContext).UserIdResp1;
            var UserId = this.oView.byId('treeTableCentros').getModel().getProperty(bindingContext).UserIdResp1;
            updateDelUserResp1(UserId,"true",viewName);
        },
        
        onPressDeleteResponsable2: function(oEvent){
        	var bindingContext = oEvent.getSource().getBindingContext().sPath;
//            var viewName = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getId();
        	var viewName = oEvent.getSource().getParent().getParent().getParent().getParent().getParent();
            //var UserId = sap.ui.getCore().byId(viewName).table.getModel().getProperty(bindingContext).UserIdResp2;
            var UserId = this.oView.byId('treeTableCentros').getModel().getProperty(bindingContext).UserIdResp2;
            updateDelUserResp2(UserId,"true", viewName);
        },
        
        onPressAddResponsable : function(oEvent){
            var bindingContext = oEvent.getSource().getBindingContext().sPath;
           // var viewName = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getId();
            var viewName = oEvent.getSource().getParent().getParent().getParent().getParent().getParent();
            //var UserId = sap.ui.getCore().byId(viewName).table.getModel().getProperty(bindingContext).UserIdResp1;
            var UserId = this.oView.byId('treeTableCentros').getModel().getProperty(bindingContext).UserIdResp1;
            updateDelUserResp1(UserId,"false", viewName);
        },
        
        onPressAddResponsable2 : function(oEvent){
        	var bindingContext = oEvent.getSource().getBindingContext().sPath;
            //var viewName = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getId();
        	var viewName = oEvent.getSource().getParent().getParent().getParent().getParent().getParent();
            //var UserId = sap.ui.getCore().byId(viewName).table.getModel().getProperty(bindingContext).UserIdResp2;            
            var UserId = this.oView.byId('treeTableCentros').getModel().getProperty(bindingContext).UserIdResp2;
            updateDelUserResp2(UserId,"false", viewName);
        },
        
        onToolbarExpand : function(oEvent) {
 		   if(this.toggle) {
 			   this.getView().byId("treeTableCentros").collapseAll();
 			   oEvent.getSource().setIcon("sap-icon://expand");
		   } else {
			   this.getView().byId("treeTableCentros").expandToLevel(5);
			   oEvent.getSource().setIcon("sap-icon://collapse");
		   }
		   this.toggle = !this.toggle;
	   },
        
        onDeleteButton : function(oEvent){
//Inicio PRL 26.07.2021        	
        var o18nmModel = this.getOwnerComponent().getModel('i18nm').getResourceBundle();
//Fin PRL 26.07.2021        	       
           var oController = this;
		   var bindingContext = oEvent.getSource().getBindingContext().sPath
		   //var index = bindingContext.substr(9);
		   var index = bindingContext.split("/")[2];
//Inicio PRL 26.07.2021        
      		   
		   var dialog = new sap.m.Dialog({
				title: o18nmModel.getText("warning"), // TODO: sap.hpa.grcaud.enh_oBundle.getText("warning"),
				type: 'Message',
					content: new sap.m.Text({
						text: o18nmModel.getText("deleting_hierarchy") // TODO: sap.hpa.grcaud.enh_oBundle.getText("deleting_hierarchy")
					}),
//Fin PRL 26.07.2021  					
				state: sap.ui.core.ValueState.Warning, 
				beginButton: new sap.m.Button({
					text: 'OK',
					press: [function (oEvent) {
						
						//Elimino la persona del model local
						//var oModel = sap.ui.getCore().getModel("centros");
						//var table = oController.getView().table;
						var table = oController.getView().byId("treeTableCentros");
						var oModel = table.getModel();
						var aEntries = oModel.getData().centros;
						delete aEntries[index];
						var filtered = aEntries.filter(function (el) { 
                            return el != undefined;
                              });

					//aEntries.splice(index,1);
					oModel.setData({
						centros : filtered
					});
//						oModel.setData({
//							centros : aEntries
//						});
						table.setModel(oModel);
						table.bindRows("/centros");
						table.setVisibleRowCount(10);
						dialog.close();
					}, oController]
				}),
				endButton: new sap.m.Button({
					text: o18nmModel.getText("cancel"), // TODO: sap.hpa.grcaud.enh_oBundle.getText("cancel"),
					press: function () {
						dialog.destroy();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});
		   dialog.open();
	   },
	   
	   //Inicio PRL 04.06.2021	   
		onAdd: function() { 
			var o18nmModel = this.getOwnerComponent().getModel('i18nm').getResourceBundle(); 
				//new sap.ui.model.resource.ResourceModel({ bundleUrl:"sap/grc/acs/aud/audit/track/extended/i18n/i18n.properties" }).getResourceBundle();
			var oController = this;
	        var url = "/InfoDepartmentsSet" ;
			
			if(sap.ui.getCore().getComponent('searchComponent')) {
				sap.ui.getCore().getComponent('searchComponent').destroy();
			}
			
			var oComp  = sap.ui.getCore().createComponent({
				id: "searchComponent",
		        name: "sap.grc.acs.aud.audit.track.extended.block.searchComponent"
		    });
			
			
			
			// Función de añadir resultados a las tablas
			var addFunct = function() {
				var selItems = this.getParent().getContent()[1].getSelectedItems();
				
				if(selItems.length == 0) { alert(o18nmModel.getText("select_option")); }
				else {
					//var bindingContext = selItems[0].getBindingContext().sPath;
					//var id = selItems[0].getAggregation("customData")[0].getValue("Key");
					//if(mirarCentrosRepetidos(selItems,oController.getView().getId())){
					if(mirarCentrosRepetidos(selItems,oController.getView())){
						//Han inserit algun centre repetit
						var dialog = new sap.m.Dialog({
							title: o18nmModel.getText("info"),
							type: 'Message',
								content: new sap.m.Text({
									text: o18nmModel.getText("repeated_hierarchy")
								}),
							beginButton: new sap.m.Button({
								text: o18nmModel.getText("accept"),
								press: function () {
									dialog.close();
								}
							}),
							endButton: new sap.m.Button({
								text: o18nmModel.getText("cancel"),
								press: function () {
									dialog.close();
								}
							}),
							afterClose: function() {
								dialog.destroy();
							}
						});
						dialog.open();
					}else{
						$.each(selItems,function(i,n){ 
							var bindingContext = n.getBindingContext().sPath;
							var Company = sap.ui.getCore().getModel('centrosSearch').getProperty(bindingContext).Company;
							var Department = sap.ui.getCore().getModel('centrosSearch').getProperty(bindingContext).Department;
							var TypeHier = "";
							
//							var url =  "/GetHierarchy?Company='"+ Company + "'&Department='" + Department+"'" + "'&TypeHier='" + TypeHier+"'";
//							loadJerarquia(url, oController.getView().getId());
							var url =  "/GetHierarchy?Company='"+ Company + "'&Department='" + Department+"'&TypeHier='" + TypeHier+"'";
							loadJerarquia(url, oController.getView());
						});		
						this.getParent().close();
					}
				}};
				
			    //Creo ola funcio a anira al search del search field
			    var addSearchFunct = function(){
			    	//Agafo el valor del serchfield
			    	var text = this.getParent().getContent()[0].getProperty("value");
			    	if (text != ""){
			    	//Preparo els filtres amb els valors
			    	/*var aFilters = [];
			    		if(tieneNumeros(text))//Si conté numeros es que cerquen per matricula
			    		aFilters.push(new sap.ui.model.Filter("Department",sap.ui.model.FilterOperator.Contains, text));
			    		else
			    			aFilters.push(new sap.ui.model.Filter("DepartmentName",sap.ui.model.FilterOperator.Contains, text));
			    		loadAddData(url, aFilters);*/
			    		
			    		//Preparo els filtres amb els valors
			          	var aFilters = [];
			          	
			          	// Intento de filtro automatico en OR
			          	/*aFilters = new sap.ui.model.Filter({
			          	    filters: [
			          	      new sap.ui.model.Filter("Department", sap.ui.model.FilterOperator.Contains, text),
			          	      new sap.ui.model.Filter("Company", sap.ui.model.FilterOperator.Contains, text)
			          	      //new sap.ui.model.Filter("DepartmentName", sap.ui.model.FilterOperator.Contains, text)
			          	    ],
			          	    and: false
			          	  });*/
			          	
			          	//INICIO RTC-578850 
			          	//Codigo antiguo
			          	// Filtro en OR manual
//			          	var source = "?$filter=(substringof({0},Department) or substringof({1},Company) or substringof({2},DepartmentName))";
			          	// Se reemplazan los parámetros
//			          	var strFilter = sap.hpa.grcaud.Enhancements.formatUrl(source, [text.toUpperCase(),text.toUpperCase(),text.toUpperCase()]);
			          	// Se añade el parametro a la funcion que carga los centros para usar filtros manuales
			          	//Código nuevo
			          	if($.isNumeric(text)){
				          	var source = "?$filter=(substringof({0},Department) or substringof({1},Company) or substringof({2},DepartmentName))";		          		
				          	var strFilter = formatUrl(source, [text.toUpperCase(),text.toUpperCase(),text.toUpperCase()]);
			          	}else{
			          		var source = "?$filter=(substringof({0},DepartmentName))";
			          		var strFilter = formatUrl(source, [text.toUpperCase()]);
			          	}
			          	  
			          	//FIN RTC-578850 
			          	
			          	loadAddData(url, aFilters,strFilter);
			          	//loadAddData(url, aFilters);
			    	}
			    	
			    }

			// Cabecera, Binding Posiciones, Modo de Lista, Binding Aggregation, Path, Model, AddFunction
			    oComp.setupInicial(["Compañía", "Departamento","Centro", "Responsable"], ["{Company}", "{Department}","{DepartmentName}", "{Fullnameresp1}"], "MultiSelect", "", "/results", "centros", addFunct, addSearchFunct,this.oView);

			// Se crea un contenedor para el componente
			var oCompCont = new sap.ui.core.ComponentContainer({
				 component: oComp,
			});
		}
//Fin PRL 04.06.2021	
        
	})
})