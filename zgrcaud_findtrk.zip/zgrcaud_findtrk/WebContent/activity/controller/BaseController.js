sap.ui.define([ "sap/ui/core/mvc/Controller" ], function(C) {
	"use strict";
	return C.extend(
			"sap.grc.acs.aud.finding.trackopen.extended.activity.controller.BaseController", {
				setBoundle : function(b) {
					this.oBoundle = b;
					this.getView().setModel(this.getModel("i18nm").getResourceBundle(), "i18nFinding");
				}
			});
});
