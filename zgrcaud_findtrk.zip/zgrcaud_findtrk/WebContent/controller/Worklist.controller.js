/*
 * Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui
		.define(
				[ "sap/grc/acs/aud/finding/controller/BaseController",
						"sap/ui/model/json/JSONModel",
						"sap/grc/acs/aud/finding/model/formatter",
						"sap/ui/model/Filter", "sap/ui/model/FilterOperator",
						"sap/ui/core/routing/History" ],
				function(B, J, f, F, a, H) {
					"use strict";
					return B
							.extend(
									"sap.grc.acs.aud.finding.extended.controller.Worklist",
									{
										formatter : f,
										onInit : function() {
											var v, o, t = this.byId("table"), l;
											o = t.getBusyIndicatorDelay();
											this._oTable = t;
											this._oTableSearchState = [];
											v = new J(
													{
														worklistTableTitle : this
																.getResourceBundle()
																.getText(
																		"worklistTableTitle"),
														saveAsTileTitle : this
																.getResourceBundle()
																.getText(
																		"worklistViewTitle"),
														shareOnJamTitle : this
																.getResourceBundle()
																.getText(
																		"worklistViewTitle"),
														shareSendEmailSubject : this
																.getResourceBundle()
																.getText(
																		"shareSendEmailWorklistSubject"),
														shareSendEmailMessage : this
																.getResourceBundle()
																.getText(
																		"shareSendEmailWorklistMessage",
																		[ location.href ]),
														tableNoDataText : this
																.getResourceBundle()
																.getText(
																		"tableNoDataText"),
														tableBusyDelay : 0
													});
											this.setModel(v, "worklistView");
											this.setModel(l, "listMenu");
											var T = this
													.getResourceBundle()
													.getText(
															this
																	.getOwnerComponent()
																	.getModel(
																			"intentConfig")
																	.getData().appTitle);
											this.getView().byId("page")
													.setTitle(T);
											t
													.attachEventOnce(
															"updateFinished",
															function() {
																v
																		.setProperty(
																				"/tableBusyDelay",
																				o);
															});
											sap.ui
													.getCore()
													.getEventBus()
													.subscribe(
															"sap.grc.acs.aud.finding.EventBus",
															"findingListRefresh",
															this.onRefresh,
															this);
										},
										onUpdateFinished : function(e) {
											var t, T = e.getSource(), i = e
													.getParameter("total");
											if (i
													&& T.getBinding("items")
															.isLengthFinal()) {
												t = this
														.getResourceBundle()
														.getText(
																"worklistTableTitleCount",
																[ i ]);
											} else {
												t = this
														.getResourceBundle()
														.getText(
																"worklistTableTitle");
											}
											this
													.getModel("worklistView")
													.setProperty(
															"/worklistTableTitle",
															t);
										},
										onPress : function(e) {
											this._showObject(e.getSource());
										},
										onClick : function(e) {
											var p = e.getParameters().rowBindingContext.sPath;
											var d = p.substring(
													p.indexOf("'") + 1, p
															.lastIndexOf("'"));
											this
													.getRouter()
													.navTo(
															"object",
															{
																objectId : d,
																intentService : this
																		.getOwnerComponent()
																		.getModel(
																				"intentConfig")
																		.getData().service
															});
										},
										onNavBack : function() {
											var p = H.getInstance()
													.getPreviousHash(), c = sap.ushell.Container
													.getService("CrossApplicationNavigation");
											if (p !== undefined
													|| !c.isInitialNavigation()) {
												history.go(-1);
											} else {
												c
														.toExternal({
															target : {
																shellHash : "#Shell-home"
															}
														});
											}
										},
										onShareInJamPress : function() {
											var v = this
													.getModel("worklistView"), s = sap.ui
													.getCore()
													.createComponent(
															{
																name : "sap.collaboration.components.fiori.sharing.dialog",
																settings : {
																	object : {
																		id : location.href,
																		share : v
																				.getProperty("/shareOnJamTitle")
																	}
																}
															});
											s.open();
										},
										onSearch : function(e) {
											if (e.getParameters().refreshButtonPressed) {
												this.onRefresh();
											} else {
												var t = [];
												var q = e.getParameter("query");
												if (q && q.length > 0) {
													t = [ new F("Title",
															a.Contains, q) ];
												}
												this._applySearch(t);
											}
										},
										onRefresh : function() {
											if (this._oTable
													.getBinding("items")) {
												this._oTable
														.getBinding("items")
														.refresh();
											} else {
												this._oTable.getBinding("rows")
														.refresh();
											}
										},
										_showObject : function(i) {
											this
													.getRouter()
													.navTo(
															"object",
															{
																objectId : i
																		.getBindingContext()
																		.getProperty(
																				"DBKey"),
																intentService : this
																		.getOwnerComponent()
																		.getModel(
																				"intentConfig")
																		.getData().service
															});
										},
										_applySearch : function(t) {
											var v = this
													.getModel("worklistView");
											this._oTable.getBinding("items")
													.filter(t, "Application");
											if (t.length !== 0) {
												v
														.setProperty(
																"/tableNoDataText",
																this
																		.getResourceBundle()
																		.getText(
																				"worklistNoDataWithSearchText"));
											}
										},
										onExit : function() {
											sap.ui
													.getCore()
													.getEventBus()
													.unsubscribe(
															"sap.grc.acs.aud.finding.EventBus",
															"findingListRefresh",
															this.onRefresh,
															this);
										}
									});
				});
