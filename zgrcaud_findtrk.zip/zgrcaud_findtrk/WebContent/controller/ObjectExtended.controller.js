/*
 * Copyright (C) 2009-2020 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
	"sap/grc/acs/aud/finding/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/grc/acs/aud/finding/model/formatter",
	"sap/grc/acs/lib/aud/extension/utils/FieldExtensibilityUtil",
	//"sap/grc/acs/lib/aud/utils/MenuItemUtils",
	"sap/grc/acs/aud/finding/trackopen/extended/util/MenuItemUtils",
	"sap/grc/acs/lib/aud/utils/MessageUtil"
], function(
	BaseController,
	JSONModel,
	History,
	formatter,
	FieldExtensibilityUtil,
	MenuItemUtil,
	MessageUtil
) {
	"use strict";

	return BaseController.extend("sap.grc.acs.aud.finding.controller.Object", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var iOriginalBusyDelay,
				oViewModel = new JSONModel({
					busy: true,
					delay: 0
				}),
				oObjectMenuModel;
			this.bIsNavToNotFound = true;
			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			// Store original busy indicator delay, so it can be restored later on
			iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
			//Set binding mode
			oViewModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			this.setModel(oViewModel, "objectView");

			//Model used to manipulate menu in list
			this.setModel(oObjectMenuModel, "objectMenu");

			//Extension model
			var oExtensionModel = new sap.ui.model.json.JSONModel();

			this.setModel(oExtensionModel, "extensionModel");

			//Set app title
			var sTitle = this.getResourceBundle().getText("objectTitle");
			this.getView().byId("objectPage").setTitle(sTitle);

			this.oMenuItemModelData = {
				MenuItem: []
			};
			this.oMenuItemModel = this.getOwnerComponent().getModel("menu");
			this.getOwnerComponent().getModel().metadataLoaded().then(function() {
				// Restore original busy indicator delay for the object view
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			});
			
			  //Se hace un enhance del i18n acsLibAudI18n para añadir los textos de nuevos estados
			var oModel = this.getOwnerComponent().getModel("i18n");
			var oModeli18nm = this.getOwnerComponent().getModel("i18nm");
			oModel.enhance({bundleName:oModeli18nm.oData.bundleName}) ; 

			this.getOwnerComponent().setModel(oModel, "i18n");
			  /* INI PLANES DE ACCION RELACIONADOS*/
		    this.tableContentModel = new sap.ui.model.json.JSONModel();
		    this.sModelData = {
		    		to_ActionsRel: [],
				};
		    this.tableContentModel.setData(this.sModelData);
		    /* FIN PLANES DE ACCION RELACIONADOS*/
		    
			 //Se hace un enhance del i18n acsLibAudI18n para añadir los textos de nuevos estados
			var oModel = this.getOwnerComponent().getModel("acsLibAudI18n");
			var oModeli18nm = this.getOwnerComponent().getModel("i18nm");
			oModel.enhance({bundleName:oModeli18nm.oData.bundleName}) ; 

			this.getOwnerComponent().setModel(oModel, "acsLibAudI18n");
			
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function() {
			var oViewModel = this.getModel("objectView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},

		/**
		 * Event handler  for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the worklist route.
		 * @public
		 */
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation() || this.getOwnerComponent().isAppToAppNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("worklist", {}, true);
			}
			// this.getView().getModel().refresh();
			sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.find.EventBus", "resetBlockToDisplayMode");
		},

		onNavBackWithoutRefresh: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation() || this.getOwnerComponent().isAppToAppNavigation()) {
				history.go(-1);
			} else {
				this.getRouter().navTo("worklist", {}, true);
			}
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) { 
//			var sObjectId = oEvent.getParameter("arguments").objectId;
			var sObjectId = this.sObjectId = oEvent.getParameter("arguments").objectId;
			var sIntentService = this.getOwnerComponent().getModel("intentConfig").getData().service;
			
			/**
			 * init mod U0199439 28.06.2022
			 * PPM086858 - Planes de acción relacionados
			 */	
		 	sap.ui.getCore().setModel(new sap.ui.model.json.JSONModel({id : sObjectId}), "findingKeyModel")

			
			//Realizar llamada al back para obtener el listado de findinds relacionados
			var actionModel = new sap.ui.model.odata.v2.ODataModel(
					"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
				);
			
			var findingKey = this.sObjectId;

			var url = "/ZGRCAUD_CV_ACTIONRELBYFINDING(p_find=guid'" + findingKey + "')/Set";

			var that = this;
			var data = [];
			var modelTitleActionRel = {};
			that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(data),"MyActionRel");      			      			
			modelTitleActionRel.title = that.getModel("i18n").getResourceBundle().getText("ActionRelSectionTitle");	
			that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(data), "ActionRelTitle");
			modelTitleActionRel.count = '0';                   			
			 
			actionModel.read(url, {
				success: function (data, response) { 
					
					if (data && data.results && data.results.length > 0) {
						
						that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(data.results),"MyActionRel");
						modelTitleActionRel.count = data.results.length;
						  
					}
					modelTitleActionRel.title = modelTitleActionRel.title +'('+modelTitleActionRel.count+')';
					that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(modelTitleActionRel), "ActionRelTitle");
					
				},
				failed: function (oData, response) {
					alert("Failed to get InputHelpValues from service!");
				},
				
				
			});	
			/**
			 * fin mod U0199439 28.06.2022
			 * PPM086858 - Planes de acción relacionados
			 */

			
			this.getModel().metadataLoaded().then(function() {
				var sObjectPath = this.getModel().createKey(sIntentService, {
					DBKey: sObjectId
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));
		},

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound
		 * @private
		 */
		_bindView: function(sObjectPath) {
			var oViewModel = this.getModel("objectView"),
				oDataModel = this.getModel();

			oViewModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
			
			var sExpand = "to_Audit,to_Tags,to_Count,to_ExecutiveResponsible,to_Reference,to_FindingOrganization";
			if( !this.getOwnerComponent().getModel("intentConfig").getData().IsMenuItemFromEntitySet ){
				sExpand = sExpand + ",to_MenuItem";
			}
			this.getView().bindElement({
				path: sObjectPath,
				parameters: {
					expand: sExpand
				},
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oDataModel.metadataLoaded().then(function() {
							// Busy indicator on view should only be set if metadata is loaded,
							// otherwise there may be two busy indications next to each other on the
							// screen. This happens because route matched handler already calls '_bindView'
							// while metadata is loaded.
							oViewModel.setProperty("/busy", true);
						});
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		_onBindingChange: function() {
			var oView = this.getView(),
				oViewModel = this.getModel("objectView"),
				oExtensionModel = this.getModel("extensionModel"),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				if(this.bIsNavToNotFound === true) {
						this.getRouter().getTargets().display("objectNotFound");
				}
				return;
			}

			var oResourceBundle = this.getResourceBundle(),
				oObject = oView.getBindingContext().getObject(),
				sObjectId = oObject.DBKey,
				sObjectName = oObject.Title,
				sObjectStatus = oObject.Status,
				sAuditType = oView.getBindingContext().getProperty("to_Audit/Type");

			var sIntent = this.getOwnerComponent().getModel("intentConfig").getData().intent;

			//get menuitem data
			var oMenuItemList = this.getView().getBindingContext().getProperty("to_MenuItem");
			var sPath = "";
			var oMenuItemsList = [];
			var oMenuItemDetail = {};
			if(oMenuItemList){
				for (var i = 0; i < oMenuItemList.length; i++) {
					sPath = "/" + oMenuItemList[i];
					oMenuItemDetail = this.getView().getBindingContext().getObject(sPath);
					oMenuItemsList.push(oMenuItemDetail);
				}
			}
			this.oMenuItemsList = oMenuItemsList;
			var oI18nModel = this.getOwnerComponent().getModel("i18n");
			var sObjectType = sap.grc.acs.aud.finding.util.constant.ObjectType.FIND;
			var oMenuItemConfigData = this.getOwnerComponent().getModel("menuItemConfig").getData();
			var oAdditionalInfo = {
				"wpaSection": {
					bIsToolBarRequired: true,
					bIsTitleRequired: false,
					titleText: "",
					id: "wpaToolBarSpacer"
				},
				"attachmentSection": {
					bIsToolBarRequired: true,
					bIsTitleRequired: false,
					titleText: "",
					id: "documentToolBarSpacer"
				},
				"actionSection": {
					bIsToolBarRequired: true,
					bIsTitleRequired: false,
					titleText: "",
					id: "actionToolBarSpacer"
				}
			};
			
			if( this.getOwnerComponent().getModel("intentConfig").getData().IsMenuItemFromEntitySet ){
				oAdditionalInfo.riskSection = {
					bIsToolBarRequired: true,
					bIsTitleRequired: false,
					titleText: "",
					id: "riskToolBarSpacer"
				};
				oAdditionalInfo.controlSection = {
					bIsToolBarRequired: true,
					bIsTitleRequired: false,
					titleText: "",
					id: "controlToolBarSpacer"
				};
				var aFilters = [],
					oDataModel = this.getModel();
				aFilters.push(new sap.ui.model.Filter("DBKey",
					sap.ui.model.FilterOperator.EQ,
					oObject.DBKey));
				aFilters.push(new sap.ui.model.Filter("ScenarioID",
					sap.ui.model.FilterOperator.EQ,
					this.getOwnerComponent().getModel("intentConfig").getData().intent));
				var sMenuItemPath = "/" + sap.grc.acs.aud.finding.util.constant.MenuItemSet;
				
				oDataModel.read(sMenuItemPath, {
					success: jQuery.proxy(function(oData) {
						oMenuItemsList = oData.results;
						this.oMenuItemsList = oMenuItemsList;
						this.oMenuItemModelData = MenuItemUtil.setMenuItemModelData(oMenuItemsList, oI18nModel, sObjectId, sObjectType, oMenuItemConfigData,
							this.oMenuItemModel, oAdditionalInfo);
						
						//set extensibility model data
						oExtensionModel.setData(
							FieldExtensibilityUtil.getExtensionFieldsStatus("Finding",
								sAuditType, sObjectStatus, this.getModel().getServiceMetadata(), oMenuItemConfigData, this.getOwnerComponent(), sIntent),
							true);
							
						sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.find.EventBus", "extensionModelDataUpdateFinished");	
					    // INI MOD PLAN RELACIONADOS 30.06.2022
					    // Se realiza llamada para determinar visibilidad de  botones de plan relacionados
					    sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.find.EventBus", "setVisibilityRelatedActionPlanTrc");
					    // FIN MOD PLAN RELACIONADOS 30.06.2022
					}, this),
					filters: aFilters
				});
			}else{

				this.oMenuItemModelData = MenuItemUtil.setMenuItemModelData(oMenuItemsList, oI18nModel, sObjectId, sObjectType, oMenuItemConfigData,
					this.oMenuItemModel, oAdditionalInfo);
				//set extensibility model data
				oExtensionModel.setData(
					FieldExtensibilityUtil.getExtensionFieldsStatus("Finding",
						sAuditType, sObjectStatus, this.getModel().getServiceMetadata(), oMenuItemConfigData, this.getOwnerComponent(), sIntent),
					true);
				sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.find.EventBus", "extensionModelDataUpdateFinished");
			    // INI MOD PLAN RELACIONADOS 30.06.2022
			    // Se realiza llamada para determinar visibilidad de  botones de plan relacionados
			    sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.find.EventBus", "setVisibilityRelatedActionPlanTrc");
			    // FIN MOD PLAN RELACIONADOS 30.06.2022
					
			}
			var oWPAParameters = {
            	sFindingKey: sObjectId };
			//Inicio PRL 0410
			//New:
			   // Para los estados verificado, se asume el riesgo o actualizado, se comprueban los campos a mostrar
			  if(oObject.Status == '06' || oObject.Status == '05' || oObject.Status == '07'|| oObject.Status == '01'){
				   var vis = {};
				
				    var oModel = new sap.ui.model.odata.v2.ODataModel('/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/',false);
				    var functionName = '/VisibilityFieldsForFinding';
					
					var oMenuItemExectuion = {};
					oMenuItemExectuion.Key = oObject.DBKey;
					// En el caso de que el estado sea verificado, se indica la acción verify_bpi, para actualizado update y assumed_risk para el estado '05' riesgo asumido
					oMenuItemExectuion.Action = oObject.Status == '06' ? "VERIFY_BPI" :  oObject.Status == '07' ? 'UPDATE' :  oObject.Status == '01' ? '' : 'ASSUMED_RISK';
					//Llamada para saber la visibilidad de los campos BPI
					var that = this;
											oModel
												.callFunction(
														functionName,
														{
															urlParameters : oMenuItemExectuion,		
											
										method:"POST",
										async : false,
										success : jQuery
												.proxy(
														function(oData) {
															vis = oData.results;
															$.each(vis,function(i,v){

																//Filtro para los campos de BPI, así como para las fechas de actualización o se asume el riesgo, para saber si añadimos el campo y su label a la pantalla. El status correspondiente
																//que recuperamos debe ser "D" para que se visualice												
															  
															  var currentVis = oExtensionModel.getData()[v.FieldId.toLowerCase()];
																	

																if (currentVis){
																	if (v.Status != "D"){
																		currentVis.visible = false;
																		
																		
																	}else{
																	currentVis.visible = true;	
																	}
																	that.getModel("extensionModel").updateBindings();
																
																}
																								
																
																	});
																
															      
														}, this),
										error : jQuery
												.proxy(
														function(oError) {
														}, this)
									});
				      
			   }
			   
			   //FIN PRL 0410
			   
            this.getOwnerComponent().getModel("wpaParameters").setData(oWPAParameters);
			// Everything went fine.
			oViewModel.setProperty("/busy", false);
			oViewModel.setProperty("/saveAsTileTitle", oResourceBundle.getText("saveAsTileTitle", [sObjectName]));
			oViewModel.setProperty("/shareOnJamTitle", sObjectName);
			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		},

		createHeaderButton: function(sId, oContext) {
			return MenuItemUtil.createButtonTemplate(sId, oContext, this,"","to_MenuItem",this.oMenuItemsList, true);
		},
		
		/**
		 * Success call back function of Finding actions
		 * @param {string} sSuccessTextID, i18n text id for success message
		*/
		actionSuccessCallBack: function(sSuccessTextID) {
			MessageUtil.showMsg("msgTypeSuccessful", this.getResourceBundle().getText(sSuccessTextID));
			sap.ui.getCore().getEventBus().publish(
				"sap.grc.acs.aud.finding.EventBus", "findingListRefresh");
			this.getView().getModel().refresh();
			this.getView().setBusy(false);
			this.bIsNavToNotFound = false;
			this.onNavBackWithoutRefresh();
		},
		
		/**
		 * Error call back function of Finding actions
		 * @param {object} oError, error information
		 * @param {string} sErrorTextID, i18n text id for error message
		*/
		actionErrorCallBack: function(oError, sErrorTextID) {
			if (oError.responseText) {
				var oJsonError = JSON.parse(oError.responseText);
				var errorMessage = oJsonError.error.message.value;
				MessageUtil.showMsg("msgTypeFailed", this.getResourceBundle().getText(sErrorTextID) + "\r\n" + errorMessage);
				this.getView().setBusy(false);
				this.getView().getModel().refresh();
			}
		},
		 /** Inicio de modificaci�n rgalan 07.09.2020 09:30:49
		*   RTC788093 - Funcionalidades segunda l�nea de defensa BPI
		*   C�digo nuevo
		*/
	  handleVerifyHeaderButtonPress: function(oData){
			  
		  var oActionHandleModel = new sap.ui.model.odata.v2.ODataModel('/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/',false);;
		   var sSuccessTextID = "MSG_EXE_FIND_ACTION_" + oData.sActionName.toUpperCase() + "_SUCCESS";
		   var sErrorTextID = "MSG_EXE_FIND_ACTION_" + oData.sActionName.toUpperCase() + "_FAIL";
		   oActionHandleModel.setUseBatch(false);
		   this.getView().setBusy(true);
		   
		   var functionName = '/ExecuteActionVerifyFind';
			

			
		   var oUrlParameters = {};	
			//Si es verify BPI, se informa los campos de verificado BPI
			if(oData.sActionName ==="VERIFY_BPI"){							
                oUrlParameters.ZZ_VERIFIED_BPI = oData.Parameter ;
				oUrlParameters.ZZ_VERIFIED_COMMENT_BPI = oData.sComment ;						
			// Si es verificado, se informan los campos de verificado	
			}else{							
                oUrlParameters.ZZ_VERIFIED = oData.Parameter ;
				oUrlParameters.ZZ_VERIFIED_COMMENT = oData.sComment ;						
			}
			
			var oBundle = this.getOwnerComponent().getModel("i18nm").getResourceBundle();
			if(oData.Parameter == undefined || oData.sComment == "" ){
			//Inicio PRL 04102021 Se comentan estos mensajes de error, no se usan y pueden provocar fallos
			//	  var oJsonError = JSON.parse(oError.responseText);
			//         var errorMessage = oJsonError.error.message.value;
			//Fin PRL 04102021        									         
			         MessageUtil.showMsg("msgTypeFailed", oBundle.getText("MSG_EXE_ACT_FINDING_VERIFY_REQ_FAIL") + "\r\n" );
			         this.getView().setBusy(false);
			         this.getView().getModel().refresh();
			         
				oBusy.close();
				MessageUtil.showMsg("msgTypeFailed",oBundle.getText("MSG_EXE_ACT_FINDING_VERIFY_REQ_FAIL"));
				
			}else{
				var oMenuItemExecution = {};
				oMenuItemExecution.Comment = oData.sComment ;
				oMenuItemExecution.Key = oData.sKey;
				oMenuItemExecution.Action = oData.sActionName;
				oMenuItemExecution.ObjectType = sap.grc.acs.aud.finding.util.constant.ObjectType.Find;
				oMenuItemExecution.Parameter = '';	
				 
				oMenuItemExecution.Parameter = encodeURI(JSON.stringify(oUrlParameters));

		   
		   
		   oActionHandleModel.callFunction(
				   functionName, {
		     urlParameters: oMenuItemExecution,
		     method: "POST",
		     async: true,
		     success: jQuery
		      .proxy(
		       function() {
		        MessageUtil.showMsg("msgTypeSuccessful", this.getResourceBundle().getText(sSuccessTextID));
		        sap.ui.getCore().getEventBus().publish(
		         "sap.grc.acs.aud.finding.EventBus", "findingListRefresh");
		        this.getView().getModel().refresh();
		        this.getView().setBusy(false);
		        this.bIsNavToNotFound = false;
		        this.onNavBackWithoutRefresh();
		       }, this),
		     error: jQuery
		      .proxy(
		       function(oError) {
		        if (oError.responseText) {
		         var oJsonError = JSON.parse(oError.responseText);
		         var errorMessage = oJsonError.error.message.value;
		         MessageUtil.showMsg("msgTypeFailed", this.getResourceBundle().getText(sErrorTextID) + "\r\n" + errorMessage);
		         this.getView().setBusy(false);
		         this.getView().getModel().refresh();
		        }
		       },
		       this)
		    });
			}
		  },

		  							  

		/** Fin de modificaci�n  rgalan RTC788093  07.09.2020 09:30:49
		*/


		handleHeaderButtonPress: function(oData) {
			var sSuccessTextID = "MSG_EXE_FIND_ACTION_" + oData.sActionName.toUpperCase() + "_SUCCESS";
			var sErrorTextID = "MSG_EXE_FIND_ACTION_" + oData.sActionName.toUpperCase() + "_FAIL";
			//get Delegatee
			var oParameter = {};
				oParameter.Delegatee = "";
			for(var i = 0; i < this.oMenuItemsList.length; i++){
				if(this.oMenuItemsList[i].Action === oData.sActionName){
					oParameter.Delegatee = this.oMenuItemsList[i].Delegatee;
					break;
				}
			}
			this.getView().setBusy(true);
			
			this.getModel().create("/MenuItemExecutionSet", {
				Key: oData.sKey,
				ObjectType: sap.grc.acs.aud.finding.util.constant.ObjectType.Find,
				ActionName: oData.sActionName,
				Comment: oData.sComment,
				Parameter: encodeURI(JSON.stringify(oParameter))
			}, {
				success: function() {
					this.actionSuccessCallBack(sSuccessTextID);
				}.bind(this),
				error: function(oError) {
					this.actionErrorCallBack(oError, sErrorTextID);
				}.bind(this)
			});
		},

		FIND_RAISE_ISSUE: function() {
			var oView = this.getView();
			this.oDialog = oView.byId("connectorDialog");

			if (!this.oDialog) {
				// create dialog via fragment factory
				this.oDialog = sap.ui.xmlfragment(oView.getId(), "sap.grc.acs.aud.finding.view.ConnectorDialog", this);
				oView.addDependent(this.oDialog);
				var oRootModel = this.getModel();
				this.oDialog.setModel(oRootModel);
			}

			this.oDialog.open();
		},

		onConnDlgBeforeClose: function() {
			this.oDialog.destroy();
		},

		_raiseIssueOK: function() {
			this._raiseIssue();
		},

		_raiseIssueCancel: function() {
			this.oDialog.close();
		},

		_raiseIssue: function() {
			var oSeletedItem = this.oView.byId("tabConnector").getSelectedItem();
			var oConnectorDialog = this.oDialog;
			if (!oSeletedItem) {
				MessageUtil.showMsg("msgTypeFailed", this.getResourceBundle().getText("msgNoConnectorSelected"));
			} else {
				var oItemData = oSeletedItem.getBindingContext().getObject();
				var aSelections = [];
				aSelections.push({
					Sign: "I",
					Opt: "EQ",
					Field: "KEY",
					Low: this.oView.getBindingContext().getProperty("DBKey").toUpperCase()
				});

				aSelections.push({
					Sign: "I",
					Opt: "EQ",
					Field: "CONN_ID",
					Low: oItemData.Connector
				});

				aSelections.push({
					Sign: "I",
					Opt: "EQ",
					Field: "CONN_NAME",
					Low: oItemData.ConnectorText
				});

				var oData = {
					ObjectType: "FIND",
					ExportType: "R",
					Selections: aSelections
				};
				var sPath = "/ExportJobSet";
				var success_msg = this.getResourceBundle().getText("msgRaiseIssueSuccess");

				if (!this.oExportJobModel) {
					this.oExportJobModel = this.getView().getModel("exportJob");
				}
				oConnectorDialog.setBusy(true);
				this.oExportJobModel
					.create(sPath,
						oData, {
							success: jQuery.proxy(
								function(oRetData, oResponse) {
									oConnectorDialog.setBusy(false);
									success_msg = success_msg.replace(/[{]1[}]/, oItemData.Connector);
									success_msg = success_msg.replace(/[{]2[}]/, oItemData.ConnectorText);
									MessageUtil.showMsg("msgTypeSuccessful", success_msg);
									oConnectorDialog.close();
									this.getView().getModel().refresh(true);
								}, this),
							error: jQuery.proxy(
								function(oError) {
									oConnectorDialog.setBusy(false);
									MessageUtil.showODataErrorMsg(oError);
									oConnectorDialog.close();
								}, this),
							async: true
						});
			}
		}
	});

});
