/*
 * Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui
		.define(
				[
						"sap/ui/core/mvc/Controller",
						"sap/grc/acs/lib/aud/extension/utils/FieldExtensibilityUtil",
						"sap/grc/acs/aud/finding/model/formatter",
						"sap/grc/acs/lib/aud/utils/ComponentUtil",
						"sap/grc/acs/lib/aud/utils/MessageUtil" ],
				function(C, F, f, a, M) {
					"use strict";
					return C
							.extend(
									"sap.grc.acs.aud.finding.extended.block.controller.General",
									{
										formatter : f,
										oMode : {
											Display : "DISPLAY",
											Edit : "EDIT",
											DisableEdit : "DISABLE_EDIT"
										},
										onInit : function() {
											this.oFindingDataInServer = {};
											this._oComponent = a
													.getComponentById(this
															.getView().getId());
											this._oComponent
													.getModel()
													.metadataLoaded()
													.then(
															function() {
																this
																		._createExtensionGroup();
															}.bind(this));
											if (this._oComponent.getModel(
													"intentConfig").getData().intent === "Finding-myFinding"
													|| this._oComponent
															.getModel(
																	"intentConfig")
															.getData().intent === "Finding-displayFindingByMyAction") {
												this
														.getView()
														.byId("auditId")
														.attachInnerControlsCreated(
																this.setAuditTitleValue,
																this);
											} else {
												this
														.getView()
														.byId("auditId")
														.attachPress(
																this.onAuditPress,
																this);
												this
														.getView()
														.byId("findOrg")
														.attachPress(
																this.onFindingOrgPress,
																this);
											}
											this.aDropDownGroupIndex = [];
											this.aDropDownEdit = [];
											this.bTimestampTransformFlag = false;
											sap.ui
													.getCore()
													.getEventBus()
													.subscribe(
															"sap.grc.acs.aud.find.EventBus",
															"resetBlockToDisplayMode",
															this.onRefresh,
															this);
											sap.ui
													.getCore()
													.getEventBus()
													.subscribe(
															"sap.grc.acs.aud.find.EventBus",
															"extensionModelDataUpdateFinished",
															this.setHeaderToolBarVisibility,
															this);
										},
										_createExtensionGroup : function() {
											var e = this.getView().byId(
													"extensionGroup");
											F.createExtensionGroup("Finding",
													e, this._oComponent);
										},
										setAuditTitleValue : function() {
											var A = this.getView().byId(
													"auditId");
											A.getInnerControls()[0].setText(A
													.getValue());
										},
										setFindOrgValue : function() {
											var o = this.getView().byId(
													"findOrg");
											o
													.setValue(this
															.getView()
															.getBindingContext()
															.getObject().FindingOrganizationName);
										},
										setValueHelpFieldsEditable : function() {
											var e = this.getView().byId(
													"extensionGroup");
											var E = this.getView().getModel(
													"extensionModel").getData();
											this.aDropDownGroupIndex = [];
											F.setValueHelpFieldsEditable(e, E,
													this.aDropDownGroupIndex,
													this.aDropDownEdit);
										},
										setDropDownFieldsEditableToFalse : function() {
											for (var i = 0; i < this.aDropDownGroupIndex.length; i++) {
												this
														.getView()
														.byId("extensionGroup")
														.removeGroupElement(
																this
																		.getView()
																		.byId(
																				"extensionGroup")
																		.getGroupElements()[this.aDropDownGroupIndex[i].index]);
												this
														.getView()
														.byId("extensionGroup")
														.insertGroupElement(
																this.aDropDownGroupIndex[i].element,
																this.aDropDownGroupIndex[i].index);
											}
										},
										_saveData : function() {
											var s = this.getView().byId(
													"smartForm");
											if (s.check().length > 0) {
												M
														.showMsg(
																"msgTypeFailed",
																this
																		.getView()
																		.getModel(
																				"i18n")
																		.getResourceBundle()
																		.getText(
																				"msgErrorInput"));
												return;
											}
											this
													._getChangedExecutiveResponsible(
															false, false);
											var u = this.getView().getModel(
													"oData");
											var b = [];
											var d = {};
											var e = this.getView().getModel(
													"extensionModel").getData();
											d = F.saveSmartForm(s, e);
											var p = this.getView()
													.getBindingContext().sPath;
											s.setBusy(true);
											b = this
													._changeExecutiveResponsible();
											var S = this._compareData(
													this.oFindingDataInServer,
													d);
											if (!jQuery.isEmptyObject(S)) {
												b.push(u.createBatchOperation(
														p, "MERGE", S));
											}
											if (b.length > 0) {
												u.addBatchChangeOperations(b);
												u
														.submitBatch(
																jQuery
																		.proxy(
																				function(
																						D,
																						r,
																						E) {
																					s
																							.setBusy(false);
																					if (E.length > 0) {
																					} else {
																						this
																								._setSmartFormToDisplayMode();
																						M
																								.showMsg(
																										"msgTypeSuccessful",
																										this
																												.getView()
																												.getModel(
																														"i18n")
																												.getResourceBundle()
																												.getText(
																														"MSG_UPDATE_FINDING_SUCCESS"));
																					}
																				},
																				this),
																jQuery
																		.proxy(
																				function() {
																					s
																							.setBusy(false);
																				},
																				this));
											} else {
												s.setBusy(false);
												this
														._setSmartFormToDisplayMode();
												M
														.showMsg(
																"msgTypeSuccessful",
																this
																		.getView()
																		.getModel(
																				"i18n")
																		.getResourceBundle()
																		.getText(
																				"MSG_UPDATE_FINDING_SUCCESS"));
											}
										},
										_setSmartFormToDisplayMode : function() {
											this
													._getChangedExecutiveResponsible(
															true, true);
											this
													.setDropDownFieldsEditableToFalse();
											this
													._setButtonVisibility("DISPLAY");
											this.getView().byId("smartForm")
													.setEditable(false);
											this.getView().getModel().refresh(
													true);
										},
										_changeExecutiveResponsibleControl : function() {
											var s = this.getView().byId(
													"smartForm");
											if (s.getGroups()) {
												if (s.getGroups()[0]
														.getFormElements()) {
													for (var j = 0; j < s
															.getGroups()[0]
															.getFormElements().length; j++) {
														var k = s.getGroups()[0]
																.getFormElements()[j]
																.getFields()[0]._oValueBind.path;
														if (k === "to_ExecutiveResponsible") {
															var e = s
																	.getGroups()[0]
																	.getFormElements()[j];
															var c = e
																	.getFields()[0]
																	.getValue();
															this.oRemovedField = e
																	.getFields()[0];
															e.removeAllFields();
															this.oSelectExecutiveResponsible = new sap.m.Select(
																	{
																		forceSelection : false
																	});
															this.oSelectExecutiveResponsible._oValueBind = {
																path : "to_ExecutiveResponsible"
															};
															e
																	.addField(this.oSelectExecutiveResponsible);
															this
																	._getExecutiveResponsibleCandidate(
																			this.oSelectExecutiveResponsible,
																			c);
															break;
														}
													}
												}
											}
										},
										_getExecutiveResponsibleCandidate : function(
												s, n) {
											var d = this.getView().getModel();
											var p = this.getView()
													.getBindingContext()
													+ "/to_AuditExecutiveResponsive";
											d.setUseBatch(false);
											d
													.read(
															p,
															{
																success : jQuery
																		.proxy(
																				function(
																						b) {
																					var t = new sap.ui.core.ListItem(
																							{
																								text : "{FullName}",
																								key : "{UserID}"
																							});
																					b.results
																							.splice(
																									0,
																									0,
																									{
																										FullName : "",
																										UserID : "NONE_USER_SELECTED"
																									});
																					var m = new sap.ui.model.json.JSONModel(
																							b.results);
																					s
																							.setModel(m);
																					s
																							.bindItems(
																									"/",
																									t);
																					if (n) {
																						this
																								._setExecutiveResponsible(
																										s,
																										n);
																					} else {
																						s
																								.setSelectedKey("NONE_USER_SELECTED");
																						this.sOldUid = "NONE_USER_SELECTED";
																					}
																				},
																				this),
																async : true
															});
										},
										_setExecutiveResponsible : function(s,
												n) {
											var I = s.getItems();
											for (var i = 0; i < I.length; i++) {
												if (I[i].getText() === n) {
													s.setSelectedKey(I[i]
															.getKey());
													this.sOldUid = I[i]
															.getKey();
												}
											}
										},
										_getChangedExecutiveResponsible : function(
												i, I) {
											var s = this.getView().byId(
													"smartForm");
											if (!this.oRemovedField) {
												return;
											}
											if (s.getGroups()) {
												if (s.getGroups()[0]
														.getFormElements()) {
													for (var j = 0; j < s
															.getGroups()[0]
															.getFormElements().length; j++) {
														var k = s.getGroups()[0]
																.getFormElements()[j]
																.getFields()[0]._oValueBind.path;
														if (k === "to_ExecutiveResponsible") {
															if (i === false) {
																this.sSelectedUid = s
																		.getGroups()[0]
																		.getFormElements()[j]
																		.getFields()[0]
																		.getSelectedItem()
																		.getKey();
															}
															if (I === true) {
																s.getGroups()[0]
																		.getFormElements()[j]
																		.removeAllFields();
																s.getGroups()[0]
																		.getFormElements()[j]
																		.addField(this.oRemovedField);
															}
															break;
														}
													}
												}
											}
										},
										_changeExecutiveResponsible : function() {
											var b = [];
											if (this.sOldUid !== "NONE_USER_SELECTED") {
												var p = "/"
														+ this
																.getView()
																.getBindingContext()
																.getProperty(
																		"to_ExecutiveResponsible")[0];
											}
											var d = this.getView().getModel(
													"oData");
											if (this.sOldUid === "NONE_USER_SELECTED"
													&& this.sSelectedUid !== "NONE_USER_SELECTED") {
												b
														.push(d
																.createBatchOperation(
																		this
																				.getView()
																				.getBindingContext()
																				.getPath()
																				+ "/to_ExecutiveResponsible",
																		"POST",
																		{
																			UserID : this.sSelectedUid,
																			RoleID : "EXE_RESP",
																			HostKey : this
																					.getView()
																					.getBindingContext()
																					.getObject().DBKey
																		}));
											} else if (this.sOldUid !== "NONE_USER_SELECTED"
													&& this.sSelectedUid === "NONE_USER_SELECTED") {
												b.push(d.createBatchOperation(
														p, "DELETE"));
											} else {
												if (this.sOldUid === this.sSelectedUid) {
												} else {
													b
															.push(d
																	.createBatchOperation(
																			p,
																			"MERGE",
																			{
																				UserID : this.sSelectedUid
																			}));
												}
											}
											return b;
										},
										_formatAudit : function(A, s) {
											return A + " " + s;
										},
										_formatReference : function(r, R) {
											return r + " " + R;
										},
										onAuditPress : function(e) {
											var A = e.getSource()
													.getBindingContext()
													.getObject();
											var s = A.AuditKey
													.replace(/-/g, "");
											var h = "/sap/bc/ui5_ui5/sap/fra_shell/index.html?AuditKey="
													+ s
													+ "&hpashell-fiori=true&lpdinst=AUD&lpdrole=HPA#audAuditDetails";
											window.open(h);
										},
										onPersonPress : function(e) {
											if (this._oPersonQuickView) {
												this._oPersonQuickView
														.destroy();
											}
											var o = e.getSource();
											var p = sap.ui
													.xmlfragment(
															"sap.grc.acs.lib.aud.person.quickView",
															this);
											this._oPersonQuickView = p;
											p.attachAfterClose(function() {
												p.destroy();
											});
											o.addDependent(p);
											jQuery.sap.delayedCall(0, this,
													function() {
														this._oPersonQuickView
																.openBy(o);
													});
										},
										onExecutivePersonPress : function(e) {
											if (this._oPersonQuickView) {
												this._oPersonQuickView
														.destroy();
											}
											var o = e.getSource();
											var p = sap.ui
													.xmlfragment(
															"sap.grc.acs.lib.aud.person.quickView",
															this);
											var d = this.getView().getModel();
											var P = this.getView()
													.getBindingContext()
													+ "/to_ExecutiveResponsible";
											d
													.read(
															P,
															{
																success : jQuery
																		.proxy(
																				function(
																						D) {
																					var b = D.results[0];
																					if (b) {
																						var m = new sap.ui.model.json.JSONModel(
																								b);
																						p
																								.setModel(m);
																						p
																								.bindElement("/");
																					}
																					this._oPersonQuickView = p;
																					p
																							.attachAfterClose(function() {
																								p
																										.destroy();
																							});
																					o
																							.addDependent(p);
																					jQuery.sap
																							.delayedCall(
																									0,
																									this,
																									function() {
																										this._oPersonQuickView
																												.openBy(o);
																									});
																				},
																				this),
																async : false
															});
											this._oPersonQuickView = p;
											p.attachAfterClose(function() {
												p.destroy();
											});
											o.addDependent(p);
											jQuery.sap.delayedCall(0, this,
													function() {
														this._oPersonQuickView
																.openBy(o);
													});
										},
										onFindingOrgPress : function() {
											var o = this
													.getView()
													.getBindingContext()
													.getProperty(
															"to_FindingOrganization");
											if (this.bTimestampTransformFlag === false) {
												o.Timestamp = this
														._transformTimestamp(o.Timestamp);
											}
											var h = "/sap/bc/ui5_ui5/sap/fra_shell/index.html?hpashell-fiori=true#/organizations?lpdrole=HPA&lpdinst=AUD&objectKey="
													+ o.OrgKey
													+ "&isRoot=&tab=info&readOnly=true&timestamp="
													+ o.Timestamp;
											window.open(h);
										},
										_transformTimestamp : function(t) {
											var n;
											if (t.length === 14) {
												var y, m, d, h, s, S;
												y = t.substring(0, 4);
												m = t.substring(4, 6);
												d = t.substring(6, 8);
												h = t.substring(8, 10);
												s = t.substring(10, 12);
												S = t.substring(12, 14);
												n = new Date(y, m - 1, d, h, s,
														S);
												this.bTimestampTransformFlag = true;
											} else {
												n = new Date();
											}
											return n.toISOString();
										},
										formatExecutiveResponsible : function(p) {
											var s = this.getView().byId(
													"smartForm");
											if (p && p !== null
													&& p.length !== 0) {
												var e = this.getView()
														.getBindingContext()
														.getObject("/" + p[0]);
												s.setBusy(false);
												if (e) {
													return e.FullName;
												} else {
													return "";
												}
											} else {
												s.setBusy(false);
												return "";
											}
										},
										_setButtonVisibility : function(m) {
											if (m === "EDIT") {
												this.getView().byId("btnEdit")
														.setVisible(false);
												this.getView().byId("btnSave")
														.setVisible(true);
												this.getView()
														.byId("btnCancel")
														.setVisible(true);
											} else if (m === "DISPLAY") {
												this.getView().byId("btnEdit")
														.setVisible(true);
												this.getView().byId("btnSave")
														.setVisible(false);
												this.getView()
														.byId("btnCancel")
														.setVisible(false);
											} else {
												this.getView().byId("btnEdit")
														.setVisible(false);
												this.getView().byId("btnSave")
														.setVisible(false);
												this.getView()
														.byId("btnCancel")
														.setVisible(false);
											}
										},
										onRefresh : function() {
											this.onCancelBtnPress();
										},
										onCancelBtnPress : function(e) {
											this
													._getChangedExecutiveResponsible(
															true, true);
											this.getView().byId("smartForm")
													.setEditable(false);
											if (this.getView()
													.byId("smartForm")
													.getEditable() === false) {
												this.getView().getModel()
														.resetChanges();
												this
														.setDropDownFieldsEditableToFalse();
												this
														._setButtonVisibility("DISPLAY");
											}
										},
										onSaveBtnPress : function() {
											this._saveData();
										},
										onEditFormPress : function(e) {
											this._setButtonVisibility("EDIT");
											this.getView().byId("smartForm")
													.setEditable(true);
											this.oFindingDataInServer = this
													.getView()
													.getBindingContext()
													.getObject();
											if (this.getView().getModel(
													"extensionModel").getData().executiveResponsible.editable) {
												this.getView().byId(
														"executiveResponsible")
														.setEditable(true);
											}
											this
													._changeExecutiveResponsibleControl();
											this.setValueHelpFieldsEditable();
											this._resetFormFieldValueState();
										},
										onExit : function() {
											F
													.destoryElements(this.aDropDownEdit);
											sap.ui
													.getCore()
													.getEventBus()
													.unsubscribe(
															"sap.grc.acs.aud.find.EventBus",
															"resetBlockToDisplayMode",
															this.onRefresh,
															this);
											sap.ui
													.getCore()
													.getEventBus()
													.unsubscribe(
															"sap.grc.acs.aud.find.EventBus",
															"extensionModelDataUpdateFinished",
															this.setHeaderToolBarVisibility,
															this);
										},
										setHeaderToolBarVisibility : function() {
											if (this.getView().getModel(
													"extensionModel").getData().SmartForm.editable) {
												this.getView().byId(
														"smartFormToolbar")
														.setVisible(true);
											}
										},
										_compareData : function(o, n) {
											var r = {};
											var N, O;
											for ( var b in n) {
												N = n[b];
												O = o[b];
												if (n[b]
														&& o[b]
														&& typeof n[b] === "object"
														&& typeof o[b] === "object"
														&& n[b].toISOString()
														&& o[b].toISOString()) {
													N = n[b].toISOString()
															.substring(0, 19);
													O = o[b].toISOString()
															.substring(0, 19);
												} else if (o[b]
														&& typeof n[b] !== "object"
														&& typeof o[b] === "object"
														&& o[b].toISOString()) {
													O = o[b].toISOString()
															.substring(0, 19);
												} else if (n[b]
														&& typeof n[b] === "object"
														&& typeof o[b] !== "object"
														&& n[b].toISOString()) {
													N = n[b].toISOString()
															.substring(0, 19);
												}
												if (N !== O) {
													r[b] = n[b];
												}
											}
											return r;
										},
										_resetFormFieldValueState : function() {
											var e = this.getView().byId(
													"smartForm").check();
											for (var i = 0; i < e.length; i++) {
												sap.ui.getCore().byId(e[i])
														.setValueState("None");
											}
										}
									});
				});
