/*
 * Copyright (C) 2009-2020 SAP SE or an SAP affiliate company. All rights reserved.
 */
//jQuery.sap.declare("sap.grc.acs.aud.finding.trackopen.extended.Component");
jQuery.sap.declare("sap.grc.acs.aud.finding.trackopen.extended.Component");
					

sap.ui.component.load({
 	name:"sap.grc.acs.aud.finding.trackopen",
 	url: "/sap/bc/ui5_ui5/sap/grcaud_findtrck"
 		 
 });


sap.ui.define([ "sap/ui/core/UIComponent", 
				"sap/ui/Device",
				"sap/grc/acs/aud/finding/app/Component" ], 
   function(U, D, C) {
	"use strict";
	
	 
	return C.extend("sap.grc.acs.aud.finding.trackopen.extended.Component", {
		metadata : {
			manifest : "json",
		     "customizing" : {
//		    	 "sap.ui.viewExtensions":{
//		    		 "sap.grc.acs.aud.finding.block.view.General": {    
//	                        className: "sap.ui.core.mvc.View",
//	                        viewName: "sap.grc.acs.aud.finding.trackopen.extended.view.GeneralCustom",            
//	                        type: "XML"
//	                    }    ,
	
//		    	 },
		    	 "sap.ui.viewReplacements" : {
						"sap.grc.acs.aud.finding.view.Object" : {
							"viewName" : "sap.grc.acs.aud.finding.trackopen.extended.view.Object",
							"type" : "XML"
						},												
						"sap.grc.acs.aud.finding.block.view.General": {    	                        
	                        "viewName": "sap.grc.acs.aud.finding.trackopen.extended.view.General",            
	                        "type": "XML"
	                    }    ,
						
						"sap.grc.acs.aud.finding.view.Worklist" : {
							"viewName" : "sap.grc.acs.aud.finding.trackopen.extended.view.Worklist",
							"type" : "XML"
						}
					},
		         "sap.ui.controllerExtensions" : {
		             
		     "sap.grc.acs.aud.finding.controller.Object" : {
					"controllerName" : "sap.grc.acs.aud.finding.trackopen.extended.Controller.ObjectExtended"
		
				},
				
				"sap.grc.acs.aud.finding.controller.Worklist" : {
					"controllerName" : "sap.grc.acs.aud.finding.trackopen.extended.Controller.Worklist"
		
				},
				
//			},
//			"sap.ui.controllerReplacements": {
				 "sap.grc.acs.aud.finding.activity.controller.BaseController" : {
					 "controllerName":"sap.grc.acs.aud.finding.trackopen.extended.activity.controller.BaseController"
				 
				 },
				 "sap.grc.acs.aud.finding.block.controller.General" : {
					 "controllerName":"sap.grc.acs.aud.finding.trackopen.extended.block.generalCustom"
				 
				 }
			
			},
		          }
		}/*,
		init() : function(){
			var i18nModel = new ResourceModel({
				bundleName: "sap.grc.acs.aud.finding.trackopen.extended.i18n.i18n"
			});
			sap.ui.getCore().setModel(i18nModel, "i18nm");
		}*/
	});
});
