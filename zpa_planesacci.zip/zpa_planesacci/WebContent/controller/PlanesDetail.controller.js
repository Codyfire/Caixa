sap.ui.controller("appPlanesAccion.controller.PlanesDetail", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf zportalaudit.view.planesAccion.PlanesDetail
*/
//	onInit: function() {
//
//	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf zportalaudit.view.planesAccion.PlanesDetail
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf zportalaudit.view.planesAccion.PlanesDetail
*/
	onAfterRendering: function() {
		if(this.getView().selStatus) {
			if(planesAccionUtils.isAuditado()) {
				if(this.getStatus(this.getView().getModel('detail').getData().ActualStatus).getData().length > 0) {
					this.getView().selStatus.setModel(this.getStatus(this.getView().getModel('detail').getData().ActualStatus));
					this.getView().selStatus.setSelectedKey(this.getView().getModel('detail').getData().Status);
					this.getView().getModel('detail').getData().Status = this.getView().selStatus.getProperty("selectedKey");
					this.getView().getModel('detail').getData().StatusDescr = this.getView().selStatus.getSelectedItem().getText();
					
				} else {
					this.getView().selStatus.destroyItems();
					this.getView().selStatus.addItem(new sap.ui.core.Item({  
												        	key : this.getView().getModel('detail').getData().Status,  
												        	text : planesAccionUtils.statusDescr(this.getView().getModel('detail').getData().Status)  
												        }));
					this.getView().selStatus.setSelectedKey(this.getView().getModel('detail').getData().Status);
					
					if(this.isFinalStatus(this.getView().getModel('detail').getData().ActualStatus)) {
						this.getView().datePicker.setEnabled(false);
						this.getView().selStatus.setEnabled(false);
					}
					
				}
				// Se habilita el botón de borrar personas a la lista de acceso
				this.getView().table.setMode(sap.m.ListMode.Delete);
			}
			if(planesAccionUtils.isAuditor()) {
				this.getView().selStatus.destroyItems();
				this.getView().selStatus.addItem(new sap.ui.core.Item({  
											        	key : this.getView().getModel('detail').getData().Status,  
											        	text : planesAccionUtils.statusDescr(this.getView().getModel('detail').getData().Status)  
											        }));
				this.getView().selStatus.setSelectedKey(this.getView().getModel('detail').getData().Status);
				
				
				// Se esconde el botón de añadir personas a la lista de acceso
				this.getView().table.getHeaderToolbar().getContent()[2].setVisible(false);
				
				if(this.getView().getModel('detail').getData().ActualStatus === "02"){
					this.getView().datePicker.setEnabled(false);
				}
				
				if(this.getView().getModel('detail').getData().Overdue === "true" && ( this.getView().getModel('detail').getData().ActualStatus === "01" || this.getView().getModel('detail').getData().ActualStatus === "04") ){
					this.getView().datePicker.setEnabled(false);
				}
				
				if(this.getView().getModel('detail').getData().Validated === "03"){
					this.getView().selStatus.setEnabled(false);
					this.getView().datePicker.setEnabled(false);
				}
				
			}
			//PRL0311
			if(planesAccionUtils.isValidator(this.getView().getModel('detail'))){
				if(this.getStatus(this.getView().getModel('detail').getData().ActualStatus).getData().length > 0) {
					this.getView().selStatus.setModel(this.getStatus(this.getView().getModel('detail').getData().ActualStatus));
					this.getView().selStatus.setSelectedKey(this.getView().getModel('detail').getData().Status);
					this.getView().getModel('detail').getData().Status = this.getView().selStatus.getProperty("selectedKey");
					this.getView().getModel('detail').getData().StatusDescr = this.getView().selStatus.getSelectedItem().getText();
				}	
				
				this.getView().selStatus.setEnabled(false);
				this.getView().datePicker.setEnabled(false);
			}
		}
		
//		if(this.getView().getParent().sId == "planesTemaNavCont") {
//			this.getView().oPage.setShowNavButton(true);
//			this.getView().oPage.setShowHeader(true);
//		}
		
		
										        
//		if(planesAccionUtils.isAuditor()) {
//			if(this.getView().selStatus) {
//				this.getView().selStatus.setModel(this.getStatus(this.getView().getModel('detail').getData().ActualStatus))
//			}
//		}
	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf zportalaudit.view.planesAccion.PlanesDetail
*/
//	onExit: function() {
//
//	}
	doBack: function() {
		sap.ui.getCore().byId('planesTemaNavCont').to('planesAccionTemas');
	},

	goToFinding: function() {
		var dialog = new sap.m.Dialog({
			title: planesAccionUtils.oBundle.getText("info"),
			type: 'Message',
				content: new sap.m.Text({
					text: planesAccionUtils.oBundle.getText("linkSimula")
				}),
			beginButton: new sap.m.Button({
				text: planesAccionUtils.oBundle.getText("ok"),
				press: function () {
					dialog.close();
				}
			}),
			afterClose: function() {
				dialog.destroy();
			}
		});

		dialog.open();
	},
	
//	onSelectFile : function(oEvent) {
//		var oUploadCollection = oEvent.getSource();
//		// Header Token
//		var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
//			name : "x-csrf-token",
//			value : "securityTokenFromModel"
//		});
//		oUploadCollection.addHeaderParameter(oCustomerHeaderToken);
//		//MessageToast.show("Event change triggered");
//	},
	
	doValidateDate: function(oEvent) {
		var date = planesAccionUtils.convertDate(byId('fechVenc').getProperty('dateValue'));
		this.getModel('detail').getData().Deadline = date.substring(6,10) + date.substring(3,5) + date.substring(0,2); 
	},
	
	getStatusValues: function(statusArray) {
		var items = [];
		
		$.each(statusArray, function(i,n){
			$.grep(getModel('statusPlModel').getData().results, function(e){ 
				if(e.Status == n) {
					items.push(e);
					return;
				} else {
				}
			});
		});
		
		return items;
	},
	
	isFinalStatus: function(status) {
		var items = ["02","03","05","07"];
		var found = false;
		
		$.each(items, function(i,n){
			if(n == status)
				found = true;
		});
				
		return found;
	},
	
	getStatus: function(currStatus) {
		var possibleStatus = [];
		var controller = this;
				
		switch(currStatus){
			case "":
				break;
			case "01": // Planificado
				if(planesAccionUtils.isAuditor())
					possibleStatus = controller.getStatusValues(["02","03","05","07"]);
				else
					possibleStatus = controller.getStatusValues(["01","02","03","05"]);
				break;
			case "02": // Finalizado
				if(planesAccionUtils.isAuditor())
					possibleStatus = controller.getStatusValues(["02","06"]);
				break;
			case "03": // Obsoleto
				//possibleStatus = getStatusValues(["01","03","05"]);
				break;
			case "04": // En estudio
				if(planesAccionUtils.isAuditor())
					possibleStatus = controller.getStatusValues(["01","03","05","07"]);
				else
					possibleStatus = controller.getStatusValues(["04","01","03","05"]);
				break;
			case "05": // Se asume el riesgo
				//possibleStatus = getStatusValues(["01","03","05"]);
				break;
			case "06": // Verificado
				//possibleStatus = getStatusValues(["01","03","05"]);
				break;
			case "07": // Actualizado
				//possibleStatus = getStatusValues(["01","03","05"]);
				break;
			default:
				break;
		}
		
		var model = new sap.ui.model.json.JSONModel();
		model.setData(possibleStatus);
		return model;
	},
	addListAcces: function (){
		var ctrl = this;
		if(sap.ui.getCore().getComponent('searchComponentListaAcceso')) {
			sap.ui.getCore().getComponent('searchComponentListaAcceso').destroy();
		}
		
		var oSearchCenterComp  = sap.ui.getCore().createComponent({
			id: "searchComponentListaAcceso",
	        name: "searchComponentPlanes"
	    });
		
		var showError = function(title, message){
			
			var dialog = new sap.m.Dialog({
		        title: title,
		        type: 'Message',
		        content: new sap.m.Text({
		            text: message
		        }),
		        state: sap.ui.core.ValueState.Warning,
		        beginButton: 
		        	new sap.m.Button({
	    				text: 'Aceptar',
	        	        press: function () {
	        	            dialog.close();
	        	        }}),
		        afterClose: function() {
		          dialog.destroy();
		        }
		     });
			
			dialog.open();
			
		}
		
		// Función de añadir resultados a las tablas
		var addFunct = function() {
			var selItems = this.getParent().getContent()[1].getSelectedItems();
			
			if(selItems.length == 0) { 
				showError(planesAccionUtils.oBundle.getText("usuNoValido"), planesAccionUtils.oBundle.getText("selecOpc"));
			}
			else {
				var bindingContext = selItems[0].getBindingContext().sPath;
				var newEntry =  sap.ui.getCore().getModel("personas").getProperty(bindingContext).UserId;
				var array = sap.ui.getCore().byId("planesDetailEditable").table.getItems();
				var detectRepeatedEntry = function(newEntry, array) {
					var i = 0;
					while(i < array.length){
						if(newEntry === array[i].getAggregation("cells")[0].getProperty("text")){
							return true;
						}
						i++;
					}
					return false;
				}
				
				if(!detectRepeatedEntry(newEntry, array)){
					
					sap.ui.getCore().byId("planesDetailEditable").table.addItem(
						new sap.m.ColumnListItem({
							cells:[
									new sap.m.Label({ text: sap.ui.getCore().getModel("personas").getProperty(bindingContext).UserId,
									editable:true,}),
									new sap.m.Label({ text: sap.ui.getCore().getModel("personas").getProperty(bindingContext).FullName,
										editable:true,})
									],
							customData: new sap.ui.core.CustomData({
								key : "key",
								value : sap.ui.getCore().getModel("personas").getProperty(bindingContext).UserId})
							})	
					);
					this.getParent().close();
				}else{
					showError(planesAccionUtils.oBundle.getText("usuExist"), planesAccionUtils.oBundle.getText("usuRepetido"));
				}
			}};
			

		    var addSearchFunct = function(){
		        //Agafo el valor del serchfield
		        var text = "*" +  this.getParent().getContent()[0].getProperty("value") + "*";
		        
		        if(text != ""){
		              //Preparo els filtres amb els valors
		              var aFilters = [];
//		            if(tieneNumeros(text))//Si conté numeros es que cerquen per matricula
//		                   aFilters.push(new sap.ui.model.Filter("UserId",sap.ui.model.FilterOperator.Contains, text));
//		            else
//		                   aFilters.push(new sap.ui.model.Filter("FullName",sap.ui.model.FilterOperator.Contains, text));
		              
		              aFilters.push(new sap.ui.model.Filter("FullName",sap.ui.model.FilterOperator.EQ,text.toUpperCase()));
		              getUsersLdap(aFilters);
		              sap.ui.getCore().getComponent('searchComponentListaAcceso').table.setModel(sap.ui.getCore().getModel("personas"));
		        }
		     }

			
		// Cabecera, Binding Posiciones, Modo de Lista, Binding Aggregation, Path, Model, AddFunction
		oSearchCenterComp.setupInicial(planAcc.tableCols.buscarPersonas, planAcc.tableCels.buscarPersonas, "SingleSelect", "", "/results", "", addFunct,addSearchFunct);
		
		// Se crea un contenedor para el componente
		var oCompCont = new sap.ui.core.ComponentContainer({
			 component: oSearchCenterComp,
		});
	
	},
	
	
	
	onSelectFile : function(oEvent) {
		var uploader = this;
		onFileSelected(oEvent, uploader);
	},
	
	onBeforeUploadStarts: function(oEvent) {
	},
	
	onUploadComplete: function(oEvent) {
		console.log("\t\tUpload Complete:");
	},
	
	onUploadTerminated: function(oEvent) {
		console.log("\t\tUpload terminado:");
	},
	
	onFileDeleted: function(oEvent) {
		console.log("\t\tFile deleted:");
	}
	
});