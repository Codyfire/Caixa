sap.ui.controller("appPlanesAccion.controller.PlanesAccion", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf zportalaudit.controller.planesAccion.PlanesAccion
*/
//	onInit: function() {
//
//	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf zportalaudit.controller.planesAccion.PlanesAccion
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf zportalaudit.controller.planesAccion.PlanesAccion
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf zportalaudit.controller.planesAccion.PlanesAccion
*/
//	onExit: function() {
//
//	}
	showDetail: function() {
		loadUserPerm(this,'planesAccion');
		var navContainer = sap.ui.getCore().byId('planesNavCont');
		
		if(navContainer.getPage('comparacionPlanAcciones')) {
			navContainer.getPage('comparacionPlanAcciones').destroy();
		}
		
		var bindingContext = this.getBindingContextPath();
		var contextData = sap.ui.getCore().getModel('planesAccion').getProperty(bindingContext);
		var binKey = "binary'" + convertKey(contextData.ActionKey) +"'";
		var url = "/InfoActionDetailSet?$filter=ActionKey eq  " + binKey + "&$expand=InfoAccessList,InfoThemes";
		
		getModel('con').read(url,{async:false, success: successActionPlanDetail, error: errorActionPlanDetail});
		
		function successActionPlanDetail(oData, oDataResp) {
			var model = new sap.ui.model.json.JSONModel();
			if(oData.results.length > 0){
				oData.results[0].ActionKey = contextData.ActionKey;
				oData.results[0].DateRepIssued = contextData.DateRepIssued;
				oData.results[0].GroupText = contextData.GroupText;
				oData.results[0].FindingId = contextData.FindingId;
				oData.results[0].FindingTitle = contextData.FindingTitle;
				oData.results[0].Recommendation = contextData.Recommendation;
				oData.results[0].DepartmentName = contextData.DepartmentName;
				/**
				 * INI MOD PPM 069908 Rafael Galán Baquero 10/02/2021				
				 * Se contempla la celda del campo departamento y se concatena el código de dpto al nombre							 
				 * Codigo nuevo
				 */ 
				// Se añade el codigo de dpto. para concatenar en el detalle con el nombre d dpto.
				oData.results[0].ZzDepartment = contextData.ZzDepartment;
				/**
			     *  FIN MOD PPM 069908 Rafael Galán Baquero 10/02/2021				
				*/
				oData.results[0].Id = contextData.Id;
				oData.results[0].Title = contextData.Title;
				oData.results[0].RankingDescr = contextData.RankingDescr;
				oData.results[0].ReportId = contextData.ZzReportId;
				oData.results[0].NameOrg = contextData.NameOrg;
				oData.results[0].ActualDeadline = contextData.Deadline;
				oData.results[0].ActualStatus = contextData.Status;
				oData.results[0].ActualStatusDescr = contextData.StatusDescr;
				oData.results[0].ZzAnOrg = contextData.ZzAnOrg;
				oData.results[0].Verified = contextData.Verified;
				oData.results[0].Overdue = contextData.Overdue;
				oData.results[0].Autho = contextData.Autho;
				oData.results[0].ZzReportId = contextData.ZzReportId;
				oData.results[0].ZzReportTitle = contextData.ZzReportTitle;
				oData.results[0].Milestone = contextData.Milestone;
				oData.results[0].Validated = contextData.Validated;
//				oData.results[0].FinalDate = contextData.FinalDate;
				/**
				 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
				 * Código nuevo
				 */
				//Se añade el campo origen
				oData.results[0].ZzOrigen = contextData.ZzOrigen;
				 		
				/**
				 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
				 */
				
				/**
				 * INI MOD PPM100084365 - (BPI) - Rol auditor/auditado compatibles en BPI2 23/01/2023				
				 * Código nuevo
				 */
				oData.results[0].ZzViewAudited = contextData.ZzViewAudited;
				oData.results[0].ZzViewAuditor = contextData.ZzViewAuditor;
				 		
				/**
				 * FIN MOD PPM100084365 - (BPI) - Rol auditor/auditado compatibles en BPI2 23/01/2023
				 */
			}
			model.setData(oData.results.length > 0 ? oData.results[0]: "");
			
			sap.ui.getCore().setModel(model,"planAccionInfo");
			
			var keyConverted = "binary'" + convertKey(oData.results[0].ActionKey) +"'";
			var url = "/InfoActionDetailSet" + "(" + keyConverted + ")/NoteSet?$orderby=CreateTime desc" ;
			//var url = formatUrl(getPlanAccionNotasUrl(),[convertKey(oData.results[0].Key)]);
			getModel('con').read(url,{async:false, success: successGetNotes, error: errorGetNotes});
				
			function successGetNotes(oData, oDataRes) {
				var modelNotes = new sap.ui.model.json.JSONModel();
				modelNotes.setData(oData);
				
				var view = sap.ui.view({id:"comparacionPlanAcciones", viewName:"appPlanesAccion.view.ComparacionPlanAcciones", type:sap.ui.core.mvc.ViewType.JS})		
				//view.setModel(model);
				
				
				
				navContainer.addPage(view);
				navContainer.to('comparacionPlanAcciones', {oModel: model, oModelNotes: modelNotes});	
			}
			
			function errorGetNotes(error) {
				console.log(error);
			}	
		}
		
		function errorActionPlanDetail(error){
			planesAccionUtils.showMsg(planesAccionUtils.oBundle.getText("errCargarAccion"));
		}
	},
	
	reloadPage: function(key) {
		
		if (byId("loading")){
			byId("loading").destroy();
		}
		byId('planesNavCont').addPage(new sap.m.Page("loading").setBusy(true));
		byId('planesNavCont').to("loading");
		byId('planesNavCont').getPage('comparacionPlanAcciones').destroy();

		var navContainer = sap.ui.getCore().byId('planesNavCont');
		
		if(navContainer.getPage('comparacionPlanAcciones')) {
			navContainer.getPage('comparacionPlanAcciones').destroy();
		}

		var binKey = "binary'" + convertKey(key) +"'";
		var url = "/InfoActionDetailSet?$filter=ActionKey eq  " + binKey + "&$expand=InfoAccessList,InfoThemes";	
		
		getModel('con').read(url,{async:false, success: successActionPlanDetail, error: errorActionPlanDetail});
		
		function successActionPlanDetail(oData, oDataResp) {
			var model = new sap.ui.model.json.JSONModel();

			if(oData.results.length > 0){
				var modelPlanesAccion = sap.ui.getCore().getModel('planesAccion').oData.results;
				var b = false, i = 0;

				for(; i < modelPlanesAccion.length && !b ; i++ ) {
					if(modelPlanesAccion[i].ActionKey == key) { 
						b = true; 
						oData.results[0].ActionKey = modelPlanesAccion[i].ActionKey;
						oData.results[0].DateRepIssued = modelPlanesAccion[i].DateRepIssued;
						oData.results[0].GroupText = modelPlanesAccion[i].GroupText;
						oData.results[0].FindingId = modelPlanesAccion[i].FindingId;
						oData.results[0].FindingTitle = modelPlanesAccion[i].FindingTitle;
						oData.results[0].Recommendation = modelPlanesAccion[i].Recommendation;
						oData.results[0].DepartmentName = modelPlanesAccion[i].DepartmentName;
						oData.results[0].Id = modelPlanesAccion[i].Id;
						oData.results[0].Title = modelPlanesAccion[i].Title;
						oData.results[0].RankingDescr = modelPlanesAccion[i].RankingDescr;
						oData.results[0].ReportId = modelPlanesAccion[i].ZzReportId;
						oData.results[0].NameOrg = modelPlanesAccion[i].NameOrg;
						oData.results[0].ActualDeadline = modelPlanesAccion[i].Deadline;
						oData.results[0].ActualStatus = modelPlanesAccion[i].Status;
						oData.results[0].ActualStatusDescr = modelPlanesAccion[i].StatusDescr;
						oData.results[0].ZzAnOrg = modelPlanesAccion[i].ZzAnOrg;
						oData.results[0].Verified = modelPlanesAccion[i].Verified;
						oData.results[0].Overdue = modelPlanesAccion[i].Overdue;
						oData.results[0].Autho = modelPlanesAccion[i].Autho;
						oData.results[0].ZzReportId =  modelPlanesAccion[i].ZzReportId;
						oData.results[0].ZzReportTitle =  modelPlanesAccion[i].ZzReportTitle;
						oData.results[0].Milestone = modelPlanesAccion[i].Milestone
						oData.results[0].Validated = modelPlanesAccion[i].Validated;
		//				oData.results[0].FinalDate = modelPlanesAccion[i].FinalDate;
						/**
						 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
						 * Código nuevo
						 */
						//Se añade el campo origen
						oData.results[0].ZzOrigen = modelPlanesAccion[i].ZzOrigen;
						 		
						/**
						 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
						 */
						
						/**
						 * INI MOD PPM 069908 Rafael Galán Baquero 10/02/2021				
						 * Se contempla la celda del campo departamento y se concatena el código de dpto al nombre							 
						 * Codigo nuevo
						 */ 
						// Se añade el codigo de dpto. para concatenar en el detalle con el nombre d dpto.
						oData.results[0].ZzDepartment = modelPlanesAccion[i].ZzDepartment;
						/**
					     *  FIN MOD PPM 069908 Rafael Galán Baquero 10/02/2021				
						*/
						/**
						 * INI MOD PPM100084365 - (BPI) - Rol auditor/auditado compatibles en BPI2 23/01/2023				
						 * Código nuevo
						 */
						oData.results[0].ZzViewAudited = modelPlanesAccion[i].ZzViewAudited;
						oData.results[0].ZzViewAuditor = modelPlanesAccion[i].ZzViewAuditor;
						 		
						/**
						 * FIN MOD PPM100084365 - (BPI) - Rol auditor/auditado compatibles en BPI2 23/01/2023
						 */
						
					}
				}
					
			}
			model.setData(oData.results.length > 0 ? oData.results[0]: "");
			
			sap.ui.getCore().setModel(model,"planAccionInfo");
			
			var keyConverted = "binary'" + convertKey(oData.results[0].ActionKey) +"'";
			var url = "/InfoActionDetailSet" + "(" + keyConverted + ")/NoteSet?$orderby=CreateTime desc" ;
			getModel('con').read(url,{async:false, success: successGetNotes, error: errorGetNotes});
				
			function successGetNotes(oData, oDataRes) {
				var modelNotes = new sap.ui.model.json.JSONModel();
				modelNotes.setData(oData);
				var view = sap.ui.view({id:"comparacionPlanAcciones", viewName:"appPlanesAccion.view.ComparacionPlanAcciones", type:sap.ui.core.mvc.ViewType.JS})		
				navContainer.addPage(view);
				navContainer.to('comparacionPlanAcciones', {oModel: model, oModelNotes: modelNotes});	
			}
			
			function errorGetNotes(error) {
				console.log(error);
			}
		}
		
		function errorActionPlanDetail(error){
			planesAccionUtils.showMsg(planesAccionUtils.oBundle.getText("errCargarAccion"));
		}
		
	},
	
	onFilterPress: function() {		
		
			/**
			 * INI MOD RTC 748088 Rafael Galán Baquero 04/07/2019
			 * Código antiguo
			 *  
//			if(!sap.ui.getCore().getComponent("planAccionFilter")){
//			var oFilterComp = new sap.ui.getCore().createComponent({
//				name: "filterComponent",
//				id:"planAccionFilter",
//				settings: {refObject: "tablePlanAcciones"},
//			});
//			var component = sap.ui.getCore().getComponent("tablePlanAcciones");
//			var table = component.table;
			
//				/**
//				 *	INI MOD RTC-537578 Rafael Galán Baquero 08/03/2019
//				 * Código antiguo
//			
//					//oFilterComp.addAllItems(
//					//		[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"), planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"), planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal"), planesAccionUtils.oBundle.getText("fechaVenc")],				
//					//		[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"), planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"), planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal")],
//					//		[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"), planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"), planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal")], 
//					//		"planesAccion", 
//					//		["RankingDescr","ZzReportId", "Id", "Title", "DepartmentName", "AudGroup", "NameOrg", "StatusDescr", "Validated"],
//					//		table, "NOTHEME"
//					//);
//				*  Código nuevo
//				*
//				// Se añaden los campos gerente y título de informa a filter y sorter
//					oFilterComp.addAllItems(
//						[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"), planesAccionUtils.oBundle.getText("tituloInforme"),planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"), planesAccionUtils.oBundle.getText("gerente"),planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal"), planesAccionUtils.oBundle.getText("fechaVenc")],				
//						[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"), planesAccionUtils.oBundle.getText("tituloInforme"),planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"), planesAccionUtils.oBundle.getText("gerente"), planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal")],
//						[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"),  planesAccionUtils.oBundle.getText("tituloInforme"),planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"),  planesAccionUtils.oBundle.getText("gerente"), planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal")], 
//						"planesAccion", 
//						["RankingDescr","ZzReportId", "ZzReportTitle","Id", "Title", "DepartmentName", "AudGroup","Fullname", "NameOrg", "StatusDescr", "Validated"],
//						table, "NOTHEME"
//						);
//			
//				/**
//				* FIN MOD RTC 537578 Rafael Galan Baquero 08/03/2019
//				*
			
			 * Código nuevo
			 */
		
		if(!sap.ui.getCore().getComponent("planAccionFilter")){
			
			// Se obtienen los departamentos disponibles en el sistema y se crea el modelo
			loadDepartments();
			
			var oFilterComp = new sap.ui.getCore().createComponent({
				name: "filterComponent",
				id:"planAccionFilter",
				settings: {refObject: "tablePlanAcciones"},
			});
			var component = sap.ui.getCore().getComponent("tablePlanAcciones");
			var table = component.table;
			/**
			 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
			 * Código antiguo
			 * 			// Se modifica la key del filtro departmentName por ZzDepartment
			oFilterComp.addAllItems(
				[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"), planesAccionUtils.oBundle.getText("tituloInforme"),planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"), planesAccionUtils.oBundle.getText("gerente"),planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal"), planesAccionUtils.oBundle.getText("fechaVenc")],				
				[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"), planesAccionUtils.oBundle.getText("tituloInforme"),planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"), planesAccionUtils.oBundle.getText("gerente"), planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal")],
				[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"),  planesAccionUtils.oBundle.getText("tituloInforme"),planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"),  planesAccionUtils.oBundle.getText("gerente"), planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal")], 
				"planesAccion", 
				["RankingDescr","ZzReportId", "ZzReportTitle","Id", "Title", "ZzDepartment", "AudGroup","Fullname", "NameOrg", "StatusDescr", "Validated"],
				table, "NOTHEME"
				);
 
			 * Código nuevo
			 */
			//Se añade el campo origen
			// Se modifica la key del filtro departmentName por ZzDepartment
			oFilterComp.addAllItems(
				[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"), planesAccionUtils.oBundle.getText("tituloInforme"),planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"), planesAccionUtils.oBundle.getText("gerente"),planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal"), planesAccionUtils.oBundle.getText("origen"), planesAccionUtils.oBundle.getText("fechaVenc")],				
				[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"), planesAccionUtils.oBundle.getText("tituloInforme"),planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"), planesAccionUtils.oBundle.getText("gerente"), planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal"),planesAccionUtils.oBundle.getText("origen")],
				[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"),  planesAccionUtils.oBundle.getText("tituloInforme"),planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"),  planesAccionUtils.oBundle.getText("gerente"), planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal"),planesAccionUtils.oBundle.getText("origen")], 
				"planesAccion", 
				["RankingDescr","ZzReportId", "ZzReportTitle","Id", "Title", "ZzDepartment", "AudGroup","Fullname", "NameOrg", "StatusDescr", "Validated","ZzOrigen"],
				table, "NOTHEME"
				);
		 		
			/**
			 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
			 */
			/**
			 * FIN MOD RTC 748088 Rafael Galán Baquero 04/07/2019
			 */
			
			
			
			var oCompCont = new sap.ui.core.ComponentContainer({
				component: oFilterComp
			});
			
			oFilterComp.openDialog();
			component.refreshTablePaginationForFilteredItems(1,10, false);
		}else{
			var oFilterComp = sap.ui.getCore().getComponent("planAccionFilter");
			oFilterComp.openDialog();
			var component = sap.ui.getCore().getComponent("tablePlanAcciones");
			component.refreshTablePaginationForFilteredItems(1,10, false);
		}
	},
	
	onAdd: function() {
		
	},
			
	doSave: function() {
	
	},
	
	doBack: function() {
		//sap.ui.getCore().byId('launchpad').to('tileContainer');
	},
	
	doValidateDate: function(oEvent) {
		var date = oEvent.getSource().getValue();
	},
	
	
	//INICIO RTC-537578
	onColumnsVisualizar: function(){
	
		
			if(!sap.ui.getCore().getComponent("visColumnComPlanComp")){
			var oVisualitzadorComp = new sap.ui.getCore().createComponent({
				name: "visualizarColumnasComponentPlanes",
				id:"visColumnComPlanComp"
			});
			var table = sap.ui.getCore().getComponent("tablePlanAcciones").table;
			oVisualitzadorComp.addAllItems(table);
			 
			oVisualitzadorComp.addConfirmFunction(planesAccionUtils.assignTableVisualizadorPlan);
						
			
			
			var oVisualitzadorCompCont = new sap.ui.core.ComponentContainer({
				component: oVisualitzadorComp
			});
			
			oVisualitzadorComp.openDialog();
			
			
		}else{
			var oVisualitzadorComp = sap.ui.getCore().getComponent("visColumnComPlanComp");

			oVisualitzadorComp.openDialog();
		}
//	
		
	}
    //FIN    RTC-537578
			
		
});