sap.ui.controller("appPlanesAccion.controller.PlanesAccionTemas", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf zportalaudit.controller.planesAccion.PlanesAccion
*/
//	onInit: function() {
//
//	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf zportalaudit.controller.planesAccion.PlanesAccion
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf zportalaudit.controller.planesAccion.PlanesAccion
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf zportalaudit.controller.planesAccion.PlanesAccion
*/
//	onExit: function() {
//
//	}
	showDetail: function() {
		loadUserPerm(this,'planesAccionTemas');
		var navContainer = sap.ui.getCore().byId('planesTemaNavCont');
		
		if(navContainer.getPage('planesTemasDetail')) {
			navContainer.getPage('planesTemasDetail').destroy();
		}
		
		var bindingContext = this.getBindingContextPath();
		var contextData = sap.ui.getCore().getModel('planesAccionTemas').getProperty(bindingContext);
		var binKey = "binary'" + convertKey(contextData.ActionKey) +"'";
		var url = "/InfoActionDetailSet?$filter=ActionKey eq  " + binKey + "&$expand=InfoAccessList,InfoThemes";
		 
		getModel('con').read(url,{async:false, success: successActionPlanDetail, error: errorActionPlanDetail});
		
		function successActionPlanDetail(oData, oDataResp) {
			var model = new sap.ui.model.json.JSONModel();
			if(oData.results.length > 0){
				oData.results[0].ActionKey = contextData.ActionKey;
				oData.results[0].DateRepIssued = contextData.DateRepIssued;
				oData.results[0].GroupText = contextData.GroupText;
				oData.results[0].FindingId = contextData.FindingId;
				oData.results[0].FindingTitle = contextData.FindingTitle;
				oData.results[0].Recommendation = contextData.Recommendation;
				oData.results[0].DepartmentName = contextData.DepartmentName;
				/**
				 * INI MOD PPM 069908 Rafael Galán Baquero 10/02/2021				
				 * Se contempla la celda del campo departamento y se concatena el código de dpto al nombre							 
				 * Codigo nuevo
				 */ 
				// Se añade el codigo de dpto. para concatenar en el detalle con el nombre d dpto.
				oData.results[0].ZzDepartment = contextData.ZzDepartment;
				/**
			     *  FIN MOD PPM 069908 Rafael Galán Baquero 10/02/2021				
				*/
				oData.results[0].Id = contextData.Id;
				oData.results[0].Title = contextData.Title;
				oData.results[0].RankingDescr = contextData.RankingDescr;
				oData.results[0].ReportId = contextData.ZzReportId;
				oData.results[0].NameOrg = contextData.NameOrg;
				oData.results[0].ActualDeadline = contextData.Deadline;
				oData.results[0].ActualStatus = contextData.Status;
				oData.results[0].ActualStatusDescr = contextData.StatusDescr;
				oData.results[0].ZzAnOrg = contextData.ZzAnOrg;
				oData.results[0].ZzReportId = contextData.ZzReportId;
				oData.results[0].ZzReportTitle = contextData.ZzReportTitle;
				oData.results[0].Milestone = contextData.Milestone;
				/**
				 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
				 * Código nuevo
				 */
				oData.results[0].ZzOrigen = contextData.ZzOrigen;
				/**
				 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
				 */
				
			}			
			model.setData(oData.results.length > 0 ? oData.results[0]: "");
			sap.ui.getCore().setModel(model, "planesAccionTemasDetail");
			
			var keyConverted = "binary'" + convertKey(oData.results[0].ActionKey) +"'";
			var url = "/InfoActionDetailSet" + "(" + keyConverted + ")/NoteSet?$orderby=CreateTime desc" ;
			//var url = formatUrl(getPlanAccionNotasUrl(),[convertKey(oData.results[0].Key)]);
			getModel('con').read(url,{async:false, success: successGetNotes, error: errorGetNotes});
				
			function successGetNotes(oData, oDataRes) {
				
				var modelNotes = new sap.ui.model.json.JSONModel();
				
				//Inicio RTC-540728
				//ocultar los comentarios de verificación con STATUS = ‘02’ de la tabla 
				//GRCAUD_D_NOTE siempre que la acción asociada a la nota este verificada, 
				//es decir que el campo ZZ_VERIFIED = 01 o ZZ_VERIFIED = 02.
				//Además el usuario tiene que ser auditado
				var isAuditado = planesAccionUtils.isAuditado()		
				var Verified = getModel("planesAccionTemasDetail").getData().Verified;
				if(isAuditado && oData.results.length > 0 && (Verified == "01" || Verified == "02") ){
					//Recuperamos todos comentarios con Status 02
					var comenSta02 = oData.results.filter(function(i) { return i.Status == "02"  });
					if (comenSta02.length > 0) {
						//REcuperamos la KEY correspondiente del último comentario, como viene ordenado del back, sería el primer comentario
						var key = comenSta02[0].Key;
						//Recuperamos todos los comentarios menos el correspondiente por KEY
						oData.results = oData.results.filter(function(i) { return i.Key != key  }); // filtramos			
						
					}
				}
				//Fin RTC-540728
				
				
				modelNotes.setData(oData);
				
				//var view = sap.ui.view({id:"comparacionPlanAccionesTemas", viewName:"appPlanesAccion.view.ComparacionPlanAcciones", type:sap.ui.core.mvc.ViewType.JS});		
				var view = sap.ui.view({id:"planesTemasDetail", height:"100%",viewName:"appPlanesAccion.view.PlanesDetail", type:sap.ui.core.mvc.ViewType.JS});
				view.oPage.setEnableScrolling(true);
				view.setModel(model,'detail');
				view.addStyleClass("nonEditable");
				model.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
				
				// Se rellena el listado de comentarios
				var list = byId('planesTemasDetail').commentList;
				var notes = oData.results;
				
				$.each(notes,function(i,n) {
					
					list.addItem(
						new sap.m.FeedListItem({
							sender:n.CreatedByName,
							iconDensityAware:false,
							info:n.CreatedBy,
							timestamp: planesAccionUtils.convertDateTime(n.CreateTime),
							text:n.Text,
							senderActive: false,
							iconActive: false,
							iconInset: false,
							showIcon:false
						})
					);
				});
				
				var key = model.getData().ActionKey;
				var oModel = onFetchStandardAttachments(key, "Actions");
				view.uploader.setModel(oModel);
				
				
				navContainer.addPage(view);
				navContainer.to('planesTemasDetail', {oModel: model, oModelNotes: modelNotes});	
			}
			
			function errorGetNotes(error) {
				console.log(error);
			}	
		}
		
		function errorActionPlanDetail(error){
			planesAccionUtils.showMsg(planesAccionUtils.oBundle.getText("errCargarAccion"));
		}
	},
	
	reloadPage: function(key) {
		
		if (byId("loading")){
			byId("loading").destroy();
		}
		byId('planesNavCont').addPage(new sap.m.Page("loading").setBusy(true));
		byId('planesNavCont').to("loading");
		byId('planesNavCont').getPage('comparacionPlanAcciones').destroy();

		var navContainer = sap.ui.getCore().byId('planesNavCont');
		
		if(navContainer.getPage('comparacionPlanAcciones')) {
			navContainer.getPage('comparacionPlanAcciones').destroy();
		}

		var binKey = "binary'" + convertKey(key) +"'";
		var url = "/InfoActionDetailSet?$filter=Key eq  " + binKey + "&$expand=InfoAccessList";		
		getModel('con').read(url,{async:false, success: successActionPlanDetail, error: errorActionPlanDetail});
		
		function successActionPlanDetail(oData, oDataResp) {
			var model = new sap.ui.model.json.JSONModel();
			model.setData(oData.results.length > 0 ? oData.results[0]: "");
			
			var keyConverted = "binary'" + convertKey(oData.results[0].Key) +"'";
			var url = "/InfoActionDetailSet" + "(" + keyConverted + ")/NoteSet?$orderby=CreateTime desc" ;
			getModel('con').read(url,{async:false, success: successGetNotes, error: errorGetNotes});
				
			function successGetNotes(oData, oDataRes) {
				var modelNotes = new sap.ui.model.json.JSONModel();
				
				modelNotes.setData(oData);
				var view = sap.ui.view({id:"comparacionPlanAcciones", viewName:"appPlanesAccion.view.ComparacionPlanAcciones", type:sap.ui.core.mvc.ViewType.JS})		
				navContainer.addPage(view);
				navContainer.to('comparacionPlanAcciones', {oModel: model, oModelNotes: modelNotes});	
			}
			
			function errorGetNotes(error) {
				console.log(error);
			}
		}
		
		function errorActionPlanDetail(error){
			planesAccionUtils.showMsg(planesAccionUtils.oBundle.getText("errCargarAccion"));
		}
		
	},
	
	onFilterPress: function() {
		if(!sap.ui.getCore().getComponent("planAccionFilterTemas")){
			var oFilterComp = new sap.ui.getCore().createComponent({
				name: "filterComponent",
				id:"planAccionFilterTemas",
				settings: {refObject: "tablePlanAccionesTema"},
			});
			var component = sap.ui.getCore().getComponent("tablePlanAccionesTema");
			var table = component.table;

			/**
			 * INI MOD RTC 748088 Rafael Galán Baquero 04/07/2019
			 * Código antiguo
			
//				/**
//				 * 	INI MOD RTC-537578 Rafael Galán Baquero 08/03/2019
//				 * Código antiguo
//			 
//				oFilterComp.addAllItems(
//						[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"), planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"), planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal"), planesAccionUtils.oBundle.getText("fechaVenc")],				
//						[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"), planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"), planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal")],
//						[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"), planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"), planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal")], 
//						"planesAccion", 
//						["RankingDescr", "ZzReportId", "Id", "Title", "DepartmentName", "AudGroup", "NameOrg", "StatusDescr", "Validated"],
//						//["RankingDescr", "ZzReportId", "Id", "Title", "DepartmentName", "AudGroup", "NameOrg", "Status", "Validated"],
//						table, "THEME"
//						);
//			
//				 * Código nuevo
//				 *
//					oFilterComp.addAllItems(
//							[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"), planesAccionUtils.oBundle.getText("tituloInforme"),planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"),planesAccionUtils.oBundle.getText("gerente"), planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal"), planesAccionUtils.oBundle.getText("fechaVenc")],				
//							[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"), planesAccionUtils.oBundle.getText("tituloInforme"),planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"),planesAccionUtils.oBundle.getText("gerente"), planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal")],
//							[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"),  planesAccionUtils.oBundle.getText("tituloInforme"),planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"),planesAccionUtils.oBundle.getText("gerente"), planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal")], 
//							"planesAccion", 
//							["RankingDescr", "ZzReportId","ZzReportTitle", "Id", "Title", "DepartmentName", "AudGroup","Fullname", "NameOrg", "StatusDescr", "Validated"],
//							table, "THEME"
//							);
//					/**
//					 * 	FIN MOD RTC-537578 Rafael Galán Baquero 08/03/2019
//					 *
					 
			 * Código nuevo
			 */
			// Se modifica la key del filtro de departamento de DepartmentName a ZzDepartment
			/**
			 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
			 * Código antiguo
			oFilterComp.addAllItems(
					[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"), planesAccionUtils.oBundle.getText("tituloInforme"),planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"),planesAccionUtils.oBundle.getText("gerente"), planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal"), planesAccionUtils.oBundle.getText("fechaVenc")],				
					[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"), planesAccionUtils.oBundle.getText("tituloInforme"),planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"),planesAccionUtils.oBundle.getText("gerente"), planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal")],
					[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"),  planesAccionUtils.oBundle.getText("tituloInforme"),planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"),planesAccionUtils.oBundle.getText("gerente"), planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal")], 
					"planesAccion", 
					["RankingDescr", "ZzReportId","ZzReportTitle", "Id", "Title", "ZzDepartment", "AudGroup","Fullname", "NameOrg", "StatusDescr", "Validated"],
					table, "THEME"
					);
			
			* Código nuevo
			*/
			oFilterComp.addAllItems(
					[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"), planesAccionUtils.oBundle.getText("tituloInforme"),planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"),planesAccionUtils.oBundle.getText("gerente"), planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal"), planesAccionUtils.oBundle.getText("origen"), planesAccionUtils.oBundle.getText("fechaVenc")],				
					[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"), planesAccionUtils.oBundle.getText("tituloInforme"),planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"),planesAccionUtils.oBundle.getText("gerente"), planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal"),planesAccionUtils.oBundle.getText("origen")],
					[planesAccionUtils.oBundle.getText("criticidad"), planesAccionUtils.oBundle.getText("numInformes"),  planesAccionUtils.oBundle.getText("tituloInforme"),planesAccionUtils.oBundle.getText("numAccion"), planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"),planesAccionUtils.oBundle.getText("gerente"), planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("estadoVal"),planesAccionUtils.oBundle.getText("origen")], 
					"planesAccion", 
					["RankingDescr", "ZzReportId","ZzReportTitle", "Id", "Title", "ZzDepartment", "AudGroup","Fullname", "NameOrg", "StatusDescr", "Validated","ZzOrigen"],
					table, "THEME"
					);
			/**
			 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
			 */
			
			/**
			 * FIN MOD RTC 748088 Rafael Galán Baquero 04/07/2019
			 */						

			
			var oCompCont = new sap.ui.core.ComponentContainer({
				component: oFilterComp
			});
			
			oFilterComp.openDialog();
			
			//true porque estamos en temas
			component.refreshTablePaginationForFilteredItems(1,10, true);
		}else{
			var oFilterComp = sap.ui.getCore().getComponent("planAccionFilterTemas");
			oFilterComp.openDialog();
			var component = sap.ui.getCore().getComponent("tablePlanAccionesTema");
			component.refreshTablePaginationForFilteredItems(1,10, true);
		}
	},
	
	onAdd: function() {
		
	},
			
	doSave: function() {
	
	},
	
	doBack: function() {
		//sap.ui.getCore().byId('launchpad').to('tileContainer');
	},
	
	doValidateDate: function(oEvent) {
		var date = oEvent.getSource().getValue();
	},
	
	getPressedFilters: function(themes) {
		for(i = 0; i < planesAccionUtils.filtersTemas.length; ++i){
			if(planesAccionUtils.filtersTemas[i].sPath == "ThemeId") {
				planesAccionUtils.filtersTemas.splice(i,1);
				--i;
			}
		}
		
		for(i = 0; i < themes.length; ++i){
			if(themes[i].getProperty("pressed")) planesAccionUtils.filtersTemas.push(new sap.ui.model.Filter("ThemeId",sap.ui.model.FilterOperator.EQ, themes[i].getAggregation("customData")[0].getValue()));	
		}
		
		 loadPlanesAccionThemes(0, 7, planesAccionUtils.filtersTemas, planesAccionUtils.sortersTemas, planesAccionUtils.grouping);
	}
	
	/**
	 * INICIO MOD RTC-537578 Rafael Galán Baquero 04/03/19 
	 * Código nuevo
	 */	
	,
	
	// Se añade el método encargado de montar el popup de visualizador de columnas
	onColumnsVisualizar: function(){
		
				
		if(!sap.ui.getCore().getComponent("visColumnComTemasComp")){
			var oVisualitzadorComp = new sap.ui.getCore().createComponent({
				name: "visualizarColumnasComponentTemas",
				id:"visColumnComTemasComp"
			});
			var table = sap.ui.getCore().getComponent("tablePlanAccionesTema").table;
			oVisualitzadorComp.addAllItems(table);
			
			
			oVisualitzadorComp.addConfirmFunction(planesAccionUtils.assignTableVisualizadorTema);
			
			var oVisualitzadorCompCont = new sap.ui.core.ComponentContainer({
				component: oVisualitzadorComp
			});
			
			oVisualitzadorComp.openDialog();
			
			
		}else{
			var oVisualitzadorComp = sap.ui.getCore().getComponent("visColumnComTemasComp");

			oVisualitzadorComp.openDialog();
		}
//	
		
	}
	/**
	 * FIN MOD RTC-537578 Rafael Galán Baquero 04/03/19 
	 */
		
});