sap.ui.controller("appPlanesAccion.controller.PlanesAccionTabContainer", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf projecte_prova_component.app
*/
//	onInit: function() {
//
//	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf projecte_prova_component.app
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf projecte_prova_component.app
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf projecte_prova_component.app
*/
//	onExit: function() {
//
//	}
	
	onIconTabBarSelect: function(oEvent) {
		var key = oEvent.getSource().getProperty("selectedKey");
		if(byId("planesNavContainer"))byId("planesNavContainer").destroy();
		if(byId("planesTemaNavContainer"))byId("planesTemaNavContainer").destroy();
		if(key == "1")
			byId("tab1").addContent(sap.ui.view({id:"planesNavContainer", height: "100%", viewName:"appPlanesAccion.view.PlanesNavContainer", type:sap.ui.core.mvc.ViewType.JS}));
		else
			byId("tab2").addContent(sap.ui.view({id:"planesTemaNavContainer", height: "100%", viewName:"appPlanesAccion.view.PlanesTemaNavContainer", type:sap.ui.core.mvc.ViewType.JS}));
	}

});