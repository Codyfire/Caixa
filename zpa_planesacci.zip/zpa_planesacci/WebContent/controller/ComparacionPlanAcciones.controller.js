sap.ui.controller("appPlanesAccion.controller.ComparacionPlanAcciones", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf zportalaudit.controller.planesAccion.ComparacionPlanAcciones
*/
//	onInit: function() {
//
//	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf zportalaudit.controller.planesAccion.ComparacionPlanAcciones
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf zportalaudit.controller.planesAccion.ComparacionPlanAcciones
*/ 
	onAfterRendering: function() {
		var view = this.getView();
		/*var sideContent = view.sideContent;
		sideContent._oMCScroller._scrollTo(0,sideContent._oSCScroller._scrollY,0);*/
		var oController = this;
		var footer = new sap.m.Bar({});
		var btns = [];
		var btns = this.botonEstadoPlanes(view.getContent()[0].getContent()[0].getAggregation("mainContent")[0].getModel('detail').getData().ActualStatus);
		$.each(btns, function(i,n) {
			footer.addContentRight(new sap.m.Button({text: n, 
					press: function(oEvent) {
						oController.doAction(oEvent, n);
					}
				})
			);
		});
		
		view.getContent()[0].setFooter(footer);
	
	},
	
/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf zportalaudit.controller.planesAccion.ComparacionPlanAcciones
*/
//	onExit: function() {
//
//	}
	
	doBack: function() {
		sap.ui.getCore().byId('planesNavCont').to('planesAccion');
	},
	
	doSave: function(validated) {
		var ctrl = this;
		var newData = ctrl.getView().sideContent.getSideContent()[0].getModel('detail').getData();
		var isComAudita = false;
		
		if(validated != undefined && validated != null && validated == "05") {
			isComAudita = true;
		}
		
		/**Realizamos comprobaciones antes de guardar**/
		
		if( (newData.Status == undefined || newData.Status == "") && planesAccionUtils.isAuditado()) {
			ctrl.showError(planesAccionUtils.oBundle.getText("adv"),planesAccionUtils.oBundle.getText("selectEstado"));
			return;
		}
		
	/*	if(ctrl.getView().sideContent.getSideContent()[0].datePicker._lastValue == "" && newData.ActualStatus !== "02"){ //Estado verificar
			ctrl.showError(planesAccionUtils.oBundle.getText("adv"),planesAccionUtils.oBundle.getText("fechaOblig"));
			return;
		}
	*/
		
		var status;
		if (planesAccionUtils.isAuditor()) {
			status = newData.ActualStatus;
		} else {
			status = newData.Status;
		}
		
		//Comprobaciones de fechas
		if(!isComAudita)
			// Comentado por RTC511450: Desactivar justificación cambio recomendación
			//if(!ctrl.validateDate(status, newData)) return;
		
		var text;
		if(validated === "01"){
			text = planesAccionUtils.oBundle.getText("validAccion");
		}else if (validated === "02"){
			text = planesAccionUtils.oBundle.getText("rechaAccion");
		}else{
			if( validated === undefined || validated == null)
				validated = newData.Validated;
			text = planesAccionUtils.oBundle.getText("guardarCambios");
		}
		
		/**Dialog para guardar**/
		var dialog = new sap.m.Dialog({
			//width: "50%",
			title: planesAccionUtils.oBundle.getText("info"),
			type: 'Message',
			content: [new sap.m.Text({text: text})
			],
			beginButton: new sap.m.Button({
				text: planesAccionUtils.oBundle.getText("aceptar"),
				press: function () {
					var entity = {};
					var notes = {};
					var notesArray = [];
					var currentData = ctrl.getView().sideContent.getMainContent()[0].getModel('detail').getData(); // Parte no editable
					
					entity.Validated = validated;
					entity.Verified = newData.Verified;
					entity.ActionKey = newData.ActionKey;
					entity.Status = status;
					if(isComAudita) {
						entity.Deadline = currentData.Deadline;
					} else {
						entity.Deadline = newData.Deadline;
					}
					entity.Autho = newData.Autho;
					entity.InfoAccessListDeep = ctrl.getInfoAccessListDeep();
					entity.InfoThemesDeep = ctrl.getInfoThemesListDeep();
					
					// Preparamos los datos para las notas
					notesArray.push({ActionKey: newData.ActionKey,
						Text: newData.Commentary,
						Status: currentData.ActualStatus}
					);
					
					//Guardamos
					savePlanAccion(entity, notesArray);
					
					//Recargamos los planes de acción con el skip y el top correspondientes
					var top = sap.ui.getCore().getComponent("tablePlanAcciones").rowsForPage;
					var currentPage = 1;
					if(sap.ui.getCore().getComponent("tablePlanAcciones").oFlex.getItems()[1] !== undefined){
						currentPage = sap.ui.getCore().getComponent("tablePlanAcciones").oFlex.getItems()[1].getCurrentPage();
					}
					var skip = (currentPage-1) * top;
					var aFilters = planesAccionUtils.filters;
					var aSorters = planesAccionUtils.sorters;
					var grouping = planesAccionUtils.grouping;
					loadPlanesAccion(skip,top,aFilters,aSorters,grouping);
					
					//Función para hacer reload a la página
					byId('planesAccion').getController().reloadPage(entity.ActionKey);
					
					dialog.close();
				
				}
			}),
			endButton: new sap.m.Button({
				text: planesAccionUtils.oBundle.getText("cancelar"),
				press: function () { dialog.close(); },
			}),
			afterClose: function() {
				dialog.destroy();
			}
		});

		dialog.open();
	},

 	doChangeStatus: function(title, textEstado, typeFragment, estado) {
 		
 		var ctrl = this;
 		/**Realizamos comprobaciones antes de guardar**/
		
		if(this.getView().sideContent.getSideContent()[0].datePicker._lastValue == "" && estado !== "02"){ //Estado !== Verificar
			this.showError(planesAccionUtils.oBundle.getText("adv"),planesAccionUtils.oBundle.getText("fechaOblig"));
			return;
		}
		
 		var newData = this.getView().sideContent.getSideContent()[0].getModel('detail').getData();
 		
 		// Comentado por RTC511450: Desactivar justificación cambio recomendación
 		//Comprobaciones de fechas
		/*if(!this.validateDate(estado, newData)){
			return "";
		}*/
 		
 		var dialog = new sap.m.Dialog("change",{
	      title: title,
	      content: [sap.ui.jsfragment(typeFragment,this)],
	      beginButton: new sap.m.Button({
	        text: textEstado,
	        press: function (oEvent) {
	        		var coment = oEvent.getSource().getParent().mAggregations.content["0"].mAggregations.formContainers["0"].mAggregations.formElements[1].mAggregations.fields["0"].mProperties.value;
	        		if(coment != undefined && coment != ""){
	        			
		        		/** Guardamos **/
	        			var entity = {};
	        			var notes = {};
	        			var notesArray = [];
	        			var currentData = ctrl.getView().sideContent.getMainContent()[0].getModel('detail').getData(); // Parte no editable
	        			
	        			//Cargamos los datos del plan de acción
	        			entity.Validated = "00";
	        			entity.Verified = "00";
	        			entity.ActionKey = newData.ActionKey;
	        			entity.Status = estado;
	        			entity.Deadline = newData.Deadline;
	        			entity.Autho = "false";
	        			entity.InfoAccessListDeep = ctrl.getInfoAccessListDeep();
	        			entity.InfoThemesDeep = ctrl.getInfoThemesListDeep();
	        			
	        			if(typeFragment == "fragment.OkKoAprobar") {
	        				var strOk = oEvent.getSource().getParent().mAggregations.content["0"].mAggregations.formContainers["0"].mAggregations.formElements[2].mAggregations.fields["0"].mProperties.selectedItemId;
	        				
	        				if(strOk == "") { 
	        					ctrl.showError(planesAccionUtils.oBundle.getText("adv"),planesAccionUtils.oBundle.getText("verifOblig"));
	        					return;
	        				}
	        				entity.Verified = strOk == "ok" ? "01" : "02";
	        			}
	        			
	        			// Preparamos los datos para las notas
	        			/*notes.ActionKey = newData.ActionKey;
	        			notes.Status = estado;
	        			notes.Text = coment;*/
	        			
	        			notesArray.push({ActionKey: newData.ActionKey,
							Text: coment,
							Status: estado}
						);
	        			
	        			notesArray.push({ActionKey: ctrl.getView().sideContent.getSideContent()[0].getModel('detail').getData().ActionKey,
							Text: ctrl.getView().sideContent.getSideContent()[0].getModel('detail').getData().Commentary,
							Status: ctrl.getView().sideContent.getSideContent()[0].getModel('detail').getData().ActualStatus}
						);
	        			
	        			//Guardamos
	        			savePlanAccion(entity, notesArray);
	        			
	        			
						//Recargamos los planes de acción con el skip y el top correspondientes
						var top = sap.ui.getCore().getComponent("tablePlanAcciones").rowsForPage;
						var currentPage = 1;
						if(sap.ui.getCore().getComponent("tablePlanAcciones").oFlex.getItems()[1] !== undefined){
							currentPage = sap.ui.getCore().getComponent("tablePlanAcciones").oFlex.getItems()[1].getCurrentPage();
						}
						var skip = (currentPage-1) * top;
						var aFilters = planesAccionUtils.filters;
						var aSorters = planesAccionUtils.sorters;
						var grouping = planesAccionUtils.grouping;
						loadPlanesAccion(skip,top,aFilters,aSorters,grouping);
	        			
	        			//Función para hacer reload a la página
	        			sap.ui.getCore().byId('planesNavCont').to('planesAccion');
	        			
		                dialog.close();
		                
	        		}else{
	        			ctrl.showError(planesAccionUtils.oBundle.getText("adv"),planesAccionUtils.oBundle.getText("comentOblig"));
	        		}
	        	}
	       }),
	       endButton: new sap.m.Button({
		        text: planesAccionUtils.oBundle.getText("cancelar"),
		        press: function(){
		          dialog.close();
		        }	
		   }),
	       afterClose: function() {
	    	   dialog.destroy();
	       }
	    })
 		
 		dialog.open();

 	},
	
 	
 	doModifyDate: function() {
 		
 		var ctrl = this;

 		var dialog = new sap.m.Dialog("change",{
	      title: planesAccionUtils.oBundle.getText("modifFechaVenc"),
	      content: [sap.ui.jsfragment("fragment.ComentarioMasFecha", this)],
	      beginButton: new sap.m.Button({
	        text: planesAccionUtils.oBundle.getText("aceptar"),
	        press: function (oEvent) {
	        		var coment = oEvent.getSource().getParent().mAggregations.content["0"].mAggregations.formContainers["0"].mAggregations.formElements[1].mAggregations.fields["0"].mProperties.value,
	        			fecha = oEvent.getSource().getParent().mAggregations.content["0"].mAggregations.formContainers["0"].mAggregations.formElements[2].mAggregations.fields["0"].mProperties.value;
	        		if(coment == undefined || coment == ""){
	        			ctrl.showError(planesAccionUtils.oBundle.getText("adv"),planesAccionUtils.oBundle.getText("comentOblig"));
	        		} else if (fecha === "") {
	        			ctrl.showError(planesAccionUtils.oBundle.getText("adv"),planesAccionUtils.oBundle.getText("fechaVencOblig"));
	        		} else {
		        		/** Guardamos **/
	        			var entity = {};
	        			var notes = {};
	        			var notesArray = [];
	        			var newData = ctrl.getView().sideContent.getSideContent()[0].getModel('detail').getData();
	        			
	        			//Cargamos los datos del plan de acción
	        			entity.Validated = "00";
	        			entity.Overdue = "false";
	        			entity.Verified = newData.Verified;
	        			entity.ActionKey = newData.ActionKey;
	        			entity.Status = newData.ActualStatus;
	        			entity.Deadline = fecha.substring(6,10) + fecha.substring(3,5) + fecha.substring(0,2);
	        			entity.Autho = newData.Autho;
	        			entity.InfoAccessListDeep = ctrl.getInfoAccessListDeep();
	        			entity.InfoThemesDeep = ctrl.getInfoThemesListDeep();
	        			
	        			// Preparamos los datos para las notas
	        			/*notes.ActionKey = newData.ActionKey;
	        			notes.Status = newData.ActualStatus;
	        			notes.Text = coment;*/
	        			
	        			
	        			notesArray.push({ActionKey: newData.ActionKey,
							Text: coment,
							Status: newData.ActualStatus}
						);
	        			
	        			notesArray.push({ActionKey: ctrl.getView().sideContent.getSideContent()[0].getModel('detail').getData().ActionKey,
							Text: ctrl.getView().sideContent.getSideContent()[0].getModel('detail').getData().Commentary,
							Status: ctrl.getView().sideContent.getSideContent()[0].getModel('detail').getData().ActualStatus}
						);
	        			
	        			
	        			//Guardamos
	        			savePlanAccion(entity, notesArray);
	        			
						//Recargamos los planes de acción con el skip y el top correspondientes
						var top = sap.ui.getCore().getComponent("tablePlanAcciones").rowsForPage;
						var currentPage = 1;
						if(sap.ui.getCore().getComponent("tablePlanAcciones").oFlex.getItems()[1] !== undefined){
							currentPage = sap.ui.getCore().getComponent("tablePlanAcciones").oFlex.getItems()[1].getCurrentPage();
						}
						var skip = (currentPage-1) * top;
						var aFilters = planesAccionUtils.filters;
						var aSorters = planesAccionUtils.sorters;
						var grouping = planesAccionUtils.grouping;
						loadPlanesAccion(skip,top,aFilters,aSorters,grouping);
	        			
	        			//Función para hacer reload a la página
	        			sap.ui.getCore().byId('planesNavCont').to('planesAccion');
	        			
		                dialog.close();
		                
	        		}
	        	}
	       }),
	       endButton: new sap.m.Button({
		        text: planesAccionUtils.oBundle.getText("cancelar"),
		        press: function(){
		          dialog.close();
		        }	
		   }),
	       afterClose: function() {
	    	   dialog.destroy();
	       }
	    })
 		
 		dialog.open();

 	},
	
	validateDate: function(estado, newData) {
		var dateDiff = planesAccionUtils.dateDiff(planesAccionUtils.convertDateToISO(planesAccionUtils.convertDate(newData.DateRepIssued)),planesAccionUtils.convertDateToISO(byId('fechVenc').getValue()),"m");
		var ctrl = sap.ui.controller("appPlanesAccion.controller.PlanesDetail");
		

		var showFragment = function(text){
			
			var dialog = new sap.m.Dialog({
		           title: planesAccionUtils.oBundle.getText("adv"),
		           type: 'Message',
		           state: 'Warning',
		                  content: new sap.m.Text({
		                         text: text
		                  }),
		           state: sap.ui.core.ValueState.Warning,
		           beginButton: new sap.m.Button({
		                  text: planesAccionUtils.oBundle.getText("aceptar"),
		                  press: function () {
		                         dialog.close();
		                         var box = sap.ui.jsfragment("fragment.ComentarioMasAdjunto", ctrl);
		                         var dialog1 = new sap.m.Dialog({
							           title: '',
							           type: 'Message',
							           state: 'Warning',
							           content: box,
							           state: sap.ui.core.ValueState.Warning,
							           beginButton: new sap.m.Button({
						                  text: planesAccionUtils.oBundle.getText("aceptar"),
						                  press: function () {
						                	  //save
						                	  ctrl = sap.ui.controller("appPlanesAccion.controller.ComparacionPlanAcciones");
						                	  var saved = ctrl.saveFromAuthPopup.call(ctrl, this.getParent().getContent()[0].mAggregations.items);
						                	  if(saved){
						                		  dialog1.close();
						                	}
						                  }
							           }),
							           endButton: new sap.m.Button({
							                  text: planesAccionUtils.oBundle.getText("cancelar"),
							                  press: function () {
							                         dialog1.close();
							                  }
							           }),
							           afterClose: function() {
							                  dialog1.destroy();
							           }
							    });
							    dialog1.open();
		                  }
		           }),
		           endButton: new sap.m.Button({
		                  text: planesAccionUtils.oBundle.getText("cancelar"),
		                  press: function () {
		                         dialog.close();
		                  }
		           }),
		           afterClose: function() {
		                  dialog.destroy();
		           }
		    });
		    dialog.open();
			
		}
		// Se añade 0.03 que es un dia en milisegundos para incluir el último dia del periodo como permitido 
		if(newData.Autho === "false") {
			switch(estado) {
				case "01": //"Planificado":
						if(dateDiff > 12.03 && newData.RankingDescr === "Bajo") {
							showFragment(planesAccionUtils.oBundle.getText("accionError1Plani"));
							return false;
							
						}else if(dateDiff > 6.03 && newData.RankingDescr === "Medio"){
							showFragment(planesAccionUtils.oBundle.getText("accionError2Plani"));
							return false;
							
						}else if(dateDiff > 3.03 && (newData.RankingDescr === "Crítico" || newData.RankingDescr === "Alto")){
							showFragment(planesAccionUtils.oBundle.getText("accionError3Plani"));
							return false;
						}
						break;
				case "04": //"En Estudio":
						if(dateDiff > 1.03 && newData.Overdue === "false" && planesAccionUtils.isAuditor()) {
							showFragment(planesAccionUtils.oBundle.getText("accionErrorSupera"));
							
							return false;
						}
						break;
				default:
						break;
			}
		}
		return true;
	},
	
	getInfoAccessListDeep: function() {
		
		var listaAcc = sap.ui.getCore().byId("planesDetailEditable").table.getItems();
		var InfoAccessList = [];
		
		$.each(listaAcc,function(i,n){
			InfoAccessList.push({Id: n.getAggregation('cells')[0].getProperty('text')});
		});
		
		return InfoAccessList.length > 0 ? InfoAccessList : [{}];
		
	},
	
	getInfoThemesListDeep: function() {
		
		var listaThemes = sap.ui.getCore().byId("planesDetailEditable").oTagCloud.oPanel.getContent();
		var InfoThemesList = [];
		
		$.each(listaThemes,function(i,n){
			var themeText = n.getProperty("text");
			//oEvent.getSource().getAggregation("customData")[0].getProperty("text")
			$.each(sap.ui.getCore().getModel("temasModel").getData().results,function(i,n){
				if(n.Theme == themeText){
					InfoThemesList.push({Key: n.Key });
					return false;;
				}
			});
			
		});
		
		return InfoThemesList.length > 0 ? InfoThemesList : [{}];
		
	},
	
	botonEstadoPlanes: function(estado) {
		
		var btns = [];
		if(planesAccionUtils.isAuditor() && (byId("planesDetailEditable").getModel('detail').getData().Validated == "01" || byId("planesDetailEditable").getModel('detail').getData().Validated == "00" || byId("planesDetailEditable").getModel('detail').getData().Validated == ""
			|| byId("planesDetailEditable").getModel('detail').getData().Validated == "04"|| byId("planesDetailEditable").getModel('detail').getData().Validated == "05")) {
			switch(estado) {
				case "04": //"En Estudio":
						btns.push(planesAccionUtils.oBundle.getText("planificar"));
						btns.push(planesAccionUtils.oBundle.getText("obsoleto"));
						/**
						 * INI MOD PPM-057146 Nuevos Estados en Findings
						 * U0192021 Rafa Galán 26/10/2020
						 *Cod. antiguo
						*/
						// Se eliminan los botones se asume el riesgo y actualizado
						//btns.push(planesAccionUtils.oBundle.getText("aceptRiesgo"));
						//btns.push(planesAccionUtils.oBundle.getText("actualizar"));
						/**
						 * FIN MOD PPM-057146 Nuevos Estados en Findings
						 * U0192021 Rafa Galán 26/10/2020
						*/
						btns.push(planesAccionUtils.oBundle.getText("comAudita"));
						if(byId("planesDetailEditable").getModel('detail').getData().Overdue === "true"){
							btns = [];
							btns.push(planesAccionUtils.oBundle.getText("modifFecha"));
						}
						break;
				case "01": //"Planificado":
						btns.push(planesAccionUtils.oBundle.getText("completar"));
						btns.push(planesAccionUtils.oBundle.getText("obsoleto"));
						/**
						 * INI MOD PPM-057146 Nuevos Estados en Findings
						 * U0192021 Rafa Galán 26/10/2020
						 *Cod. antiguo
						*/
						// Se eliminan los botones se asume el riesgo y actualizado
						//btns.push(planesAccionUtils.oBundle.getText("aceptRiesgo"));
						//btns.push(planesAccionUtils.oBundle.getText("actualizar"));
						/**
						 * FIN MOD PPM-057146 Nuevos Estados en Findings
						 * U0192021 Rafa Galán 26/10/2020
						*/
						btns.push(planesAccionUtils.oBundle.getText("comAudita"));
						if(byId("planesDetailEditable").getModel('detail').getData().Overdue === "true"){
							btns = [];
							btns.push(planesAccionUtils.oBundle.getText("modifFecha"));
						}
						break;
				case "03": //"Obsoleto":
						break;
				case "02": //"Completo/Finalizado":
						if(byId("planesDetailEditable").getModel('detail').getData().Verified === "02") {
							btns.push(planesAccionUtils.oBundle.getText("planificar"));
						/**INI MOD RTC788093 lzumarra 03.07.2020*/
							//Se comenta la verificación
						} /*else if(byId("planesDetailEditable").getModel('detail').getData().Verified === "00"){
							btns.push(planesAccionUtils.oBundle.getText("verificar"));
						}*/
							/**FIM MOD RTC788093*/					
						break;		
				case "06": //"Verificado":
						break;
				case "05": //"Riesgo Aceptado":
					break;
				case "07": //"Actualizado":
					break;
				default:
					break;
			}
			
			if(byId("planesDetailEditable").getModel('detail').getData().Verified !== "01") {
				btns.push(planesAccionUtils.oBundle.getText("guardar"));
			}
			
		}else if(planesAccionUtils.isValidator(this.getView().sideContent.getMainContent()[0].getModel('detail')) && byId("planesDetailEditable").getModel('detail') && byId("planesDetailEditable").getModel('detail').getData().Validated == "03"){
			btns.push(planesAccionUtils.oBundle.getText("validar"));
			btns.push(planesAccionUtils.oBundle.getText("rechazar"));
		} else if(planesAccionUtils.isAuditado() && byId("planesDetailEditable").getModel('detail') && byId("planesDetailEditable").getModel('detail').getData().Validated != "03"){
			btns.push(planesAccionUtils.oBundle.getText("guardar"));
		}  else if(planesAccionUtils.isAuditor()) {
			btns.push(planesAccionUtils.oBundle.getText("guardar"));
		}
		
		return btns;
	},
	
	
	doAction: function(oEvent, action) {
		var estado = "";
		var oController = this;
		switch(action) {
			case planesAccionUtils.oBundle.getText("enEstudio"):
				break;
			case planesAccionUtils.oBundle.getText("planificar"):
				this.doChangeStatus(planesAccionUtils.oBundle.getText("planifAccion"), planesAccionUtils.oBundle.getText("planificar"), "fragment.Comentario", "01");
				break;
			case planesAccionUtils.oBundle.getText("obsoleto"):
				this.doChangeStatus(planesAccionUtils.oBundle.getText("accionEstObs"), planesAccionUtils.oBundle.getText("aceptar"), "fragment.Comentario", "03");
				break;
			case planesAccionUtils.oBundle.getText("completar"):
				this.doChangeStatus(planesAccionUtils.oBundle.getText("complAccion"), planesAccionUtils.oBundle.getText("aceptar"), "fragment.Comentario", "02");
				break;
			case planesAccionUtils.oBundle.getText("aceptRiesgo"):
				this.doChangeStatus(planesAccionUtils.oBundle.getText("asumirRiesgo"), planesAccionUtils.oBundle.getText("aceptar"), "fragment.Comentario", "05");
				break;
			case planesAccionUtils.oBundle.getText("verificar"):	
				this.doChangeStatus(planesAccionUtils.oBundle.getText("verifAccion"), planesAccionUtils.oBundle.getText("aceptar"), "fragment.OkKoAprobar", "02");
				break;
			case planesAccionUtils.oBundle.getText("validar"):
				oController.doSave("01");
				break;
			case planesAccionUtils.oBundle.getText("rechazar"):
				oController.doSave("02");
				break;
			case planesAccionUtils.oBundle.getText("actualizar"):
				this.doChangeStatus(planesAccionUtils.oBundle.getText("actuAccion"), planesAccionUtils.oBundle.getText("aceptar"), "fragment.Comentario", "07");
				break;
			case planesAccionUtils.oBundle.getText("guardar"):
				oController.doSave("");
				break;
			case planesAccionUtils.oBundle.getText("modifFecha"):
				this.doModifyDate();
				break;
			case planesAccionUtils.oBundle.getText("comAudita"):
				oController.doSave("05");
				break;
			default:
				
				break;
		}
	},
	
	showError: function(title, message){
		
		var dialog = new sap.m.Dialog({
	        title: title,
	        type: 'Message',
	        content: new sap.m.Text({
	            text: message
	        }),
	        state: sap.ui.core.ValueState.Warning,
	        beginButton: 
	        	new sap.m.Button({
    				text: planesAccionUtils.oBundle.getText("aceptar"),
        	        press: function () {
        	            dialog.close();
        	        }}),
	        afterClose: function() {
	          dialog.destroy();
	        }
	     });
		
		dialog.open();
		
	},
	
	saveFromAuthPopup: function(dialog){
		
		var coment = dialog["0"].mAggregations.formContainers["0"].mAggregations.formElements[1].mAggregations.fields["0"].mProperties.value;
		
		if(coment === undefined || coment === "" || dialog[1].mAggregations.items.length == 0){
			
			this.showError(planesAccionUtils.oBundle.getText("adv"), planesAccionUtils.oBundle.getText("seRequiereCom"));
			return false;
		}
		else{
		
			var newData = byId("comparacionPlanAcciones").sideContent.getSideContent()[0].getModel('detail').getData();
	
			var entity = {};
			var notes = {};
			var currentData = byId("comparacionPlanAcciones").sideContent.getMainContent()[0].getModel('detail').getData(); // Parte no editable
			
			// Si el auditor solo cambia la fecha del plan de acción mandaremos un espacio en el campo
			// Validated para que en BACKEND sepa que el Auditor a pulsado sobre "Guardar"
			if( planesAccionUtils.isAuditor() 
			&&  newData.ActualStatus == newData.Status 
			&&  newData.ActualDeadline != newData.Deadline ){
				
				entity.Validated = "";
			}
			else{
				
				entity.Validated = newData.Verified;	
				
			}
			
			//entity.Validated = newData.Validated;
			entity.Verified = newData.Verified;
			entity.ActionKey = newData.ActionKey;
			entity.Status = newData.ActualStatus;
			entity.Deadline = newData.Deadline;
			entity.Autho = "true";
			entity.InfoAccessListDeep = this.getInfoAccessListDeep();
			entity.InfoThemesDeep = this.getInfoThemesListDeep();
			
			//this.getParent().getContent()[0].mAggregations.items["0"].mAggregations.formContainers["0"].mAggregations.formElements[1].mAggregations.fields["0"].mProperties
	  	  	//this.getParent().getContent()[0].mAggregations.items["1"]
			
			
			// Preparamos los datos para las notas
			notes.ActionKey = newData.ActionKey;
			notes.Status = newData.ActualStatus;
			notes.Text = coment;
			
			//Guardamos
			savePlanAccion(entity, notes);
			
			//Función para hacer reload a la página
			sap.ui.getCore().byId('planesNavCont').to('planesAccion');

			return true;
		}
	}
});