sap.ui.jsview("appPlanesAccion.view.PlanesDetailEditable", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf zportalaudit.view.planesAccion.PlanesDetail
	*/ 
	getControllerName : function() {
		return "appPlanesAccion.controller.PlanesDetail";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf zportalaudit.view.planesAccion.PlanesDetail
	*/ 
	createContent : function(oController) {
		var view = this;
		var edit = false;
		if(sap.ui.getCore().getModel("userPermModel").getData().Edit == "true")
			edit = true;
		var delegator = false;
		if(sap.ui.getCore().getModel("userPermModel").getData().Delegator == "true")
			delegator = true;
		var validator = false;
		if(sap.ui.getCore().getModel("userPermModel").getData().Validator == "true")
			validator = true; 
		
		var header = new sap.m.ObjectHeader({
			//number: "id",
			title: "{detail>/Id} > {detail>/Title}",
			attributes: [
//	         	new sap.m.ObjectAttribute({
//	         		text: "{/FindingId}: {/FindingTitle}",
//	         		active: true,
//	         		press: oController.goToFinding
//	         	}),
	         	new sap.m.ObjectAttribute({
	         		text: "{detail>/FindingId}: {detail>/FindingTitle}",
	         		active: false
	         	}),
	         	new sap.m.ObjectAttribute({
	         		title: planesAccionUtils.oBundle.getText("numInformes"),
	         		text: "{detail>/ZzReportId}",
	         		active: false
	         	}),
	         	new sap.m.ObjectAttribute({
	         		title: planesAccionUtils.oBundle.getText("tituloInformes"),
	         		text: "{detail>/ZzReportTitle}",
	         		active: false
	         	}),
	         	new sap.m.ObjectAttribute({
	         		//TODO: Recuperar fecha distribución
	         		title: planesAccionUtils.oBundle.getText("fechaDistrInforme"),
	         		text: "{detail>/DateRespIssued}",
	         		active: false,
	         	}).bindProperty("text",{
	 				   parts: [{path: "detail>/DateRepIssued"}], 
	 				   formatter: function(fecha){
	 					  return planesAccionUtils.convertDate(fecha);
	 				   }
	 			 }),
	         	new sap.m.ObjectAttribute({
	         		title: planesAccionUtils.oBundle.getText("clasRiesgo"),
	         		text: "{detail>/RankingDescr}",
	         		active: false,
	         		state: sap.ui.core.ValueState.Error
	         	}),	         		         	
	         	/**
				 * INI MOD PPM 069908 Rafael Galán Baquero 10/02/2021				
				 * Se contempla la celda del campo departamento y se concatena el código de dpto al nombre							 
				 * Codigo antiguo
				new sap.m.ObjectAttribute({
	         		title: planesAccionUtils.oBundle.getText("departamento"),
	         		text: "{/DepartmentName}",
	         		active: false,
	         	}),		
				 * Código nuevo
				 */
				//Se añade la columna departamento en la lista 	         	
	         	,new sap.m.ObjectAttribute({
				 	title : planesAccionUtils.oBundle.getText("departamento"),
				 	text  : { parts: [{path: "detail>/DepartmentName"},
				 					  {path: "detail>/ZzDepartment"}],
		 				   formatter: function(departName,depart){
		 					// return depart + ' - ' + departName;
		 					  return departName;
	 					   }
			 }
				 }).bindProperty("active", "false"),
			,								 						 				
	 			/**
			     *  FIN MOD PPM 069908 Rafael Galán Baquero 10/02/2021				
				*/
	         	
	         	
	         	new sap.m.ObjectAttribute({
	         		title: planesAccionUtils.oBundle.getText("grupo"),
	         		text: "{detail>/GroupText}",
	         		active: false,
	         	})  
	         	/**
				 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
				 * Código nuevo
				 */
				//Se añade la columna origen en la lista con visibilidad según si está informado o no
			 ,  new sap.m.ObjectAttribute({}).bindProperty("text",{
 				   parts: [{path: "detail>/ZzOrigen"}], 
 				   formatter: function(origen){
 					   return planesAccionUtils.getOrigenText(origen);
 					   }
			 }).bindProperty("title",{
 				   parts: [{path: "detail>/ZzOrigen"}], 
 				   formatter: function(origen){ 					   
 					return  planesAccionUtils.oBundle.getText("origen")
 					   }
			 }).bindProperty("visible",{
					parts:["detail>/ZzOrigen"],
					formatter: function(origen){
						return origen != '' ? true : false;				
					}
				}),
				
				/**
				 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
				 */
			],
			firstStatus:[
				new sap.m.ObjectStatus({
					//TODO: Recuperar validación supervisor
				}).bindProperty("text",{
					parts:["detail>/Validated"],
					formatter: function(validated){
						if(validated != undefined)
							return planesAccionUtils.getStatusText(validated)
						else
							return "";
					}
				}).bindProperty("visible",{
					parts:["detail>/Validated"],
					formatter: function(validated){
						if(validated == "") return false;
						else return true;
					}
				})
			]
		});
		
		var fechaFinal;
		if (planesAccionUtils.isAuditor()){
		fechaFinal = new sap.ui.layout.form.FormElement({					
			label: new sap.m.Label({text: planesAccionUtils.oBundle.getText("fechaFinal")}),
			fields: [
	        new sap.m.DatePicker({
	        	editable: false, 
	        	valueFormat: 'dd/MM/yyyy',
	        	displayFormat: 'dd/MM/yyyy',
	        }).bindProperty("value",{
	        	parts: [{path: "detail>/FinalDate"}], 
 				formatter: function(fecha){
					   if(fecha == "" || fecha == undefined )return "";
					   else if(fecha.lenght > 8){
						   var año = fecha.getFullYear();
						   var mes;
						   if(fecha.getMonth + 1 < 10) mes = "0" + fecha.getMonth() + 1;
						   else mes = fecha.getMonth() + 1;
						   var dia = fecha.getDate();
					   
						   return año + "/" + mes + "/" + dia; 
					   }else{
						  return fecha.substring(6,8) + "/" + fecha.substring(4,6) + "/" + fecha.substring(0,4);
					   }
 				}
 			})
			         
		]
		
		})
		};
		
		var	selStatus = new sap.m.Select({
			forceSelection: false,
			enabled: ((edit || !planesAccionUtils.isAuditado()) && !planesAccionUtils.isAuditor()),
			change: function(oEvent) {
				byId('planesDetailEditable').getModel('detail').getData().Status = this.getProperty("selectedKey");
				byId('planesDetailEditable').getModel('detail').getData().StatusDescr = this.getSelectedItem().getText();
			}
		//Cambio PRL 02112021
		//antiguo
	    //}).bindAggregation("items","/", new sap.ui.core.Item({key : "{detail>/Status}", text : "{detail>/StatusT}"}));
		//nuevo
		}).bindAggregation("items","/", new sap.ui.core.Item({key : "{Status}", text : "{StatusT}"}));
		//Fin PRL 02112021
		this.selStatus = selStatus;
		
		var oForm2 = new sap.ui.layout.form.Form({
			editable: false,
			layout: new sap.ui.layout.form.GridLayout(),
			formContainers: [
				new sap.ui.layout.form.FormContainer({
					title: planesAccionUtils.oBundle.getText("general"),
					formElements: [
//						new sap.ui.layout.form.FormElement({
//							label: new sap.m.Label({text: planesAccionUtils.oBundle.getText("numInformes")}),
//							fields: [ 
//								new sap.m.Input( { value: "{/ReportId}", placeholder: "", editable: false, layoutData: new sap.ui.layout.form.GridElementData({hCells: "auto"})}),
//								new sap.m.Label({text: planesAccionUtils.oBundle.getText("numAcc")}),
//								new sap.m.Input( { value: "{/Id}", placeholder: "", editable: false, layoutData: new sap.ui.layout.form.GridElementData({hCells: "auto"})})
//						    ]
//						}),
						new sap.ui.layout.form.FormElement({
							label: new sap.m.Label({text: planesAccionUtils.oBundle.getText("responsable")}),
							fields: [
								new sap.m.Input({ 
									placeholder: "", 
									editable: false, 
									layoutData: new sap.ui.layout.form.GridElementData({hCells: "auto"})
								}).bindProperty("value",{
				 				    parts: [{path: "detail>/NameOrg"}], 
				 				    formatter: function(nameOrg){
				 				    	if(nameOrg != undefined)
					 						   return nameOrg.capitalize();
					 					else
					 						   return "";
				 				   }
								}),
							]
						}),
						//INICIO RTC-597440
						new sap.ui.layout.form.FormElement({
							label: new sap.m.Label({text: planesAccionUtils.oBundle.getText("recomendacion")}).addStyleClass("textRecommendation"),
						// TODO: Recuperar Recommendation
							fields: [new sap.m.TextArea( { value: "{detail>/Recommendation}", rows: 10, editable: false, placeholder: "",layoutData: new sap.ui.layout.form.GridElementData({hCells: "auto"})})]
						}),
						//FIN RTC-597440						
						new sap.ui.layout.form.FormElement({
							label: new sap.m.Label({text: planesAccionUtils.oBundle.getText("detalles")}),
						//TODO: Recuperar detalles
							fields: [new sap.m.TextArea( { value: "{detail>/Milestone}", rows: 10, editable: false, placeholder: "",layoutData: new sap.ui.layout.form.GridElementData({hCells: "auto"})})]
						}),
						new sap.ui.layout.form.FormElement({
							label: new sap.m.Label({text: planesAccionUtils.oBundle.getText("estado")}),
							fields: [ 	
								selStatus,
						        new sap.m.Label({text: planesAccionUtils.oBundle.getText("fechaVenc")}),
						        view.datePicker = new sap.m.DatePicker("fechVenc",{
					        	   valueFormat: 'dd/MM/yyyy', 
					        	   displayFormat: 'dd/MM/yyyy',
					        	   editable: ((edit || !planesAccionUtils.isAuditado())),
					        	   change: oController.doValidateDate
						        }).bindProperty("value",{
					 				   parts: [{path: "detail>/Deadline"}], 
					 				   formatter: function(fecha){
					 					   //Inicialmente 201610923
					 					   // Al cambiar la fecha se devuelve un string tipo Mon 23 Sep .... 
					 					   if(fecha == "" || fecha == undefined )return "";
					 					   else if(fecha.lenght > 8){
					 						   var año = fecha.getFullYear();
					 						   var mes;
					 						   if(fecha.getMonth + 1 < 10) mes = "0" + fecha.getMonth() + 1;
					 						   else mes = fecha.getMonth() + 1;
					 						   var dia = fecha.getDate();
					 					   
					 						   return año + "/" + mes + "/" + dia; 
					 					   }else{
					 						  return fecha.substring(6,8) + "/" + fecha.substring(4,6) + "/" + fecha.substring(0,4);
					 					   }
					 				   }
					 			})
						    ]
						}),
						fechaFinal,
//						new sap.ui.layout.form.FormElement({					
//							label: new sap.m.Label({text: planesAccionUtils.oBundle.getText("fechaFinal")}),
//							fields: [
//					        new sap.m.DatePicker({
//					        	editable: false, 
//					        	valueFormat: 'dd/MM/yyyy',
//					        	displayFormat: 'dd/MM/yyyy',
//					        }).bindProperty("value",{
//					        	parts: [{path: "/FinalDate"}], 
//				 				formatter: function(fecha){
//			 					   if(fecha == "" || fecha == undefined )return "";
//			 					   else if(fecha.lenght > 8){
//			 						   var año = fecha.getFullYear();
//			 						   var mes;
//			 						   if(fecha.getMonth + 1 < 10) mes = "0" + fecha.getMonth() + 1;
//			 						   else mes = fecha.getMonth() + 1;
//			 						   var dia = fecha.getDate();
//			 					   
//			 						   return año + "/" + mes + "/" + dia; 
//			 					   }else{
//			 						  return fecha.substring(6,8) + "/" + fecha.substring(4,6) + "/" + fecha.substring(0,4);
//			 					   }
//				 				}
//				 			})
//							         
//						]
//						
//					})
						
					]
				}),
			]
		});
		
		var oFormComponent = new sap.ui.layout.form.Form({
			editable: false,
			layout: new sap.ui.layout.form.GridLayout(),
			formContainers: [             
				new sap.ui.layout.form.FormContainer({
					
					height:"150%",
					title: "Temas",
					formElements: [
						new sap.ui.layout.form.FormElement({
							fields: [
								new sap.ui.core.ComponentContainer({
									width:"100%",
									height:"150px",
									component:this.oTagCloud = new sap.ui.getCore().createComponent({
										name: "tagCloudComponentPlanes",
										id: "tagCloudPlanes"
									})
								})
							]
						}),
					]
				}),
			]
		});
		
		this.oTagCloud.setMode(3);
		
		if(planesAccionUtils.isAuditado()) {
			this.oTagCloud.setMode(5);
		}
		
		this.oTagCloud.loadAllTokens();
		
		var oForm3 = new sap.ui.layout.form.Form({
			editable: false,
			layout: new sap.ui.layout.form.GridLayout(),
			formContainers: [             
				new sap.ui.layout.form.FormContainer({
					title: planesAccionUtils.oBundle.getText("comentarios"),
					formElements: [
						new sap.ui.layout.form.FormElement({
							fields: [new sap.m.TextArea({ value: "{detail>/Commentary}", rows: 5, placeholder: "", required: true, editable: (edit || !planesAccionUtils.isAuditado()), layoutData: new sap.ui.layout.form.GridElementData({hCells: "auto"})})]
						}),
					]
				}),
			]
		});
			
		var oTable = new sap.m.Table({
			headerToolbar: new sap.m.Toolbar({
				content:[
				     new sap.m.Label({text:planesAccionUtils.oBundle.getText("listAcceso"), design: sap.m.LabelDesign.Bold}),
				     new sap.m.ToolbarSpacer(),
					 new sap.m.Button({icon: "sap-icon://add", visible:(delegator || !planesAccionUtils.isAuditado()), press: oController.addListAcces,})
				]
			}),
			columns : [
				  new sap.m.Column({  
					    hAlign : "Left",  
					    header : new sap.m.Label({  
					              text : planesAccionUtils.oBundle.getText("matricula"),
					              design: sap.m.LabelDesign.Bold
					    })  
				   }),new sap.m.Column({  
			                 hAlign : "Left",  
			                 header : new sap.m.Label({  
			                           text : planesAccionUtils.oBundle.getText("nombre"),
			                           design: sap.m.LabelDesign.Bold
			                 })  
			       })
		    ],
			delete: function(oEvent) {
				var table = this;
				var model = this.getModel();
				var item = oEvent.getParameters().listItem;
				var bindingPath = item.getBindingContextPath();
			
				var dialog = new sap.m.Dialog({
					title: planesAccionUtils.oBundle.getText("adv"),
					type: 'Message',
					state: 'Warning',
						content: new sap.m.Text({
							text: planesAccionUtils.oBundle.getText("seguroElimLista")
						}),
					state: sap.ui.core.ValueState.Warning,
					beginButton: new sap.m.Button({
						text: planesAccionUtils.oBundle.getText("aceptar"),
						press: function () {
							table.removeItem(item);								
							dialog.close();
						}
					}),
					endButton: new sap.m.Button({
						text: planesAccionUtils.oBundle.getText("cancelar"),
						press: function () {
							dialog.close(); 
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});
		
				dialog.open();
			},
			width : "100%",
			height : "100%",
		});
		
		 var itemTemplate = new sap.m.ColumnListItem("access",{
			  type: "Inactive",
              cells : [  
                    new sap.m.Label({text : "{Id}"}), 
                 	new sap.m.Label({text : "{FullName}"}) 
              ],
              customData: [new sap.ui.core.CustomData({key : "Id", value : "{Id}"})]
		});  
		 
		oTable.bindAggregation("","/InfoAccessList/results/" , itemTemplate);
		//oTable.setModel(sap.ui.getCore().getModel("accList"));
		
		this.table = oTable;
		this.template = itemTemplate;
			
		var that = this;
	
		

		// Se recuperan todos los attachements del tipo de alerta
		
		// Template para anexos
		var oItemTemplate = new sap.m.UploadCollectionItem({
			contributor : "{CreateByName}",
			documentId : "{DocId}",
			enableEdit : false,
			enableDelete : true,
			visibleEdit : false,
			visibleDelete : true,
			fileName : "{Name}",
			//fileSize : "{fileSize}",
			mimeType : "{MimeType}",
			//thumbnailUrl : "{thumbnailUrl}",
			uploadedDate : "{CreateTime}",
			url : "{Url}",
			customData: [new sap.ui.core.CustomData({key : "{DeleteUrl}"})],
		});
		
		// Se rellena el uploader
		var uploader = new sap.m.UploadCollection("anexosType2", {
	        multiple : false,
			items : {
				path : "/",
				template : oItemTemplate
			},
			fileDeleted: oController.onFileDeleted,
			change: oController.onSelectFile,
			instantUpload: false,
			uploadEnabled: (edit || !planesAccionUtils.isAuditado()),
			beforeUploadStarts: oController.onBeforeUploadStarts,
			uploadComplete: oController.onUploadComplete,
			uploadTerminated: oController.onUploadTerminated,
		}).setModel(new sap.ui.model.json.JSONModel());
		
		this.uploader = uploader;
		this.upldTemplate = oItemTemplate;
		
 		return new sap.m.Page({
 			enableScrolling: true,
 			showNavButton: false,
 			showHeader: false,
			content: [header,oForm2, oFormComponent, oForm3, oTable, uploader, new sap.m.Panel({height:"10%"})],
			navButtonPress: oController.doBack,
		});
	}
});