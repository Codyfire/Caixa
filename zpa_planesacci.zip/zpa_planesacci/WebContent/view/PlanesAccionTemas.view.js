sap.ui.jsview("appPlanesAccion.view.PlanesAccionTemas", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf zportalaudit.controller.planesAccion.PlanesAccion
	*/ 
	getControllerName : function() {
		return "appPlanesAccion.controller.PlanesAccionTemas";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf zportalaudit.controller.planesAccion.PlanesAccion
	*/ 
	createContent : function(oController) {
		
		var headerContent;
		var aThemes = [];
		planesAccionUtils.filtersTemas = [];
		loadPlanesAccionThemes(0,7,planesAccionUtils.filtersTemas,planesAccionUtils.sortersTemas,planesAccionUtils.grouperTemas);
		if(planesAccionUtils.isAuditor()){
			//Si el usuario es un auditor, tiene todos los temas y por lo tanto le ponemos un componente para la busqueda de temas.
			var that = this;
			/**
			 * INI MOD RTC 537578 Rafael Galán Baquero 07/03/2019
			 * Código antiguo
			 * this.oTagCloud = new sap.ui.getCore().createComponent({
			 * Código nuevo
			 */
			this.oTagCloud = sap.ui.getCore().getComponent('tagCloudPlanesTemas');
			if ( this.oTagCloud == undefined)
				this.oTagCloud = new sap.ui.getCore().createComponent({
	 			/**
			 * FIN MOD RTC 537578 Rafael Galán Baquero 07/03/2019
			 */						
				name: "tagCloudComponentPlanes",
				id: "tagCloudPlanesTemas"
			});
			
			this.oContTagCloud = new sap.ui.core.ComponentContainer({
				width:"100%",
				height:"100px",
				component: that.oTagCloud
			}).addStyleClass("tablePaddings");
			
			this.oTagCloud.setMode(2);
			this.oTagCloud.loadAllTokens();
			headerContent = this.oContTagCloud;
				
		}else if(planesAccionUtils.isAuditado()){
			//Si es auditado, le enseñamos sus temas propios mediante botones de seleccion de temas para poder filtrarlos
			
			var controller = oController;
			if(getModel("userThemes").getData().results.length > 0)
				$.each(getModel("userThemes").getData().results[0].InfoThemes.results,function(i,n){
					aThemes.push(
						new sap.m.ToggleButton({
							text:n.Theme,
							customData:new sap.ui.core.CustomData({value:n.Id}),
							press: function(oEvent) {
								byId("planesAccionTemas").getController().getPressedFilters(aThemes);
							}
							}).addStyleClass("marginRight")
					);
				});
			
			this.oPanel = new sap.m.Panel({
				headerText: "Seleccionar temas",
				expandable: true,
				content:aThemes
			});
			
			headerContent = this.oPanel;
		}
		auxThemes = aThemes;

//		this.template = new sap.m.ColumnListItem({  
//			type : "Navigation",  
//			cells : [
//				new sap.m.Text({text : "{ZzReportId}"}),
//				new sap.m.Text({text : "{Id}"}),
//	 			new sap.m.Text({text : "{Title}"}),		
//	 			new sap.m.Text({text : "{DepartmentName}"}),	
//	 			new sap.m.Text({text : "{GroupText}"}),	
//	 			new sap.m.Text({}).bindProperty("text",{
// 				   parts: [{path: "NameOrg"}], 
// 				   formatter: function(nameOrg){
// 					   if(nameOrg != undefined)
// 						   return nameOrg.capitalize();
// 					   else
// 						   return "";
// 				   }
//	 			 }),  
//	 			new sap.m.Text({  
//	 			   text: "{StatusDescr}"
//	 			}),
//	 			new sap.m.Text({}).bindProperty("text",{
// 				   parts: [{path: "Deadline"}], 
// 				   formatter: function(fecha){
// 					   return planesAccionUtils.transformDate(fecha);
// 				   }
//	 		    }),
//	 		],
//	 		customData: [new sap.ui.core.CustomData({key: "{Key}"})],
//	 		press: oController.showDetail
//		});
		
		if(planesAccionUtils.isAuditado()) {
			this.template = new sap.m.ColumnListItem({  
				type : "Navigation",  
				cells : [
					new sap.m.Text({text : "{RankingDescr}"}),
					new sap.m.Text({text : "{ZzReportId}"}),
					new sap.m.Text({text: "{ZzReportTitle}"}),
//					new sap.m.Text({text : "{Id}"}),
					new sap.m.HBox({
	        			items: [
	        			    new sap.ui.core.Icon({  
	        	                src : "sap-icon://warning",
	        	                color: "#ff0000",
	        	                size: "15px",
	        	                tooltip: planesAccionUtils.oBundle.getText("accVencicda")
	        			    }).bindProperty("src", {
	        			    	parts:["Overdue"],
	        			    	formatter: function(overdue){
	        			    		var source;
	        			    		if(overdue == "true"){
	        			    			source = "sap-icon://warning";
	        			    			this.addStyleClass("OverdueIconMargin");
	        			    		} else {
	        			    			source = "";
	        			    		}
	        			    		return source;
	        			    	}
	        			    }),
	        			    new sap.m.Text({
	        			    	text:"{Id}"
	        			    })
	        			]
	               }),
		 			new sap.m.Text({text : "{Title}"}),		
		 			new sap.m.Text({}).bindProperty("text",{
	 				   parts: [{path: "NameOrg"}], 
	 				   formatter: function(nameOrg){
	 					   if(nameOrg != undefined)
	 						   return nameOrg.capitalize();
	 					   else
	 						   return "";
	 				   }
		 			 }),  
		 			new sap.m.Text({  
		 			   text: "{StatusDescr}"
		 			}),
		 			new sap.m.Text({}).bindProperty("text", {
    			    	parts:["Validated"],
    			    	formatter: function(validated){
    			    		return planesAccionUtils.getStatusText(validated);
    			    	}
    			    }),
		 			new sap.m.Text({}).bindProperty("text",{
	 				   parts: [{path: "Deadline"}], 
	 				   formatter: function(fecha){
	 					   return planesAccionUtils.transformDate(fecha);
	 				   }
		 		    }),
		 		       /**
						 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
						 * Código nuevo
						 */
						//Se añade la columna origen en la lista
					  new sap.m.Text({}).bindProperty("text",{
		 				   parts: [{path: "ZzOrigen"}], 
		 				   formatter: function(origen){
		 					   return planesAccionUtils.getOrigenText(origen);
		 					   }
					  })
						 		
						/**
						 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
						 */	 					   
		 		],
		 		customData: [new sap.ui.core.CustomData({key: "{Key}"})],
		 		press: oController.showDetail
			});
		} else {
			this.template = new sap.m.ColumnListItem({  
				type : "Navigation",  
				cells : [
					new sap.m.Text({text : "{RankingDescr}"}),
					new sap.m.Text({text : "{ZzReportId}"}),
					/**
					 * INI MOD RTC 537578 Rafael Galán Baquero 07/03/2019
					 * Código nuevo
					 */
					// Se añade el titulo de informe
					new sap.m.Text({text: "{ZzReportTitle}"}),
					/**
					 * FIN MOD RTC 537578 Rafael Galán Baquero 07/03/2019
					 */
//					new sap.m.Text({text : "{Id}"}),
					new sap.m.HBox({
	        			items: [
	        			    new sap.ui.core.Icon({  
	        	                src : "sap-icon://warning",
	        	                color: "#ff0000",
	        	                size: "15px",
	        	                tooltip: planesAccionUtils.oBundle.getText("accVencicda")
	        			    }).bindProperty("src", {
	        			    	parts:["Overdue"],
	        			    	formatter: function(overdue){
	        			    		var source;
	        			    		if(overdue == "true"){
	        			    			source = "sap-icon://warning";
	        			    			this.addStyleClass("OverdueIconMargin");
	        			    		} else {
	        			    			source = "";
	        			    		}
	        			    		return source;
	        			    	}
	        			    }),
	        			    new sap.m.Text({
	        			    	text:"{Id}"
	        			    })
	        			]
	               }),
		 			new sap.m.Text({text : "{Title}"}),		
		 			/**
					 * INI MOD PPM 069908 Rafael Galán Baquero 10/02/2021
					 * Código antiguo */
					  new sap.m.Text({text : "{DepartmentName}"}),
					 /** Código nuevo
					 */
		 			// Se concatena el codigo de dept. auditoría al departamento de auditoría
//		 			new sap.m.Text({}).bindProperty("text",{
//		 				   parts: [ "DepartmentName", "ZzDepartment"], 
//		 				   formatter: function(deptName,dept){
//
//		 					   return dept + ' - ' + deptName;
//		 				   }
//			 			 }),  
		 			/**
					 * FIN MOD PPM069908 Rafael Galán Baquero 10/02/2021
					 */,
		 			new sap.m.Text({text : "{GroupText}"}),	
		 			/**
					 * INI MOD RTC 537578 Rafael Galán Baquero 07/03/2019
					 * Código nuevo
					 */
		 			//Se añade la columna Gerente 
		 			new sap.m.Text({text : "{Fullname}"}),
		 			/**
					 * FIN MOD RTC 537578 Rafael Galán Baquero 07/03/2019
					 */
		 			new sap.m.Text({}).bindProperty("text",{
	 				   parts: [{path: "NameOrg"}], 
	 				   formatter: function(nameOrg){
	 					   if(nameOrg != undefined)
	 						   return nameOrg.capitalize();
	 					   else
	 						   return "";
	 				   }
		 			 }),  
		 			new sap.m.Text({  
		 			   text: "{StatusDescr}"
		 			}),
		 			new sap.m.Text({}).bindProperty("text", {
    			    	parts:["Validated"],
    			    	formatter: function(validated){
    			    		return planesAccionUtils.getStatusText(validated);
    			    	}
    			    }),
		 			new sap.m.Text({}).bindProperty("text",{
	 				   parts: [{path: "Deadline"}], 
	 				   formatter: function(fecha){
	 					   return planesAccionUtils.transformDate(fecha);
	 				   }
		 		    }),
		 		    
		 		   /**
					 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
					 * Código nuevo
					 */
					//Se añade la columna origen en la lista
				  new sap.m.Text({}).bindProperty("text",{
	 				   parts: [{path: "ZzOrigen"}], 
	 				   formatter: function(origen){
	 					   return planesAccionUtils.getOrigenText(origen);
	 					   }
				  })
					 		
					/**
					 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
					 */
		 		],
		 		customData: [new sap.ui.core.CustomData({key: "{Key}"})],
		 		press: oController.showDetail
			});
		}
		
		if(sap.ui.getCore().getComponent('tablePlanAccionesTema')) {
			sap.ui.getCore().getComponent('tablePlanAccionesTema').destroy();
		}
 		
 		//Creo la taula de paginació a partir del component creat
 		this.oTableComp = new sap.ui.getCore().createComponent({
 			name: "tablePagination",
 			id: "tablePlanAccionesTema"
 		});

 		
// 		this.oTableComp.addColumns([planesAccionUtils.oBundle.getText("numInformes"),planesAccionUtils.oBundle.getText("numPlanAccion"),planesAccionUtils.oBundle.getText("titulo"), planesAccionUtils.oBundle.getText("departamento"), planesAccionUtils.oBundle.getText("grupo"), planesAccionUtils.oBundle.getText("responsable"), planesAccionUtils.oBundle.getText("estado"), planesAccionUtils.oBundle.getText("fechaVenc")]);
 		if(planesAccionUtils.isAuditado()) {
 	 		this.oTableComp.addColumns([
 	 			planesAccionUtils.oBundle.getText("criticidad"),
 	 			planesAccionUtils.oBundle.getText("numInformes"),
 	 			planesAccionUtils.oBundle.getText("tituloInforme"),
 	 			planesAccionUtils.oBundle.getText("numPlanAccion"),
 	 			planesAccionUtils.oBundle.getText("titulo"), 
 	 			planesAccionUtils.oBundle.getText("responsable"), 
 	 			planesAccionUtils.oBundle.getText("estado"), 
 	 			planesAccionUtils.oBundle.getText("estadoVal"), 
 	 			planesAccionUtils.oBundle.getText("fechaVenc")
 	 			/**
				 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020
				 * Código antiguo
				 * ]);				
				 * Código nuevo
				 */
				//Se añade la columna origen en la lista
	 			
	 				,planesAccionUtils.oBundle.getText("origen")
	 				],9);
	 			/*
				 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
				 */	 		
 	 		
 		} else {
 	 		this.oTableComp.addColumns([
 	 			planesAccionUtils.oBundle.getText("criticidad"),
 	 			planesAccionUtils.oBundle.getText("numInformes"),
 	 			/**
				 * INI MOD RTC 537578 Rafael Galán Baquero 07/03/2019
				 * Código nuevo
				 */
 	 			planesAccionUtils.oBundle.getText("tituloInforme"),
 	 			/**
				 * FIN MOD RTC 537578 Rafael Galán Baquero 07/03/2019
				 */ 
 	 			planesAccionUtils.oBundle.getText("numPlanAccion"),
 	 			planesAccionUtils.oBundle.getText("titulo"), 
 	 			planesAccionUtils.oBundle.getText("departamento"), 
 	 			planesAccionUtils.oBundle.getText("grupo"), 
 	 			/**
				 * INI MOD RTC 537578 Rafael Galán Baquero 07/03/2019
				 * Código nuevo				
				 */
 	 			planesAccionUtils.oBundle.getText("gerente"),
 	 			/**
				 * FIN MOD RTC 537578 Rafael Galán Baquero 07/03/2019
				 */ 
 	 			planesAccionUtils.oBundle.getText("responsable"), 
 	 			planesAccionUtils.oBundle.getText("estado"), 
 	 			planesAccionUtils.oBundle.getText("estadoVal"), 
 	 			planesAccionUtils.oBundle.getText("fechaVenc")
 	 			/**
				 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020
				 * Código antiguo
				 * ]);				
				 * Código nuevo				 
				 */
				//Se añade la columna origen en la lista
	 			
	 				,planesAccionUtils.oBundle.getText("origen")
	 				],12);
	 			/*
				 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
				 */	 		
 	 		
 		}
 		this.oTableComp.addItemTemplate("", "/results", this.template);
 		this.oTableComp.setDataModel("planesAccionTemas");  
 		
 		
 		var func = function(){
			return sap.ui.getCore().getModel("planesAccionTemas").getData().__count;
		}
		
 		this.oTableComp.setCountFunction(func); 
 		this.oTableComp.createPaginationMenu("planesAccionTemas",7,"tablePlanAccionesTema", true);
 		
 		var oCompCont = new sap.ui.core.ComponentContainer({
 			component: this.oTableComp,
 		});
 		
// 		this.oScroll = new sap.m.ScrollContainer({
// 			content: [oCompCont],
// 			vertical: true,
// 			height: "100%",
// 			width: "100%"
// 		}).addStyleClass("test");
// 		
// 		/*this.oPage = new sap.m.Page({
// 			subHeader:new sap.m.Toolbar({
// 				content:[
// 				    new sap.m.ToolbarSpacer({}),
// 				    new sap.m.Button({
// 				    	icon:"sap-icon://download",
// 				    	//exportToExcel, true parameter if we are at themes tab.
// 				    	press: function(){sap.ui.getCore().getComponent("tablePlanAccionesTema").exportToExcel("ExportPlanesAccion", planesAccionUtils.filtersTemas, planesAccionUtils.sortersTemas, true);}
// 				    }),
// 				    new sap.m.Button({
// 				    	icon: "sap-icon://drop-down-list", 
// 			            press: oController.onFilterPress       
// 				    })
// 				]
// 			}),
// 			showHeader:false,
// 			showFooter:false,
// 			showNavButton: false,
//  			fitContainer: true,
// 			content: [this.oScroll],
// 		});*/
// 		
// 		this.oBox = new sap.m.VBox({
// 			items:[
// 			       headerContent,
// 			       new sap.m.ToolbarSpacer({}),
// 			       new sap.m.Button({
//				 	icon:"sap-icon://download",
//				 	//exportToExcel, true parameter if we are at themes tab.
//				 	press: function(){sap.ui.getCore().getComponent("tablePlanAccionesTema").exportToExcel("ExportPlanesAccion", planesAccionUtils.filtersTemas, planesAccionUtils.sortersTemas, true);}
// 			       }),
// 			       new sap.m.Button({
// 			    	   icon: "sap-icon://drop-down-list", 
// 			    	   press: oController.onFilterPress       
// 			       }),
// 			       this.oScroll
// 			 ]
// 		});
// 		
// 		
// 		
// 		
// 		return new sap.m.Page({
//  			showHeader:false,
//  			showFooter:true,
// 			showNavButton: false,
//  			fitContainer: true,
// 			content: [this.oBox],
// 			navButtonPress: oController.doBack,
// 			enableScrolling: false
// 		});
// 		
//		this.oToolbar = new sap.m.Toolbar({
//			content: [
//				headerContent,
//			    new sap.m.Button({
//			    	icon:"sap-icon://download",
//			    	//exportToExcel, true parameter if we are at themes tab.
//			    	press: function(){sap.ui.getCore().getComponent("tablePlanAccionesTema").exportToExcel("ExportPlanesAccion", planesAccionUtils.filtersTemas, planesAccionUtils.sortersTemas, true);}
//			    }),
//			    new sap.m.Button({
//			    	icon: "sap-icon://drop-down-list", 
//		            press: oController.onFilterPress       
//			    })
//			],
//		}).addStyleClass("themesTabHeader");
// 		
// 		return new sap.m.Page({
//			showHeader:true,
//			showFooter:true,
//			showNavButton: false,
//			fitContainer: true,
//			customHeader: this.oToolbar,
//// 			subHeader: [new sap.m.Toolbar({
////				content:[
//// 				    new sap.m.ToolbarSpacer({}),
////				    new sap.m.Button({
////				    	icon:"sap-icon://download",
////				    	//exportToExcel, true parameter if we are at themes tab.
////				    	press: function(){sap.ui.getCore().getComponent("tablePlanAccionesTema").exportToExcel("ExportPlanesAccion", planesAccionUtils.filtersTemas, planesAccionUtils.sortersTemas, true);}
////				    }),
////				    new sap.m.Button({
////				    	icon: "sap-icon://drop-down-list", 
////			            press: oController.onFilterPress       
////				    })
////				]
////			})],
//			content: [oCompCont],
//			navButtonPress: oController.doBack,
//			enableScrolling: true
// 		});
 		
 		/**
	     * INICIO MOD RTC-537578 Rafael Galán Baquero 04/03/19
	     * 
	     * Código nuevo
	     */
 		// Se contempla cuando se viene de otra pestaña y se le ha dado a visualizador de columnas
 		if(sap.ui.getCore().getComponent("visColumnComTemasComp")){
 			var oVisualizadorComp = sap.ui.getCore().getComponent("visColumnComTemasComp");
 			oVisualizadorComp.table = sap.ui.getCore().getComponent("tablePlanAccionesTema").table;
 			planesAccionUtils.assignTableVisualizadorTema();
 			
 		}
 		/**
	     * FIN MOD  RTC-537578 Rafael Galán Baquero 04/03/19
	     */
 		//Nueva forma de page 
 		return new sap.m.Page({
			subHeader:new sap.m.Toolbar({
				content:[
				    new sap.m.ToolbarSpacer({}),
				    new sap.m.Button({
				    	icon:"sap-icon://download",
				    	//exportToExcel, true parameter if we are at themes tab.
				    	press: function(){sap.ui.getCore().getComponent("tablePlanAccionesTema").exportToExcel("ExportPlanesAccion", planesAccionUtils.filtersTemas, planesAccionUtils.sortersTemas, true);}
				    }),
				    new sap.m.Button({
				    	icon: "sap-icon://drop-down-list", 
			            press: oController.onFilterPress       
				    }),
				    /**
				     * INICIO MOD RTC-537578 Rafael Galán Baquero 04/03/19
				     * Se incluye el botón visualizador de columnas
				     * Código nuevo
				     */						
				    ,
				    new sap.m.Button({
				    	icon: "sap-icon://person-placeholder", 
			            press: oController.onColumnsVisualizar       
				    })  
				    /**
				     * FIN MOD  RTC-537578 Rafael Galán Baquero 04/03/19
				     */
				]
			}),
			showHeader:false,
			//fitContainer: true,
			navButtonPress: oController.doBack,
			content: [headerContent, oCompCont],
		});
 		// \Nueva forma de page
 		
	}

});