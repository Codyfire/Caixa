sap.ui.jsview("appPlanesAccion.view.PlanesAccion", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf zportalaudit.controller.planesAccion.PlanesAccion
	*/ 
	getControllerName : function() {
		return "appPlanesAccion.controller.PlanesAccion";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf zportalaudit.controller.planesAccion.PlanesAccion
	*/ 
	createContent : function(oController) {
		
//		planesAccionUtils.filters.push(new sap.ui.model.Filter("Status",sap.ui.model.FilterOperator.EQ, "01"));
//		planesAccionUtils.filters.push(new sap.ui.model.Filter("Status",sap.ui.model.FilterOperator.EQ, "02"));
//		planesAccionUtils.filters.push(new sap.ui.model.Filter("Status",sap.ui.model.FilterOperator.EQ, "04"));
		loadPlanesAccion(0,7,planesAccionUtils.filters,[]);

		if(planesAccionUtils.isAuditado()) {
			this.template = new sap.m.ColumnListItem({  
				type : "Navigation",  
				cells : [
					new sap.m.Text({text : "{RankingDescr}"}),
					new sap.m.Text({text : "{ZzReportId}"}),
					new sap.m.Text({text: "{ZzReportTitle}"}),
//					new sap.m.Text({text : "{Id}"}),
					new sap.m.HBox({
	        			items: [
	        			    new sap.ui.core.Icon({  
	        	                src : "sap-icon://warning",
	        	                color: "#ff0000",
	        	                size: "15px",
	        	                tooltip: planesAccionUtils.oBundle.getText("accVencicda")
	        			    }).bindProperty("src", {
	        			    	parts:["Overdue"],
	        			    	formatter: function(overdue){
	        			    		var source;
	        			    		if(overdue == "true"){
	        			    			source = "sap-icon://warning";
	        			    			this.addStyleClass("OverdueIconMargin");
	        			    		} else {
	        			    			source = "";
	        			    		}
	        			    		return source;
	        			    	}
	        			    }),
	        			    new sap.m.Text({
	        			    	text:"{Id}"
	        			    })
	        			]
	               }),
		 			new sap.m.Text({text : "{Title}"}),		
		 			new sap.m.Text({}).bindProperty("text",{
	 				   parts: [{path: "NameOrg"}], 
	 				   formatter: function(nameOrg){
	 					   if(nameOrg != undefined)
	 						   return nameOrg.capitalize();
	 					   else
	 						   return "";
	 				   }
		 			 }),  
		 			new sap.m.Text({text: "{StatusDescr}"}),
		 			new sap.m.Text({}).bindProperty("text", {
    			    	parts:["Validated"],
    			    	formatter: function(validated){
    			    		return planesAccionUtils.getStatusText(validated);
    			    	}
    			    }),
		 			new sap.m.Text({}).bindProperty("text",{
	 				   parts: [{path: "Deadline"}], 
	 				   formatter: function(fecha){
	 					   return planesAccionUtils.transformDate(fecha);
	 				   }
		 		    }),		 
	 					  /**
							 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
							 * Código nuevo
							 */
							//Se añade la columna origen en la lista
						  new sap.m.Text({}).bindProperty("text",{
			 				   parts: [{path: "ZzOrigen"}], 
			 				   formatter: function(origen){
			 					   return planesAccionUtils.getOrigenText(origen);
			 					   }
						  })						 		
							/**
							 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
							 */					   
	 					   
		 		],
		 		customData: [new sap.ui.core.CustomData({key: "{Key}"})],
		 		press: oController.showDetail
			});
		} else {
			this.template = new sap.m.ColumnListItem({  
				type : "Navigation",  
				cells : [
					new sap.m.Text({text : "{RankingDescr}"}),
					new sap.m.Text({text : "{ZzReportId}"}),
					/**
					 * INI MOD RTC 537578 Rafael Galán Baquero 07/03/2019
					 * Código nuevo
					 */
					// Se añade el campo titulo de informe
					new sap.m.Text({text : "{ZzReportTitle}"}),
					/**
					 * FIN MOD RTC 537578 Rafael Galán Baquero 07/03/2019					 
					 */
//					new sap.m.Text({text : "{Id}"}),
					new sap.m.HBox({
	        			items: [
	        			    new sap.ui.core.Icon({  
	        	                src : "sap-icon://warning",
	        	                color: "#ff0000",
	        	                size: "15px",
	        	                tooltip: planesAccionUtils.oBundle.getText("accVencicda")
	        			    }).bindProperty("src", {
	        			    	parts:["Overdue"],
	        			    	formatter: function(overdue){
	        			    		var source;
	        			    		if(overdue == "true"){
	        			    			source = "sap-icon://warning";
	        			    			this.addStyleClass("OverdueIconMargin");
	        			    		} else {
	        			    			source = "";
	        			    		}
	        			    		return source;
	        			    	}
	        			    }),
	        			    new sap.m.Text({
	        			    	text:"{Id}"
	        			    })
	        			]
	               }),
		 			new sap.m.Text({text : "{Title}"}),
		 			
		 			/**
					 * INI MOD PPM 069908 Rafael Galán Baquero 10/02/2021
					 * Código antiguo*/
					  new sap.m.Text({text : "{DepartmentName}"}),
					 /** Código nuevo
					 */
//		 			// Se concatena el codigo de dept. auditoría al departamento de auditoría
//		 			new sap.m.Text({}).bindProperty("text",{
//		 				   parts: [ "DepartmentName", "ZzDepartment"], 
//		 				   formatter: function(deptName,dept){
//
//		 					   return dept + ' - ' + deptName;
//		 				   }
//			 			 }),  
		 			/**
					 * FIN MOD PPM069908 Rafael Galán Baquero 10/02/2021
					 */
		 			new sap.m.Text({text : "{GroupText}"}),	
		 			
		 			
		 			
		 			/**
					 * INI MOD RTC 537578 Rafael Galán Baquero 07/03/2019
					 * Código nuevo
					 */
		 			// Se añade el gerente
		 			new sap.m.Text({text : "{Fullname}"}),
		 			/**
					 * FIN MOD RTC 537578 Rafael Galán Baquero 07/03/2019
					 */
		 			new sap.m.Text({}).bindProperty("text",{
	 				   parts: [{path: "NameOrg"}], 
	 				   formatter: function(nameOrg){
	 					   if(nameOrg != undefined)
	 						   return nameOrg.capitalize();
	 					   else
	 						   return "";
	 				   }
		 			 }),  
		 			new sap.m.Text({ text: "{StatusDescr}"}),
		 			new sap.m.Text({}).bindProperty("text", {
    			    	parts:["Validated"],
    			    	formatter: function(validated){
    			    		return planesAccionUtils.getStatusText(validated);
    			    	}
    			    }),
		 			new sap.m.Text({}).bindProperty("text",{
	 				   parts: [{path: "Deadline"}], 
	 				   formatter: function(fecha){
	 					   return planesAccionUtils.transformDate(fecha);
	 				   }
		 		    }),	 		
		 			/**
						 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
						 * Código nuevo
						 */
						//Se añade la columna origen en la lista
					  new sap.m.Text({}).bindProperty("text",{
		 				   parts: [{path: "ZzOrigen"}], 
		 				   formatter: function(origen){
		 					   return planesAccionUtils.getOrigenText(origen);
		 					   }
					  })						 		
						/**
						 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
						 */	 					   
					   

		 		],
		 		customData: [new sap.ui.core.CustomData({key: "{Key}"})],
		 		press: oController.showDetail
			});
		}
		
		
		
		if(sap.ui.getCore().getComponent('tablePlanAcciones')) {
			sap.ui.getCore().getComponent('tablePlanAcciones').destroy();
		}
 		
 		//Creo la taula de paginació a partir del component creat
 		this.oTableComp = new sap.ui.getCore().createComponent({
 			name: "tablePagination",
 			id: "tablePlanAcciones"
 		});
 		
 		if(planesAccionUtils.isAuditado()) {
 	 		this.oTableComp.addColumns([
 	 			planesAccionUtils.oBundle.getText("criticidad"),
 	 			planesAccionUtils.oBundle.getText("numInformes"),
 	 			planesAccionUtils.oBundle.getText("tituloInforme"),
 	 			planesAccionUtils.oBundle.getText("numPlanAccion"),
 	 			planesAccionUtils.oBundle.getText("titulo"), 
 	 			planesAccionUtils.oBundle.getText("responsable"), 
 	 			planesAccionUtils.oBundle.getText("estado"), 
 	 			planesAccionUtils.oBundle.getText("estadoVal"), 
 	 			planesAccionUtils.oBundle.getText("fechaVenc") 
 	 			/**
					 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020
					 * Código antiguo
					 * ]);				
					 * Código nuevo
					 */
					//Se añade la columna origen en la lista
 	 			
 	 				,planesAccionUtils.oBundle.getText("origen") ,
 	 				],9);
 	 			/*
					 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
					 */	 					   
				   
 	 			
 		} else {
 	 		this.oTableComp.addColumns([
 	 			planesAccionUtils.oBundle.getText("criticidad"),
 	 			planesAccionUtils.oBundle.getText("numInformes"),
 	 			/**
				 * INI MOD RTC 537578 Rafael Galán Baquero 07/03/2019
				 * Código nuevo
				 */
 	 			planesAccionUtils.oBundle.getText("tituloInforme"),
 	 			/**
				 * FIN MOD RTC 537578 Rafael Galán Baquero 07/03/2019
				 */
 	 			planesAccionUtils.oBundle.getText("numPlanAccion"),
 	 			planesAccionUtils.oBundle.getText("titulo"), 
 	 			planesAccionUtils.oBundle.getText("departamento"), 
 	 			planesAccionUtils.oBundle.getText("grupo"), 
 	 			/**
				 * INI MOD RTC 537578 Rafael Galán Baquero 07/03/2019
				 * Código nuevo
				 */ 	 			 	 		
 	 				//Se añade la columna Gerente 
 	 			planesAccionUtils.oBundle.getText("gerente"),
 	 			/**
				 * FIN MOD RTC 537578 Rafael Galán Baquero 07/03/2019
				 */
 	 			planesAccionUtils.oBundle.getText("responsable"), 
 	 			planesAccionUtils.oBundle.getText("estado"),
 	 			planesAccionUtils.oBundle.getText("estadoVal"), 
 	 			planesAccionUtils.oBundle.getText("fechaVenc") 	
 	 			/**
				 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020	
				 * Código antiguo
				 * 	]);			
				 * Código nuevo
				 */
				//Se añade la columna origen en la lista
	 			
	 				,planesAccionUtils.oBundle.getText("origen")
	 				],12);
	 			/*
				 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
				 */	 					   
			   
 	 		
 		}
 		
 		
		this.oTableComp.addItemTemplate("", "/results", this.template);
 		this.oTableComp.setDataModel("planesAccion");
		
 		
 		var func = function(){
			return sap.ui.getCore().getModel("planesAccion").getData().__count;
		}
		
 		this.oTableComp.setCountFunction(func); 
 		this.oTableComp.createPaginationMenu("planesAccion",7,"tablePlanAcciones", false);
 		
 		var oCompCont = new sap.ui.core.ComponentContainer({
 			component: this.oTableComp
 		});
 		
 		
 		/**
 		 *  INI MOD RTC 537578 Rafael Galán Baquero 06/03/2019		
		* Código nuevo
		*/
 		// Si existe el componente visualizador de Vis.Centro, se refresca la tabla asociado
 		if(sap.ui.getCore().getComponent("visColumnComPlanComp")){
 			var oVisualizadorComp = sap.ui.getCore().getComponent("visColumnComPlanComp");
 			oVisualizadorComp.table = sap.ui.getCore().getComponent("tablePlanAcciones").table;
 			planesAccionUtils.assignTableVisualizadorPlan();
 			
 		}

 		/**
 		 * FIN MOD RTC 537578 Rafael Galán Baquero 06/03/2019
 		 */
 		
 		return new sap.m.Page({
  			showHeader:false,
  			showFooter:true,
 			showNavButton: false,
  			//fitContainer: true,
  			subHeader:[
				new sap.m.Toolbar({
					content:[
					    new sap.m.ToolbarSpacer({}),
					    new sap.m.Button({
					    	icon:"sap-icon://download",
					    	press: function(){sap.ui.getCore().getComponent("tablePlanAcciones").exportToExcel("ExportPlanesAccion", planesAccionUtils.filters, planesAccionUtils.sorters);}
					    }),
					    new sap.m.Button({
					    	icon: "sap-icon://drop-down-list", 
				            press: oController.onFilterPress       
					    })
					  //INICIO RTC-537578						
					    ,
					    new sap.m.Button({
					    	icon: "sap-icon://person-placeholder", 
				            press: oController.onColumnsVisualizar       
					    })  
					    //FIN    RTC-537578
					]
				})
  			],
 			content: [
 				oCompCont,
 			],
 			navButtonPress: oController.doBack,
 		});
	}

});