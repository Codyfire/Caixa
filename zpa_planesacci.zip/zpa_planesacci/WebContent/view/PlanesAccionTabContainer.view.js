sap.ui.jsview("appPlanesAccion.view.PlanesAccionTabContainer", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf zportalaudit.controller.alertas.AdminAlertasTabContainer
	*/ 
	getControllerName : function() {
		return "appPlanesAccion.controller.PlanesAccionTabContainer";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf zportalaudit.controller.alertas.AdminAlertasTabContainer
	*/ 
	createContent : function(oController) {
		
		var that = this;
		var aTabs = [];
		aTabs.push(new sap.m.IconTabFilter("tab1",{
						icon: "sap-icon://building",
						text: "Vis. centro",
						key: "1",
						content: [sap.ui.view({id:"planesNavContainer", height: "100%", viewName:"appPlanesAccion.view.PlanesNavContainer", type:sap.ui.core.mvc.ViewType.JS})]
					}));
		
		//Cargamos los temas del usuario, y en caso de que tenga, añadiremos el tab de temas.		
		if(!planesAccionUtils.isAuditor()) {
			loadUserThemes(planesAccionUtils.getCurrentUser());
			if(sap.ui.getCore().getModel("userThemes").getData().results.length >  0) {
				aTabs.push(new sap.m.IconTabFilter("tab2",{
					icon: "sap-icon://tags",
					text: "Vis. tema",
					key: "2",
				}));
			}
		} else {
			aTabs.push(new sap.m.IconTabFilter("tab2",{
				icon: "sap-icon://tags",
				text: "Vis. tema",
				key: "2",
			}));
		}
			
		this.oIconTabBar = new sap.m.IconTabBar({
			expanded: true,
			expandable: false,
			selectedKey: "1",
			stretchContentHeight: true,
			backgroundDesign: "Transparent",
			applyContentPadding: false,
			items: [aTabs],
			select: oController.onIconTabBarSelect
		});
									
 		this.oPage = new sap.m.Page({
			showHeader: true,
			customHeader: [new sap.m.Bar({contentMiddle:[new sap.m.Text({text:planesAccionUtils.oBundle.getText("gestPlanAcc"),textAlign:"Center"})]})],
			showNavButton: false,
			fitContainer: true,
			enableScrolling: false,
			content: [that.oIconTabBar]
		});
 		
 		return this.oPage;
	}

});