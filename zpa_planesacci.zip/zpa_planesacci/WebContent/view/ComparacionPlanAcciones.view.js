sap.ui.jsview("appPlanesAccion.view.ComparacionPlanAcciones", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf zportalaudit.controller.planesAccion.ComparacionPlanAcciones
	*/ 
	getControllerName : function() {
		return "appPlanesAccion.controller.ComparacionPlanAcciones";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf zportalaudit.controller.planesAccion.ComparacionPlanAcciones
	*/ 
	createContent : function(oController) {
		
		var masterView = sap.ui.view({id:"planesDetail", height:"100%",viewName:"appPlanesAccion.view.PlanesDetail", type:sap.ui.core.mvc.ViewType.JS});
		var detailView = sap.ui.view({id:"planesDetailEditable",height:"100%", viewName:"appPlanesAccion.view.PlanesDetailEditable", type:sap.ui.core.mvc.ViewType.JS});
				
		
		//var oModel = new sap.ui.model.json.JSONModel();
		//masterView.setModel(sap.ui.getCore().getModel('planesAccionDetail'));
		
		
	//	sap.ui.getCore().byId('planesDetail1').setEnabled(false);
		masterView.addStyleClass("nonEditable");
		
		var sideContent = new sap.ui.layout.DynamicSideContent({
			equalSplit: true,
			
			mainContent:[masterView],
			sideContent: [detailView],
		});
		
		// Añadimos evento para que ambos lados hagan scroll simultaneo

		this.sideContent = sideContent;
		
		this.addEventDelegate({
			onBeforeShow: function(oEvent) {
				// Se recogen los datos para las dos pantallas
				var detailData = oEvent.data.oModel.getData();
				
				/***
				 * Modelo pantalla no editable
				 */
				var mainModel = new sap.ui.model.json.JSONModel();
				mainModel.setDefaultBindingMode(sap.ui.model.BindingMode.OneWay);
				mainModel.setData(detailData);
				byId(oEvent.toId).sideContent.getMainContent()[0].setModel(mainModel,'detail');
				
				// Se rellena el listado de comentarios
				var list = byId(oEvent.toId).sideContent.getMainContent()[0].commentList;
				var notes = oEvent.data.oModelNotes.getData().results;
				
				$.each(notes,function(i,n) {
					/*var createDate = new Date(n.CreateTime);
					var timestamp = createDate.getDate() + '/' + (createDate.getMonth()+1) + "/" + createDate.getFullYear();
					timestamp = timestamp + "  " + createDate.getHours() + ":" + createDate.getMinutes() + ":" + createDate.getSeconds();*/
					
					list.addItem(
						new sap.m.FeedListItem({
							sender:n.CreatedByName,
							iconDensityAware:false,
							info:n.CreatedBy,
							timestamp: planesAccionUtils.convertDateTime(n.CreateTime),
							text:n.Text,
							senderActive: false,
							iconActive: false,
							iconInset: false,
							showIcon:false
						})
					);
				});
				
				var key = detailData.ActionKey;
				var oModel = onFetchStandardAttachments(key, "Actions");
				byId('planesDetail').uploader.setModel(oModel);
				
				/***
				 * Modelo pantalla editable
				 */
				var sideModel = new sap.ui.model.json.JSONModel();
				sideModel.setData(detailData);
				byId(oEvent.toId).sideContent.getSideContent()[0].setModel(sideModel,'detail');
			}
		});
		
 		return new sap.m.Page({
			title: planesAccionUtils.oBundle.getText("planAccion"),
			showNavButton: true,
			//enableScrolling:true,
			content: [sideContent],
			navButtonPress: oController.doBack,
 		});
	}

});