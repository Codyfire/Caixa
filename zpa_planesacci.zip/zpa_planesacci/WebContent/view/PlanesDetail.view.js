sap.ui.jsview("appPlanesAccion.view.PlanesDetail", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf zportalaudit.view.planesAccion.PlanesDetail
	*/ 
	getControllerName : function() {
		return "appPlanesAccion.controller.PlanesDetail";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf zportalaudit.view.planesAccion.PlanesDetail
	*/ 
	createContent : function(oController) {
		
		
		var header = new sap.m.ObjectHeader({
			//number: "id",
			title: "{detail>/Id} > {detail>/Title}",
			attributes: [
//	         	new sap.m.ObjectAttribute({
//	         		text: "{/FindingId}: {/FindingTitle}",
//	         		active: true,
//	         		press: oController.goToFinding
//	         	}),
				new sap.m.ObjectAttribute({
	         		text: "{detail>/FindingId}: {detail>/FindingTitle}",
	         		active: false
	         	}),
	         	new sap.m.ObjectAttribute({
	         		title: planesAccionUtils.oBundle.getText("numInformes"),
	         		text: "{detail>/ZzReportId}",
	         		active: false
	         	}),
	         	new sap.m.ObjectAttribute({
	         		title: planesAccionUtils.oBundle.getText("tituloInformes"),
	         		text: "{detail>/ZzReportTitle}",
	         		active: false
	         	}),
	         	new sap.m.ObjectAttribute({
	         		//TODO: Recuperar fecha distribución
	         		title: planesAccionUtils.oBundle.getText("fechaDistrInforme"),
	         		//text: "{/DateRepIssued}",
	         		active: false,
	         	}).bindProperty("text",{
	 				   parts: [{path: "detail>/DateRepIssued"}], 
	 				   formatter: function(fecha){
	 					   return planesAccionUtils.convertDate(fecha);
	 				   }
	 			 }),
	         	new sap.m.ObjectAttribute({
	         		title: planesAccionUtils.oBundle.getText("clasRiesgo"),
	         		text: "{detail>/RankingDescr}",
	         		active: false,
	         		state: sap.ui.core.ValueState.Error
	         	}),
	         		         	
	         	/**
				 * INI MOD PPM 069908 Rafael Galán Baquero 10/02/2021				
				 * Se contempla la celda del campo departamento y se concatena el código de dpto al nombre							 
				 * Codigo antiguo
				new sap.m.ObjectAttribute({
	         		title: planesAccionUtils.oBundle.getText("departamento"),
	         		text: "{/DepartmentName}",
	         		active: false,
	         	}),		
				 * Código nuevo
				 */
				//Se añade la columna departamento en la lista 	         	
				 ,			
				 new sap.m.ObjectAttribute({
								 	title : planesAccionUtils.oBundle.getText("departamento"),
								 	text  : {parts: [{path: "detail>/DepartmentName"},
					 					  			 {path: "detail>/ZzDepartment"}],
     				 				   formatter: function(departName,depart){
     				 					// return depart + ' - ' + departName;
     				 					 return departName;
    				 					   }
							 }
    							 }).bindProperty("active", "false"),
				 
				 ,								 						 				
	 			/**
			     *  FIN MOD PPM 069908 Rafael Galán Baquero 10/02/2021				
				*/

	         	
	         	new sap.m.ObjectAttribute({
	         		title: planesAccionUtils.oBundle.getText("grupo"),
	         		text: "{detail>/GroupText}",
	         		active: false,	         		
	         	})   
				/**
				 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
				 * Código nuevo
				 */
				//Se añade la columna origen en la lista con visibilidad según si está informado o no
			 , new sap.m.ObjectAttribute({}).bindProperty("text",{
 				   parts: [{path: "detail>/ZzOrigen"}], 
 				   formatter: function(origen){
 					   return planesAccionUtils.getOrigenText(origen);
 					   }
			 }).bindProperty("title",{
 				   parts: [{path: "detail>/ZzOrigen"}], 
 				   formatter: function(origen){
 					   return planesAccionUtils.oBundle.getText("origen")
 					   }
			 }).bindProperty("visible",{
					parts:["detail>/ZzOrigen"],
					formatter: function(origen){
						return origen != '' ? true : false;						
					}
				}),
				 		
				/**
				 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
				 */
			],
			firstStatus: [
				new sap.m.ObjectStatus({
					//TODO: Recuperar validación supervisor
				}).bindProperty("text",{
					parts:["detail>/Validated"],
					formatter: function(validated){
						if(validated != undefined)
							return planesAccionUtils.getStatusText(validated)
						else
							return "";
					}
				}).bindProperty("visible",{
					parts:["detail>/Validated"],
					formatter: function(validated){
						if(validated == "") return false;
						else return true;
					}
				})
			]
		});
		
		 //Creo la llista que contindrà les notes
        var commentList = new sap.m.ListBase({ 
       	 inset : false
        }); 
        
        this.commentList = commentList;
		
		var oForm2 = new sap.ui.layout.form.Form({
			editable: false,
			layout: new sap.ui.layout.form.GridLayout(),
			formContainers: [
				new sap.ui.layout.form.FormContainer({
					title: planesAccionUtils.oBundle.getText("general"),
					formElements: [
//						new sap.ui.layout.form.FormElement({
//							label: new sap.m.Label({text: planesAccionUtils.oBundle.getText("numInformes")}),
//							fields: [ 
//								new sap.m.Input( { value: "{/ReportId}", placeholder: "", editable: false, layoutData: new sap.ui.layout.form.GridElementData({hCells: "auto"})}),
//								new sap.m.Label({text: planesAccionUtils.oBundle.getText("numAcc")}),
//								new sap.m.Input( { value: "{/Id}", placeholder: "",  editable: false, layoutData: new sap.ui.layout.form.GridElementData({hCells: "auto"})})
//							]
//						}),
						new sap.ui.layout.form.FormElement({
							label: new sap.m.Label({text: planesAccionUtils.oBundle.getText("responsable")}),
							fields: [
								new sap.m.Input({ 
									placeholder: "", 
									editable: false, 
									layoutData: new sap.ui.layout.form.GridElementData({hCells: "auto"})}).bindProperty("value",{
					 				   parts: [{path: "detail>/NameOrg"}], 
					 				   formatter: function(nameOrg){
					 					  if(nameOrg != undefined)
					 						   return nameOrg.capitalize();
					 					  else
					 						   return "";
					 				   }
					 			 })
					 		] 
						}),
						//INICIO RTC-597440
						new sap.ui.layout.form.FormElement({
							label: new sap.m.Label({text: planesAccionUtils.oBundle.getText("recomendacion")}).addStyleClass("textRecommendation"),
						//TODO: Recuperar Recommendation
							fields: [new sap.m.TextArea( { value: "{detail>/Recommendation}", rows: 10, editable: false, placeholder: "",layoutData: new sap.ui.layout.form.GridElementData({hCells: "auto"})})]
						}),
						//FIN RTC-597440
						new sap.ui.layout.form.FormElement({
							label: new sap.m.Label({text: planesAccionUtils.oBundle.getText("detalles")}),
						//TODO: Recuperar detalles
							fields: [new sap.m.TextArea( { value: "{detail>/Milestone}", rows: 10,editable: false,  placeholder: "", editable: false, layoutData: new sap.ui.layout.form.GridElementData({hCells: "auto"})})]
						}),
						new sap.ui.layout.form.FormElement({
							label: new sap.m.Label({text: planesAccionUtils.oBundle.getText("estados")}),
							fields: [ new sap.m.Select({
								enabled: false,
								items: [
							        new sap.ui.core.Item({  
							        	key : "{detail>/ActualStatus}",  
							        	text : "{detail>/ActualStatusDescr}"  
							        })
								]
							}),
					        new sap.m.Label({text: planesAccionUtils.oBundle.getText("fechaVenc")}),
					        new sap.m.DatePicker({
					        	editable: false, 
					        	valueFormat: 'dd/MM/yyyy',
					        	displayFormat: 'dd/MM/yyyy',
					        }).bindProperty("value",{
					        	parts: [{path: "/ActualDeadline"}], 
				 				formatter: function(fecha){
			 					   if(fecha == "" || fecha == undefined )return "";
			 					   else if(fecha.lenght > 8){
			 						   var año = fecha.getFullYear();
			 						   var mes;
			 						   if(fecha.getMonth + 1 < 10) mes = "0" + fecha.getMonth() + 1;
			 						   else mes = fecha.getMonth() + 1;
			 						   var dia = fecha.getDate();
			 					   
			 						   return año + "/" + mes + "/" + dia; 
			 					   }else{
			 						  return fecha.substring(6,8) + "/" + fecha.substring(4,6) + "/" + fecha.substring(0,4);
			 					   }
				 				}
				 			})
							         
						]
						
					}),					
					new sap.ui.layout.form.FormElement({					
						label: new sap.m.Label({text: planesAccionUtils.oBundle.getText("fechaFinal")}),
						fields: [
				        new sap.m.DatePicker({
				        	editable: false, 
				        	valueFormat: 'dd/MM/yyyy',
				        	displayFormat: 'dd/MM/yyyy',
				        }).bindProperty("value",{
				        	parts: [{path: "detail>/FinalDate"}], 
			 				formatter: function(fecha){
		 					   if(fecha == "" || fecha == undefined )return "";
		 					   else if(fecha.lenght > 8){
		 						   var año = fecha.getFullYear();
		 						   var mes;
		 						   if(fecha.getMonth + 1 < 10) mes = "0" + fecha.getMonth() + 1;
		 						   else mes = fecha.getMonth() + 1;
		 						   var dia = fecha.getDate();
		 					   
		 						   return año + "/" + mes + "/" + dia; 
		 					   }else{
		 						  return fecha.substring(6,8) + "/" + fecha.substring(4,6) + "/" + fecha.substring(0,4);
		 					   }
			 				}
			 			})
						         
					]
					
				})
				]
			}),
		]});
		
		var oForm3 = new sap.ui.layout.form.Form({
			editable: false,
			layout: new sap.ui.layout.form.GridLayout(),
			formContainers: [        
				new sap.ui.layout.form.FormContainer({
					title: planesAccionUtils.oBundle.getText("comentarios"),
					formElements: [
						new sap.ui.layout.form.FormElement({
							//label: new sap.m.Label({text: planesAccionUtils.oBundle.getText("comentarios")}),
							fields: [commentList]
						}),
					]
				}),
			]
		});
		
		var oTable = new sap.m.Table({
			headerToolbar: new sap.m.Toolbar({
				content:[
				   new sap.m.Label({text:planesAccionUtils.oBundle.getText("listAcceso"), design: sap.m.LabelDesign.Bold}),
				   new sap.m.ToolbarSpacer(),
				]
			}),
			columns : [
			    new sap.m.Column({  
				    hAlign : "Left",  
				    header : new sap.m.Label({  
		                text : planesAccionUtils.oBundle.getText("matricula"),
		                design: sap.m.LabelDesign.Bold
				    })  
			     }),new sap.m.Column({  
	                 hAlign : "Left",  
	                 header : new sap.m.Label({  
                        text : planesAccionUtils.oBundle.getText("nombre"),
                        design: sap.m.LabelDesign.Bold
	                 })  
		         })
			],
			width : "100%",
			height : "100%",
		});
		
		 var itemTemplate = new sap.m.ColumnListItem({
			  type: "Inactive",
              cells : [  
                  new sap.m.Label({  
                      text : "{Id}",
                  }), 
         		  new sap.m.Label({  
                      text : "{FullName}",
                  })
              ],
              customData: [new sap.ui.core.CustomData({key : "Id", value : "{Id}"})]
		});  
		 
		oTable.bindAggregation("","/InfoAccessList/results/" , itemTemplate);
		
		this.table = oTable;
		this.template = itemTemplate;
		
		
//		var that = this;
//    	//Creo el component tagCloud
//		this.oTagCloud = new sap.ui.getCore().createComponent({
//			name: "tagCloudComponentPlanes",
//			id: "tagCloudPlanesDisabled"
//		});
//		
//		this.oTextTitle = new sap.m.Text({text:"Temas"}).addStyleClass("tableTitles");
//		//Creo el contenidor per el tagCloud
//		this.oContTagCloud = new sap.ui.core.ComponentContainer({
//			width:"100%",
//			height:"30%",
//			component: that.oTagCloud
//		});
		
//		var oFormComponent = new sap.ui.layout.form.Form({
//			editable: false,
//			layout: new sap.ui.layout.form.GridLayout(),
//			formContainers: [             
//				new sap.ui.layout.form.FormContainer({
//					
//					height:"100%",
//					title: "Temas",
//					formElements: [
//						new sap.ui.layout.form.FormElement({
//							fields: [
//								new sap.ui.core.ComponentContainer({
//									width:"100%",
//									height:"150px",
//									component:this.oTagCloud = new sap.ui.getCore().createComponent({
//										name: "tagCloudComponentPlanes",
//										id: "tagCloudPlanesDisabled"
//									})
//								})
//							]
//						}),
//					]
//				}),
//			]
//		});
//		
//		this.oTagCloud.setMode(4);
//		this.oTagCloud.loadAllTokens();
//		this.oTagCloud.oSearchField.setEnabled(false);
		
		var temasText = new sap.m.Text({text:"Temas"}).addStyleClass("tableTitles");
		
		var tokenizer = new sap.m.Tokenizer({
			editable: false
		});
		
		var listaThemes;
		
		if(sap.ui.getCore().getModel("planAccionInfo")) {
			
			var listaThemes = sap.ui.getCore().getModel("planAccionInfo").getData().InfoThemes.results;
			$.each(listaThemes ,function(i,n){
				tokenizer.addToken(
						new sap.m.Token({
							text:n.Theme,
							editable: false,
							customData: new sap.ui.core.CustomData({key:n.Key}),
							delete: function(oEvent){}
						}).addStyleClass("alignToken")
				)
			});
			
		} else {
			
			var listaThemes = sap.ui.getCore().getModel("planesAccionTemasDetail").getData().InfoThemes.results;
			$.each(listaThemes ,function(i,n){
				tokenizer.addToken(
						new sap.m.Token({
							text:n.Theme,
							editable: false,
							customData: new sap.ui.core.CustomData({key:n.Key}),
							delete: function(oEvent){}
						}).addStyleClass("alignToken")
				)
			});
			
		}
		
		var temasFlexBox = new sap.m.FlexBox({
			items: [temasText, tokenizer],
			direction: "Column",
			alignItems: "Start"
		});
		
		/**
		 * INI MOD RTC542699  Rafael Galán Baquero 06/03/19
		 * Código antiguo
		 * 
		 *	// Template para anexos
      	*	//var oItemTemplate = new sap.m.UploadCollectionItem({
		*	//contributor : "{CreateByName}",
		*	//documentId : "{DocId}",
		*	//enableEdit : false,
		*	//enableDelete : false,
		*	//visibleEdit : false,
		*	//visibleDelete : false,
		*	//fileName : "{Name}",
		*	//mimeType : "{MimeType}",
		*	//uploadedDate : "{CreateTime}",
		*	//url : "{Url}",
		*	//customData: [new sap.ui.core.CustomData({key : "{DeleteUrl}"})],
		*  //});
 
		 * Código nuevo
		 */	
		// Template para anexos, se le da formato a la fecha de creación del adjunto (se añade como atributo)
		var oItemTemplate = new sap.m.UploadCollectionItem({
			contributor : "{CreateByName}",
			documentId : "{DocId}",
			enableEdit : false,
			enableDelete : false,
			visibleEdit : false,
			visibleDelete : false,
			fileName : "{Name}",
			mimeType : "{MimeType}",
			url : "{Url}",
			 attributes : [
			               new sap.m.ObjectAttribute({}).bindProperty("text",{
			               parts:["CreateTime"],
    			    	   formatter: function(CreateTime){
    			    		return planesAccionUtils.convertDateTime(CreateTime)
    			    	   }
    			    	})
                       
          ],
			customData: [new sap.ui.core.CustomData({key : "{DeleteUrl}"})],		   				 			
		});
		/**
		 * FIN MOD RTC542699  Rafael Galán Baquero 06/03/19
		 */
		
		// Se rellena el uploader
		var uploader = new sap.m.UploadCollection("anexosType", {
	        multiple : false,
			items : {
				path : "/",
				template : oItemTemplate
			},
			uploadEnabled: false
		});
		
		this.uploader = uploader;
		this.upldTemplate = oItemTemplate;
			
 		this.oPage = new sap.m.Page({
 			enableScrolling: true,
 			showNavButton: false,
 			showHeader: false,
			content: [header,oForm2, temasFlexBox, oForm3, oTable,uploader, new sap.m.Panel({height:"10%"})],
//			content: [header,oForm2, this.oTextTitle, this.oContTagCloud, oForm3, oTable,uploader, new sap.m.Panel({height:"10%"})],
			navButtonPress: oController.doBack,
		});
 		
 		if(this.sId === "planesTemasDetail") {
 			this.oPage.setShowNavButton(true);
 			this.oPage.setTitle(planesAccionUtils.oBundle.getText("planAccion"));
 			this.oPage.setShowHeader(true);
 		}
 		
 		return this.oPage;
	},

});