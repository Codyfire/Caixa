sap.ui.jsview("appPlanesAccion.view.PlanesNavContainer", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf zportalaudit.view.planesAccion.PlanesNavContainer
	*/ 
	getControllerName : function() {
		return "appPlanesAccion.controller.PlanesNavContainer";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf zportalaudit.view.planesAccion.PlanesNavContainer
	*/ 
	createContent : function(oController) {
		var navContainer = new sap.m.NavContainer("planesNavCont", {
			pages: [
			   	sap.ui.view({id:"planesAccion", viewName:"appPlanesAccion.view.PlanesAccion", type:sap.ui.core.mvc.ViewType.JS}),
			    //sap.ui.view({id:"planesDetail", viewName:"appPlanesAccion.view.PlanesDetail", type:sap.ui.core.mvc.ViewType.JS}),
			    //sap.ui.view({id:"ComparacionPlanAcciones", viewName:"appPlanesAccion.view.ComparacionPlanAcciones", type:sap.ui.core.mvc.ViewType.JS})
			]
		});
		
		
 		return new sap.m.Page({
			showHeader: false,
			fitContainer: true,
			content: [navContainer]
		});
	}

});