jQuery.sap.declare("appPlanesAccion.Component");

sap.ui.core.UIComponent.extend("appPlanesAccion.Component",{
	metadata:{
		includes: [
			   "utils/utils.js",
			   "utils/conUtils.js",
			   "css/style.css",
			   "utils/encodingUtils.js",
			   "model/oDataGenerator.js",
			   "fragment/Comentario.fragment.js",
			   "fragment/OkKoAprobar.fragment.js",
			   "fragment/ComentarioMasAdjunto.fragment.js",
			   "fragment/ComentarioMasFecha.fragment.js",
			   "filterComponent/Component.js",
			   "tagCloudComponentPlanes/Component.js",
			   "tablePagination/Component.js",
			   "searchComponentPlanes/Component.js",
//INICIO RTC-537578
			   "visualizarColumnasComponentPlanes/Component.js",
			   "visualizarColumnasComponentTemas/Component.js",
//FINF   RTC-537578
			   "Download/download.min.js",
			   "utils/attachFilesUtils.js"
		], dependencies : { // external dependencies
			libs: ["sap.ui.commons"]
		}, config:{
			"fullWidth" : true
		}
	},
	
	destroy : function() {
        if(sap.ui.getCore().byId("planesCont")) sap.ui.getCore().byId("planesCont").destroy();
        sap.ui.core.UIComponent.prototype.destroy.apply(this, arguments);
	},
	
	createContent : function(){
		//Seteamos nombre del TAB:
		document.title = 'Planes de Acción';
		var con = {};
	    con.Model = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/", false);
	    sap.ui.getCore().setModel(con.Model,"con");
	    
	    var conAlertas = {};
	    conAlertas.Model = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_ALERTAS_SRV/", false);
	    sap.ui.getCore().setModel(conAlertas.Model,"conAlert");
	    
		var conAttach = {};
	    conAttach.Model = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/GRCAUD_SRV/", false);
	    sap.ui.getCore().setModel(conAttach.Model,"conAttach");
	    
	    //Cargo los roles del currentUser.
	    loadRol();
	    //Cargo el modelo de status, para hacer las traducciones.
	    loadStatusPlAccion();
	    //Cargo el modelo de status de validacion, para hacer las traducciones.
	    //loadValStatusPlAccion();
	    loadValidatorStatus();
	    // Se cargan valores de la criticidad
	    loadCriticidadStatus();
	    //Cargo los posibles grupos por los que se podrá filtrar.
	    loadGroups();
	    //Se cargan los temas para el componente temas.
	    loadTemas();
	    
	    /**
		 * INI MOD RTC 748088 Rafael Galán Baquero 04/07/2019				
		 * Código nuevo
		 */
		// Se obtienen los departamentos disponibles en el sistema y se crea el modelo
		loadDepartments();		
		/**
		 * FIN MOD RTC 748088 Rafael Galán Baquero 04/07/2019
		 */						

		/**
		 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
		 * Código nuevo
		 */
		//Se obtienen los valores disponibles en el sistema para el campo origen
		loadOrigen();
		 		
		/**
		 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
		 */
		var oView = sap.ui.view({
			id:"planesAccionTabContainer", 
			height: "100%", 
			viewName:"appPlanesAccion.view.PlanesAccionTabContainer", 
			type:sap.ui.core.mvc.ViewType.JS,
			viewData : { component : this }
		});
	
		return oView;
	}
});

