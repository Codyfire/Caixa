jQuery.sap.declare("filterComponent.Component");
jQuery.sap.require("sap.ui.core.UIComponent");

sap.ui.core.UIComponent.extend("filterComponent.Component", {		
	metadata: {
        properties: {
           refObject: {
       		type: 'string',
       		defaultValue: ''
           }
        }
	},
	
	init : function () {
		// define variable for control initial loading handling
	    this._bInitialLoading = true;
		// execute standard control method
	    sap.ui.core.UIComponent.prototype.init.apply(this,arguments);
	},
	
	createContent: function(){
		var that = this;
		this.dialog = new sap.m.ViewSettingsDialog({
			cancel: function(oEvent){},
			resetFilters: function(oEvent) {
				
				var toDeleteFilters = this.getAggregation("filterItems");
				
				for(i = 0; i < toDeleteFilters.length; ++i) {
					if(this.getAggregation("filterItems")[i]._control) {
						toDeleteFilters[i]._control.getAggregation("formContainers")[0].getAggregation("formElements")[0].getAggregation("fields")[0].setValue("");
					}
				}
			}
		});
	},
		
   	setRefObject: function (refObject) {
   		
   		this.setProperty("refObject", refObject, true);
		var that = this;
		var oComponent = sap.ui.getCore().getComponent(this.getRefObject());
		
		var confirmFunction = function(oEvent){			
			
		     var oTable = sap.ui.getCore().getComponent(refObject).table;
		     var mParams = oEvent.getParameters();
		     var oBinding = oTable.getBinding("");
	 
		     planesAccionUtils.grouping = false;
		     planesAccionUtils.sorters = [];
		     planesAccionUtils.grouper = [];
		     planesAccionUtils.sortersTemas = [];
		     planesAccionUtils.grouperTemas = [];
		     // apply sorter
		     if(mParams.sortItem){
		    	 
		    	 var sPath = mParams.sortItem.getKey();
		    	 //Si ordenamos por Status queremos ordenar por el descriptivo, no por la key.
		    	 if(sPath == "Status") {
		    		 sPath = "StatusDescr";
		    	 }
		    	 
			     var bDescending = mParams.sortDescending;
			     if(that.mode == "NOTHEME"){
			    	 planesAccionUtils.sorters.push(new sap.ui.model.Sorter(sPath, bDescending));
			     } else if(that.mode == "THEME"){ {
			    	 planesAccionUtils.sortersTemas.push(new sap.ui.model.Sorter(sPath, bDescending));
			     }
		     }
			     
		     // apply grouping
		     if (mParams.groupItem) {
		    	 planesAccionUtils.sorters = [];
		    	 planesAccionUtils.sortersTemas = [];
		         var sPath = mParams.groupItem.getKey();
		         if(sPath == "CreatedAt"){
		        	 var bDescending = mParams.groupDescending;
			         var vGroup = function(oContext) {
			             var date = oContext.getProperty(mParams.groupItem.mProperties.key);
			             var convertedDate = planesAccionUtils.convertDate(date);
			             return {
			                 key: convertedDate,
			                 text: convertedDate
			             };
			         };
			         planesAccionUtils.sorters.push(new sap.ui.model.Sorter(sPath, bDescending, vGroup));
		         }else{
		        	 var bDescending = mParams.groupDescending;
			         var vGroup = function(oContext) {
			             var name = oContext.getProperty(mParams.groupItem.mProperties.key);
			             return {
			                 key: name,
			             	/**
								 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020
								 * Código antiguo
								  text: planesAccionUtils.getStatusString(name)				
								 * Código nuevo
								 */
								//Para el campo origen, se contempla el texto de origen, en caso contrario, tal como se hacía anteriormente
			                 text: sPath != 'ZzOrigen' ? planesAccionUtils.getStatusString(name) : planesAccionUtils.getOrigenText(name)									
								/**
								 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
								 */								
			                 
			             };
			         };
			         var sPathSort = mParams.groupItem.getKey();
				     var bDescendingSort = mParams.groupDescending;
			         
				     planesAccionUtils.grouping = true;
				     if(that.mode == "NOTHEME"){
				         planesAccionUtils.grouper.push(new sap.ui.model.Sorter(sPath, bDescending, vGroup));
				     	 // apply sorter
					     planesAccionUtils.sorters.push(new sap.ui.model.Sorter(sPathSort, bDescendingSort));
				     } else if(that.mode == "THEME") {
				    	 planesAccionUtils.grouperTemas.push(new sap.ui.model.Sorter(sPath, bDescending, vGroup));         
				     	 // apply sorter
					     planesAccionUtils.sortersTemas.push(new sap.ui.model.Sorter(sPathSort, bDescendingSort));
				     	}
				     }
		         }
		     }
		     
		     /**
			   *	INI MOD RTC-537578 Rafael Galán Baquero 08/03/2019
			   * Código antiguo
		     if(that.mode == "NOTHEME"){
			     //Limpio los tipos marcados anteriormente
		    	 
						for(i=planesAccionUtils.filters.length-1; i>=0; i--){
						if(planesAccionUtils.filters[i].sPath == "ZzReportId" 				
							|| planesAccionUtils.filters[i].sPath == "Id" 
							|| planesAccionUtils.filters[i].sPath == "Title" 
							|| planesAccionUtils.filters[i].sPath == "DepartmentName"
							|| planesAccionUtils.filters[i].sPath == "GroupText" 
							|| planesAccionUtils.filters[i].sPath == "NameOrg"
							|| planesAccionUtils.filters[i].sPath == "AudGroup"
							|| planesAccionUtils.filters[i].sPath == "RankingDescr"
							|| planesAccionUtils.filters[i].sPath == "Validated"
							|| planesAccionUtils.filters[i].sPath == "StatusDescr")
							planesAccionUtils.filters.splice(i,1);
					 }
				}else if(that.mode == "THEME"){
		    	//Limpio los tipos marcados anteriormente
			     for(i=planesAccionUtils.filtersTemas.length-1; i>=0; i--){
					if(planesAccionUtils.filtersTemas[i].sPath == "ZzReportId" 
						|| planesAccionUtils.filtersTemas[i].sPath == "Id" 
						|| planesAccionUtils.filtersTemas[i].sPath == "Title" 
						|| planesAccionUtils.filtersTemas[i].sPath == "DepartmentName" 
						|| planesAccionUtils.filtersTemas[i].sPath == "GroupText" 
						|| planesAccionUtils.filtersTemas[i].sPath == "NameOrg" 
						|| planesAccionUtils.filtersTemas[i].sPath == "AudGroup"
						|| planesAccionUtils.filtersTemas[i].sPath == "RankingDescr"
						|| planesAccionUtils.filters[i].sPath == "Validated"
						|| planesAccionUtils.filtersTemas[i].sPath == "StatusDescr")
						planesAccionUtils.filtersTemas.splice(i,1);
				 }
		     }
			
		      * Código nuevo
		      * 	// Se añaden los campos Gerente y título de informe para limpiar para temas y planes de accion
		      */   
		     
		     if(that.mode == "NOTHEME"){
			     //Limpio los tipos marcados anteriormente

				     for(i=planesAccionUtils.filters.length-1; i>=0; i--){
						if(planesAccionUtils.filters[i].sPath == "ZzReportId" 
							|| planesAccionUtils.filters[i].sPath == "ZzReportTitle"
							|| planesAccionUtils.filters[i].sPath == "Id" 
							|| planesAccionUtils.filters[i].sPath == "Title" 
							/**
							 * INI MOD RTC 748088 Rafael Galán Baquero 04/07/2019
							 * Código antiguo
							 *  								
							|| planesAccionUtils.filters[i].sPath == "DepartmentName"
								
							 * Código nuevo
							 */
							// Se modifica el path de DepartmentName por ZzDepartment
								|| planesAccionUtils.filters[i].sPath == "ZzDepartment"	
							/**
							 * FIN MOD RTC 748088 Rafael Galán Baquero 04/07/2019
							 */
							|| planesAccionUtils.filters[i].sPath == "GroupText" 
							|| planesAccionUtils.filters[i].sPath == "NameOrg"
							|| planesAccionUtils.filters[i].sPath == "AudGroup"
							|| planesAccionUtils.filters[i].sPath == "Fullname"
							|| planesAccionUtils.filters[i].sPath == "RankingDescr"
							|| planesAccionUtils.filters[i].sPath == "Validated"
								/**
								 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
								 * Código nuevo
								 */
								//Se añade el campo origen
							|| planesAccionUtils.filters[i].sPath == "ZzOrigen"		
								/**
								 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
								 */								
							|| planesAccionUtils.filters[i].sPath == "StatusDescr")
							planesAccionUtils.filters.splice(i,1);
					 }
		 	}else if(that.mode == "THEME"){
		    	//Limpio los tipos marcados anteriormente
			     for(i=planesAccionUtils.filtersTemas.length-1; i>=0; i--){
					if(planesAccionUtils.filtersTemas[i].sPath == "ZzReportId"
						|| planesAccionUtils.filtersTemas[i].sPath == "ZzReportTitle"
						|| planesAccionUtils.filtersTemas[i].sPath == "Id" 
						|| planesAccionUtils.filtersTemas[i].sPath == "Title" 
						/**
						 * INI MOD RTC 748088 Rafael Galán Baquero 04/07/2019
						 * Código antiguo
						 *  								
						|| planesAccionUtils.filtersTemas[i].sPath == "DepartmentName"
								
						 * Código nuevo
						 */
						// Se modifica el path de DepartmentName por ZzDepartment para el filtro en temas
							|| planesAccionUtils.filtersTemas[i].sPath == "ZzDepartment"	
						/**
						 * FIN MOD RTC 748088 Rafael Galán Baquero 04/07/2019
						 */						
						|| planesAccionUtils.filtersTemas[i].sPath == "GroupText" 
						|| planesAccionUtils.filtersTemas[i].sPath == "NameOrg" 
						|| planesAccionUtils.filtersTemas[i].sPath == "AudGroup"
						|| planesAccionUtils.filtersTemas[i].sPath == "Fullname"
						|| planesAccionUtils.filtersTemas[i].sPath == "RankingDescr"
						|| planesAccionUtils.filtersTemas[i].sPath == "Validated"
							/**
							 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
							 * Código nuevo
							 */
							//Se añade el campo origen
						|| planesAccionUtils.filtersTemas[i].sPath == "ZzOrigen"		
							/**
							 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
							 */
						|| planesAccionUtils.filtersTemas[i].sPath == "StatusDescr")
						planesAccionUtils.filtersTemas.splice(i,1);
				 }
		     }
				
		     /**
			  * FIN MOD RTC 537578 Rafael Galán Baquero 08/03/2019
			 */
		     
	     
		     // apply filters
		     if(that.mode == "NOTHEME"){
			     var aStatusFilters = [];
			     var statusFalg = false;
				 $.each(oEvent.getParameters().filterItems,function(j,value2){
					var field  = oEvent.getParameters().filterItems[j].oParent.mProperties.key;
					if(field == "Status") {
						aStatusFilters.push(new sap.ui.model.Filter("Status",sap.ui.model.FilterOperator.EQ, planesAccionUtils.getStatusCode(oEvent.getParameters().filterItems[j].mProperties.text)));
						statusFalg = true;	
					}else if(field == "AudGroup"){
						planesAccionUtils.filters.push(new sap.ui.model.Filter(field,sap.ui.model.FilterOperator.EQ, oEvent.getParameters().filterItems[j].mAggregations.customData["0"].mProperties.value));
					}else if(field == "Validated"){
						planesAccionUtils.filters.push(new sap.ui.model.Filter(field,sap.ui.model.FilterOperator.EQ, oEvent.getParameters().filterItems[j].mAggregations.customData["0"].mProperties.value));
					}else if(field == "StatusDescr"){
						planesAccionUtils.filters.push(new sap.ui.model.Filter(field,sap.ui.model.FilterOperator.EQ, oEvent.getParameters().filterItems[j].mProperties.text));
						/**
						 * INI MOD RTC 748088 Rafael Galán Baquero 04/07/2019				
						 * Código nuevo
						 */
						/**
						 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020
						 * Código antiguo
						// Se le pasa la key en el caso de filtrar por departament (ZzDepartment)
							}else if(field == "ZzDepartment"){ 				
						 
						 * Código nuevo
						 */
						//Se añade el campo origen para buscar por la key en vez de por el nombre
					}else if(field == "ZzDepartment" || field == 'ZzOrigen'){ 				
							planesAccionUtils.filters.push(new sap.ui.model.Filter(field,sap.ui.model.FilterOperator.EQ, oEvent.getParameters().filterItems[j].mProperties.key));																			
						
						/**
						 * FIN MOD RTC 748088 Rafael Galán Baquero 04/07/2019
						 */						
						
					}else{
						if(planesAccionUtils.getStatusCode(oEvent.getParameters().filterItems[j].mProperties.text)!= "")
							planesAccionUtils.filters.push(new sap.ui.model.Filter(field,sap.ui.model.FilterOperator.EQ,planesAccionUtils.getStatusCode(oEvent.getParameters().filterItems[j].mProperties.text)));
						else{
							planesAccionUtils.filters.push(new sap.ui.model.Filter(field,sap.ui.model.FilterOperator.EQ, oEvent.getParameters().filterItems[j].mProperties.text));
						}
					}
				 });
			 
			 
				 if(statusFalg){
					 for(i=planesAccionUtils.filters.length-1; i>=0; i--){
						if(planesAccionUtils.filters[i].sPath == "Status")
							planesAccionUtils.filters.splice(i,1);
					 }
					 $.each(aStatusFilters, function(i,n){
						 planesAccionUtils.filters.push(n); 
					 });
				 }else{
					 for(i=planesAccionUtils.filters.length-1; i>=0; i--){
						if(planesAccionUtils.filters[i].sPath == "Status")
							planesAccionUtils.filters.splice(i,1);
					 }
					 if($.grep(planesAccionUtils.filters,function(n,i){return n.sPath == "Status"}).length == 0){
						 planesAccionUtils.filters.push(new sap.ui.model.Filter("Status",sap.ui.model.FilterOperator.EQ, "01"));// Modificación RTC 540728 AUM (EVR) Plans d'acció Verificats NOK
						 // Inicio Mod. PPM057146 - PRJ - 3T - AUM - Estado Se Asume el Riesgo y Actualizado en Finding						
						 //	if (!planesAccionUtils.isAuditado()) //Los auditados no podrán ver las recomendaciones en estado finalizado
								// FIN Modificación RTC 540728 AUM (EVR) Plans d'acció Verificats NOK
						 //planesAccionUtils.filters.push(new sap.ui.model.Filter("Status",sap.ui.model.FilterOperator.EQ, "02"));
						 // Fin Mod. PPM057146 - PRJ - 3T - AUM - Estado Se Asume el Riesgo y Actualizado en Finding
						 planesAccionUtils.filters.push(new sap.ui.model.Filter("Status",sap.ui.model.FilterOperator.EQ, "04"));
						//Modificación RTC 540728 AUM (EVR) Plans d'acció Verificats NOK
							//Código anterior
							//planesAccionUtils.filters.push(new sap.ui.model.Filter("Verified",sap.ui.model.FilterOperator.NE, "01"));
						 
						 // FIN Modificación RTC 540728 AUM (EVR) Plans d'acció Verificats NOK			

						 
					 }
				 }
			 }else if (that.mode == "THEME"){
				 var aStatusFilters = [];
			     var statusFalg = false;
				 $.each(oEvent.getParameters().filterItems,function(j,value2){
					var field  = oEvent.getParameters().filterItems[j].oParent.mProperties.key;
					if(field == "Status") {
						aStatusFilters.push(new sap.ui.model.Filter("Status",sap.ui.model.FilterOperator.EQ, planesAccionUtils.getStatusCode(oEvent.getParameters().filterItems[j].mProperties.text)));
						statusFalg = true;	
					}else if(field == "AudGroup"){
						planesAccionUtils.filtersTemas.push(new sap.ui.model.Filter(field,sap.ui.model.FilterOperator.EQ, oEvent.getParameters().filterItems[j].mAggregations.customData["0"].mProperties.value));
					}else if(field == "Validated"){
						planesAccionUtils.filtersTemas.push(new sap.ui.model.Filter(field,sap.ui.model.FilterOperator.EQ, oEvent.getParameters().filterItems[j].mAggregations.customData["0"].mProperties.value));
					}else if(field == "StatusDescr"){
						planesAccionUtils.filtersTemas.push(new sap.ui.model.Filter(field,sap.ui.model.FilterOperator.EQ, oEvent.getParameters().filterItems[j].mProperties.text));
						/**
						 * INI MOD RTC 748088 Rafael Galán Baquero 04/07/2019				
						 * Código nuevo
						 */
						
						/**
						 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020
						 * Código antiguo
						// Se le pasa la key en el caso de filtrar por departament (ZzDepartment)
							}else if(field == "ZzDepartment"){
						 * Código nuevo
						 */
						//Se añade el campo origen para buscar por la key en vez de por el nombre
					}else if(field == "ZzDepartment" || field == 'ZzOrigen'){ 																																
						/**
						 * FIN MOD RTC 748088 Rafael Galán Baquero 04/07/2019
						 */											
							planesAccionUtils.filtersTemas.push(new sap.ui.model.Filter(field,sap.ui.model.FilterOperator.EQ, oEvent.getParameters().filterItems[j].mProperties.key));
						/**
						 * FIN MOD RTC 748088 Rafael Galán Baquero 04/07/2019
						 */						
					
					}else{
						if(planesAccionUtils.getStatusCode(oEvent.getParameters().filterItems[j].mProperties.text)!= "")
							planesAccionUtils.filtersTemas.push(new sap.ui.model.Filter(field,sap.ui.model.FilterOperator.EQ,planesAccionUtils.getStatusCode(oEvent.getParameters().filterItems[j].mProperties.text)));
						else{
							planesAccionUtils.filtersTemas.push(new sap.ui.model.Filter(field,sap.ui.model.FilterOperator.EQ, oEvent.getParameters().filterItems[j].mProperties.text));
						}
					}
				 });
				 
				 //Si hi han status antics, els borra
				 if(statusFalg){
					 for(i=planesAccionUtils.filtersTemas.length-1; i>=0; i--){
						if(planesAccionUtils.filtersTemas[i].sPath == "Status")
							planesAccionUtils.filtersTemas.splice(i,1);
					 }
					 //Afageix els status nous
					 $.each(aStatusFilters, function(i,n){
						 planesAccionUtils.filtersTemas.push(n); 
					 });
				 }else{
					 for(i=planesAccionUtils.filtersTemas.length-1; i>=0; i--){
						if(planesAccionUtils.filtersTemas[i].sPath == "Status")
							planesAccionUtils.filtersTemas.splice(i,1);
					 }
					
				 }
			
			 }
			 
			 //Extra filter text
			 if(oEvent.getSource()._page2 != undefined)

				 if(oEvent.getSource()._page2.mAggregations.content != undefined)
					 if(oEvent.getSource()._page2.mAggregations.content["0"].mAggregations.formContainers != undefined)
						 if(oEvent.getSource()._page2.mAggregations.content["0"].mAggregations.formContainers["0"] != undefined)
							 if(oEvent.getSource()._page2.mAggregations.content["0"].mAggregations.formContainers["0"].mAggregations.formElements["0"].mAggregations.fields["0"].mProperties.value != ""){
								 var value = oEvent.getSource()._page2.mAggregations.content["0"].mAggregations.formContainers["0"].mAggregations.formElements["0"].mAggregations.fields["0"].mProperties.value;
								 var key = oEvent.getSource()._page2.mAggregations.content["0"].mAggregations.formContainers["0"].mAggregations.formElements["0"].mAggregations.label.mAggregations.customData["0"].mProperties.key;
								 if(key == "Assigned"){
									 if(that.mode == "NOTHEME"){
										 for(i=planesAccionUtils.filters.length-1; i>=0; i--){
											if(planesAccionUtils.filters[i].sPath == "Assigned")
												planesAccionUtils.filters.splice(i,1);
										 }
									 }else if (that.mode == "THEME"){
										 for(i=planesAccionUtils.filtersTemas.length-1; i>=0; i--){
											if(planesAccionUtils.filtersTemas[i].sPath == "Assigned")
												planesAccionUtils.filtersTemas.splice(i,1);
										 }
									 }
								 }
								 if(that.mode == "NOTHEME") {
									 planesAccionUtils.filters.push(new sap.ui.model.Filter(key,sap.ui.model.FilterOperator.Contains, value)); 
								 } else if (that.mode == "THEME") {
									 planesAccionUtils.filtersTemas.push(new sap.ui.model.Filter(key,sap.ui.model.FilterOperator.Contains, value)); 
								 }
							}	
			 if(that.mode == "NOTHEME"){
				 loadPlanesAccion(0, 7, planesAccionUtils.filters, planesAccionUtils.sorters, planesAccionUtils.grouping);
				 sap.ui.getCore().getComponent("tablePlanAcciones").createPaginationMenu("planesAccion",7,"tablePlanAcciones","NOTHEME");
			 }else if (that.mode == "THEME"){
				 loadPlanesAccionThemes(0, 7, planesAccionUtils.filtersTemas, planesAccionUtils.sortersTemas, planesAccionUtils.grouping);
				 sap.ui.getCore().getComponent("tablePlanAccionesTema").createPaginationMenu("planesAccionTemas",7,"tablePlanAccionesTema","THEME");
			 }
			 
//			 //Filtros estado anterior
//			 planesAccionUtils.previousFilters =  $.parseJSON(JSON.stringify(planesAccionUtils.filters));
		};
		
		this.dialog.attachConfirm(confirmFunction);
	},
		
	//Funcion que añade todos los items al componente de filtro, los agrupadores, los filtros y los ordenadores.
	addAllItems: function(sortItems, groupItems, filterItems, model,claus,table,mode){
		this.mode = mode;
		var dialog = this.dialog;
		var that = this;
		this.sortItems = sortItems;
		this.claus = claus;
		
		dialog.setSortDescending(true);
		
		$.each(sortItems, function(i,value){
			var selected = (i == 1);
			

		     /**
				*	INI MOD RTC-537578 Rafael Galán Baquero 08/03/2019
				* Código antiguo
				* 
			if(claus[i] == "NameOrg")
				dialog.addSortItem(
					new sap.m.ViewSettingsItem({
				    	text: value,
				    	key: "ZzAnOrg",
				    	selected:selected
				    })
				); 
			else
				// Añadido para la búsqueda por fecha de vencimiento
				var key = ( value == planesAccionUtils.oBundle.getText("fechaVenc") ? "Deadline" : claus[i] );
			
				dialog.addSortItem(
					new sap.m.ViewSettingsItem({
				    	text: value,
				    	key: key,
				    	selected:selected
				    })
				);
		});
		
		       * código nuevo
		       */
			//Se añaden las llaves al IF para que no duplique responsable
			if(claus[i] == "NameOrg"){
				dialog.addSortItem(
						new sap.m.ViewSettingsItem({
					    	text: value,
					    	key: "ZzAnOrg",
					    	selected:selected
					    })
					); 
				/**
				 * INI MOD RTC 748088 Rafael Galán Baquero 04/07/2019				
				 * Código nuevo
				 */
			// Para department, se realiza la ordenación por el nombre del departamento
			}else if(claus[i] == "ZzDepartment"){
				// Se modifica el valor de la key y se añade a la ordenación
			    	 key = "DepartmentName";
			    	 
			 		dialog.addSortItem(
							new sap.m.ViewSettingsItem({
						    	text: value,
						    	key: key,
						    	selected:selected
						    })
						); 
				/**
				 * FIN MOD RTC 748088 Rafael Galán Baquero 04/07/2019
				 */
			
			}else{
				// Añadido para la búsqueda por fecha de vencimiento
				var key = ( value == planesAccionUtils.oBundle.getText("fechaVenc") ? "Deadline" : claus[i] );
			
				dialog.addSortItem(
					new sap.m.ViewSettingsItem({
				    	text: value,
				    	key: key,
				    	selected:selected
				    })
				);
			}
		});
			
				
			
			/**
			 * FIN MOD RTC 537578 Rafael Galán Baquero 08/03/2019
			 */
     
		$.each(groupItems, function(i,value){
//			if(value == "Tipo" || value == "Estado"){
			/**
			 * INI MOD RTC 748088 Rafael Galán Baquero 04/07/2019
			 * Código antiguo
			 * 
//				dialog.addGroupItem(
//						new sap.m.ViewSettingsItem({
//				    		text: value,
//				    		key: claus[i],
//				    		selected:false
//				   	 	})
//					);
 				
			 * Código nuevo
			 */
			// Se obtiene la key de la agrupación
			var key = claus[i];
			
		// Para department, se realiza la agrupación por el nombre del departamento
		 if(claus[i] == "ZzDepartment")
			// Se modifica el valor de la key y se añade a la agrupación
		    	 key = "DepartmentName";
		 
		 // Se añade la agrupación   	 
		 dialog.addGroupItem(
					new sap.m.ViewSettingsItem({
				    	text: value,
				    	key: key,
				    	selected:false
				    })
				);
			/**
			 * FIN MOD RTC 748088 Rafael Galán Baquero 04/07/2019
			 */	
			
				 
//			}
		});
		
		var oModel = sap.ui.getCore().getModel(model);
		
		$.each(filterItems, function(i,value){
			if(i<claus.length){
				var items = [];
				var flac = false;
				
				if(claus[i]=="RankingDescr"){
					$.each(getModel("criticidadStatus").getData().results,function(j,n){
						items.push(
							new sap.m.ViewSettingsItem({
								text: n.Description
							})
						);
					});
					dialog.addFilterItem(new sap.m.ViewSettingsFilterItem({setModel: oModel, text:value, key: claus[i], items:[items]}));
				}else if(claus[i]=="Validated"){
					$.each(getModel("validatorStatus").getData().results,function(j,n){
						if(n.Value != "00") { // Estado vacío sin descripción
							items.push(
								new sap.m.ViewSettingsItem({
									text: n.Description,
									customData: new sap.ui.core.CustomData({key:"key", value: n.Value})
								})
							);
						}
					});
					dialog.addFilterItem(new sap.m.ViewSettingsFilterItem({setModel: oModel, text:value, key: claus[i], items:[items]}));
				}else if(claus[i]=="Status"){
					$.each(getModel("statusPlModel").getData().results,function(j,n){
						if(n.Status == "01" || n.Status == "02" || n.Status == "04" && n.Status != ""){
							items.push(
								new sap.m.ViewSettingsItem({
									text: planesAccionUtils.getStatusString(n.Status)
								})
							);
						}
					});
					dialog.addFilterItem(new sap.m.ViewSettingsFilterItem({setModel: oModel, text:value, key: claus[i], items:[items]}));
				}else  if (claus[i] == "StatusDescr") {
					var status = getModel("statusPlModel").getData().results;
					//that.oModelController.getModel("statusPlModel").getData().d.results.filter(function(i) { return i.Objtyp == "ACTION" && i.Langu == "ES"  });
					$.each(status,function(j, n) {
										if (  ( n.Status == "01"
											// Inicio Mod. PPM057146 - PRJ - 3T - AUM - Estado Se Asume el Riesgo y Actualizado en Finding
											//|| (n.Status == "02" && !planesAccionUtils.isAuditado() )
											// Fin Mod. PPM057146 - PRJ - 3T - AUM - Estado Se Asume el Riesgo y Actualizado en Finding
											|| n.Status == "04") || that.mode == "THEME" ) {
											items.push(new sap.m.ViewSettingsItem({
																text : n.StatusT,//planesAccionUtilsHisto.getStatusString(
																		//		n.Status,
																			//	that.oModelController)
																customData : new sap.ui.core.CustomData({
																	key : "key",
																	value : n.StatusT
																})
															}));
										}
									});
					dialog.addFilterItem(new sap.m.ViewSettingsFilterItem({
										setModel : oModel,
										text : value,
										key : claus[i],
										items : [ items ]
									}));
				} else if(claus[i] == "AudGroup"){
					$.each(getModel("listGroupsFilter").getData().results,function(j,n){
						items.push(
							new sap.m.ViewSettingsItem({
								text: n.GroupText,
								customData: new sap.ui.core.CustomData({key:"key", value: n.GroupId})
							})
						);
					});
					dialog.addFilterItem(new sap.m.ViewSettingsFilterItem({setModel: oModel, text:value, key: claus[i], items:[items]}));
					
					/**
					 * INI MOD RTC 748088 Rafael Galán Baquero 04/07/2019				
					 * Código nuevo
					 */
					// Se montan los elementos para el departamento
				}else if(claus[i]=="ZzDepartment"){
					// Se añaden los elementos desde el modelo
					$.each(getModel("DepActionPlan").getData().results,function(j,n){							
							items.push(
								new sap.m.ViewSettingsItem({
									/**
									 * INI MOD PPM 069908 Rafael Galán Baquero 10/02/2021
									 * Código antiguo
									 * text: n.AuditDepartment +' - '+ n.Text,
									 * Codigo nuevo
									*/
									text: n.AuditDepartment +' - '+ n.Text,
									/**
									* FIN MOD PPM069908 Rafael Galán Baquero 10/02/2021
									*/
									key: n.AuditDepartment
								})
							);							
					});				
					 
					// Se añaden los items al filtro
					dialog.addFilterItem(
						new sap.m.ViewSettingsFilterItem({
							setModel: oModel,
							text:value,
							key: claus[i],
							items:[
							    items   
							],
							
						})
					);
					/**
					 * FIN MOD RTC 748088 Rafael Galán Baquero 04/07/2019
					 */	
					/**
					 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
					 * Código nuevo
					 */
					//Se añade lista para el campo origen
					
				}else if(claus[i]=="ZzOrigen"){
					// Se añaden los elementos desde el modelo
					$.each(getModel("OrigenActionPlan").getData().results,function(j,n){							
							items.push(
								new sap.m.ViewSettingsItem({
									text: n.Text,
									key: n.Id
								})
							);							
					});				
					 
					// Se añaden los items al filtro
					dialog.addFilterItem(
						new sap.m.ViewSettingsFilterItem({
							setModel: oModel,
							text:value,
							key: claus[i],
							items:[
							    items   
							],
							
						})
					);
					
					/**
					 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
					 */
				
				}else{
					dialog.addFilterItem(
						new sap.m.ViewSettingsCustomItem({	
							text:value,
							customControl: new sap.ui.layout.form.Form({
								editable: false,
								width:"100%",
								height: "100%",
								layout: new sap.ui.layout.form.GridLayout({}),
								formContainers: [
									new sap.ui.layout.form.FormContainer({
										formElements: [
											new sap.ui.layout.form.FormElement({
												label: new sap.m.Label({
													text: value,
													layoutData: new sap.ui.layout.form.GridElementData({hCells: "4"}),
													customData: new sap.ui.core.CustomData({key:claus[i]})
												}).addStyleClass("lbAdUsr"),
												fields: [
												    new sap.m.Input({ value: "", placeholder: "Filtro",editable: true, required: false, layoutData: new sap.ui.layout.form.GridElementData({hCells: "auto"})}),	
												]
											})
										]
									})
								]
							})
						})
					);
				}
			}
		});	
	},
	
	//Función que nos abre el filtro
	openDialog: function(){this.dialog.open();}
});
