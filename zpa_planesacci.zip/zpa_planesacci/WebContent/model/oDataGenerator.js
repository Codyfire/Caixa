//--------------------> Planes accion section <---------------------------------

function loadPlanesAccion(skip, top, aFilters, aSorters, grouping) {
  // Refresco el security token per a poder logar-nos a sap
  getModel('con').refreshSecurityToken();

  if (aFilters.length == 0) {
    aFilters.push(new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "01"));
    // Modificación RTC 540728 AUM (EVR) Plans d'acció Verificats NOK
    // Inicio Modificación PPM057146 - PRJ - 3T - AUM - Estado Se Asume el Riesgo y Actualizado en Finding
    //if (!planesAccionUtils.isAuditado()) //Los auditados no podrán ver las recomendaciones en estado finalizado
    // Fin Modificación PPM057146 - PRJ - 3T - AUM - Estado Se Asume el Riesgo y Actualizado en Finding
    	// FIN Modificación RTC 540728 AUM (EVR) Plans d'acció Verificats NOK
      //aFilters.push(new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "02"));

    aFilters.push(new sap.ui.model.Filter("Status", sap.ui.model.FilterOperator.EQ, "04"));

    // Modificación RTC 540728 AUM (EVR) Plans d'acció Verificats NOK
    // Código anterior
    // aFilters.push(new
    // sap.ui.model.Filter("Verified",sap.ui.model.FilterOperator.NE,
    // "01"));
    // Código Nuevo
    // Inicio Modificación PPM057146 - PRJ - 3T - AUM - Estado Se Asume el Riesgo y Actualizado en Finding
    //aFilters.push(new sap.ui.model.Filter("Verified", sap.ui.model.FilterOperator.EQ, "00"));
    //aFilters.push(new sap.ui.model.Filter("Verified", sap.ui.model.FilterOperator.EQ, ""));
    // Fin Modificación PPM057146 - PRJ - 3T - AUM - Estado Se Asume el Riesgo y Actualizado en Finding
    // FIN Modificación RTC 540728 AUM (EVR) Plans d'acció Verificats NOK
  }

  getModel('con').read(
      "/InfoActionsSet?&$skip=" + skip + "&$top=" + top,
      {
        filters : aFilters,
        sorters : aSorters,
        async : false,
        success : function(oData) {
          console.log(oData);
          var oModel = new sap.ui.model.json.JSONModel();
          oModel.setData(oData);
          sap.ui.getCore().setModel(oModel, "planesAccion");
          if (byId("planesAccion"))
            if (byId("planesAccion").oTableComp != undefined) {
              byId("planesAccion").oTableComp.addItemTemplate("", "/results", byId("planesAccion").template);
              byId("planesAccion").oTableComp.setDataModel("planesAccion");
              if (grouping) {
                var oTable = byId("planesAccion").oTableComp.table;
                var oBinding = oTable.getBinding("");
                oBinding.sort(planesAccionUtils.grouper);
              }
            }
        }.bind(this),
        error : function(oError) {
          jQuery.sap.log.info("Odata Error occured");
        }.bind(this)
      });
}

function loadPlanesAccionThemes(skip, top, aFilters, aSorters, grouping) {

  if (planesAccionUtils.isAuditado()) {

    var hasThemeFilters = false;
    for (i = 0; i < planesAccionUtils.filtersTemas.length; ++i) {


      if (planesAccionUtils.filtersTemas[i].sPath == "ThemeId") hasThemeFilters = true;
    }

    if (!hasThemeFilters) {
      for (i = 0; i < getModel("userThemes").getData().results[0].InfoThemes.results.length; ++i) {
        aFilters.push(new sap.ui.model.Filter("ThemeId", sap.ui.model.FilterOperator.EQ,
            getModel("userThemes").getData().results[0].InfoThemes.results[i].Id));
      }
    }
  }

  /**
   * INI AJUSTES SPAU 14/11/18
   * Codigo nuevo
   * Se le pasa el skip para saber si es nueva llamada o cambiar de página
   */
  that = this;
  that.skip = skip;
  /**
   * FIN AJUSTES SPAU 14/11/18
   */
  getModel('con').read(
      "/InfoActionsThemesSet?&$skip=" + skip + "&$top=" + top,
      {
        filters : aFilters,
        sorters : aSorters,
        async : false,
        success : function(oData) {
          var oModel = new sap.ui.model.json.JSONModel();
          oModel.setData(oData);
          sap.ui.getCore().setModel(oModel, "planesAccionTemas");
          if (byId("planesAccionTemas"))
            if (byId("planesAccionTemas").oTableComp != undefined) {
              byId("planesAccionTemas").oTableComp.addItemTemplate("", "/results",
                  byId("planesAccionTemas").template);
              byId("planesAccionTemas").oTableComp.setDataModel("planesAccionTemas");              
              /**
               * INI AJUSTES SPAU 14/11/18
               * Codigo nuevo
               * Para cada nueva llamada se crea el menú de paginación según los items devueltos
               */
              if(that.skip == 0 )
              byId("planesAccionTemas").oTableComp.createPaginationMenu("planesAccionTemas",7,"tablePlanAccionesTema", true);
              /**
               * FIN AJUSTES SPAU 14/11/18
               */
              if (grouping) {
                var oTable = byId("planesAccionTemas").oTableComp.table;
                var oBinding = oTable.getBinding("");
                oBinding.sort(planesAccionUtils.grouperTemas);
              }
            }

        }.bind(this),
        error : function(oError) {
          jQuery.sap.log.info("Odata Error occured");
        }.bind(this)
      });
}

// Funció per guardar
function savePlanAccion(oEntity, notes) {
  console.log(oEntity);
  var url = "/InfoActionDetailDeepSet";
  getModel('con').create(url, oEntity, {
    success : onSavePlanAccionSuccess.bind({
      oNotes : notes
    }),
    error : onSavePlanAccionError
  });

}

// La funcio succes del saveUser
function onSavePlanAccionSuccess(oData, oDataRes) {

  console.log("Updateado correctamente!");
  loadPlanesAccion(0, 7, planesAccionUtils.filters, planesAccionUtils.sorters,
      planesAccionUtils.grouping);
  //sap.ui.getCore().getComponent("tablePlanAcciones").setDataModel("planesAccion");
  sap.ui.getCore().getComponent("tablePlanAcciones").setDataModel(sap.ui.getCore().getModel('planesAccion'),"planesAccion");
  for (var i = 0; i < this.oNotes.length; i++) {
    if (this.oNotes[i] != null && this.oNotes[i] != undefined
        && this.oNotes[i].Text != undefined && this.oNotes[i].Text != "") {
      var oEntity = {};
      oEntity.TypeKey = "COMMENT";
      oEntity.Text = this.oNotes[i].Text;
      oEntity.Status = this.oNotes[i].Status;

      // Recupero la key recien creada y la busco para obtener el
      // ParentKey para crear la nota
      var key = byId('planesDetailEditable').getModel('detail').getData().ActionKey;
      // var array =
      // sap.ui.getCore().getModel("planesAccion").getData().results;
      // var findObject = $.grep(array, function(e){ return e.ActionKey ==
      // key; });

      console.log(oEntity);

      // if(findObject.length > 0) {
      // Guardo la nota del nuevo usuario
      // var url =
      // formatUrl(getPlanAccionNotasUrl(),[convertKey(findObject[0].ActionKey)]);
      var url = formatUrl(getPlanAccionNotasUrl(), [ convertKey(key) ]);
      var success;
      getModel("con").create(url, oEntity, null, function() {
        success = true;
      }, function() {
        success = false;
      });

      if (success) {
        planesAccionUtils.showMsg(planesAccionUtils.oBundle.getText("guardarOk"));
      } else {
        planesAccionUtils.showMsg(planesAccionUtils.oBundle.getText("errCrearNota"));
      }

      // }
    }
  }

  // Se guardan los attachements
  if (byId('anexosType2'))
    onSaveAttachments(byId('planesDetailEditable').getModel('detail').getData().ActionKey,
        byId('anexosType2'), "Action");
  if (byId('anexosTypeDialog'))
    onSaveAttachments(byId('planesDetailEditable').getModel('detail').getData().ActionKey,
        byId('anexosTypeDialog'), "Action");

}

// La funció error del saveUser
function onSavePlanAccionError(oError) {
  //Inicio RTC611024  - AUM [EVR] Verificación de recomendaciones
  //Codigo Antiguo
//    console.log(oError);
//  // Refresco el model
//  loadPlanesAccion(0, 7, planesAccionUtils.filters, planesAccionUtils.sorters,
//      planesAccionUtils.grouping);
//  sap.ui.getCore().getComponent("tablePlanAcciones").table.setModel(sap.ui.getCore().getModel(
//      "planesAccion"));

  //Codigo Nuevo
  console.log(oError);
  var dialog = new sap.m.Dialog({
    title: 'Error',
    type: 'Message',
    state: 'Error',
    content: new sap.m.Text({
      text:  $(oError.response.body).find('message').first().text()
    }),
    beginButton: new sap.m.Button({
      text: 'Aceptar',
      press: function () {
        dialog.close();
      }
    }),
    afterClose: function() {
      dialog.destroy();

      loadPlanesAccion(0, 7, planesAccionUtils.filters, planesAccionUtils.sorters,
          planesAccionUtils.grouping);
      sap.ui.getCore().getComponent("tablePlanAcciones").table.setModel(sap.ui.getCore().getModel(
          "planesAccion"));
    }
  });
  dialog.open();
  //Fin RTC611024  - AUM [EVR] Verificación de recomendaciones

}

// ---------------------> End section <----------------------------------//

// --------------------> Status section <--------------------------------//

function loadStatusPlAccion() {
  // Dels status segons els seus codis
  var aFilters = [];
  aFilters.push(new sap.ui.model.Filter("Objtyp", sap.ui.model.FilterOperator.EQ, "ACTION"));
//  Codigo nuevo
  aFilters.push(new sap.ui.model.Filter("Langu", sap.ui.model.FilterOperator.EQ, sap.ui.getCore().getConfiguration().getLanguage().toUpperCase()));
//  Codigo viejo
//  aFilters.push(new sap.ui.model.Filter("Langu", sap.ui.model.FilterOperator.EQ, "ES"));

  getModel('conAlert').read("/InfoStatusSet", {
    filters : aFilters,
    async : false,
    success : function(oData) {
      var oModel = new sap.ui.model.json.JSONModel();
      oModel.setData(oData);
      sap.ui.getCore().setModel(oModel, "statusPlModel");
    }.bind(this),
    error : function(oError) {
      jQuery.sap.log.info("Odata Error occured");
    }.bind(this)
  });
}

// ---------------------> End section <-----------------------------------//

// --------------------> User Perm section <------------------------------//
function loadUserPerm(oController,model) {
//INI RTC-587472
  var indice = oController.getBindingContextPath()
  //var companyDepart = sap.ui.getCore().getModel('planesAccion').getProperty(indice).ZzAnOrg;
  var companyDepart = sap.ui.getCore().getModel(model).getProperty(indice).ZzAnOrg;
//FIN RTC-587472
  getModel('con').read(
      "/InfoUserRolSet",
      {
        async : false,
        success : function(oData) {
          var oModel = new sap.ui.model.json.JSONModel();
          oModel.setData(oData);
          sap.ui.getCore().setModel(oModel, "rol");
          var oModel = new sap.ui.model.json.JSONModel();
          var oEntity = {};
          oEntity.Delegator = false;
          oEntity.Edit = false;
          oEntity.Validator = false;
          oModel.setData(oEntity);
          sap.ui.getCore().setModel(oModel, "userPermModel");

          $.each(sap.ui.getCore().getModel("rol").getData().results,
              function(i, n) {
                // var companyDepart =
                // sap.ui.getCore().getModel("planesAccion").getData().results[0].Responsable;
            //INI RTC-587472
            // Código OLD
//            var companyDepart = sap.ui.getCore().getModel("planesAccion")

//            .getData().results[0].ZzAnOrg;
            //FIN RTC-587472

                var comp = companyDepart.substring(0, 5);
                var depart = companyDepart.substring(5);
                if (n.Company == comp && n.Department == depart) {

                  // si tiene alguno de los permisos por el
                  // departamento se los damos
                  oEntity.Delegator = n.Delegator;
                  oEntity.Edit = n.Edit;
                  oEntity.Validator = n.Validator;
                  oModel.setData(oEntity);
                  sap.ui.getCore().setModel(oModel, "userPermModel");
                  return false;
                }
              });
        }.bind(this),
        error : function(oError) {
          jQuery.sap.log.info("Odata Error occured");
        }.bind(this)
      });
}

// ---------------------> End section <-------------------------------------//

// ---------> Sección que carga datos necesarios para el filtro <----------//

// Función que carga los codigos y los estados posibles de un plan de acción
// segun su validador
function loadValidatorStatus() {
  getModel('con').read("/InfoValidatedSet", {
    async : false,
    success : function(oData) {
      var oModel = new sap.ui.model.json.JSONModel();
      oModel.setData(oData);
      sap.ui.getCore().setModel(oModel, "validatorStatus");
    }.bind(this),
    error : function(oError) {
      jQuery.sap.log.info("Odata Error occured");
    }.bind(this)
  });
}

// Función que carga los codigos y las descripciones de la criticidad
function loadCriticidadStatus() {
  // getModel('conAttach').read("/FindingRankings?Ranking",{
  getModel('con').read("/FindingRankingsSet", {

    async : false,
    success : function(oData) {
      var oModel = new sap.ui.model.json.JSONModel();
      oModel.setData(oData);
      sap.ui.getCore().setModel(oModel, "criticidadStatus");
    }.bind(this),
    error : function(oError) {
      jQuery.sap.log.info("Odata Error occured");
    }.bind(this)
  });
}

// Función que carga los distintos grupos por los que se puede filtrar
function loadGroups() {
  var url = "/InfoGroupAuditSet"
  getModel('con').read(url, null, null, false, function(data, response) {
    var oModel = new sap.ui.model.json.JSONModel();
    oModel.setData(data);
    async: false, sap.ui.getCore().setModel(oModel, "listGroupsFilter");
  }, function(oError) {
    console.log(oError);
  });
}

// ---------------------> End section <-------------------------------------//

// --------------------> Ldap section <-------------------------------------//

// Función que carga los usuarios de ldap
function getUsersLdap(aFilters) {
  getModel("con").read(getLDAPUrl(), {
    filters : aFilters,
    async : false,
    success : function(oData) {
      jQuery.sap.log.info("Odata Read Successfully:::");
      console.log(oData);
      var oModel = new sap.ui.model.json.JSONModel();
      oModel.setData(oData);
      sap.ui.getCore().setModel(oModel, "personas");
      sap.ui.getCore().getModel("personas").iSizeLimit = 200;
    }.bind(this),
    error : function(oError) {
      jQuery.sap.log.info("Odata Error occured");
    }.bind(this)
  });
}

// ---------------------> End section <------------------------------------//

// ---------------------> Temas section <----------------------------------//

function loadUserThemes(user) {
  var skip = 0;
  var top = 7;
  var aFilters = [];
  aFilters.push(new sap.ui.model.Filter("Id", sap.ui.model.FilterOperator.Contains, user));
  getModel("con").read("/InfoUsersSet?$expand=InfoThemes&$skip=" + skip + "&$top=" + top, {
    filters : aFilters,
    async : false,
    success : function(oData) {
      jQuery.sap.log.info("Odata Read Successfully:::");
      console.log(oData);
      var oModel = new sap.ui.model.json.JSONModel();
      oModel.setData(oData);
      sap.ui.getCore().setModel(oModel, "userThemes");

    }.bind(this),
    error : function(oError) {
      console.log(oError);
    }.bind(this)
  });
}

// Funció que carrega els temes.
function loadTemas() {
  getModel("con").read("/InfoThemesSet", {
    async : false,
    success : function(oData) {
      jQuery.sap.log.info("Odata Read Successfully:::");
      console.log(oData);
      var oModel = new sap.ui.model.json.JSONModel();
      oModel.setData(oData);
      sap.ui.getCore().setModel(oModel, "temasModel");
      sap.ui.getCore().getModel("temasModel").iSizeLimit = 200;
    }.bind(this),
    error : function(oError) {
      console.log(oError);
    }.bind(this)
  });
}
// ---------------------> End section <------------------------------------//

// --------------------> Rol section <---------------------------------//
function loadRol() {
  getModel('con').read("/InfoUserRolSet", {
    async : false,
    success : function(oData) {
      var oModel = new sap.ui.model.json.JSONModel();
      oModel.setData(oData);
      sap.ui.getCore().setModel(oModel, "rol");
      var rolObj = sap.ui.getCore().getModel('rol').getData().results;
      var oDepartModel = new sap.ui.model.json.JSONModel();
      $.each(rolObj, function(i, n) {
        $.each(n.Rol.split("_"), function(j, k) {
          if ($.isNumeric(k))
            oDepartModel.getData().Department = k;
        });
      })
      sap.ui.getCore().setModel(oDepartModel, "depart");
    }.bind(this),
    error : function(oError) {
      jQuery.sap.log.info("Odata Error occured");
    }.bind(this)
  });
}

// ---------------------> End section
// <-----------------------------------------------

// Función que nos exporta un excel de backend
function createExportJob(aFilters, aSorters, atThemesTab) {

  // //Si aFilters conté "Langu" no l'afegim de nou.
  // var hasLangu = false;
  // $.each(aFilters,function(i,n){
  // if(n.sPath === "Langu"){
  // hasLangu = true;
  // return false;
  // }
  // });
  //
  // if (!hasLangu) {
  // var sCurrentLocale = sap.ui.getCore().getConfiguration().getLanguage();
  // var language = sCurrentLocale.toUpperCase();
  // aFilters.push(new
  // sap.ui.model.Filter("Langu",sap.ui.model.FilterOperator.EQ, language));
  // }

  var oEntity = {};
  var selections = [];
  if (atThemesTab) {
    oEntity.ObjectType = "ZACTT";
  } else {
    oEntity.ObjectType = "ZACTP";

  }
  oEntity.Scenario = "LST_ACTPOR";
  oEntity.Template = "XLSX";

  $.each(aFilters, function(i, n) {
    var operator = "";
    var value = ""
    switch (n.sOperator) {
    default:
      operator = n.sOperator;
      value = n.oValue1;
      break;
    case "Contains":
      operator = "CP";
      value = "*" + n.oValue1 + "*";
      break;
    }
    selections.push({
      Field : n.sPath,
      Sign : "I",
      Opt : operator,
      Low : value
    });
  });

  // selections.length == 0 ? selections = [{}]: false;

  var sorts = [];
  $.each(aSorters, function(i, n) {
    sorts.push({
      AttributeName : n.sPath,
      Ascending : !n.bDescending
    });
  });
  // sorts.length == 0 ? sorts = [{AttributeName: "Type", Ascending: true}]:
  // false;

  if (selections.length != 0)
    oEntity.Selections = selections;
  if (sorts.length != 0)
    oEntity.Sorts = sorts;

  var url = "/ExportJobSet";
  getModel('con').create(
      url,
      oEntity,
      null,
      function(dataResp) {
        window.open(planesAccionUtils.getServerURL() + getModel('con').sServiceUrl
            + "/ExportJobSet(guid'" + dataResp.Key + "')/File/$value", '_blank');
      }, function(oError) {
        console.log(oError);
      });
}

// --------------------> End section <------------------------//

/**
 * INI MOD RTC 748088 Rafael Galán Baquero 04/07/2019				
 * Código nuevo
 */
//Se obtienen los departamentos disponibles en el sistema
function loadDepartments(){
	var url = "/InfoDepAuditSet";
	getModel('con').read(url,null,null,false,
			function(data,response){
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData(data);
				async: false,	
			sap.ui.getCore().setModel(oModel,"DepActionPlan");
},function(oError){
	console.log(oError);		
});
	
}
 
/**
 * FIN MOD RTC 748088 Rafael Galán Baquero 04/07/2019
 */

/**
 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
 * Código nuevo
 */
//Se obtienen los valores  disponibles en el sistema para el campo origen 
function loadOrigen(){
	var url = "/InfoOrigenSet";
	getModel('con').read(url,null,null,false,
			function(data,response){
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData(data);
				async: false,	
			sap.ui.getCore().setModel(oModel,"OrigenActionPlan");
},function(oError){
	console.log(oError);		
});
	
}
 
/**
 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
 */