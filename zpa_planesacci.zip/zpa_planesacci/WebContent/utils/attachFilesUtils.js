//La funció per guardar els arxius adjunts

function onSaveAttachments(key, uploader, entityType) {
  console.log("*** Inicio llamada al delete de adjuntos ***");
  uploader.setBusy(true);

  //var attach = byId('anexosType')._oFileUploader._aXhr;
  //var attach = uploader.getAggregation("items");
  var attach2 = uploader._aDeletedItemForPendingUpload;
  if (attach2.length > 0 ){

    $.each(attach2,function(i,n){
      var deleteUrl = "";

      if (n.getAggregation("customData") != null){
        deleteUrl = n.getAggregation("customData")[0].getProperty("key");
      }
      console.log("Delete URL:");
      console.log(deleteUrl);
      /*getModel('conAttach').remove(deleteUrl,{*/
      if(deleteUrl != "") {
        $.ajax({
          method: "DELETE",
          url: deleteUrl,
          async: false,
          beforeSend: function(XMLHttpRequest)
                {
                  XMLHttpRequest.setRequestHeader("x-csrf-token",getModel('con').getSecurityToken());
                 /* if(slug_head){
                    XMLHttpRequest.setRequestHeader("slug",slug_head);
                  };   */                
                },
              success : function (oData, oDataRes) {
                console.log("Borrado correctamente!");
                uploader.setBusy(false);
              },
              error: function (oError) {
                console.log("Error al borrar!");
                uploader.setBusy(false);
              }
        });
      }
    });
  }

  console.log("*** Fin llamada al delete de adjuntos ***");

  console.log("*** Inicio llamada al load de adjuntos ***");
  uploader.setBusy(true);

  //var attach = byId('anexosType')._oFileUploader._aXhr;
  var attach = uploader.getAggregation("items");
  //var attach = uploader._aFileUploadersForPendingUpload;
  if (attach.length > 0 ){
    var binKey = convertKey(key);
    binKey = binKey.substring(0,8) + "-" + binKey.substring(8,12) + "-" + binKey.substring(12,16) + "-" + binKey.substring(16,20) + "-" + binKey.substring(20);
   
    // Es necesario invertir el orden de los items:
    // --> Custom data se ordena de primero a último (FIFO)
    // --> Pending files se ordenan de primero a último (FIFO)
    // --> Items se ordenan según lo mostrado en pantalla (LIFO)
    //attach.reverse();
    $.each(attach,function(i,n){
      if(n._status == "pendingUploadStatus") {
        //if($.grep(planesAccionUtils.duplicateFilesNames,function(m,j){return m == n.oFileUpload.files[0].name}).length == 0){
        var url = "/CreateDocWorkPaper"; 
        url+= "?Phase=''";
        //url+= "&Name='" + n.getProperty("fileName") + "'";
        //url+= "&Name='" + n.oFileUpload.files[0].name + "'";
        //Inicio mod RTC675938
        //url+= "&Name='" + n.getFileName() + "'";
        url+= "&Name='" + encodeURIComponent(n.getFileName()) + "'";
        //Fin mod RTC675938
        url+= "&Entity='" + entityType +"'";
        url+= "&ObjectKey=guid'" + binKey + "'";
        url+= "&Type='Attachment'"; 

        // Para subidas automáticas, es necesario cambiar la url de upload en tiempo de ejecución
  //      for (var i = 0; i < uploader._aFileUploadersForPendingUpload.length; i++) {
  //         uploader._aFileUploadersForPendingUpload[i].setUploadUrl(url);
  //      }
  //      n.setUploadUrl(url);

        console.log("\t\t Antes de la llamada /CreateDocWorkPaper:");
        console.log("\t\t\t Url: " + url);
        console.log("\t\t\t Key Tipo Alerta: " + key);
        console.log("\t\t\t Key Tipo Alerta: " + binKey);

        console.log("\t\t Refrescamos security token:");
        getModel('conAttach').refreshSecurityToken();
        console.log("\t\t\t Done!");
        console.log("\t\t Llamada a Backend:");
        getModel('conAttach').create(url,null,{async:false, success: successCreateDocWorkPaper.bind({item : n}), error: errorCreateDocWorkPaper});
        function successCreateDocWorkPaper(oEvent) { 
          console.log("\t\t\t SuccessCreateDocWorkPaper:"); 
          console.log(oEvent); 
          //byId(attachField).fireUploadComplete(oEvent)
          onUploadCompleted(oEvent, uploader, this.item);
        }; 
        function errorCreateDocWorkPaper(error) { 
          //alert("\t\t\t ErrorCreateDocWorkPaper:");
          alert(planesAccionUtils.findErrorMsg(error.response.body));
          console.log(error); 
          uploader.setBusy(false);
        };
      /*}else{
        uploader._aFileUploadersForPendingUpload.shift();
        uploader.removeCustomData(0);
      }*/
      }

    });

    planesAccionUtils.showMsg(planesAccionUtils.oBundle.getText("accGuardarOk"));
    uploader.setBusy(false);

  } else {
    planesAccionUtils.showMsg(planesAccionUtils.oBundle.getText("accGuardarOk"));
    uploader.setBusy(false);
  }

  console.log("*** Fin llamada al load de adjuntos ***");

}

function onUploadCompleted(oEvent, uploader, item) {

  console.log("\t\t Upload completado con parametros:");
  var refKey = oEvent.ReferenceKey;//oEvent.getParameter("ReferenceKey");//findValueXML(xml, 'ReferenceKey');
  console.log("\t\t\t RefKey: " + refKey);
   
  var url = "/DocWorkPaperSet(guid'" + refKey + "')/File"; 
  console.log("\t\t Antes de la llamada /DocWorkPaperSet:");
  console.log("\t\t\t Url: " + url);
  console.log("\t\t\t Key CreateDocWordPaper: " + refKey);
  //console.log("\t\t\Data: ");
  //console.log(data);
  //console.log("\t\tRefrescamos security token:");
  //getModel('conAttach').refreshSecurityToken();
  console.log("\t\t Llamada a Backend:");
  getModel('conAttach').read(url,{async: false, success: successDocWorkPaperSet.bind({item:item}), error: errorDocWorkPaperSet});

  function successDocWorkPaperSet(oEvent) { 
    console.log("\t\t\t SuccessDocWorkPaperSet:");  
    console.log(oEvent); 
    var key = oEvent.Key;
    //var url2 = "https://sapriast05.lacaixa.es:44300/sap/opu/odata/sap/GRCAUD_SRV/FileSet(guid'" + key + "')/$value"; 
    var url2  = window.location.protocol + "//" + window.location.hostname + ":" + window.location.port + getModel('conAttach').sServiceUrl + "/FileSet(guid'" + key + "')/$value";
    //console.log("\t\tRefrescamos security token $value:");
    //getModel('conAttach').refreshSecurityToken();
    console.log("\t\t Antes de la llamada /FileSet:");
    console.log("\t\t\ Url: " + url2);
    console.log("\t\t\t Key DocWordPaperSet: " + key);
    /*var data = {};
    data.Key = oEvent.Key;
    data.MimeTypeKey = oEvent.MimeTypeKey;
    data.Name = oEvent.Name;
    data.ParentKey = oEvent.ParentKey;*/

    console.log("\t\t Refrescamos security token:");
    getModel('conAttach').refreshSecurityToken();
    console.log("\t\t\t Done!");
    console.log("\t\t Llamada a Backend:");

    var contData = {};
    //contData.mime_type = uploader._aFileUploadersForPendingUpload[0].oFileUpload.files[0].type;
    //contData.value = uploader.getAggregation('customData')[0].getKey("key");
    contData.mime_type = this.item.getAggregation('customData')[0].getValue();
    if(contData.mime_type == "") {
      contData.mime_type = "application/x-www-form-urlencoded";
    }
    contData.value = this.item.getAggregation('customData')[0].getKey();
    contData.value = contData.value.substring(contData.value.indexOf('base64,')+ 'base64,'.length );
    console.log("\t\t\t Datos para Backend:");
    //console.log(contData);

    /*getModel('conAttach').update(url2,contData,{headers: {"contentType" : byId('anexosType')._aFileUploadersForPendingUpload[0].oFileUpload.files[0].type},
      success: successFileSet, error: errorFileSet});*/

    $.ajax({
      type: "PUT",
      url: url2,
      data: contData.value,
      contentType: contData.mime_type,
      success: successFileSet,
      error: errorFileSet,
      async: false,
      beforeSend: function(XMLHttpRequest)
            {
              XMLHttpRequest.setRequestHeader("x-csrf-token",getModel('conAttach').getSecurityToken());
             /* if(slug_head){
                XMLHttpRequest.setRequestHeader("slug",slug_head);
              };   */                
            },
    });

    function successFileSet(oEvent) { 
      console.log("\t\t\t SuccessFileSet:"); 
      console.log(oEvent);
      // Si se carga correctamente, eliminamos la primera posición de ficheros pendientes y su contenido
      //uploader._aFileUploadersForPendingUpload.shift();
      //uploader.removeCustomData(0);
      uploader.setBusy(false);
    }; 
    function errorFileSet(oEvent) { 
      console.log("\t\t\t ErrorFileSet:"); 
      console.log(oEvent); 
      alert(planesAccionUtils.findErrorMsg(oEvent.response.body)); 
      uploader.setBusy(false);
    };
  };

  function errorDocWorkPaperSet(oEvent) { console.log("\t\t\tErrorDocWorkPaperSet:");   console.log(oEvent); alert(planesAccionUtils.findErrorMsg(oEvent.response.body)); uploader.setBusy(false);};
} 

/*function onFileSelected(oEvent, uploader) {
  // Se recogen los ficheros del upload
  var pendings = oEvent.getParameters("files");

  if(pendings) {
    //Recogemos los ficheros
    var pendFiles = pendings.files;

    var arrayFiles = [];

    $.map(pendFiles, function(n,i){
      arrayFiles.push(n);
    });

    var foundNames = [];
    var found = false;

    // Se comprueban los ficheros
    try{
    $.each(pendFiles, function(i,n) {
      found = uploader._checkDoubleFileName(n.name, uploader.getItems())
      if(found) {
        throw "Documento existente";
        //foundNames.push(n);
        //found = false;
        //arrayFiles.splice(i,1);
      }
    });

//    if(arrayFiles.length == 0) {
//      // Si hay nombres repetidos, los eliminamos de los pendientes
//      var pendingUploads = uploader._aFileUploadersForPendingUpload;
//      var newPendingUploads = [];
//
//      $.each(foundNames, function(i,n) {
//        $.each(uploader.getItems().reverse(), function(j,m) {
//          //if( m.getProperty("value").replaceAll("\"", "").trim() != n )
//          if(m.getProperty("fileName") == n.name && m._status == "pendingUploadStatus")
//          {
//            //uploader.removeItem(n);
//            //oUploadCollection.removeItem(n);
//            found = true;
//            //uploader.removeItem(m);
//            return false;
//            //newPendingUploads.push(m);
//            //uploader.removeItem(j);
//            //pendingUploads.splice(j,1);
//            //uploader.removeItem(uploader.);
//
//          }
//        });
//        if(found) return false;
//      });
//
//      //uploader._aFileUploadersForPendingUpload = newPendingUploads;
//
//    } else {
      uploader.setBusy(true);
      var oUploadCollection = oEvent.getSource();
      // Header Token
      var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
        name : "x-csrf-token",
        value : getModel('conAttach').getSecurityToken()
      });
      oUploadCollection.addHeaderParameter(oCustomerHeaderToken);

      console.log("\t\t Leemos el contenido del fichero:");
      var file = oEvent.getParameter("files") && oEvent.getParameter("files")[0];
        if(file && window.FileReader){  
           var reader = new FileReader();  
           var that = this;  
           reader.onload = function(evn) {  
             var strCSV = evn.target.result;
               uploader.addCustomData(new sap.ui.core.CustomData({key : strCSV}));
               uploader.setBusy(false);
             };
           //reader.readAsText(file);  
             reader.readAsDataURL(file);  
         }
    }
//    }
    catch(err){
      var dialog = new sap.m.Dialog({
        title: 'Advertencia',
        type: 'Message',  
          content: new sap.m.Text({
          text: err
          }),
        state: sap.ui.core.ValueState.Warning,
        endButton: new sap.m.Button({
          text: "Aceptar",
          press: function(){

            dialog.close();
          }
          }),
       });
       dialog.open(); 
    }
    finally{}
  }

}*/

function onFileSelected(oEvent, uploader) {
  var errorMsg = "";
  var found = false;
  // inicio ajuste spau 19/10/18
  var checkItems = uploader.getItems();
  var toCheck = false;
  // fin ajuste spau 19/10/18
  var files = oEvent.getParameters("files").files;
  $.each(files, function(i,n){
    //inicio ajuste spau 19/10/18
    // Codigo antiguo
    //if(uploader._checkDoubleFileName(n.name, uploader.getItems()) == true){
    // Codigo nuevo
    toCheck = $.grep(checkItems, function(value){
      return value.getFileName() == n.name;
    });
    if(toCheck.length > 0){
    // fin ajuste spau 19/10/18

      //byId("anexosType2").setBusy(true);
      found = true;
        errorMsg = "Nombre de fichero ya existente";
    }
    /**
     * INI MOD RTC RTC708001 17.04.19 Rafael Galán Baquero 
     */
    // Se añade validación del nombre del fichero
    else if(n.name.length > 100){    	
    	planesAccionUtils.findErrorMsg( planesAccionUtils.showMsg(planesAccionUtils.oBundle.getText("fileNameMaxLength")) );
      return;
    }
    
    /**
     * FIN MOD RTC RTC708001 17.04.19 Rafael Galán Baquero
     */
    
  });


  if(byId("anexosType2")) {
    $.each(files, function(i,n){ 
      //inicio ajuste spau 19/10/18
      // Codigo antiguo
      //if(byId("anexosType2")._checkDoubleFileName(n.name, byId("anexosType2").getItems()) == true){
      // Codigo nuevo
      checkItems = undefined;
      toCheck = false;
      checkItems = byId("anexosType2").getItems();
      toCheck = $.grep(checkItems, function(value){
        return value.getFileName() == n.name;
      });

      if(toCheck.length > 0){
      //Fin ajuste spau 19/10/18
        //byId("anexosType2").setBusy(true);
        found = true;
          errorMsg = planesAccionUtils.oBundle.getText("errFicheroDupl");
      }
    });
  }

  if(found) {

    var dialog = new sap.m.Dialog({
      title: planesAccionUtils.oBundle.getText("adv"),
      type: 'Message',
        content: new sap.m.Text({ 
          text: errorMsg
        }),

      state: sap.ui.core.ValueState.Warning,
      endButton: new sap.m.Button({
        text: planesAccionUtils.oBundle.getText("aceptar"),
        press: function(){
//          uploader.destroyAggregation(oEvent.file[0].name,true);
          //var uploader = byId("anexosType2");
          var aFiles = uploader.getAggregation("items");
          //var pendings = uploader._aFileUploadersForPendingUpload;
          uploader.removeAggregation("items",aFiles[0], true);


//          var aFileNames = [];
//          $.each(aFiles,function(i,n){aFileNames.push(n.getFileName())})
//          gestUtils.aDuplicates = gestUtils.findDuplicatesInArray(aFileNames);
/*  gestUtils.duplicateFilesNames = [];
//          if(uploader._aFileUploadersForPendingUpload[0].oFileUpload.files.length > 0){
            var files = uploader._aFileUploadersForPendingUpload[0].oFileUpload.files;
            if(aFiles.length == 1) {
              uploader.removeAggregation("items",aFiles[0],true);
            } else {
              $.each(aFiles,function(z,l){
                $.each(aFiles,function(c,v){
                  if(z != c)
                    if(l.getProperty('fileName') == v.getProperty('fileName') && $.grep(gestUtils.duplicateFilesNames,function(f,e){return f==l.getProperty('fileName')}).length == 0){
                      gestUtils.duplicateFilesNames.push(l.getProperty('fileName'));
                      uploader.removeAggregation("items",aFiles[z],true);
                    }
                })
              });
            }
*/
//            $.each(files,function(j,k){
//              var z = 0; var trobat = false;
//              while(z < files.length && !trobat){
//                if(aFiles[z].getProperty("fileName") == k.name)trobat = true;
//                else z++;
//              }
//              if(trobat)uploader.removeAggregation("items",aFiles[z],true);
//            });
//            var numFiles = uploader._aFileUploadersForPendingUpload[0].oFileUpload.files.length
//            gestUtils.duplicateFileNames = [];
//            $.each(uploader._aFileUploadersForPendingUpload[0].oFileUpload.files,function(i,n){
//              gestUtils.duplicateFileNames.push(n.name); 
//            });
            //uploader._aFileUploadersForPendingUpload.pop();
//          }
//          $.each(aFiles,function(i,n){aFileNames.push(n.getFileName())})
//          var aDuplicates = gestUtils.findDuplicatesInArray(aFileNames);
//          $.each(aDuplicates,function(i,n){
//            var file = $.grep(aFiles,function(m,j){return aFiles.name == aDuplicates.name});
//            uploader.removeAggregation("items",file[file.length-1],true);
//            $.each(uploader._aFileUploadersForPendingUpload,function(j,k){
//              if(k.getProperty("value").trim() == '"' + file[0].getProperty("fileName") + '"'){
//                uploader._aFileUploadersForPendingUpload.splice(j,1);
//              }
//            });
//          });
          uploader.rerender();
          dialog.close();
          byId("anexosType2").setBusy(false);
        }
        }),
     });
     dialog.open();

  } else {
    // Se añade el fichero
    uploader.setBusy(true);
    var oUploadCollection = oEvent.getSource();
    // Header Token
    var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
      multiple: false,
      name : "x-csrf-token",
      value : getModel('conAttach').getSecurityToken( )
    });
    oUploadCollection.addHeaderParameter(oCustomerHeaderToken);

    console.log("\t\t Leemos el contenido del fichero:");
    var file = oEvent.getParameter("files") && oEvent.getParameter("files")[0];
      if(file && window.FileReader){  
         var reader = new FileReader();  
         var that = this;  
         reader.onload = function(evn) {  
           var strCSV = evn.target.result;
             //uploader.addCustomData(new sap.ui.core.CustomData({key : strCSV})); 
           var fileType = this.type;
             uploader.getItems()[0].addCustomData(new sap.ui.core.CustomData({key : strCSV, value: fileType}));
             uploader.setBusy(false);
           }.bind({type : file.type});
         //reader.readAsText(file);  
         reader.readAsDataURL(file);  
      }
  }
}
/*
function onFileSelected(oEvent, uploader) {
  var encontrado = false;
  var file = oEvent.getParameters("files").files;
  $.each(uploader.getItems(), function(i,n){ 
    if(uploader._checkDoubleFileName(file[i].name, uploader.getItems()) == true){
      byId("anexosType2").setBusy(true);
        encontrado = true;
    }
  });
//  var name = uploader.getItems();
//  if (encontrado != true){
//  $.each(uploader._aFileUploadersForPendingUpload, function(i,n){
//    if(uploader._checkDoubleFileName(name[i].getProperty('fileName'), uploader.getItems()) == true){
//      byId("anexosType2").setBusy(true);
//      var dialog = new sap.m.Dialog({
//        title: 'Advertencia',
//        type: 'Message',
//          content: new sap.m.Text({
//            text: 'Documento Repetido Borrado'
//          }),
//
//        state: sap.ui.core.ValueState.Warning,
//        endButton: new sap.m.Button({
//          text: "Aceptar",
//          press: function(){
//            var a = byId("anexosType2").getAggregation("items");
//            var array = [];
//            $.each(a,function(i,n){array.push(n.getFileName())})
//            //planesAccionUtils.findDuplicatesInArray(array);
////            $.each(planesAccionUtils.findDuplicatesInArray(array),function(i,n){
////            for (var i = planesAccionUtils.findDuplicatesInArray(array).length - 1; i>=0; i--){
////              var b = array.indexOf(planesAccionUtils.findDuplicatesInArray(array)[i]);
////              byId("anexosType2").removeItem(b); 
////            }
////
////            });
//            dialog.close();
//            byId("anexosType2").setBusy(false);
//          }
//          }),
//       });
//         dialog.open();
//         encontrado = true;
//         return false;
//      }
//
//    })
//
//  }
//
  if (!encontrado){

      uploader.setBusy(true);
      var oUploadCollection = oEvent.getSource();
      // Header Token
      var oCustomerHeaderToken = new sap.m.UploadCollectionParameter({
        multiple: false,
        name : "x-csrf-token",
        value : getModel('conAttach').getSecurityToken( )
      });
      oUploadCollection.addHeaderParameter(oCustomerHeaderToken);

      console.log("\t\t Leemos el contenido del fichero:");
      var file = oEvent.getParameter("files") && oEvent.getParameter("files")[0];
        if(file && window.FileReader){  
           var reader = new FileReader();  
           var that = this;  
           reader.onload = function(evn) {  
             var strCSV = evn.target.result;
               uploader.addCustomData(new sap.ui.core.CustomData({key : strCSV}));
               uploader.setBusy(false);
             };
           //reader.readAsText(file);  
             reader.readAsDataURL(file);  
        }
  }else{
    var dialog = new sap.m.Dialog({
      title: 'Advertencia',
      type: 'Message',
        content: new sap.m.Text({ 
          text: 'No se pueden subir documentos con el mismo nombre.'
        }),

      state: sap.ui.core.ValueState.Warning,
      endButton: new sap.m.Button({
        text: "Aceptar",
        press: function(){
//          uploader.destroyAggregation(oEvent.file[0].name,true);
          var uploader = byId("anexosType2");
          var aFiles = uploader.getAggregation("items");
//          var aFileNames = [];
//          $.each(aFiles,function(i,n){aFileNames.push(n.getFileName())})
//          planesAccionUtils.aDuplicates = planesAccionUtils.findDuplicatesInArray(aFileNames);
          planesAccionUtils.duplicateFilesNames = [];
          if(uploader._aFileUploadersForPendingUpload[0].oFileUpload.files.length > 0){
            var files = uploader._aFileUploadersForPendingUpload[0].oFileUpload.files;
            $.each(aFiles,function(z,l){
              $.each(aFiles,function(c,v){
                if(z != c)
                  if(l.getProperty('fileName') == v.getProperty('fileName') && $.grep(planesAccionUtils.duplicateFilesNames,function(f,e){return f==l.getProperty('fileName')}).length == 0){
                    planesAccionUtils.duplicateFilesNames.push(l.getProperty('fileName'));
                    uploader.removeAggregation("items",aFiles[z],true);
                  }
              })
            });
//            $.each(files,function(j,k){
//              var z = 0; var trobat = false;
//              while(z < files.length && !trobat){
//                if(aFiles[z].getProperty("fileName") == k.name)trobat = true;
//                else z++;
//              }
//              if(trobat)uploader.removeAggregation("items",aFiles[z],true);
//            });
//            var numFiles = uploader._aFileUploadersForPendingUpload[0].oFileUpload.files.length
//            planesAccionUtils.duplicateFileNames = [];
//            $.each(uploader._aFileUploadersForPendingUpload[0].oFileUpload.files,function(i,n){
//              planesAccionUtils.duplicateFileNames.push(n.name); 
//            });
            //uploader._aFileUploadersForPendingUpload.pop();
          }
//          $.each(aFiles,function(i,n){aFileNames.push(n.getFileName())})
//          var aDuplicates = planesAccionUtils.findDuplicatesInArray(aFileNames);
//          $.each(aDuplicates,function(i,n){
//            var file = $.grep(aFiles,function(m,j){return aFiles.name == aDuplicates.name});
//            uploader.removeAggregation("items",file[file.length-1],true);
//            $.each(uploader._aFileUploadersForPendingUpload,function(j,k){
//              if(k.getProperty("value").trim() == '"' + file[0].getProperty("fileName") + '"'){
//                uploader._aFileUploadersForPendingUpload.splice(j,1);
//              }
//            });
//          });
          uploader.rerender();
          dialog.close();
          byId("anexosType2").setBusy(false);
        }
        }),
     });
     dialog.open();
  }

}*/

function onFetchStandardAttachments(objKey,entityType) {
  // create JSON model instance
  var oModel = new sap.ui.model.json.JSONModel();

  // Se recuperan todos los attachements del tipo de alerta
  var key = convertKey(objKey);
  var url = "/" + entityType + "(binary'" + key + "')/Attachments";
  getModel('con').read(url,{
    async: false,
        success : function (oData, oDataRes) {
          // Para cada attachement debemos obtener sus datos y la URL del  $value
          var data = [];
          $.each(oData.results, function(i,n){
            var item = {};
            item.CreateBy = n.CreateBy;
            item.CreateByName = n.CreateByName;
            item.CreateTime = n.CreateTime;
            item.Name = n.Name;
            item.DeleteUrl = n.__metadata.uri;
            //item.ServiceURL = n.ServiceURL;
            let url = n.ServiceURL +"/File";
            getModel('conAttach').read(url,{
              async: false,
                  success : function (oData, oDataRes) {
                    item.MimeType = oData.MimeTypeKey;
                    item.DocId = oData.Key;
                    //var key = convertKey(oData.Key);
                    //key = key.substring(0,8) + "-" + key.substring(8,12) + "-" + key.substring(12,16) + "-" + key.substring(16,20) + "-" + key.substring(20);
                    item.Url = window.location.protocol + "//" + window.location.hostname + ":" + window.location.port + getModel('conAttach').sServiceUrl;
                    item.Url += "/FileSet(guid'" + oData.Key + "')/$value";
                    data.push(item);
                  },
                  error: function (oError) {
                    console.log(oError);
                    alert(planesAccionUtils.findErrorMsg(oError.response.body));
                  }
            });
          });
          oModel.setData(data);
        },
        error: function (oError) {
          console.log(oError);
          alert(planesAccionUtils.findErrorMsg(oError.response.body));
        }
  });

  return oModel;
}

function onFetchStandardAttachments(objKey, entityType) {
    // create JSON model instance
    var oModel = new sap.ui.model.json.JSONModel();
    
    var key = convertKey(objKey);
    key = key.substring(0,8) + "-" + key.substring(8,12) + "-" + key.substring(12,16) + "-" + key.substring(16,20) + "-" + key.substring(20);
    var url = "/" + entityType + "(guid'" + key + "')/WorkPapers";
                 
    getModel('conAttach').read(url,{
          async: false,
     success : function (oData, oDataRes) {
          // Para cada attachement debemos obtener sus datos y la URL del  $value
          var data = [];
          $.each(oData.results, function(i,n){
                 var item = {};
                 item.CreateBy = n.CreateBy;
                 item.CreateByName = n.CreateByName;
                 item.CreateTime = n.CreateTime;
                 item.Name = n.Name;
                 item.DeleteUrl = n.__metadata.uri;
                 //item.ServiceURL = n.ServiceURL;
                 let url = n.ServiceURL +"/File";
                 getModel('conAttach').read(url,{
                        async: false,
                  success : function (oData, oDataRes) {
                       item.MimeType = oData.MimeTypeKey;
                       item.DocId = oData.Key;
                       //var key = convertKey(oData.Key);
                       //key = key.substring(0,8) + "-" + key.substring(8,12) + "-" + key.substring(12,16) + "-" + key.substring(16,20) + "-" + key.substring(20);
                       item.Url = window.location.protocol + "//" + window.location.hostname + ":" + window.location.port + getModel('conAttach').sServiceUrl;
                       item.Url += "/FileSet(guid'" + oData.Key + "')/$value";
                       data.push(item);
                  },
                  error: function (oError) {
                    console.log(oError);
                    alert(planesAccionUtils.findErrorMsg(oError.response.body));
                  }
                 });
          });
          oModel.setData(data);
     },
     error: function (oError) {
         console.log(oError);
         alert(planesAccionUtils.findErrorMsg(oError.response.body));
       }
    });
    
    return oModel;

}