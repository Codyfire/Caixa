// Funciones añadidas al tipo String en Javascript
String.prototype.contains = function(it) { return this.indexOf(it) != -1; };

String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.replace(new RegExp(search, 'g'), replacement);
};

String.prototype.trim = String.prototype.trim || function() {
    return this.replace(/^\s+|\s+$/,"");
}

String.prototype.capitalize =  function() {
	var str = this.toLowerCase();
	return str.replace(/(?:^\w|[A-Z]|\b\w)/g, function(letter, index) {
	    return letter.toUpperCase();
	  }).replace(/\s+/g, ' ');
};

String.prototype.capitalizeNoSpaces =  function() {
	var str = this.toLowerCase();
	return str.replace(/(?:^\w|[A-Z]|\b\w)/g, function(letter, index) {
	    return letter.toUpperCase();
	  }).replace(/\s+/g, '');
};

String.prototype.camelize =  function() {
	return this.replace(/(?:^\w|[A-Z]|\b\w)/g, function(letter, index) {
	    return index == 0 ? letter.toLowerCase() : letter.toUpperCase();
	  }).replace(/\s+/g, ' ');
};

String.prototype.camelizeNoSpaces =  function() {
	return this.replace(/(?:^\w|[A-Z]|\b\w)/g, function(letter, index) {
	    return index == 0 ? letter.toLowerCase() : letter.toUpperCase();
	  }).replace(/\s+/g, '');
};

//Funciones añadidas al tipo Date en Javascript

Date.prototype.toClean=function(){
    if(this!==null){
            var vDay = ((this.getDate())<10)?'0'+(this.getDate()):(this.getDate()),
                    oMonths = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
                    vMonth = oMonths[this.getMonth()],
                    vYear = this.getFullYear().toString().right(2);
                    
            return vDay+' '+vMonth+' \''+vYear;
    } else {
            return '[Invalid Date]';
    }
}

function getModel(name) {
	return sap.ui.getCore().getModel(name);
}

function byId(name) {
	return sap.ui.getCore().byId(name);
}

var planesAccionUtils = {};

//load i18n
planesAccionUtils.oBundle = new sap.ui.model.resource.ResourceModel ({
    bundleName: "appPlanesAccion.i18n.i18n"
}).getResourceBundle();

//Funciones para obtener el dispositivo
planesAccionUtils.isPhone = function(){
	return sap.ui.Device.system.phone;
}

planesAccionUtils.isTablet = function(){
	return sap.ui.Device.system.tablet;
}

planesAccionUtils.isDesktop = function(){
	return sap.ui.Device.system.desktop;
}

planesAccionUtils.getCurrentUser = function(){
	return sap.ushell.Container.getService("UserInfo").getId();
}

//Convertir fecha para backend
planesAccionUtils.convertDate2Backend = function(date){
	if(date != "") {
//		if(date.contains("/")) {
//			var dat = this.convertDate(date);
//			var splited = dat.split("/");
//			return splited[2] + splited[1] + splited[0];
//		} else {
//			return date.substring(0,4) + date.substring(4,6) + date.substring(6,8);
//		}
		if(date.length == 8) { 
				return date.substring(0,4) + date.substring(4,6) + date.substring(6,8); 
			} else { 
				var dat = this.convertDate(date);
				var splited = dat.split("/");
				return splited[2] + splited[1] + splited[0];
		}
		
	} else { return ""; }
}

//Recive un String con una fecha en formato yyyymmdd y la pasa a yyyy/mm/dd
planesAccionUtils.formatDate = function(date) {
	
	if(date) return date.substring(0,4) + "/" + date.substring(4,6) + "/" + date.substring(6,8);
	else return "";
}

// Convertir fecha "1987-09-23T00:00:00" a "23/09/1987"
planesAccionUtils.convertDate = function(date){
	if(date != "") {
		var dat = new Date(date);
		var day = dat.getDate() < 10 ? '0' + dat.getDate() : '' + dat.getDate();
		var month = dat.getMonth()+1;
		month = month < 10 ? '0' + month : '' + month;
		return day + "/" + month + "/" + dat.getFullYear();
	} else { return ""; }
}

//Convertir fecha "23/09/1987" a ISO para new Date
planesAccionUtils.convertDateToISO = function(date) {
	var st = date.replaceAll("/",".");
	var pattern = /(\d{2})\.(\d{2})\.(\d{4})/;
	return new Date(st.replace(pattern,'$3-$2-$1'));
}

//Convertir fecha "1987-09-23T12:30:45" a "23/09/1987 12:30:45"
planesAccionUtils.convertDateTime = function(date){
	if(date != "") {
		var dat = new Date(date);
		var day = dat.getDate() < 10 ? '0' + dat.getDate() : '' + dat.getDate();
		var month = dat.getMonth()+1;
		month =  month < 10 ? '0' + month : '' + month;
		/**
		 * INI MOD RTC542699  Rafael Galán Baquero 05/03/19
		 * Código antiguo
		 * //var hour = dat.getUTCHours() < 10 ? '0' + dat.getUTCHours() : '' + dat.getUTCHours();
		 * 
		 * Código nuevo
		 */		
		// Se muestra la hora correcta sin el descuadre (se incrementa una hora a la hora de la creación del registro)
		var hour = dat.getHours()-dat.getTimezoneOffset()/60 < 10 ? '0' + ( dat.getHours()-dat.getTimezoneOffset()/60 )  : '' + ( dat.getHours()-dat.getTimezoneOffset()/60 );
		/**
		 * FIN MOD RTC542699  Rafael Galán Baquero 05/03/19
		 */
		var min = dat.getMinutes() < 10 ? '0' + dat.getMinutes() : '' + dat.getMinutes();
		var sec = dat.getSeconds() < 10 ? '0' + dat.getSeconds() : '' + dat.getSeconds();
		return day + "/" + month + "/" + dat.getFullYear() + " " + hour + ":" + min + ":" + sec;
	} else { return ""; }
}

//Convertir fecha "20160215" a "15/02/2016"
planesAccionUtils.transformDate = function(date){
	if(date != undefined)
		return date.substring(6,8) + "/" + date.substring(4,6) + "/" + date.substring(0,4); 
}

planesAccionUtils.dateDiff = function(oldDate,newDate,format) {
    var milliseconds = newDate - oldDate;
    var days = milliseconds / 86400000;
    var hours = milliseconds / 3600000;
    var weeks = milliseconds / 604800000;
    var months = milliseconds / 2628000000;
    var years = milliseconds / 31557600000;
    if (format == "h") {
        return hours;
    }
    if (format == "d") {
        return days;
    }
    if (format == "w") {
        return weeks;
    }
    if (format == "m") {
        return months;
    }
    if (format == "y") {
        return years;
    }
}


// Mostrar mensaje de aplicación

planesAccionUtils.showMsg = function(text) {
	 sap.m.MessageToast.show(text, {duration: 800});
}

planesAccionUtils.statusDescr = function(status) {
	var found = $.grep(getModel("statusPlModel").getData().results,function(m,j){return m.Status == status});
	return found.length > 0 ? found[0].StatusT : "";
}

planesAccionUtils.isAuditor = function(){
	/*const AUDITOR = "ZSAP_GRCAUD_AUDITOR";
	var array = $.grep(sap.ui.getCore().getModel("rol").getData().results,function(n,i){return n.Rol.indexOf(AUDITOR) === 0});
	return array.length > 0 ? true : false;*/
	/**
	 * INI MOD PPM100084365 - (BPI) - Rol auditor/auditado compatibles en BPI2 23/01/2023				
	 * Código nuevo
	 */
	var model = sap.ui.getCore().getModel("planAccionInfo");
	if(model && model.getData()){
		var data = model.getData();
		if(data.ZzViewAuditor){
			if(data.ZzViewAuditor === 'true'){
				return true;
			}else if(data.ZzViewAuditor === 'false'){
				return false;
			}
		}else{
			return false;
		}
//		return data.ZzViewAuditor;
	}else{
		const AUDITOR = "ZSAP_GRCAUD_AUDITOR";
		var array = $.grep(sap.ui.getCore().getModel("rol").getData().results,function(n,i){return n.Rol.indexOf(AUDITOR) === 0});
		return array.length > 0 ? true : false;
	}
	/**
	 * FIN MOD PPM100084365 - (BPI) - Rol auditor/auditado compatibles en BPI2 23/01/2023
	 */
}  

planesAccionUtils.isValidator = function(oModel){
	var validator = false
	if(oModel) {
		var company = oModel.getData('Detail').ZzAnOrg.substring(0,5);
		var department = oModel.getData('Detail').ZzAnOrg.substring(5);
		$.each(getModel("rol").getData().results,function(i,n){
			if(n.Department == department && n.Company == company){
				if(n.Validator == "true") validator = true;
			}
		});
	}
	return validator;
}

planesAccionUtils.isAuditado = function(){
	/*const AUDITADO = "ZSAP_GRCAUD_AUDITADO";
	var array = $.grep(sap.ui.getCore().getModel("rol").getData().results,function(n,i){return n.Rol == AUDITADO});
	return array.length > 0 ? true : false;*/
	/**
	 * INI MOD PPM100084365 - (BPI) - Rol auditor/auditado compatibles en BPI2 23/01/2023				
	 * Código nuevo
	 */
	var model = sap.ui.getCore().getModel("planAccionInfo");
	if(model && model.getData()){
		var data = model.getData();
		if(data.ZzViewAudited){
			if(data.ZzViewAudited === 'true'){
				return true;
			}else if(data.ZzViewAudited === 'false'){
				return false;
			}
		}else{
			return false;
		}
//		return data.ZzViewAudited;
	}else{
		const AUDITADO = "ZSAP_GRCAUD_AUDITADO";
		var array = $.grep(sap.ui.getCore().getModel("rol").getData().results,function(n,i){return n.Rol == AUDITADO});
		return array.length > 0 ? true : false;
	}
	/**
	 * FIN MOD PPM100084365 - (BPI) - Rol auditor/auditado compatibles en BPI2 23/01/2023
	 */
}

planesAccionUtils.findErrorMsg = function(xml) {
	var parseXml = $.parseXML(xml);
	var firstMessage =  $(parseXml).find("message")[0];

	return "Error: " + firstMessage.textContent;
}

//Funcion a la que se le pasa el numero de un status de validacion, y te devuelve su string
planesAccionUtils.getStatusText = function(status){
	var statusText = "";
	$.each(getModel("validatorStatus").getData().results,function(i,n){
		if(n.Value == status) statusText = n.Description; 
	});
	return statusText;
}

//Función para mostrar un dialog de mensaje, se le pasa el state, el titulo y el mensaje 
planesAccionUtils.showMessageDialog = function(message, state, title){
	var dialog = new sap.m.Dialog({
        title: title,
        type: 'Message',
        content: new sap.m.Text({
            text: message
        }),
        state: state,
        beginButton: 
        	new sap.m.Button({
				text: 'Aceptar',
    	        press: function () {
    	            dialog.close();
    	        }
        	}),
        afterClose: function() {
            dialog.destroy();
        }
     });
	dialog.open();
}

//Variables de filtros, agrupadors y ordenadores.
planesAccionUtils.filters = [];
planesAccionUtils.grouping = false;
planesAccionUtils.sorters = [];
planesAccionUtils.grouper = [];

//Variables de filtros, agrupadores y ordenadores para temas.
planesAccionUtils.filtersTemas = [];
planesAccionUtils.groupingTemas = false;
planesAccionUtils.sortersTemas = [];
planesAccionUtils.grouperTemas= [];

//Funcion a la que se le pasa el numero de un status, y te devuelve su string
planesAccionUtils.getStatusString = function(status){
	var statusString = "";
	$.each(sap.ui.getCore().getModel("statusPlModel").getData().results,function(i,n){
		if(n.Status == status) statusString = n.StatusT;
	});
	return statusString;
}

//Funcion a la que se le pasa el numero de un ranking de criticidad , y te devuelve su string
planesAccionUtils.getCriticidadString = function(ranking){
	var statusString = "";
	$.each(sap.ui.getCore().getModel("criticidadStatus").getData().results,function(i,n){
		if(n.Ranking == ranking) statusString = n.Description;
	});
	return statusString;
}

//Funcion a la que se le pasa el string de un status, y te devuelve su numero
planesAccionUtils.getStatusCode = function(statusString){
	var statusCode = ""
	$.each(sap.ui.getCore().getModel("statusPlModel").getData().results,function(i,n){
		if(n.StatusT == statusString) statusCode = n.Status;
	});
	return statusCode;
}

planesAccionUtils.getServerURL = function(){
	return location.protocol + "//" + location.hostname + ":" + location.port;
}

/**
 * INI MOD RTC 537578 Rafael Galán Baquero 06/03/2019
 */

// Función que trata la visualización de columnas para el componente visualizarColumnasComponentPlanes
planesAccionUtils.assignTableVisualizadorPlan = function(){
	var oVisualizadorComp = sap.ui.getCore().getComponent("visColumnComPlanComp");
	var table = sap.ui.getCore().getComponent("tablePlanAcciones").table
	$.each(oVisualizadorComp.oSelectDialog.getItems(),function(i,n){
		j = i - 1;
		if(j > -1 && j < oVisualizadorComp.table.getColumns().length)
			table.getColumns()[j].setVisible(n.getSelected());
	}); 
	return true;
}

//Función que trata la visualización de columnas para el componente visualizarColumnasComponentTemas
planesAccionUtils.assignTableVisualizadorTema = function(){
	var oVisualizadorComp = sap.ui.getCore().getComponent("visColumnComTemasComp");
	var table = sap.ui.getCore().getComponent("tablePlanAccionesTema").table
	$.each(oVisualizadorComp.oSelectDialog.getItems(),function(i,n){
		j = i - 1;
		if(j > -1 && j < oVisualizadorComp.table.getColumns().length)
			table.getColumns()[j].setVisible(n.getSelected());
	}); 
	return true;
}

/**
 * FIN RTC 537578 Rafael Galán Baquero 06/03/2019
 */


/**
 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
 * Código nuevo
 */
//Se obtiene el texto a mostrar para el campo origen
planesAccionUtils.getOrigenText = function(origen){
////var element = sap.ui.getCore().getModel('OrigenActionPlan').getData().results.find(element => element.Id == origen );
	var element = sap.ui.getCore().getModel('OrigenActionPlan').getData().results.filter(function(item) { return item.Id == origen; });

	return element.length > 0 ? element[0].Text : '';
}
 		
/**
 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
 */
