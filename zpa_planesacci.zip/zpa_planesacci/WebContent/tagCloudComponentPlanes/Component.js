//define a new UIComponent 
jQuery.sap.require("sap.ui.core.UIComponent");
jQuery.sap.require("sap.m.SearchField");
jQuery.sap.require("sap.m.Panel");
jQuery.sap.require("sap.m.FlexBox");
jQuery.sap.require("sap.m.Page");
jQuery.sap.declare("tagCloudComponentPlanes.Component");

sap.ui.define([
	"sap/ui/core/UIComponent"
], function (UIComponent) {
	

	return UIComponent.extend("tagCloudComponentPlanes.Component", {

		init : function () {
			// call the init function of the parent
			UIComponent.prototype.init.apply(this, arguments);
		},
		
		createContent: function(){
			var that = this;
			
			this.oPanel = new sap.m.Panel({
				height:"100%",
				width: "100%",
				enabled:false,
			});
			
				
			this.oSuggestionItem = new sap.m.SuggestionItem({
				text: "{Theme}",
				customData: new sap.ui.core.CustomData({key:"{Key}"})
			});
			
			this.oSearchField = new sap.m.SearchField({
				enableSuggestions: true,
		      	suggestionItems:[],
		      	search: this.onSearch,
		      	suggest: this.onSuggest,
				customData: [
					new sap.ui.core.CustomData({
						key : "mapping",
						value : "area"
					})
				]
			});
			
			this.oSearchField.bindAggregation("suggestionItems","/results",this.oSuggestionItem);
			
			this.oFlex = new sap.m.FlexBox({
				width: "100%",
				height:"100%",
				direction: sap.m.FlexDirection.Column,
				//alignItems: sap.m.FlexAlignItems.Center,
				fitContainer:false,
				items:[that.oSearchField, that.oPanel]
			});

			
			this.oPage = new sap.m.Page({
				height: "100%",
				width: "100%",
				showHeader:false,
				content:[this.oFlex]
			})
			
			if(planesAccionUtils.isAuditado()) this.oSearchField.setVisible(false);
			
			return this.oPage;
		},
		
		//Aquí seteo el modo con el que quiero que se comporte el componente
		setMode: function(mode){
			this.mode = mode;
		},
		
		loadAllTokens: function(){
			var that = this;
			
			if(this.mode==0){
				$.each(that.oPanel.getContent(),function(i,n){n.destroy()}); 
				$.each(getModel("temasModel").getData().results,function(i,n){
					that.oPanel.addContent(
						new sap.m.Token({
							text:n.Theme,
							customData: new sap.ui.core.CustomData({key:n.Key}),
							delete: function(oEvent){
								deleteTema(oEvent.getSource().getAggregation("customData")[0].getProperty("key"));
								loadTemas();
								that.loadAllTokens();
							}
						}).addStyleClass("marginRight")
					);
				});
				this.oPanel.rerender();
			}else if (this.mode == 2) {
				//modo para tab de temas	
				
				this.oSearchField.setModel(sap.ui.getCore().getModel("temasModel"));
				$.each(that.oPanel.getContent(),function(i,n){n.destroy()}); 
			
				
			}else if (this.mode == 3){
//				if(this.oSearchField) this.oSearchField.setModel(sap.ui.getCore().getModel("temasModel"));
				this.oSearchField.setModel(sap.ui.getCore().getModel("temasModel"));
				$.each(that.oPanel.getContent(),function(i,n){n.destroy()}); 
				if(getModel("planAccionInfo")){
					if(getModel("planAccionInfo").getData().InfoThemes.results){
						$.each(getModel("planAccionInfo").getData().InfoThemes.results,function(i,n){
							that.oPanel.addContent(
								new sap.m.Token({
									text:n.Theme,
									customData: new sap.ui.core.CustomData({key:n.Key}),
									delete: function(oEvent){
										var aThemes = [];
										var oPanel = sap.ui.getCore().getComponent(this.getParent()._sOwnerId).oPanel;
										$.each(oPanel.getContent(),function(i,n){
											if(n.getAggregation("customData")[0].getProperty("key") != oEvent.getSource().getAggregation("customData")[0].getProperty("key"))
												aThemes.push({Key:n.getAggregation("customData")[0].getProperty("key")});
										});
//										if(aThemes.length == 0){
//											//Han borrado el ultimo tema y por tanto ponemos un modelo vacio
//											var oModel = new sap.ui.model.json.JSONModel();
//									   		sap.ui.getCore().setModel(oModel,"planesAccionTemas");
//											planesAccionUtils.filtersTemas = [];
//											byId("planesAccionTemas").oTableComp.addItemTemplate("", "/results", byId("planesAccionTemas").template);
//								   			byId("planesAccionTemas").oTableComp.setDataModel("planesAccionTemas");
//								   			oPanel.removeContent(this);
//											loadPlanesAccionThemes(0,7,planesAccionUtils.filtersTemas,planesAccionUtils.sortersTemas,planesAccionUtils.groupingTemas);
//										}else{
											//Todavia quedan temas y hacemos un get con los temas que quedan
											
											for(i = 0; i < planesAccionUtils.filtersTemas.length; ++i){
												if(planesAccionUtils.filtersTemas[i].sPath == "ThemeId") {
													planesAccionUtils.filtersTemas.splice(i,1);
													--i;
												}
											}
											
											oPanel.removeContent(this);
											$.each(oPanel.getContent(), function(i,n){
												planesAccionUtils.filtersTemas.push(new sap.ui.model.Filter("ThemeId",sap.ui.model.FilterOperator.EQ, n.getAggregation("customData")[0].getProperty("key")));
											});
											loadPlanesAccionThemes(0,7,planesAccionUtils.filtersTemas,planesAccionUtils.sortersTemas,planesAccionUtils.groupingTemas);
											
//										}
									}
								}).addStyleClass("marginRight")
							);
						});
						this.oPanel.rerender();
					}	
				}
			} else if (this.mode == 4){

//				if(this.oSearchField) this.oSearchField.setModel(sap.ui.getCore().getModel("temasModel"));
				this.oSearchField.setModel(sap.ui.getCore().getModel("temasModel"));
				$.each(that.oPanel.getContent(),function(i,n){n.destroy()}); 
				if(getModel("planAccionInfo")){
					if(getModel("planAccionInfo").getData().InfoThemes.results){
						$.each(getModel("planAccionInfo").getData().InfoThemes.results,function(i,n){
							that.oPanel.addContent(
								new sap.m.Token({
									text:n.Theme,
									editable: false,
									customData: new sap.ui.core.CustomData({key:n.Key}),
									delete: function(oEvent){}
								}).addStyleClass("marginRight")
							);
						});
						this.oPanel.rerender();
					}	
				}
			
			} else if (this.mode == 5){
				this.oSearchField.setModel(sap.ui.getCore().getModel("temasModel"));
				$.each(that.oPanel.getContent(),function(i,n){n.destroy()}); 
				if(getModel("planAccionInfo")){
					if(getModel("planAccionInfo").getData().InfoThemes.results){
						$.each(getModel("planAccionInfo").getData().InfoThemes.results,function(i,n){
							that.oPanel.addContent(
								new sap.m.Token({
									text:n.Theme,
									editable: false,
									customData: new sap.ui.core.CustomData({key:n.Key}),
									delete: function(oEvent){}
								}).addStyleClass("marginRight")
							);
						});
						this.oPanel.rerender();
					}	
				}
			}
		},
		
		onSearch: function (event) {
			var that = this;
			var item = event.getParameter("suggestionItem");
			if(sap.ui.getCore().getComponent(this.getParent()._sOwnerId).mode == 0){
				//Comportament d'administració
				var oSearchField = sap.ui.getCore().getComponent(this.getParent()._sOwnerId).oSearchField;
				var theme = oSearchField.getProperty("value");
				if(theme!=""){
					var aCoincidencias = $.grep(getModel("temasModel").getData().results,function(n,i){return n.Theme == theme});
					if(aCoincidencias.length == 0){
						var oEntity = {};
						oEntity.Theme = theme;
						saveTema(oEntity);
						loadTemas();
//						oSearchField.removeAllSuggestionItems();
						sap.ui.getCore().getComponent(this.getParent()._sOwnerId).loadAllTokens();
						oSearchField.setValue("");
					}							
				}
				oSearchField.setValue("");				
			}else if(sap.ui.getCore().getComponent(this.getParent()._sOwnerId).mode == 1){
				//Comportament d'alta d'un nou usuari
				var oSearchField = sap.ui.getCore().getComponent(this.getParent()._sOwnerId).oSearchField;
				var theme = oSearchField.getProperty("value");
				if(theme!=""){
					var aCoincidencias = $.grep(getModel("temasModel").getData().results,function(n,i){return n.Theme == theme});
					if(aCoincidencias.length == 1){
						var oPanel = sap.ui.getCore().getComponent(this.getParent()._sOwnerId).oPanel;
						var inPanel = $.grep(oPanel.getContent(),function(n,i){return n.getProperty("text") == theme});
						if(inPanel.length == 0){
							oPanel.addContent(
								new sap.m.Token({
									text:aCoincidencias[0].Theme,
									customData: new sap.ui.core.CustomData({key:aCoincidencias[0].Key}),
									delete: function(oEvent){
										oPanel.removeContent(this);
									}
								}).addStyleClass("marginRight")
							)
						}	
					}
				}
				oSearchField.setValue("");				
			}else if(sap.ui.getCore().getComponent(this.getParent()._sOwnerId).mode == 2 || sap.ui.getCore().getComponent(this.getParent()._sOwnerId).mode == 3){
				//Comportament per afegir temes a una acció
				var oSearchField = sap.ui.getCore().getComponent(this.getParent()._sOwnerId).oSearchField;
				var theme = oSearchField.getProperty("value");
				if(theme!=""){
					var aCoincidencias = $.grep(getModel("temasModel").getData().results,function(n,i){return n.Theme == theme});
					if(aCoincidencias.length == 1){
						var oPanel = sap.ui.getCore().getComponent(this.getParent()._sOwnerId).oPanel;
						var inPanel = $.grep(oPanel.getContent(),function(n,i){return n.getProperty("text") == theme});
						if(inPanel.length == 0){
							oPanel.addContent(
								new sap.m.Token({
									text:aCoincidencias[0].Theme,
									customData: [new sap.ui.core.CustomData({key:aCoincidencias[0].Key}),new sap.ui.core.CustomData({key:aCoincidencias[0].Id})],
									delete: function(oEvent){
										var aThemes = [];
										var oPanel = sap.ui.getCore().getComponent(this.getParent()._sOwnerId).oPanel;
										$.each(oPanel.getContent(),function(i,n){
											if(n.getAggregation("customData")[0].getProperty("key") != oEvent.getSource().getAggregation("customData")[0].getProperty("key"))
												aThemes.push({Key:n.getAggregation("customData")[0].getProperty("key")});
										});
//										if(aThemes.length == 0){
//											//Han borrado el ultimo tema y por tanto ponemos un modelo vacio
//											var oModel = new sap.ui.model.json.JSONModel();
//									   		sap.ui.getCore().setModel(oModel,"planesAccionTemas");
//											planesAccionUtils.filtersTemas = [];
//											byId("planesAccionTemas").oTableComp.addItemTemplate("", "/results", byId("planesAccionTemas").template);
//								   			byId("planesAccionTemas").oTableComp.setDataModel("planesAccionTemas");
//								   			oPanel.removeContent(this);
//											loadPlanesAccionThemes(0,7,planesAccionUtils.filtersTemas,planesAccionUtils.sortersTemas,planesAccionUtils.groupingTemas);
//										}else{
											//Todavia quedan temas y hacemos un get con los temas que quedan
											
											for(i = 0; i < planesAccionUtils.filtersTemas.length; ++i){
												if(planesAccionUtils.filtersTemas[i].sPath == "ThemeId") {
													planesAccionUtils.filtersTemas.splice(i,1);
													--i;
												}
											}
											
											oPanel.removeContent(this);
											$.each(oPanel.getContent(), function(i,n){
												
												var listaThemes = sap.ui.getCore().getModel("temasModel").getData().results;
												for(i = 0; i < listaThemes.length; ++i) {
													if(listaThemes[i].Key == n.getAggregation("customData")[0].getProperty("key")) {
														planesAccionUtils.filtersTemas.push(new sap.ui.model.Filter("ThemeId",sap.ui.model.FilterOperator.EQ, listaThemes[i].Id));
														break;
													}
												}
												
											});
											loadPlanesAccionThemes(0,7,planesAccionUtils.filtersTemas,planesAccionUtils.sortersTemas,planesAccionUtils.groupingTemas);
											
//										}
									}
								}).addStyleClass("marginRight")
							);
							oSearchField.setValue("");
							//Se prepara la llamada a backend filtrando por todos los temas seleccionados.
							planesAccionUtils.filtersTemas = [];
							
							var listaThemes = oPanel.getContent();
							$.each(listaThemes,function(i,n){
								
								var themeText = n.getProperty("text");
								//oEvent.getSource().getAggregation("customData")[0].getProperty("text")
								$.each(sap.ui.getCore().getModel("temasModel").getData().results,function(i,n){
									if(n.Theme == themeText){
										planesAccionUtils.filtersTemas.push(new sap.ui.model.Filter("ThemeId",sap.ui.model.FilterOperator.EQ, n.Id));
										return false;
									}
								});
								
							});
							
//							$.each(oPanel.getContent(), function(i,n){
//								planesAccionUtils.filtersTemas.push(new sap.ui.model.Filter("ThemeId",sap.ui.model.FilterOperator.EQ, n.getAggregation("customData")[0].getProperty("id")));
//							});
							loadPlanesAccionThemes(0,7,planesAccionUtils.filtersTemas,planesAccionUtils.sortersTemas,planesAccionUtils.groupingTemas);
						}
					}
				}
			} else if(sap.ui.getCore().getComponent(this.getParent()._sOwnerId).mode == 4) {

				//Comportament per afegir temes a una acció
				var oSearchField = sap.ui.getCore().getComponent(this.getParent()._sOwnerId).oSearchField;
				var theme = oSearchField.getProperty("value");
				if(theme!=""){
					var aCoincidencias = $.grep(getModel("temasModel").getData().results,function(n,i){return n.Theme == theme});
					if(aCoincidencias.length == 1){
						var oPanel = sap.ui.getCore().getComponent(this.getParent()._sOwnerId).oPanel;
						var inPanel = $.grep(oPanel.getContent(),function(n,i){return n.getProperty("text") == theme});
						if(inPanel.length == 0){
							oPanel.addContent(
								new sap.m.Token({
									text: aCoincidencias[0].Theme,
									editable: false,
									customData: [new sap.ui.core.CustomData({key:aCoincidencias[0].Key}),new sap.ui.core.CustomData({key:aCoincidencias[0].Id})],
									delete: function(oEvent){}
								}).addStyleClass("marginRight")
							);
							oSearchField.setValue("");
							//Se prepara la llamada a backend filtrando por todos los temas seleccionados.
							planesAccionUtils.filtersTemas = [];
							
							var listaThemes = oPanel.getContent();
							$.each(listaThemes,function(i,n){
								
								var themeText = n.getProperty("text");
								//oEvent.getSource().getAggregation("customData")[0].getProperty("text")
								$.each(sap.ui.getCore().getModel("temasModel").getData().results,function(i,n){
									if(n.Theme == themeText){
										planesAccionUtils.filtersTemas.push(new sap.ui.model.Filter("ThemeId",sap.ui.model.FilterOperator.EQ, n.Id));
										return false;
									}
								});
								
							});
							
//							$.each(oPanel.getContent(), function(i,n){
//								planesAccionUtils.filtersTemas.push(new sap.ui.model.Filter("ThemeId",sap.ui.model.FilterOperator.EQ, n.getAggregation("customData")[0].getProperty("id")));
//							});
							loadPlanesAccionThemes(0,7,planesAccionUtils.filtersTemas,planesAccionUtils.sortersTemas,planesAccionUtils.groupingTemas);
						}
					}
				}
			
			} else if(sap.ui.getCore().getComponent(this.getParent()._sOwnerId).mode == 5) {
				var oSearchField = sap.ui.getCore().getComponent(this.getParent()._sOwnerId).oSearchField;
				var theme = oSearchField.getProperty("value");
				if(theme!=""){
					var aCoincidencias = $.grep(getModel("temasModel").getData().results,function(n,i){return n.Theme == theme});
					if(aCoincidencias.length == 1){
						var oPanel = sap.ui.getCore().getComponent(this.getParent()._sOwnerId).oPanel;
						var inPanel = $.grep(oPanel.getContent(),function(n,i){return n.getProperty("text") == theme});
						if(inPanel.length == 0){
							oPanel.addContent(
								new sap.m.Token({
									text:aCoincidencias[0].Theme,
									editable: false,
									customData: [new sap.ui.core.CustomData({key:aCoincidencias[0].Key}),new sap.ui.core.CustomData({key:aCoincidencias[0].Id})],
									delete: function(oEvent){}
								}).addStyleClass("marginRight")
							);
							oSearchField.setValue("");
							//Se prepara la llamada a backend filtrando por todos los temas seleccionados.
							planesAccionUtils.filtersTemas = [];
							
							var listaThemes = oPanel.getContent();
							$.each(listaThemes,function(i,n){
								
								var themeText = n.getProperty("text");
								//oEvent.getSource().getAggregation("customData")[0].getProperty("text")
								$.each(sap.ui.getCore().getModel("temasModel").getData().results,function(i,n){
									if(n.Theme == themeText){
										planesAccionUtils.filtersTemas.push(new sap.ui.model.Filter("ThemeId",sap.ui.model.FilterOperator.EQ, n.Id));
										return false;
									}
								});
								
							});
							
//							$.each(oPanel.getContent(), function(i,n){
//								planesAccionUtils.filtersTemas.push(new sap.ui.model.Filter("ThemeId",sap.ui.model.FilterOperator.EQ, n.getAggregation("customData")[0].getProperty("id")));
//							});
							loadPlanesAccionThemes(0,7,planesAccionUtils.filtersTemas,planesAccionUtils.sortersTemas,planesAccionUtils.groupingTemas);
						}
					}
				}
			}
		},

		onSuggest: function (event) {
			var oSearchField = sap.ui.getCore().getComponent(this.getParent()._sOwnerId).oSearchField;
			oSearchField.$().toggleClass("sapMFocus", false);
			 
			if (oSearchField._bSuggestionSuppressed) {
				oSearchField._bSuggestionSuppressed = false; // void the reset button handling
			}
			// restore toltip of the refresh button
			if (oSearchField.getShowRefreshButton()) {
			 	tooltip = oSearchField.getRefreshButtonTooltip();
			}
	
			var value = event.getParameter("suggestValue");
			if(sap.ui.getCore().getComponent(this.getParent()._sOwnerId).mode == 0){
				var oPanel = sap.ui.getCore().getComponent(this.getParent()._sOwnerId).oPanel;
				$.each(oPanel.getContent(),function(i,n){
					if(value != ""){
						n.removeStyleClass("boldFont");
						n.removeStyleClass("disabled");
						if(n.getProperty("text").toUpperCase().indexOf(value.toUpperCase()) > -1)
							n.addStyleClass("boldFont");
						else
							n.addStyleClass("disabled");
					}else{
						n.removeStyleClass("boldFont");
						n.removeStyleClass("disabled");
					}
				});
				oPanel.rerender();
			}else{
				var filters = [];
				if (value) {
					filters = [	
					     new sap.ui.model.Filter([
					    	 new sap.ui.model.Filter("Theme", function(sText) {return (sText || "").toUpperCase().indexOf(value.toUpperCase()) > -1;}),
			             ],false)
				    ];
				}
				
				if(filters.length){
					this.getBinding('suggestionItems').filter(filters);
					this.suggest();
				}
			}
		}
	});
			
});