sap.ui.jsfragment ("fragment.Conclusion",{ 
	createContent: function (oController ) {
		var oForm =  new sap.ui.layout.form.Form({
			height: "100%",
			layout: new sap.ui.layout.form.GridLayout({}),
			formContainers: [
				new sap.ui.layout.form.FormContainer({
					title: "",
					formElements: [
						new sap.ui.layout.form.FormElement({
							label: new sap.m.Label({text: "Código de conclusión",layoutData: new sap.ui.layout.form.GridElementData({hCells: "3"})	}).addStyleClass("lbAdUsr"),
							fields: [
							    new sap.m.Select({
							    	items:[
							    	       new sap.ui.core.Item({text:"Código conclusión 1"}),
							    	       new sap.ui.core.Item({text:"Código conclusión 2"}),
							    	       new sap.ui.core.Item({text:"Código conclusión 3"}),
							    	       new sap.ui.core.Item({text:"Código conclusión 4"}),
							    	       new sap.ui.core.Item({text:"Código conclusión 5"})
							    	]
							    })    	
							]
						}),
						new sap.ui.layout.form.FormElement({
							label: new sap.m.Label({text: "Incidencia",layoutData: new sap.ui.layout.form.GridElementData({hCells: "3"})	}).addStyleClass("lbAdUsr"),
							fields: [
							    new sap.m.CheckBox({ 
							    	select: function(){
							    		if(this.selected){
							    			this.selected = false;
							    			this.getParent().getParent().getAggregation("formElements")[2].getFields()[0].setEnabled(false);
							    			this.getParent().getParent().getAggregation("formElements")[3].getFields()[0].setEnabled(false);
							    			this.getParent().getParent().getAggregation("formElements")[4].getFields()[0].setEditable(false);
							    			this.getParent().getParent().getAggregation("formElements")[5].getFields()[0].setEditable(false);
							    		}else{
							    			this.selected = true;
							    			this.getParent().getParent().getAggregation("formElements")[2].getFields()[0].setEnabled(true);
							    			this.getParent().getParent().getAggregation("formElements")[3].getFields()[0].setEnabled(true);
							    			this.getParent().getParent().getAggregation("formElements")[4].getFields()[0].setEditable(true);
							    			this.getParent().getParent().getAggregation("formElements")[5].getFields()[0].setEditable(true);
							    		}
							    		
							    	}
								})       	
							]
						}),
						new sap.ui.layout.form.FormElement({
							label: new sap.m.Label({text: "Código de incidencia",layoutData: new sap.ui.layout.form.GridElementData({hCells: "3"})	}).addStyleClass("lbAdUsr"),
							fields: [
							    new sap.m.Select({
							    	enabled:false,
							    	items:[
							    	       new sap.ui.core.Item({text:"Código incidencia 1"}),
							    	       new sap.ui.core.Item({text:"Código incidencia 2"}),
							    	       new sap.ui.core.Item({text:"Código incidencia 3"}),
							    	       new sap.ui.core.Item({text:"Código incidencia 4"}),
							    	       new sap.ui.core.Item({text:"Código incidencia 5"})
							    	]
							    })    	
							]
						}),
						new sap.ui.layout.form.FormElement({
							label: new sap.m.Label({text: "Final",layoutData: new sap.ui.layout.form.GridElementData({hCells: "3"})	}).addStyleClass("lbAdUsr"),
							fields: [
							    new sap.m.Select({
							    	enabled:false,
							    	items:[
							    	       new sap.ui.core.Item({text:"Llamada"}),
							    	       new sap.ui.core.Item({text:"Mail"}),
							    	       new sap.ui.core.Item({text:"Informe"})
							    	]
							    })    	
							]
						}),
						new sap.ui.layout.form.FormElement({
							label: new sap.m.Label({text: "Importe",layoutData: new sap.ui.layout.form.GridElementData({hCells: "3"})	}).addStyleClass("lbAdUsr"),
							fields: [
							    	    new sap.m.Input({value: "", placeholder: "Importe",editable: false, type:sap.m.InputType.Number, required: true, layoutData: new sap.ui.layout.form.GridElementData({hCells: "auto"})})   	
							]
						}),
						new sap.ui.layout.form.FormElement({
							label: new sap.m.Label({text: "Conclusión",layoutData: new sap.ui.layout.form.GridElementData({hCells: "3"})	}).addStyleClass("lbAdUsr"),
							fields: [
							    	    new sap.m.TextArea({rows:4, editable:false})   	
							]
						})
					]
				})	
			]
		});
		
		return oForm; 
	} 
});