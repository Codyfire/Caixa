sap.ui.jsfragment ("fragment.ComentarioMasAdjunto",{ 
	createContent: function (oController) {
		var oForm =  new sap.ui.layout.form.Form({
			height: "100%",
			layout: new sap.ui.layout.form.GridLayout({}),
			formContainers: [
				new sap.ui.layout.form.FormContainer({
					title: "",
					formElements: [
						new sap.ui.layout.form.FormElement({
							fields: [
							    new sap.m.Text({ 
									text: planesAccionUtils.oBundle.getText("comentAutoOblig"),  
								})
							         	
							]
						}),
						new sap.ui.layout.form.FormElement({
							label: new sap.m.Label({text: planesAccionUtils.oBundle.getText("comentario"),layoutData: new sap.ui.layout.form.GridElementData({hCells: "3"})	}).addStyleClass("lbAdUsr"),
							fields: [
							    new sap.m.TextArea({ 
									rows:5,  
								})
							         	
							]
						}),
						
					]
				})	
			]
		});
		
		var oItemTemplate = new sap.m.UploadCollectionItem({
			enableEdit : false,
			enableDelete : true,
			visibleEdit : false,
			visibleDelete : true,
			fileName : "{Name}",
			//fileSize : "{fileSize}",
			mimeType : "{MimeType}",
			//thumbnailUrl : "{thumbnailUrl}",
			uploadedDate : "{CreateTime}",
			url : "{Url}",
			customData: [new sap.ui.core.CustomData({key : "{DeleteUrl}"})],
		});
		
		// Se rellena el uploader
		var uploader = new sap.m.UploadCollection("anexosTypeDialog",{
	        multiple : false,
			items : {
				path : "/",
				template : oItemTemplate
			},
			fileDeleted: oController.onFileDeleted,
			change: oController.onSelectFile,
			instantUpload: false,
			beforeUploadStarts: oController.onBeforeUploadStarts,
			uploadComplete: oController.onUploadComplete,
			uploadTerminated: oController.onUploadTerminated,
		}).setModel(new sap.ui.model.json.JSONModel());
		
		var oVBox = new sap.m.VBox({
			width: "100%",
			height: "100%",
			items:[
			     oForm,
			     uploader
			]
		})
		return oVBox; 
	} 
});