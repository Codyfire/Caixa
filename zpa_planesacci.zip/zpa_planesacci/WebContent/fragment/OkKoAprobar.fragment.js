sap.ui.jsfragment ("fragment.OkKoAprobar",{ 
	createContent: function (oController ) {
		var oForm =  new sap.ui.layout.form.Form({
			height: "100%",
			layout: new sap.ui.layout.form.GridLayout({}),
			formContainers: [
				new sap.ui.layout.form.FormContainer({
					title: "",
					formElements: [
						new sap.ui.layout.form.FormElement({
							fields: [
							    new sap.m.Text({ 
									text: planesAccionUtils.oBundle.getText("comentObligAcc"),  
								})
							         	
							]
						}),
						new sap.ui.layout.form.FormElement({
							label: new sap.m.Label({text: planesAccionUtils.oBundle.getText("comentario"),layoutData: new sap.ui.layout.form.GridElementData({hCells: "3"})	}).addStyleClass("lbAdUsr"),
							fields: [
							    new sap.m.TextArea({ 
									rows:5,  
								})
							         	
							]
						}),
						new sap.ui.layout.form.FormElement({
							label: new sap.m.Label({text: planesAccionUtils.oBundle.getText("verificar"),required: true, layoutData: new sap.ui.layout.form.GridElementData({hCells: "3"})	}).addStyleClass("lbAdUsr"),
							fields: [
								new sap.m.Select({
								    items:[new sap.ui.core.Item("ok",{text: planesAccionUtils.oBundle.getText("ok")}),new sap.ui.core.Item("ko", {text: planesAccionUtils.oBundle.getText("nok")})],
								    forceSelection:false,
								    required: true
								})   	
							]
						})
					]
				})	
			]
		});
		return oForm; 
	} 
});