jQuery.sap.declare("visualizarColumnasComponentPlanes.Component");
jQuery.sap.require("sap.ui.core.UIComponent");

sap.ui.core.UIComponent.extend("visualizarColumnasComponentPlanes.Component", {	
	getControllerName : function() {
		return "visualizarColumnasComponentPlanes.visualizadorColumnsPlanesControler";
	},
	
	init : function () {
		// define variable for control initial loading handling
	    this._bInitialLoading = true;
		// execute standard control method
	    sap.ui.core.UIComponent.prototype.init.apply(this,arguments);
	},
	
	createContent: function(){
		var oComp = this;
		var that = this;
		this.oSelectDialog = new sap.m.SelectDialog({
			multiSelect:true,
			title: planesAccionUtils.oBundle.getText("col_view"), 
			rememberSelections:true,
			cancel: function(oEvent){
				sap.ui.getCore().getComponent(that.sId).destroy();
			}
		});
		
		// Para evitar que la lista interna sea del estilo "Growing"
		this.oSelectDialog.mAggregations._dialog.mAggregations.content[1].mProperties.growing = false;
		this.oSelectDialog.mAggregations._dialog.mAggregations.content[1].mProperties.growingScrollToLoad = false;
		//Para ocultar el buscador
		this.oSelectDialog.mAggregations._dialog.mAggregations.subHeader.setVisible(false);
	},
	
	addAllItems: function(table){
		
		var oSelectDialog = this.oSelectDialog;
		var that = this;
		this.table = table;
		
		oSelectDialog.addItem(
			new sap.m.StandardListItem({
				title: planesAccionUtils.oBundle.getText("select_all"),
				type: "Inactive",
				selected: false,
				customData: [
                    new sap.ui.core.CustomData({
							key : "multiselector",
							value : "all"
                    })
               ],
			})
		);
		
		var funct = function(oEvent){
			
			var itemPress = oEvent.getParameter('listItem');
			var items = this.getItems();
			
			if(itemPress.getAggregation("customData").length > 0){
				$.each(items, function(i,n) { if(i>0) {n.setSelected(itemPress.isSelected()); } });
			}
		}
		
		oSelectDialog.getAggregation("_dialog").getContent()[1].attachSelect(funct);
		
		var table;
		$.each(table.getColumns(),function(i,n){
			if(n.getVisible())
				oSelectDialog.addItem(
					new sap.m.StandardListItem({
						title: n.getAggregation("header").getProperty("text"),
						type: "Inactive",
						selected:true
					})	
				);
			else
				oSelectDialog.addItem(
					new sap.m.StandardListItem({
						title: n.getAggregation("header").getProperty("text"),
						type: "Inactive"
					})	
				);
		});
	},
	
	openDialog: function(){
		this.oSelectDialog.open();
	},
	
	mirarRepetit: function(array, item){
		var trobat = false
		if(item == undefined || item == "" || item == null) trobat = true;
		$.each(array, function(i,n){
			if(array[i].mProperties.text.toLowerCase() == item.toLowerCase()){
				trobat = true;
			}	
		});
		return trobat;
	},
	
	addConfirmFunction: function(funct){
		
		this.oSelectDialog.attachConfirm(funct);
	}	
});
