sap.ui.jsview("appDataQ.view.PlanesAccionDetailScreen", {
	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf zportalaudit.view.AdminListasNavContainer
	*/ 
	getControllerName : function() {
		return "appDataQ.controller.PlanesAccionDetailScreen";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf zportalaudit.view.AdminListasNavContainer
	*/ 
	createContent : function(oController) {
		var oSelScreenView = byId("selScreen");
		var fields = this.oViewData;
		var objectContent = zpa.grcaud.createDynamicFields(fields,oController,-1);
		
		this.oForm = new sap.ui.layout.form.Form({
			editable: true,
			height: "100%",
			layout: new sap.ui.layout.form.GridLayout({}),
			formContainers: [
				new sap.ui.layout.form.FormContainer({
					formElements: [objectContent.content]
				}),
			]
		}).addStyleClass("planesFormDataQ");
		
 		return new sap.m.Page({
			title: "Acción: " + zpa.grcaud.dataqmodel.getModel("actionPlanModel").oData.results[2].ValueOrig,
 			showHeader: true,
 			showNavButton: true,
			navButtonPress: [oController.doBack, oController],
			content: [this.oForm],
 			footer: new sap.m.Bar({contentRight: new sap.m.Button({text: "Guardar", press: [oController.onSave, oController]})})
		});
	}
});