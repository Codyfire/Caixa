sap.ui.jsview("appDataQ.view.SelScreen", {
	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf zportalaudit.view.AdminListasNavContainer
	*/ 
	getControllerName : function() {
		return "appDataQ.controller.SelScreen";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf zportalaudit.view.AdminListasNavContainer
	*/ 
	createContent : function(oController) {
		var that = this;
		// Checks de selección
		var aChecks = [];
		
		/*INI PPM100076335 - Pestaña clasificacionIE 01/08/2022*/
		var checksAux = zpa.grcaud.Constants.SelChecks;
		
		/*FIN PPM100076335 - Pestaña clasificacionIE 01/08/2022*/
		
		$.each(checksAux,function(i,n) {
			aChecks.push(new sap.m.CheckBox({
				enabled : false,
				text : n.string,
				select : function() {
					if(!this.getSelected()) {
						that.oForm.getFormContainers()[1].getFormElements()[0].getFields()[0].setSelected(false);
					}else{
						var count = 0;
						for(var y = 0; y < that.aChecks.length; y++){
							if(that.aChecks[y].getSelected()){
								count++;
							}
						}
						if(count === aChecks.length){
							that.oForm.getFormContainers()[1].getFormElements()[0].getFields()[0].setSelected(true);
						}
					}
				}
			}));
			
		});
		
		/*INI PPM100076335 - Pestaña clasificacionIE 01/08/2022*/
		/*$.each(aChecks, function(i,checks)
		{
			if(checks.mProperties.text === "Info") checks.mProperties.enabled = true;
		});*/
		/*FIN PPM100076335 - Pestaña clasificacionIE 01/08/2022*/
		
		
		this.aChecks = aChecks;
		
		this.oLayout = new sap.ui.layout.form.ResponsiveGridLayout();

		this.oForm = new sap.ui.layout.form.Form({
			editable: true,
			layout: this.oLayout,
			formContainers: [
				new sap.ui.layout.form.FormContainer({
					title: "Búsqueda",
					formElements: [
						new sap.ui.layout.form.FormElement({
							label: "Auditoría",
							fields: [
								new sap.m.VBox({
									items:[
										this.oSearch = new sap.m.SearchField({
											editable: true,
											placeholder : "Id",
											liveChange: function(){
												oController.onResetScreen();
												that.oSearchFinding.setValue("");
												that.oSearchPlAccion.setValue("");
											},
											search : [oController.onAuditSearch, oController]
										}),this.oInfoAuditMessageStrip = new sap.m.MessageStrip({visible:false}).addStyleClass("MessageStrip")
									]
								})
							]
						}),
						new sap.ui.layout.form.FormElement({
							label: "Finding",
							fields: [
								new sap.m.VBox({
									items:[
										this.oSearchFinding = new sap.m.SearchField({
											editable: true,
											placeholder : "Id",
											liveChange: function(){
												oController.onResetScreen();
												that.oSearch.setValue("");
												that.oSearchPlAccion.setValue("");
											},
											search : [oController.onFindingSearch, oController]
										}),this.oInfoFindingMessageStrip = new sap.m.MessageStrip({visible:false}).addStyleClass("MessageStrip")
									]
								})
							]
						}),
						new sap.ui.layout.form.FormElement({
							label: "Plan de acción",
							fields: [
								new sap.m.VBox({
									items:[
										this.oSearchPlAccion = new sap.m.SearchField({
											editable: true,
											placeholder : "Id",
											liveChange: function(){
												oController.onResetScreen();
												that.oSearchFinding.setValue("");
												that.oSearch.setValue("");
											},
											search : [oController.onPlAccionSearch, oController]
										}),this.oInfoPlAccionMessageStrip = new sap.m.MessageStrip({visible:false}).addStyleClass("MessageStrip")
									]
								})
							]
						})
					]
				}),
				new sap.ui.layout.form.FormContainer({
					title: "Pestañas a editar",
					formElements: [
						new sap.ui.layout.form.FormElement({
							label: "",
							fields: [
								this.oCheckAll = new sap.m.CheckBox({
									enabled : false, 
									text : "Todas",
									select: function(oEvent){
										if(this.getProperty("selected"))
											$.each(byId("selScreen").aChecks,function(i,n){n.setSelected(true)})
										else
											$.each(byId("selScreen").aChecks,function(i,n){n.setSelected(false)})
									}
								})
							]	
						})
					]
				})
			]
		});
		
		
		this.oPage = new sap.m.Page({
			showNavButton:false,
			title: "Data Quality",
			content:[this.oForm],
			footer: new sap.m.Bar({
				contentRight: new sap.m.Button({
					text: "Editar",
					press: [oController.onEdit, oController]
				})
			})
		});
		
		return this.oPage;
	}
});