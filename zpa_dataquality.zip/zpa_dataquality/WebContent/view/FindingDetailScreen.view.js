sap.ui.jsview("appDataQ.view.FindingDetailScreen", {
	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf zportalaudit.view.AdminListasNavContainer
	*/ 
	getControllerName : function() {
		return "appDataQ.controller.FindingDetailScreen";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf zportalaudit.view.AdminListasNavContainer
	*/ 
	createContent : function(oController) {
		var that = this;
		var oSelScreenView = byId("selScreen");
		var fields = this.oViewData;
		
		this.aForms = [];
		this.aTables = [];
//		$.each($.grep(oSelScreenView.aChecks,function(check,index){return check.getSelected()}),function(i,n){
//			var oContent = zpa.grcaud.createDynamicFields(fields, oController, tabStringByCheck(n.getText()));
//			that.aForms.push(
//				new sap.ui.layout.form.Form({
//					editable: false,
//					height: "100%",
//					layout: new sap.ui.layout.form.GridLayout({}),
//					formContainers: [
//						new sap.ui.layout.form.FormContainer({
//							formElements: [oContent.content]
//						})	
//					]
//				})
//			);
//			that.aTables.push(oContent.tables);
//			if(n.getText() === oSelScreenView.aChecks[2].getText()){
//				that.work = oContent.work;
//			}
//		});
		
		
		var objectContent = zpa.grcaud.createDynamicFields(fields,oController,-1);
		
		var title1 = objectContent.content[0].splice(0, 1);
		var title2 = objectContent.content[1].splice(0, 1);
		
		
		this.aForms.push(new sap.ui.layout.form.Form({
			editable: true,
			height: "100%",
			layout: new sap.ui.layout.form.ResponsiveGridLayout({}),
			formContainers: [
				new sap.ui.layout.form.FormContainer({
					title: title1,
					formElements: [objectContent.content[0]]
				}),
				new sap.ui.layout.form.FormContainer({
					title: title2,
					formElements: [objectContent.content[1]]
				}),
				new sap.ui.layout.form.FormContainer({
					title: new sap.ui.core.Title({level: "H4", text: "Recomendación"}),
					formElements: [objectContent.content[2]]
				})
			]
		}));
		
		this.aTables.push(objectContent.tables);
		
		var oLeftColumnListItem = new sap.m.ColumnListItem({  
			type : "Inactive",  
            cells : [ 
			   new sap.m.Text({  
				  text : "{ID}"  
			   }),
               new sap.m.Text({  
                  text : "{Title}"  
               }),               
               new sap.ui.core.Icon({  
            	  size: "17px",
            	  color:"#e52929",
            	  src:"sap-icon://sys-cancel",
            	  tooltip: "Eliminar",
            	  press: function(oEvent){
                	  oController.leftToRightRisk.call(oController, oEvent);
                  }
               })
            ]
        });
		
		var oRightColumnListItem = new sap.m.ColumnListItem({  
			type : "Inactive",  
            cells : [ 
			   new sap.m.Text({  
				  text : "{ID}"  
			   }),
               new sap.m.Text({  
                  text : "{Title}"  
               }),  
               new sap.ui.core.Icon({  
            	  size: "17px",
            	  color:"#008a3b",
                  src:"sap-icon://add",
                  tooltip: "Añadir",
                  press: function(oEvent){
                	  oController.rightToLeftRisk.call(oController, oEvent);
                  }
               })
            ]
        });
		

		this.oLeftList = new sap.m.Table({
			headerText:"Riesgos",
			columns:[
				new sap.m.Column({  
                    hAlign : "Left",  
                    header : new sap.m.Label({  
                             	text : "ID",
                             	design: sap.m.LabelDesign.Bold
                    })  
				}), 
				new sap.m.Column({  
                    hAlign : "Left",  
                    header : new sap.m.Label({  
                             	text : "Título",
                             	design: sap.m.LabelDesign.Bold
                    })  
				}),
				new sap.m.Column({  
                    hAlign : "Center",  
                    header : new sap.m.Label({  
                             	text : "",
                             	design: sap.m.LabelDesign.Bold
                    })  
				})
			],
		}).bindAggregation("items","/results", oLeftColumnListItem).addStyleClass("tablePadding");
		
		
		this.oRightList = new sap.m.Table({
			headerToolbar: new sap.m.Toolbar({content:[new sap.m.Text({text: "Añadir Riesgo"}).addStyleClass("risksTitle"), new sap.m.ToolbarSpacer({}), new sap.m.SearchField({search: function(oEvent){oController.onSearchRisk.call(oController, oEvent)}})]}),
			columns:[
				new sap.m.Column({  
                    hAlign : "Left",  
                    header : new sap.m.Label({  
                             	text : "ID",
                             	design: sap.m.LabelDesign.Bold
                    })  
				}), 
				new sap.m.Column({  
                    hAlign : "Left",  
                    header : new sap.m.Label({  
                             	text : "Título",
                             	design: sap.m.LabelDesign.Bold
                    })  
				}),
				new sap.m.Column({  
                    hAlign : "Center",  
                    header : new sap.m.Label({  
                             	text : "",
                             	design: sap.m.LabelDesign.Bold
                    })  
				})
			],
			growing: true,
			growingScrollToLoad: true,
			growingThreshold: 20,
		}).bindAggregation("items","/results", oRightColumnListItem).addStyleClass("tablePadding");
		
		
		this.oRightPage = new sap.m.Page({showHeader: false, enableScrolling: true, content: [this.oRightList]});
		
		this.oDynamicSideContent = new sap.ui.layout.DynamicSideContent({
			equalSplit: true,
			mainContent:[this.oLeftList],
			sideContent: [this.oRightPage]
		});
		
		
		this.oIconTabBar = new sap.m.IconTabBar({
			expanded: true,
			expandable: false,
			stretchContentHeight: true,
			backgroundDesign: "Transparent",
		});
		
 		return new sap.m.Page({
			title: "Finding: " + zpa.grcaud.dataqmodel.getModel("findingModel").getData().results[3].ValueOrig,
 			showHeader: true,
 			showNavButton: true,
			navButtonPress: [oController.doBack, oController],
//			content: [this.oForm, objectContent.tables],
			content: [this.oIconTabBar],
 			footer: new sap.m.Bar({contentRight: new sap.m.Button({text: "Guardar", press: [oController.doSave, oController]})})
		});
	}
});