sap.ui.jsview("appDataQ.view.ClasificacionIEScreen", {
	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf zportalaudit.view.AdminListasNavContainer
	*/ 
	getControllerName : function() {
		return "appDataQ.controller.ClasificacionIEScreen";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf zportalaudit.view.AdminListasNavContainer
	*/ 
	createContent : function(oController) {
		var oSelScreenView = byId("selScreen");
		var fields = this.oViewData;
		var objectContent = zpa.grcaud.createDynamicFields(fields,oController,-1);
		
		this.oLabelEmp = new sap.m.Label({
			text : "Empleado:",
			required : false,
			tooltip: "Empleado",
			textAlign : sap.ui.core.TextAlign.Right,
		}).addStyleClass("formLabel");
		
		
 		return new sap.m.Page({
			title: "Clasificación IE: ",
 			showHeader: true,
 			showNavButton: true,
			navButtonPress: [oController.doBack, oController],
			content: [this.oLabelEmp],
 			footer: new sap.m.Bar({contentRight: new sap.m.Button({text: "Guardar", press: [oController.onSave, oController]})})
		});
	}
});