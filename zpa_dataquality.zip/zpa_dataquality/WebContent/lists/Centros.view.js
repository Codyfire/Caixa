sap.ui.jsview("lists.Centros", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf zportalaudit.view.Centros
	*/ 
	getControllerName : function() {
		return "lists.Centros";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf zportalaudit.view.Centros
	*/ 
	createContent : function(oController) {
		
		this.hBox = new sap.m.HBox({
			items: [
			    new sap.ui.core.Icon({  
	                src : "sap-icon://sys-minus",  
	                size : "15px",  
	                color : "#ff0000",
	                width : "15px", 
	                press: function(oEvent){
		                var bindingContext = oEvent.getSource().getBindingContext().sPath;
		                //var UserId = sap.ui.getCore().getModel("centros").getProperty(bindingContext).UserIdResp1;
		                var viewName = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getId();
		                var UserId = sap.ui.getCore().byId(viewName).table.getModel().getProperty(bindingContext).UserIdResp1;
//		                sap.ui.getCore().getModel("centros").getProperty(bindingContext).DelUserResp1 = "true";
//		                oEvent.getSource().getParent().getAggregation("items")[1].addStyleClass("lineThrough");
		                updateDelUserResp1(UserId,"true",viewName);
	                }
	            }),
			    new sap.m.Text({     
			    	customData:  new sap.ui.core.CustomData({key:"{UserIdResp1}"}),
					layoutData: new sap.m.FlexItemData({
						alignSelf: sap.m.FlexAlignSelf.Center,styleClass: "marginRight"})
					}).bindProperty("text",{
					    parts:[{path:"FullNameResp1"},
					           {path:"DelUserResp1"}],
					    formatter: 
						    function(FullNameResp1,DelUserResp1){
						    	if(FullNameResp1 != null && FullNameResp1 != undefined && FullNameResp1 != "") {
						    		if(DelUserResp1 == "false") {
						    			this.getParent().getAggregation("items")[1].removeStyleClass("lineThrough");
						    		}else if (DelUserResp1 == "true") {
						    			this.getParent().getAggregation("items")[1].addStyleClass("lineThrough");
						    		}
						    		this.getParent().setVisible(true);
						    		return FullNameResp1;
						    	}else {
						    		this.getParent().setVisible(false);
						    		return "";
						    	}
						     }
					     }),
			       new sap.ui.core.Icon({  
		                src : "sap-icon://sys-add",  
		                size : "15px",  
		                color : "#007833",   
		                width : "15px", 
		                press: function(oEvent){
			                var bindingContext = oEvent.getSource().getBindingContext().sPath;
			                //var UserId = sap.ui.getCore().getModel("centros").getProperty(bindingContext).UserIdResp1;
			                var viewName = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getId();
			                var UserId = sap.ui.getCore().byId(viewName).table.getModel().getProperty(bindingContext).UserIdResp1;
//			                sap.ui.getCore().getModel("centros").getProperty(bindingContext).DelUserResp1 = "false";
//			                oEvent.getSource().getParent().getAggregation("items")[1].removeStyleClass("lineThrough");
			                updateDelUserResp1(UserId,"false", viewName);
		                }
		            })
				]
		});

		
		this.hBox2 = new sap.m.HBox({
			items: [
			    new sap.ui.core.Icon({  
	                src : "sap-icon://sys-minus",  
	                size : "15px",  
	                color : "#ff0000",
	                width : "15px", 
	                press: function(oEvent){
	                var bindingContext = oEvent.getSource().getBindingContext().sPath;
	                //var UserId = sap.ui.getCore().getModel("centros").getProperty(bindingContext).UserIdResp2;
	                var viewName = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getId();
	                var UserId = sap.ui.getCore().byId(viewName).table.getModel().getProperty(bindingContext).UserIdResp2;
//	                sap.ui.getCore().getModel("centros").getProperty(bindingContext).DelUserResp2 = "true";
//	                oEvent.getSource().getParent().getAggregation("items")[1].addStyleClass("lineThrough");
	                updateDelUserResp2(UserId,"true", viewName);
	                }
	            }),
			    new sap.m.Text({    
			    	customData:  new sap.ui.core.CustomData({key:"{UserIdResp2}"}),
					layoutData: new sap.m.FlexItemData({
						alignSelf: sap.m.FlexAlignSelf.Center,styleClass: "marginRight"})
					}).bindProperty("text",{
					    parts:[{path:"FullNameResp2"},
					           {path:"DelUserResp2"}],
					    formatter: 
						    function(FullNameResp2,DelUserResp2){
						    	if(FullNameResp2 != null && FullNameResp2 != undefined && FullNameResp2 != "") {
						    		if(DelUserResp2 == "false") {
						    			this.getParent().getAggregation("items")[1].removeStyleClass("lineThrough");
						    		}else if (DelUserResp2 == "true") {
						    			this.getParent().getAggregation("items")[1].addStyleClass("lineThrough");
						    		}
						    		this.getParent().setVisible(true);
						    		return FullNameResp2;
						    	}else{
						    		this.getParent().setVisible(false);
						    		return "";
						    	}
						     }
					     }),
			       new sap.ui.core.Icon({  
		                src : "sap-icon://sys-add",  
		                size : "15px",  
		                color : "#007833",   
		                width : "15px", 
		                press: function(oEvent){
			                var bindingContext = oEvent.getSource().getBindingContext().sPath;
			                //var UserId = sap.ui.getCore().getModel("centros").getProperty(bindingContext).UserIdResp2;
			                var viewName = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getId();
			                var UserId = sap.ui.getCore().byId(viewName).table.getModel().getProperty(bindingContext).UserIdResp2;
//			                sap.ui.getCore().getModel("centros").getProperty(bindingContext).DelUserResp2 = "false";
//			                oEvent.getSource().getParent().getAggregation("items")[1].removeStyleClass("lineThrough");
			                updateDelUserResp2(UserId,"false", viewName);
		                }
		            })
				]
		});
		
			
		
		var hBox3 = new sap.m.HBox({
			items: [
			    oText =    new sap.m.Text({
			        	//text: "{DepartmentName}",
			    	}),
			        ]
		   });
		 
         oText.bindProperty("text", {
             parts: [
                     {path: "Company"},
                     {path: "Department"},
                     {path: "DepartmentName" },
                     
                     
             ],
             formatter: function(Company, Department, DepartmentName) {
                 return Company + Department + " " + DepartmentName
             }
         });
		
		var oDeleteButton = new sap.ui.core.Icon({
			   //type:sap.m.ButtonType.Reject,
			   src: "sap-icon://sys-cancel",
			   press: [function(oEvent){
				   var bindingContext = oEvent.getSource().getBindingContext().sPath
				   var index = bindingContext.substr(9);						
				   var dialog = new sap.m.Dialog({
						title: sap.hpa.grcaud.enh_oBundle.getText("warning"),
						type: 'Message',
							content: new sap.m.Text({
								text: sap.hpa.grcaud.enh_oBundle.getText("deleting_hierarchy")
							}),
						state: sap.ui.core.ValueState.Warning,
						beginButton: new sap.m.Button({
							text: 'OK',
							press: [function (oEvent) {
								
								//Elimino la persona del model local
								//var oModel = sap.ui.getCore().getModel("centros");
								var table = oController.getView().table;
								var oModel = table.getModel();
								var aEntries = oModel.getData().centros;
								delete aEntries[index];
								//aEntries.splice(index,1);
								oModel.setData({
									centros : aEntries
								});
								table.setModel(oModel);
								table.bindRows("/centros");
								table.setVisibleRowCount(10);
								dialog.close();
							}, oController]
						}),
						endButton: new sap.m.Button({
							text: sap.hpa.grcaud.enh_oBundle.getText("cancel"),
							press: function () {
								dialog.destroy();
							}
						}),
						afterClose: function() {
							dialog.destroy();
						}
					});
				   dialog.open();
			   },oController]
		   }).addStyleClass("sapMTokenIcon");
		//Create an instance of the table control
		
		var oTable = new sap.ui.table.TreeTable(this.createId("distList"), {
			columns: [
				new sap.ui.table.Column({label: sap.hpa.grcaud.enh_oBundle.getText("name"),template: hBox3, width: "30%"}),
				new sap.ui.table.Column({label: sap.hpa.grcaud.enh_oBundle.getText("responsable"), template: this.hBox, width: "30%"}),
				new sap.ui.table.Column({label: sap.hpa.grcaud.enh_oBundle.getText("responsable2"), template: this.hBox2, width: "30%"}),
				new sap.ui.table.Column({template: oDeleteButton, width: "50px", hAlign:"Center"})
			],
			visibleRowCount: 10,
			selectionMode: sap.ui.table.SelectionMode.Single,
			enableColumnReordering: false,
			expandFirstLevel: false,
			showHeaderIcons: true,
			toggleOpenState: function(oEvent,reorganizarEstilosTabla) {
				var iRowIndex = oEvent.getParameter("rowIndex");
				var oRowContext = oEvent.getParameter("rowContext");
				var bExpanded = oEvent.getParameter("expanded");
				//Un thread independent
//				setTimeout(function(){ refrescarEstilsTaula();}, 100);;
				
			},
			onAfterRendering: function(){
				refrescarEstilsTaula(this);
				this.setVisibleRowCount(10);
			}
		});
		oTable.setVisibleRowCount(10);
		
//		oTable.expandToLevel(5);

		//Button to demonstrate collapse and expand feature
		var oBtn = new sap.m.Button({
						text: "Toggle",
						press: function() {
							var iSelectedIndex = oTable.getSelectedIndex();
							if (iSelectedIndex > -1) {
								if (oTable.isExpanded(iSelectedIndex)) {
									oTable.collapse(iSelectedIndex);
								} else {
									oTable.expand(iSelectedIndex);
								}
							}
						}
					});
		
		oTable.setToolbar(
			new sap.m.Toolbar({
				content: [
				    new sap.m.Label({text:sap.hpa.grcaud.enh_oBundle.getText("dest_center"), design: sap.m.LabelDesign.Bold}),
                    new sap.m.ToolbarSpacer(),
                    //oBtn, 
                    new sap.m.ToolbarSpacer(),
                    new sap.m.Button({
                	   icon: "sap-icon://expand", 
                	   press: function() {
                		   if(this.toggle) {
                			   oTable.collapseAll();
                			   this.setIcon("sap-icon://expand");
                		   } else {
                			   oTable.expandToLevel(5);
                			   this.setIcon("sap-icon://collapse");
                		   }
                		   this.toggle = !this.toggle;
                	   },
                	   addCustomData: [new sap.ui.core.CustomData({ key : "toggle", value : false })]
                    }),
                    new sap.m.Button({icon: "sap-icon://add", press: [oController.onAdd, oController]}),
                ]
			})
		);
		
		
		this.table = oTable;

		return new sap.m.VBox({
			height: "100%",
			items: [this.table]
		});
	},

});