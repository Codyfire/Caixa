jQuery.sap.registerModulePath("lists", oShell.getUI5Path()+"lists");
jQuery.sap.require("lists.listsUtils");
jQuery.sap.require("lists.encodingUtils");
jQuery.sap.require("lists.oDataGenerator");
jQuery.sap.require("lists.searchComponent.Component");
jQuery.sap.require("lists.listComponent.Component");

sap.hpa.grcaud.Utility.require({
	modName : "lists.ListView",
	type : "view"
});
sap.hpa.grcaud.Utility.require({
	modName : "lists.ListView",
	type : "controller"
});
sap.hpa.grcaud.Utility.require({
	modName : "lists.Personas",
	type : "view"
});
sap.hpa.grcaud.Utility.require({
	modName : "lists.Personas",
	type : "controller"
});
sap.hpa.grcaud.Utility.require({
	modName : "lists.Centros",
	type : "view"
});
sap.hpa.grcaud.Utility.require({
	modName : "lists.Centros",
	type : "controller"
});
sap.hpa.grcaud.Utility.require({
	modName : "lists.AdminListasDetail",
	type : "view"
});
sap.hpa.grcaud.Utility.require({
	modName : "lists.AdminListasDetail",
	type : "controller"
});
jQuery.sap.includeStyleSheet( oShell.getUI5Path()+"grcaud/resources/js/enhancements/lists/styleLists.css");

sap.ui.jsview("lists.ListView", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf zportalaudit.view.ListView
	*/ 
	getControllerName : function() {
		return "lists.ListView";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf zportalaudit.view.ListView
	*/ 
	createContent : function(oController) {
		
		var oComp  = sap.ui.getCore().createComponent({
			id: "component2",
	        name: "lists.listComponent"
	    });
		
		this.oComp = oComp;
		
		// Se crea un contenedor para el componente
		var oCompCont = new sap.ui.core.ComponentContainer({
			 component: oComp,
		});
		
		this.oCompCont = oCompCont;
		
		return oCompCont;
		
// 		var vBox = new sap.m.VBox({
//			height: "100%",
//			items: [
//			        new sap.m.Panel({
//			        	headerText: "Lista de Distribución",
//			        	headerToolbar: new sap.m.Toolbar({
//							content:
//								[
//							         new sap.m.Label({text:"Lista de Distribucion", design: sap.m.LabelDesign.Bold}),
//									 new sap.m.ToolbarSpacer(),
//									 //new sap.m.Button({icon: "sap-icon://edit", press: oController.onEditDist}),
//									 new sap.m.Button({icon: "sap-icon://add", press: [oController.onAddDist, oController]}),
//									 new sap.m.Button({icon: "sap-icon://delete", press: oController.onDeleteDist}),
//								 ]
//						}),
//			        	expandable: true,
//			        	expanded: true,
//			        	width: "auto",
//			        	content: [sap.ui.view({id:"distListView", viewName:"grcaud.lists.AdminListasDetail", type:sap.ui.core.mvc.ViewType.JS})]
//			        }),
//			        new sap.m.Panel({
//			        	headerText: "Lista de Acceso",
//			        	headerToolbar: new sap.m.Toolbar({
//							content:
//								[
//							         new sap.m.Label({text:"Lista de Acceso", design: sap.m.LabelDesign.Bold}),
//									 new sap.m.ToolbarSpacer(),
//									 //new sap.m.Button({icon: "sap-icon://edit", press: oController.onEditAcc}),
//									 new sap.m.Button({icon: "sap-icon://add", press: [oController.onAddAcc, oController]}),
//									 new sap.m.Button({icon: "sap-icon://delete", press: oController.onDeleteAcc}),
//								 ]
//						}),
//			        	expandable: true,
//			        	expanded: false,
//			        	width: "auto",
//			        	content: [sap.ui.view({id:"accListView", viewName:"grcaud.lists.AdminListasDetail", type:sap.ui.core.mvc.ViewType.JS})]
//			        }),
//			]
//		});
// 		
// 		this.vBox = vBox;
// 		
// 		return this.vBox;
	}

});