sap.ui.controller("lists.Centros", {

/**
* Called when a controller is instantiated and its controller controls (if available) are already created.
* Can be used to modify the controller before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf zportalaudit.controller.Centros
*/
//	onInit: function() {
//
//	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's controller is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf zportalaudit.controller.Centros
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the controller has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf zportalaudit.controller.Centros
*/
	onAfterRendering: function() {
		//var table = this.getView().table;
		//setTimeout(function(){ refrescarEstilsTaula(table);}, 1000);
	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf zportalaudit.controller.Centros
*/
//	onExit: function() {
//
//	}

//	Data: function() {
//		
//        var key = sap.ui.getCore().getModel('distList').getData('results').results[0].Key;
//        var keyConverted = "binary'" + convertKey(key) +"'";
//        var url = "/InfoListsSet(" + keyConverted + ")" +"/InfoUsersHierListSet" ;
//	
//		loadCData(url);
//	},
	onAdd: function() {
		var oController = this;
        var url = "/InfoDepartmentsSet" ;
		
		if(sap.ui.getCore().getComponent('searchComponent')) {
			sap.ui.getCore().getComponent('searchComponent').destroy();
		}
		
		var oComp  = sap.ui.getCore().createComponent({
			id: "searchComponent",
	        name: "lists.searchComponent"
	    });
		
		// Función de añadir resultados a las tablas
		var addFunct = function() {
			var selItems = this.getParent().getContent()[1].getSelectedItems();
			
			if(selItems.length == 0) { alert(sap.hpa.grcaud.enh_oBundle.getText("select_option")); }
			else {
				//var bindingContext = selItems[0].getBindingContext().sPath;
				//var id = selItems[0].getAggregation("customData")[0].getValue("Key");
				if(mirarCentrosRepetidos(selItems,oController.getView().getId())){
					//Han inserit algun centre repetit
					var dialog = new sap.m.Dialog({
						title: sap.hpa.grcaud.enh_oBundle.getText("info"),
						type: 'Message',
							content: new sap.m.Text({
								text: sap.hpa.grcaud.enh_oBundle.getText("repeated_hierarchy")
							}),
						beginButton: new sap.m.Button({
							text: sap.hpa.grcaud.enh_oBundle.getText("accept"),
							press: function () {
								dialog.close();
							}
						}),
						endButton: new sap.m.Button({
							text: sap.hpa.grcaud.enh_oBundle.getText("cancel"),
							press: function () {
								dialog.close();
							}
						}),
						afterClose: function() {
							dialog.destroy();
						}
					});
					dialog.open();
				}else{
					$.each(selItems,function(i,n){ 
						var bindingContext = n.getBindingContext().sPath;
						var Company = sap.ui.getCore().getModel('centrosSearch').getProperty(bindingContext).Company;
						var Department = sap.ui.getCore().getModel('centrosSearch').getProperty(bindingContext).Department;
						var TypeHier = "";
						
						var url =  "/GetHierarchy?Company='"+ Company + "'&Department='" + Department+"'" + "'&TypeHier='" + TypeHier+"'";
						loadJerarquia(url, oController.getView().getId());
					});		
					this.getParent().close();
				}
			}};
			
		    //Creo ola funcio a anira al search del search field
		    var addSearchFunct = function(){
		    	//Agafo el valor del serchfield
		    	var text = this.getParent().getContent()[0].getProperty("value");
		    	if (text != ""){
		    	//Preparo els filtres amb els valors
		    	var aFilters = [];
		    		if(tieneNumeros(text))//Si conté numeros es que cerquen per matricula
		    		aFilters.push(new sap.ui.model.Filter("Department",sap.ui.model.FilterOperator.Contains, text));
		    		else
		    			aFilters.push(new sap.ui.model.Filter("DepartmentName",sap.ui.model.FilterOperator.Contains, text));
		    		loadAddData(url, aFilters);
		    	}
		    	
		    }

		// Cabecera, Binding Posiciones, Modo de Lista, Binding Aggregation, Path, Model, AddFunction
		oComp.setupInicial(["Departamento","Centro", "Responsable"], ["{Department}","{DepartmentName}", "{Fullnameresp1}"], "MultiSelect", "", "/results", "centros", addFunct, addSearchFunct);

		// Se crea un contenedor para el componente
		var oCompCont = new sap.ui.core.ComponentContainer({
			 component: oComp,
		});
	}
});