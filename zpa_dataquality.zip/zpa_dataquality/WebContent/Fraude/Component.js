jQuery.sap.require("sap.ui.core.UIComponent");
jQuery.sap.declare("Fraude.Component");
//
sap.ui.define([
	"sap/ui/core/UIComponent"
], function (UIComponent) {
	

	return UIComponent.extend("Fraude.Component", {
		
		init : function () {
			// call the init function of the parent
			UIComponent.prototype.init.apply(this, arguments);
		},
			
		createContent: function(){
			this.oController = sap.ui.controller("appDataQ.Fraude.Fraude")

			var that = this;
			
			/***
			* Tabla Empleados -> Empleado - Resolucion
			***/
				// Empleado
			
				this.oLabelEmp = new sap.m.Label({
					text : "Empleado:",
					required : false,
					tooltip: "Empleado",
					textAlign : sap.ui.core.TextAlign.Right,
				}).addStyleClass("formLabel");
				
				this.oInputEmp = new sap.m.Input("input_emp",
				{
					enabled:true,
					valueHelpOnly: true,
					showValueHelp: true,
					showSuggestion: true,
					//width : "25%",
					tooltip: "Empleados",
					customData: [ new sap.ui.core.CustomData({key: "UserId",value: "",}),],
					valueHelpRequest: [that.oController.empValueHelp, that.oController],
					//suggest: [oController.empSuggest, oController],
					//suggestionItemSelected: [oController, oController._empItemSelected],
					//change: [oController.empInputChange, oController],
					layoutData : new sap.ui.commons.layout.ResponsiveFlowLayoutData({weight : 7}),
				});
				
				this.oCheckNA = new sap.m.CheckBox({
					enabled:true,
					text: "N/A",				
					select: [that.oController.onSelectNA, that.oController],
				});
				
				this.oBtnAddEmp = new sap.m.Button({
		        	  type: "Transparent", 
		        	  width: "38px",
		        	  icon: "sap-icon://add",
		        	  enabled: false,
		        	  press: [that.oController.onAddEmp, that.oController]
		        });
							
				// Tabla
				this.empTable = new sap.m.Table({
					mode: sap.m.ListMode.None,
					columns : [
								  new sap.m.Column({  
									    hAlign : "Center",  
									    header : new sap.m.Label({  
									              text : "Empleado",
									              design: sap.m.LabelDesign.Bold
									    })  
								   }),
								   new sap.m.Column({  
									    hAlign : "Center",  
									    header : new sap.m.Label({  
									              text : "Resolución",
									              design: sap.m.LabelDesign.Bold
									    })  
								   })  
						       ],
					width : "100%",
					height : "100%",
					delete: [that.oController.onDeleteItem, that.oController]
				});
			
			this.empTableTemplate  = new sap.m.ColumnListItem({
				vAlign: sap.ui.core.VerticalAlign.Middle,		
	            cells : [  
		                    new sap.m.Text({ text : "{FullName}", }), 
//Cambios PRL 17.03.2022
//Antiguo		                    
		               		//new sap.m.TextArea({ value : "{Resolucion}", editable: true, growing: true, cols: 50 }),
//Nuevo
		               		new sap.m.TextArea({ value : "{Resolucion}", editable: true, growing: false, cols: 50 }),
	                    ]
			});
			
			/***
			 * Tabla Clientes -> Nombre - NIF - Participaci�n
			 ***/
			
			// Nombre
			this.oLabelName = new sap.m.Label({
				text : "Nombre:",
				required : false,
				tooltip: "Nombre",
				textAlign : sap.ui.core.TextAlign.Right,
			}).addStyleClass("formLabel");
			
			this.oInputName = new sap.m.Input("input_name",
								{	
									width : "10rem",
									enabled:true,
									tooltip:"Nombre",
									layoutData : new sap.ui.commons.layout.ResponsiveFlowLayoutData({weight : 7}),
									liveChange: function(oEvent) {
										this.setValue(this.getValue().toUpperCase());
									}
								});
			
			this.oLabelName.setLabelFor(this.oInputName);
			
			// NIF
			this.oLabelNIF = new sap.m.Label({
				text : "NIF:",
				required : false,
				tooltip: "NIF",
				textAlign : sap.ui.core.TextAlign.Center,
			}).addStyleClass("clientFormLabel");
			
			this.oInputNIF = new sap.m.Input("input_nif",
								{	//width : "25%",
									width : "10rem",
									enabled:true,
									placeholder: "NIF",
									tooltip:"NIF",
									layoutData : new sap.ui.commons.layout.ResponsiveFlowLayoutData({weight : 7}),
									maxLength: 9,
	//								liveChange: function(oEvent) {
	//									this.setValue(this.getValue().toUpperCase());
	//								},
									change: [that.oController.validateNif, this] 
								});
			
			this.oLabelNIF.setLabelFor(this.oInputNIF);
	
			// Participaci�n
			this.oLabelPartic = new sap.m.Label({
				text : "Participación:",
				required : false,
				tooltip: "Participación",
				textAlign : sap.ui.core.TextAlign.Right,
			}).addStyleClass("clientFormLabel");
			
			this.oSelectPartic = new sap.m.Select("input_partic",{	
										enabled:true,
										//width : "25%",
										width : "10rem",
										forceSelection: false,
										tooltip:"Participación",
										layoutData : new sap.ui.commons.layout.ResponsiveFlowLayoutData({weight : 7}),
										change: function(oEvent) {
											//byId('planesDetailEditable').getModel().getData().ProStatus = this.getProperty("selectedKey");
											//byId('planesDetailEditable').getModel().getData().ProStatusDescr = this.getSelectedItem().getText();
										}
									}).bindAggregation("items","/results", new sap.ui.core.Item({key : "{Id}", text : "{Name}"}));
					
			this.oLabelPartic.setLabelFor(this.oSelectPartic);
			
			// Tabla
			this.clieTable = new sap.m.Table({ 
				mode: sap.m.ListMode.None,
				columns : [
							  new sap.m.Column({  
								    hAlign : "Center",  
								    header : new sap.m.Label({  
								              text : "Nombre",
								              design: sap.m.LabelDesign.Bold
								    })  
							   }),
							   new sap.m.Column({  
								    hAlign : "Center",  
								    header : new sap.m.Label({  
								              text : "NIF",
								              design: sap.m.LabelDesign.Bold
								    })  
							   }),
							   new sap.m.Column({  
								    hAlign : "Center",  
								    header : new sap.m.Label({  
								              text : "Participación",
								              design: sap.m.LabelDesign.Bold
								    })  
							   }) 
					       ],
				width : "100%",
				height : "100%",
				delete: [that.oController.onDeleteItem, that.oController]
			});
			
			this.clieTableTemplate  = new sap.m.ColumnListItem({
			   vAlign: sap.ui.core.VerticalAlign.Middle,
		       cells : [  
		                   new sap.m.Text({ text : "{Nombre}",}), 
		              	   new sap.m.Text({ text : "{Nif}",}),
		                   new sap.m.Text({ text : "{ParticipacionSt}",}),
		               ]
			});
			
			/***
			 * Tabla Centros -> Centros
			 ***/
			
			this.oLabelCent = new sap.m.Label({
				text : "Centro:",
				required : false,
				tooltip: "Centro",
				textAlign : sap.ui.core.TextAlign.Right,
			}).addStyleClass("formLabel");
			
			this.oInputCenter = new sap.m.Input("input_cent", {
				enabled:true,
				valueHelpOnly: true,
				showValueHelp: true,
				showSuggestion: true,
				tooltip: "Centro",
				customData: [ new sap.ui.core.CustomData({key: "Id",value: "",}),],
				valueHelpRequest: [that.oController.centerValueHelp, that.oController],
				//suggest: [oController.empSuggest, oController],
				//suggestionItemSelected: [oController, oController._empItemSelected],
				//change: [oController.empInputChange, oController],
				layoutData : new sap.ui.commons.layout.ResponsiveFlowLayoutData({weight : 7}),
			});
			
					
			// Tabla
			this.centerTable = new sap.m.Table({
				mode: sap.m.ListMode.None,
				columns : [
							  new sap.m.Column({  
								    hAlign : "Center",  
								    header : new sap.m.Label({  
								              text : "SAP-ID",
								              design: sap.m.LabelDesign.Bold
								    })  
							   }),
							   new sap.m.Column({  
								    hAlign : "Center",  
								    header : new sap.m.Label({  
								              text : "Título",
								              design: sap.m.LabelDesign.Bold
								    })  
							   }),
					       ],
				width : "100%",
				height : "100%",
				delete: [that.oController.onDeleteItem, that.oController]
			});
			
			this.centerTableTemplate  = new sap.m.ColumnListItem({
			   vAlign: sap.ui.core.VerticalAlign.Middle,
		       cells : [  
		                   new sap.m.Text({ text : "{CentroId}",}), 
		              	   new sap.m.Text({ text : "{Name}",}),
		               ]
			});
			
			this.oForm =  new sap.ui.layout.form.Form({
				//title: new sap.ui.core.Title({text: "Activity Info"}),
				editable: false,
				height: "100%",
				width: "100%",
				layout: new sap.ui.layout.form.ResponsiveGridLayout({
					columnsL: 1,
					columnsXL: 1,
					columnsM: 1
				}),
				formContainers: [
						new sap.ui.layout.form.FormContainer({
							title: new sap.ui.core.Title({text: "Empleados",
															level: sap.ui.core.TitleLevel.H4}),
							formElements: [
								new sap.ui.layout.form.FormElement({
									label: new sap.m.Label({
															text: "Empleado",
															layoutData: new sap.ui.layout.form.GridElementData({hCells: "3"})
															}).addStyleClass("formLabelStd"),
									fields: [  this.oInputEmp, 
									           this.oBtnAddEmp,
									           this.oCheckNA,
											]
								}),
								new sap.ui.layout.form.FormElement({
									//label: new sap.m.Label({text: "Nombre"}),
									fields: [this.empTable]
								}),

							]
							 
						}),
						new sap.ui.layout.form.FormContainer({
							title: new sap.ui.core.Title({text: "Clientes",
													level: sap.ui.core.TitleLevel.H4}),
							formElements: [
								new sap.ui.layout.form.FormElement({
									label: new sap.m.Label({
										text: "Nombre",
										layoutData: new sap.ui.layout.form.GridElementData({hCells: "3"})
										}).addStyleClass("formLabelStd"),
									fields: [ new sap.m.HBox({
												items: [
											         /* new sap.m.Label({
																	text: sap.hpa.grcaud.Enhancements.constants.Fraude.clieTable.Name,
																	layoutData: new sap.ui.layout.form.GridElementData({hCells: "1"}),
																	}).addStyleClass("lbAdUsr"),*/
//													  this.oLabelName,
													  this.oInputName, 
											         /* new sap.m.Label({
															text: sap.hpa.grcaud.Enhancements.constants.Fraude.clieTable.Nif,
															layoutData: new sap.ui.layout.form.GridElementData({hCells: "1"})
															}).addStyleClass("lbAdUsr"),*/
													 this.oLabelNIF,
													 this.oInputNIF, 
													 /*new sap.m.Label({
															text: sap.hpa.grcaud.Enhancements.constants.Fraude.clieTable.Participation,
															layoutData: new sap.ui.layout.form.GridElementData({hCells: "1"})
															}).addStyleClass("lbAdUsr"),*/
													 this.oLabelPartic, 
													 this.oSelectPartic, 
											         this.oBtnAddClie = new sap.m.Button({
											        	  type: "Transparent", 
											        	  width: "38px",
											        	  icon: "sap-icon://add",
											        	  enabled: true,
											        	  press: [that.oController.onAddClie, that.oController]
											          }) 
										      	]})
											]
								}),
								new sap.ui.layout.form.FormElement({
									//label: new sap.m.Label({text: "Nombre"}),
									fields: [this.clieTable]
								}),
							]
						}),
						new sap.ui.layout.form.FormContainer({
							title: new sap.ui.core.Title({text: "Centros",
													level: sap.ui.core.TitleLevel.H4}),
							formElements: [
								new sap.ui.layout.form.FormElement({
									label: new sap.m.Label({
														text: "Centro",
														layoutData: new sap.ui.layout.form.GridElementData({hCells: "3"})
											}).addStyleClass("formLabelStd"),
									fields: [ 
									         	this.oInputCenter,
										        this.oBtnAddCent = new sap.m.Button({
										        	  type: "Transparent", 
										        	  width: "38px",
										        	  icon: "sap-icon://add",
										        	  enabled: true,
										        	  press: [that.oController.onAddCenter, that.oController]
										        }) 
											]
								}),
								new sap.ui.layout.form.FormElement({
									//label: new sap.m.Label({text: "Nombre"}),
									fields: [this.centerTable]
								}),
							]
						}),
				]
			});	
			
			this.toogleBtn = new sap.m.ToggleButton({ 
		 	   icon: "sap-icon://edit",
		 	   visible: false,
			   press: function(oEvent) {
				   if(this.getPressed()) {
					   that.oController.onEdit();
					   this.setIcon("sap-icon://save");
				   } else {
					   that.oController.onSave(oEvent);
				   }
			   }});
			
			this.oPanel = new sap.m.Panel({
				headerToolbar: new sap.m.Toolbar({
					content: [ new sap.m.ToolbarSpacer({}), 
					           this.toogleBtn
							]
				}),
				content: this.oForm 
			}); 
			
			this.onInitState(this.oController);
			this.loadData();
			this.oController.onEdit();
			
			return this.oPanel;
		},
		
		_getCurrentUser: function() {
			return window.oShell.getUser();
		},
		
		_getInTeam: function(auditKey) {
			
			if(auditKey){
				// Find current user in Team
				var inTeam = false;
				var currUser = this._getCurrentUser();
				var oModel = sap.hpa.grcaud.oODataModelPool.get();
				oModel.read("/AuditSet(guid'"+ auditKey + "')/UserRoles", { async: false, success: success, error: error });
				
				function success(oData,oDataRes)
				{
					var users = $.grep(oData.results,function(n){ return (n.UserID == currUser); });
					inTeam = users.length > 0 ? true : false;
				}
				
				function error(error) {
					console.log("Error retrieving Team members");
					inTeam = false;
				}
				
				return inTeam;
			} else return false;
		},
		
		setEditable: function(oController) {
			
			// Read Z
		    /*oController.oDataModel.read(url, {
				async: false,
				success : function (oData, oDataResp) {
					this.currAuditDept = oData.ZZ_DEPARTMENT;
					this.currAuditGrp = oData.AuditGroupKey;
					this.noAplicaEmp = oData.ZZ_NOAPLICA_EMP;
		       }.bind(this),
		       error: function (oError) {
		    	   alert("KO")
		       }.bind(this)
			});*/
			
			// Se comprueba si esta en el team para poder editar o no
			if(this._getInTeam(this.currAuditKey)) {
				this.toogleBtn.setVisible(true);
			} else {
				this.toogleBtn.setVisible(false);
			}
		},
		
		setParticipa: function() {
			var select = this.oSelectPartic;
			var oModel = new sap.ui.model.json.JSONModel();
		    var conModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/", false);
		    //https://sapriast05.lacaixa.es:44300/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/ParticipacionSet
			 // Read Z
		    conModel.read("/ParticipacionSet", {
				async: false,
				success : function (oData, oDataResp) {
					oModel.setData(oData);
					select.setModel(oModel);
		       }.bind(this),
		       error: function (oError) {
		       	//oTable.setBusy(false);
		       }.bind(this)
			});
		},
		
		getCurrAudit: function(mode) {
			
			//mode = 0 -> Key binaria, mode = 1 -> key guid
			if(mode == 0) {
				return zpa.grcaud.dataqmodel.getModel("firstCallModel").getData().results[0].Value;

			} else {
				return listaInfoUtils.convertKeyBinToGuid(zpa.grcaud.dataqmodel.getModel("firstCallModel").getData().results[0].Value);
			}
		},
		
		loadData: function() {
			var that = this;
			var conModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/", false);
			
			//AuditSet(guid'3A487BD0-47A7-4E91-8362-104EBE073353')?
			var url = "/AuditSet(guid'" + that.getCurrAudit(1) + "')";
			that.empTable.setBusy(true);
			// Read Z
		    conModel.read(url, {
				async: true,
				success : function (oData, oDataResp) {
					//this.noAplicaEmp = oData.ZzNoaplicaEmp;
					//this.currAuditDept = oData.ZzDepartment;
					//this.currAuditGrp = oData.AudGroup;
					this.oCheckNA.setSelected(JSON.parse(oData.ZzNoaplicaEmp));
					
					this.currAuditHeader = oData;
		       }.bind(this),
		       error: function (oError) {
		    	   that.empTable.setBusy(false);
		       }.bind(this)
			});
			
		    //AuditSet(guid'3A487BD0-47A7-4E91-8362-104EBE073353')?$expand=AuditToFraudUserResolution
			var url = "/AuditSet(guid'" + that.getCurrAudit(1) + "')?$expand=AuditToFraudUserResolution";
			that.empTable.setBusy(true);
			// Read Z
		    conModel.read(url, {
				async: true,
				success : function (oData, oDataResp) {
					var oModel = new sap.ui.model.json.JSONModel();
					var fraudEmpData = oData.AuditToFraudUserResolution;
					$.each(fraudEmpData.results, function(i,n) {
						n.Editable = false;
					});
					oModel.setData(fraudEmpData);
					
					that.empTable.bindAggregation("", "/results", that.empTableTemplate);
					that.empTable.bindItems({path:"/results",template:that.empTableTemplate});
					that.empTable.setModel(oModel);
					that.empTable.updateBindings(true);
					that.empTable.setBusy(false);
		       }.bind(this),
		       error: function (oError) {
		    	   that.empTable.setBusy(false);
		       }.bind(this)
			});
		    
		    //AuditSet(guid'3A487BD0-47A7-4E91-8362-104EBE073353')?$expand=AuditToFraudClientes
		    url = "AuditSet(guid'" + that.getCurrAudit(1) + "')?$expand=AuditToFraudClientes";
		    that.clieTable.setBusy(true);
		    // Read Z
		    conModel.read(url, {
				async: true,
				success : function (oData, oDataResp) {
					var oModel = new sap.ui.model.json.JSONModel();
					var fraudClieData = oData.AuditToFraudClientes;
					oModel.setData(fraudClieData);
					
					that.clieTable.bindAggregation("", "/results", that.clieTableTemplate);
					that.clieTable.bindItems({path:"/results",template:that.clieTableTemplate});
					that.clieTable.setModel(oModel);
					that.clieTable.updateBindings(true);
					that.clieTable.setBusy(false);
		       }.bind(this),
		       error: function (oError) {
		    	   that.clieTable.setBusy(false);
		       }.bind(this)
			});
		    
		    
		    //AuditSet(guid'3A487BD0-47A7-4E91-8362-104EBE073353')?$expand=AuditToFraudCentros
		    url = "AuditSet(guid'" + that.getCurrAudit(1) + "')?$expand=AuditToFraudCentros";
		    that.centerTable.setBusy(true);
		    // Read Z
		    conModel.read(url, {
				async: true,
				success : function (oData, oDataResp) {
					var oModel = new sap.ui.model.json.JSONModel();
					var fraudCentrosData = oData.AuditToFraudCentros;
					oModel.setData(fraudCentrosData);
					
					that.centerTable.bindAggregation("", "/results", that.centerTableTemplate);
					that.centerTable.bindItems({path:"/results",template:that.centerTableTemplate});
					that.centerTable.setModel(oModel);
					that.centerTable.updateBindings(true);
					that.centerTable.setBusy(false);
		       }.bind(this),
		       error: function (oError) {
		    	   that.centerTable.setBusy(false);
		       }.bind(this)
			});
		},
			
		onInitState: function(oController) {
			var that = this;
			
			// Se guarda la key actual de la auditoria
			this.currAuditKey = oController.auditKey;
			// Se guarda el departamento y grupo de la auditoria
			//var url = "/AuditSet(guid'" + this.currAuditKey + "')";
			
			// Guardamos el controlador del IconTabContainer
			this.tabContainerController = oController;
			
			var conModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/", false);
			
			//AuditSet(guid'3A487BD0-47A7-4E91-8362-104EBE073353')?
			var url = "/AuditSet(guid'" + that.getCurrAudit(1) + "')";
			that.empTable.setBusy(true);
			// Read Z
		    conModel.read(url, {
				async: false,
				success : function (oData, oDataResp) {
					//this.noAplicaEmp = oData.ZzNoaplicaEmp;
					//this.currAuditDept = oData.ZzDepartment;
					//this.currAuditGrp = oData.AudGroup;
					this.oCheckNA.setSelected(JSON.parse(oData.ZzNoaplicaEmp));
					
					this.currAuditHeader = oData;
					that.empTable.setBusy(false);
		       }.bind(this),
		       error: function (oError) {
		    	   that.empTable.setBusy(false);
		       }.bind(this)
			});
//			// Volvemos el bot�n al estado inicial
//			this.toogleBtn.setPressed(false);
//			this.toogleBtn.setIcon("sap-icon://edit");
//		
//			// Deshabilitamos todos los campos editables
//			this.oController.enableDisableBtns(this, false, sap.m.ListMode.None);
//			this.oController.lookupButtons(this, false);
			
			// Deshabilitamos el campo Resoluci�n en table empleados
//			var oModel = this.empTable.getModel();
//			var data = oModel ? oModel.getData().results ? oModel.getData().results : undefined : undefined;
//			if(data){
//				$.each(data,function(i,n){
//					n.Editable = false;
//				})
//				
//				this.empTable.bindAggregation("", "/results", this.empTableTemplate);
//				//that.empTable.setModel(oModel);
//				this.empTable.updateBindings(true);
//			}
	  	},
	
	});
	
});