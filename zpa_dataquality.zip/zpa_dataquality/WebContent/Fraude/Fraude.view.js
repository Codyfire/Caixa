jQuery.sap.registerModulePath("grcaud.Fraude", oShell.getUI5Path()+"grcaud/resources/js/enhancements/Fraude");
jQuery.sap.require("grcaud.Fraude.Component");
//jQuery.sap.includeStyleSheet( oShell.getUI5Path()+"grcaud/grcaud/lists/styleLists.css");

sap.ui.jsview("Fraude.Fraude", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf Fraude.Fraude
	*/ 
	getControllerName : function() {
		return "Fraude.Fraude";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf Fraude.Fraude
	*/ 
	createContent : function(oController) {
		//return new sap.m.Text({text:"Under implementation"});
		var oComp  = sap.ui.getCore().createComponent({
			id: "FraudeComp",
	        name: "Fraude"
	    });
		
		this.oComp = oComp;
		
		// Se crea un contenedor para el componente
		var oCompCont = new sap.ui.core.ComponentContainer({
			 component: oComp,
		});
		
		this.oCompCont = oCompCont;
		
		return oCompCont;
	}

});