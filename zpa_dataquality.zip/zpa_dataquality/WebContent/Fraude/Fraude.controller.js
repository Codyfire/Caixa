sap.ui.controller("appDataQ.Fraude.Fraude", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf Fraude.Fraude
*/
//	onInit: function() {
//
//	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf Fraude.Fraude
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf Fraude
*/
	onAfterRendering: function() {
		var oComp = sap.ui.getCore().getComponent("FraudeComp")
		
		if(oComp) {
			oComp.setParticipa();
		}
		
	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf Fraude.Fraude
*/
//	onExit: function() {
//
//	}

	/*
	  * event method for emp
	  */
	oModel : {
		  inputEmpFlag : true,
		  valueHelpType : "",
		  valueHelpSource : "",
		  valueModel : "",
		  valueHelpModel : new sap.ui.model.json.JSONModel()
	},
		 
	 empValueHelp : function(oEvent) {
		  this.oModel.valueHelpType = "emp";
		  this.oModel.valueModel = "/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/",
		  this.oModel.valueHelpSource = "/RoleSet(RoleId='AUD',RoleDepId='')/Users"; //"/DataElementSet('LAND1')/NameValuePairs";
		  if (this.oValueHelpDialog) {
			  this.oValueHelpDialog.destroy();
		  }
		  this._createValueHelpDialog();
		  this.oValueHelpDialog.open();
	 },
	 
	 centerValueHelp : function(oEvent) {
		  this.oModel.valueHelpType = "cent";
		  this.oModel.valueModel = "/sap/opu/odata/sap/GRCAUD_SRV/",
		  this.oModel.valueHelpSource = "/DimensionSet";//?$orderby=ID desc&$select=ID,Title,Key";
		  if (this.oValueHelpDialog) {
			  this.oValueHelpDialog.destroy();
		  }
		  this._createValueHelpDialog();
		  this.oValueHelpDialog.open();
	 },
	 
//   /*
//   * build value help dialog
//   */
	 _createValueHelpDialog : function() {
		var that = this;
		// press search button
		var searchPress = function(oEvent) {
		  	var sInput = oEvent.getSource().getParent().getContent()[0].getValue();
		   	// var sSearchPath = this.oModel.valueHelpSource + "?$filter=FullName eq " + sInput.toUpperCase();//' and Value eq '*" + sInput + "*'"; 
		    // !!CAUTION: condition uses 'and', back end implements in or'
		    var aFilters = [];
		    var aSorters = [];
		    if (that.oModel.valueHelpType === "emp") {
		    	aFilters.push(new sap.ui.model.Filter("FullName",sap.ui.model.FilterOperator.EQ, "*" + sInput.toUpperCase() + "*"));
		    } else  if (that.oModel.valueHelpType === "cent") {
		    	aFilters.push(new sap.ui.model.Filter("Title",sap.ui.model.FilterOperator.EQ, "*" + sInput.toUpperCase() + "*" ));
		    	aFilters.push(new sap.ui.model.Filter("Type",sap.ui.model.FilterOperator.EQ, "5DEP" ));
		    	/**
		    	 * INI MOD PPM78221 AuM Dimensiones Bankia 09.06.2021
		    	 * Código nuevo 
		    	 */
		    	// Se añade el filtro para departamentos de Bankia
		    	aFilters.push(new sap.ui.model.Filter("Type",sap.ui.model.FilterOperator.EQ, "7DEPBANKIA" ));
		    	/**
		    	 * FIN MOD PPM78221 AuM Dimensiones Bankia 09.06.2021
		    	 */
		    	aFilters.push(new sap.ui.model.Filter("Timestamp",sap.ui.model.FilterOperator.EQ, "2099-12-30T23:00:00" ));
		    	aSorters.push(new sap.ui.model.Sorter("ID",true));
		    }
			
		    var conModel = new sap.ui.model.odata.ODataModel(this.oModel.valueModel, false);
			 //sap.ui.getCore().setModel(con.Model,"con");
			    
		    var oTable = oEvent.getSource().getParent().getParent();
		    //var oODataModel = sap.hpa.grcaud.oODataModelPool.get();

		    this.oModel.valueHelpModel.oData.results = undefined;
		    this.oModel.valueHelpModel.refresh(true);
		    oTable.setBusy(true);
		    
		    // Read Z
		    conModel.read(this.oModel.valueHelpSource, {
				filters : aFilters,
				sorters: aSorters,
				
				async: false,
				success : function (oData, oDataResp) {
					this.oModel.valueHelpModel.setData(oData);
			        oTable.setBusy(false);
		       }.bind(this),
		       error: function (oError) {
		       	oTable.setBusy(false);
		       }.bind(this)
			});
		    
		    /*oODataModel.read(sSearchPath, undefined, undefined,
		      true, jQuery.proxy(
		        function(data, response) {
		         this.oModel.valueHelpModel
		           .setData(data);
		         oTable.setBusy(false);
		        }, this), jQuery.proxy(function(
		        oError) {
		       oTable.setBusy(false);
		      }, this));
		   };*/  
	};	
	
	// select an item
    var itemSelected = function(oEvent) {
     var selectedItem = oEvent.oSource.getSelectedItem().getModel().getProperty(oEvent.oSource.getSelectedItem().getBindingContext().getPath());
     if (this.oModel.valueHelpType === "emp") {
 	      sap.ui.getCore().byId("input_emp").setValue(selectedItem.FullName);
 	      sap.ui.getCore().byId("input_emp").getCustomData().forEach(function(data) {
 	           if (data.getKey() == "UserId") {
 	            data.setValue(selectedItem.UserId);
 	           }
 	      });
 	      sap.ui.getCore().byId("input_emp").setValueState(sap.ui.core.ValueState.None);
 	      this.oValueHelpDialog.close();
 	     // this.oModel.inputCountryFlag = true;
     } else if (this.oModel.valueHelpType === "cent") {
    	  sap.ui.getCore().byId("input_cent").setValue(selectedItem.Title);
	      sap.ui.getCore().byId("input_cent").getCustomData().forEach(function(data) {
	           if (data.getKey() == "Id") {
	            data.setValue(selectedItem.ID);
	           }
	      });
	      sap.ui.getCore().byId("input_cent").setValueState(sap.ui.core.ValueState.None);
	      this.oValueHelpDialog.close();
     }/*else {
 	      sap.ui.getCore().byId("text_company_name").setText(selectedItem.Value);
 	      sap.ui.getCore().byId("input_company_code").setValue(selectedItem.Name);
 	      sap.ui.getCore().byId("input_company_code").setValueState(sap.ui.core.ValueState.None);
 	      this.oModel.inputCompanyCodeFlag = true;
 	      this.oValueHelpDialog.close();
 	    }*/
    };
	  
	// search table to be put into value help dialog
    var oSearchTable = new sap.m.Table({
	     inset : true,
	     mode : sap.m.ListMode.SingleSelectMaster,
	     growing : true,
	     growingThreshold : 50,
	     growingScrollToLoad : true,
	     headerToolbar : new sap.m.Toolbar({
		     content : [
				        new sap.m.Input({ width : "300px", change : [ searchPress, this ]}),
				        new sap.m.ToolbarSpacer({width : "1em"}),
				        new sap.m.Button({  type : sap.m.ButtonType.Emphasized, 
				        					text : "Search",
				        					press : [ searchPress, this ]})
			  ],
	     }),
		     columns : [ 
		                 new sap.m.Column({
						      width : "35%",
						      vAlign : sap.ui.core.VerticalAlign.Middle,
						      header : new sap.m.Label({}),
						     }), 
						 new sap.m.Column({
						      width : "65%",
						      vAlign : sap.ui.core.VerticalAlign.Middle,
						      header : new sap.m.Label({}),
						     }), 
			],
	     select : [ itemSelected, this ],
    });

    if (that.oModel.valueHelpType === "emp") {
    	 oSearchTable.bindItems("/results",
        	     new sap.m.ColumnListItem({
    	    	      cells : [ 
    	    	                new sap.m.Text({text : "{UserId}"}), 
    	    	                new sap.m.Text({text : "{FullName}"}), 
    	    	      ],
        	     }));
    } else  if (that.oModel.valueHelpType === "cent") {
    	 oSearchTable.bindItems("/results",
        	     new sap.m.ColumnListItem({
    	    	      cells : [ 
    	    	                new sap.m.Text({text : "{ID}"}), 
    	    	                new sap.m.Text({text : "{Title}"}), 
    	    	      ],
        	     }));
    }
   
    
    oSearchTable.setModel(this.oModel.valueHelpModel);
	   
	 // create value help dialog
	 this.oValueHelpDialog = new sap.m.Dialog({
	    title : "Search Dialog",
	    stretchOnPhone:true,
	    //  stretch : jQuery.device.is.phone, // when it is phone,stretch the search box to full screen
	    contentWidth : "600px",
	    contentHeight:"300px",
	    horizontalScrolling : false,
	    rightButton : new sap.m.Button({
	    						text : "Cancel",
	    						press : jQuery.proxy(function() { this.oValueHelpDialog.close(); }, this),
	    			  }),
	    content : [ oSearchTable ],
//		beforeOpen : [ this._dialogBeforeOpen, this ],
		afterClose : [ this._dialogAfterClose, this ],
		afterOpen : [ this, this._dialogAfterOpen ],
	  }); 
  },
	 
	 
//	 
//	  empSuggest : function(oEvent) {
//	       // skip validation event for 1 time
//	       // as this is validation event is earlier than suggested item select event 
//	       this.skipempValidation = true;
//	             oEvent.getSource().destroySuggestionItems();
//	             var sValue = oEvent.getParameter("suggestValue");
//	             var sValueLowerCase = sValue.toLowerCase();
//	             for (var i = 0; i < this.empSuggestionList.length; i++) {
//	                 var empLowerCase = this.empSuggestionList[i].Value.toLowerCase();
//	                 var index = empLowerCase.indexOf(sValueLowerCase);
//	                 if (index != -1) {
//	              oEvent.getSource().addSuggestionItem(new sap.ui.core.ListItem({
//	                  text : this.empSuggestionList[i].Value + "(" + this.empSuggestionList[i].Name + ")",
//	                  key : this.empSuggestionList[i].Value,
//	                  customData:new sap.ui.core.CustomData({
//	                       key:"code",
//	                       value:this.empSuggestionList[i].Name
//	                         })
//	              }));
//	                 }
//	             }
//	            },
//	                        
//	            _loadContrySuggestionList : function() {
//	                 var oController = this;
//	             var sPath = "/DataElementSet('LAND1')/NameValuePairs";
//	             var oODataModel = sap.hpa.grcaud.oODataModelPool.get();
//	             sap.ui.getCore().byId("input_emp").setBusy(true);
//	             oODataModel.read(sPath, undefined, undefined, true, jQuery.proxy(function(data, response) {
//	                 oController.empSuggestionList = data.results;
//	                 sap.ui.getCore().byId("input_emp").setBusy(false);
//	             }, this), jQuery.proxy(function(oError) {
//	                 sap.ui.getCore().byId("input_emp").setBusy(false);
//	             }, this));
//	            },
//
//	 empInputChange : function(oEvent) {
//	  this.oModel.valueHelpType = "emp";
//	  this.oModel.valueHelpSource = "/DataElementSet('LAND1')/NameValuePairs";
//	  sap.ui.getCore().byId("input_emp").setValueState(sap.ui.core.ValueState.None);
//	 },
//	 
//	 _empItemSelected : function(oEvent, that){
//        var selectedItem = oEvent.getParameter("selectedItem");
//    this.setValue(selectedItem.getKey());
//    this.setValueState(sap.ui.core.ValueState.None);   
//
//       sap.ui.getCore().byId("input_emp").getCustomData().forEach(function(data) {
//        if (data.getKey() == "id") {
//     data.setValue(selectedItem.getCustomData()[0].getValue());
//        }
//    });
//   },
//   
   
   
//
//   _dialogBeforeOpen : function(oEvent) {
//    oEvent.getSource().getContent()[0].getColumns()[0]
//      .getHeader()
//      .setText(
//        sap.hpa.grcaud.oBundle
//          .getText(this.oModel.valueHelpType === "country" ? "LABEL_COUNTRY_ID"
//            : "LABEL_COMPANY_CODE"));
//    oEvent.getSource().getContent()[0].getColumns()[1]
//      .getHeader()
//      .setText(
//        sap.hpa.grcaud.oBundle
//          .getText(this.oModel.valueHelpType === "country" ? "LABEL_COUNTRY"
//            : "LABEL_COMPANY_NAME"));
//    oEvent.getSource().getContent()[0].getHeaderToolbar()
//      .getContent()[0]
//      .setValue(this.oModel.valueHelpType === "country" ? sap.ui
//        .getCore().byId("input_country")
//        .getValue()
//        : sap.ui.getCore().byId(
//          "input_company_code")
//          .getValue());
//   },
//
   _dialogAfterOpen : function(oEvent, oControl) {
	    var that = this;
	    document.getElementById(that.getContent()[0].getHeaderToolbar().getContent()[2].getId()).focus();
   },

   _dialogAfterClose : function(oEvent) {
    this.oModel.valueHelpModel.oData.results = undefined;
    this.oModel.valueHelpModel.refresh(true);
    this.oValueHelpDialog.getContent()[0].removeSelections(true);
    this.oValueHelpDialog.getContent()[0].getHeaderToolbar().getContent()[0].setValue("");
   },

  
  	onAddEmp: function(oEvent) {
  		var component = sap.ui.getCore().getComponent("FraudeComp");

  		if(component && component.oInputEmp.getValue() != "" ) {
  			var empTable = component.empTable;
  			var empTableTemp = component.empTableTemplate;
  	  		var empInput = component.oInputEmp;
  	  		
  	  		if(!empTable.getModel()) {
  	  			var oModel = new sap.ui.model.json.JSONModel();
  	  			empTable.setModel(oModel);
  	  		}
  	  		
  	  		var model = empTable.getModel();
  	  		var data = model.getData();
  	  		var userId = empInput.getCustomData()[0] ? empInput.getCustomData()[0].getValue() : "";
  	  		

  	  		if(!data.results) {
  	  			var duplicate = $.grep(data, function(n,i) { return n.UserId == userId} )
  	  		} else {

  	  			var duplicate = $.grep(data.results, function(n,i) { return n.UserId == userId} )
  	  		}
  	  		  	  		
  	  		if(duplicate.length > 0) {
  	  			alert("El empleado seleccionado ya ha sido añadido previamente");
  	  		} else {
	  	  		if(data.results) {
	  	  			data.results.push({"UserId": userId, "FullName" : empInput.getValue(), "Resolucion": "", "Editable": true});
	  	  		} else {
	  	  			data.results = [];
	  	  			data.results.push({"UserId": userId, "FullName" : empInput.getValue(), "Resolucion": "", "Editable": true});
	  	  		}
	  	  		
	  	  		empTable.bindAggregation("", "/results", empTableTemp);
	  	  	    empTable.bindItems({path:"/results",template:empTableTemp});
	  	  		empTable.getModel().setData(data);
	  	  		empTable.updateBindings(true);
	  	  		
	  	  		component.oInputEmp.setValue("");
  	  		}

  		} else {
  			alert("No se ha seleccionado ningún empleado");
  			component.oInputEmp.setValue("");
  		}  		
  	},
  	
  	validateNif:  function(oEvent) {
  		if(oEvent.getParameter("value") != undefined && oEvent.getParameter("value") != ""){
  		  var dni = oEvent.getParameter("value");
  		  var numero;
  		  var letr;
  		  var letra;
  		  var expresion_regular_dni = /^\d{8}[a-zA-Z]$/;
  		 
  		  if(expresion_regular_dni.test(dni) == true){
  		     numero = dni.substr(0,dni.length-1);
  		     letr = dni.substr(dni.length-1,1);
  		     numero = numero % 23;
  		     letra='TRWAGMYFPDXBNJZSQVHLCKET';
  		     letra=letra.substring(numero,numero+1);
  		    if (letra!=letr.toUpperCase()) {
  		    	oEvent.getSource().setValueState(sap.ui.core.ValueState.Error); 
  		     }else{
  		       oEvent.getSource().setValueState(sap.ui.core.ValueState.Success);
  		     }
  		  }else{
  		     oEvent.getSource().setValueState(sap.ui.core.ValueState.Error); 
  		   }
  		 }else{
  			 oEvent.getSource().setValueState(sap.ui.core.ValueState.None); 
  		 }
  	},
  	
  	onAddClie: function(oEvent) {
  		var component = sap.ui.getCore().getComponent("FraudeComp");
  		
  		if(component.oInputNIF.getValueState() == sap.ui.core.ValueState.Error)
  		{
  			alert("El NIF introducido no es correcto");
  			return;
  		}

  		if(component && component.oInputName.getValue() != "" && component.oInputNIF.getValue() != "" && component.oSelectPartic.getSelectedKey() != "") {
  			var clieTable = component.clieTable;
  			var clieTableTemp = component.clieTableTemplate;
  	  		var nameInput = component.oInputName;
	  	  	var nifInput = component.oInputNIF;
	  	  	var particInput = component.oSelectPartic;
	  	  	var selItem = particInput.getSelectedItem();
  	  		
  	  		if(!clieTable.getModel()) {
  	  			var oModel = new sap.ui.model.json.JSONModel();
  	  			clieTable.setModel(oModel);
  	  		}
  	  		
  	  		var model = clieTable.getModel();
  	  		var data = model.getData();
  	  		var particId = particInput.getSelectedKey();
  	  		
  	  		if(data.results) {
  	  			data.results.push({"Nombre" : nameInput.getValue(), "Nif": nifInput.getValue().toUpperCase(), "Participacion": particId, "ParticipacionSt" : selItem ? selItem.getText() : ""});
  	  		} else {
  	  			data.results = [];
  	  			data.results.push({"Nombre" : nameInput.getValue(), "Nif": nifInput.getValue().toUpperCase(), "Participacion": particId, "ParticipacionSt" : selItem ? selItem.getText() : ""});
  	  		}
  	  		
  	  		clieTable.bindAggregation("", "/results", clieTableTemp);
  	  	    clieTable.bindItems({path:"/results",template:clieTableTemp});
  	  		clieTable.getModel().setData(data);
  	  		clieTable.updateBindings(true);
  	  		
  	  		component.oInputName.setValue("");
  	  		component.oInputNIF.setValue("");
  	  		component.oInputNIF.setValueState(sap.ui.core.ValueState.None); 
  	  		component.oSelectPartic.setSelectedKey("");
  		} else {
  			alert("No se han rellenado todos los campos");
  		}  		
  	},
  	
  	onAddCenter: function(oEvent) {
  		var component = sap.ui.getCore().getComponent("FraudeComp");
  		
  		if(component && component.oInputCenter.getValue() != "") {
  			var centerTable = component.centerTable;
  			var centerTableTemp = component.centerTableTemplate;
  	  		var centerInput = component.oInputCenter;
  	  		
  	  		if(!centerTable.getModel()) {
  	  			var oModel = new sap.ui.model.json.JSONModel();
  	  			centerTable.setModel(oModel);
  	  		}
  	  		
  	  		var model = centerTable.getModel();
  	  		var data = model.getData();
  	  		
  	  		var centerId = centerInput.getCustomData()[0] ? centerInput.getCustomData()[0].getValue() : "";

  	  		if(data.results) {
  	  			data.results.push({"CentroId" : centerId, "Name": centerInput.getValue().toUpperCase()});
  	  		} else {
  	  			data.results = [];
  	  			data.results.push({"CentroId" : centerId, "Name": centerInput.getValue().toUpperCase()});
  	  		}
  	  		
  	  		centerTable.bindAggregation("", "/results", centerTableTemp);
  	  	    centerTable.bindItems({path:"/results",template:centerTableTemp});
		  	centerTable.getModel().setData(data);
		  	centerTable.updateBindings(true);
  	  		
  	  		component.oInputCenter.setValue("");
  	  		//component.oSelectPartic.setValue("");
  		} else {
  			alert("No se han rellenado todos los campos");
  		}  		
  	},
  	
  	onDeleteItem: function(oEvent) {
  		var selItem = oEvent.getParameter("listItem");
  		var table = oEvent.getSource();
  		
  		var dialog = new sap.m.Dialog({
			title: 'Advertencia',
			type: 'Message',
			state: 'Warning',
				content: new sap.m.Text({
					text: '¿Está seguro que desea eliminar el registro seleccionada?'
				}),
			state: sap.ui.core.ValueState.Warning,
			beginButton: new sap.m.Button({
				text: 'Aceptar',
				press: function () {
					dialog.close();
					var bindingContext = selItem.getBindingContext().sPath;
					var index = bindingContext.substring(bindingContext.lastIndexOf("/")+1);
					var data = table.getModel().getData();
					if(data.results)
						data.results.splice(index,1);
					table.getModel().setData(data);
					table.updateBindings(true);
				}
			}),
			endButton: new sap.m.Button({
				text: 'Cancelar',
				press: function () {
					dialog.close();
				}
			}),
			afterClose: function() {
				dialog.destroy();
			}
		});

		dialog.open();
  	},
  	
  	onEdit: function() {
  		var component = sap.ui.getCore().getComponent("FraudeComp");
  		if(component){
  			// Habilitamos los campos de editables
			this.lookupButtons(component, true);
			this.enableDisableBtns(component, true, sap.m.ListMode.Delete);
			// Habilitamos el campo Resolución en table empleados
			var oModel = component.empTable.getModel();
			var data = oModel ? oModel.getData().results ? oModel.getData().results : undefined : undefined;
			if(data){
				$.each(data,function(i,n){
					n.Editable = true;
				})
				
				component.empTable.bindAggregation("", "/results", component.empTableTemplate);
				component.empTable.bindItems({path:"/results",template:component.empTableTemplate});
				component.empTable.updateBindings(true);
			}
			
  		}
  	},
  	
  	checkTerritorial: function(component) {
  		// Si:
  		// --> No esta seleccionado el check de N/A
  		// --> Es de departamento/grupo territorial
  		// ------> Debe tener un empleado añadido mínimo
  		if(!component.oCheckNA.getSelected() && 
  				(	component.currAuditHeader.ZzDepartment == "09423" ||
  					component.currAuditHeader.AudGroup.startsWith("09423"))
  				) {
  			var empTable = component.empTable;
	  		var empTableModel = empTable ? empTable.getModel() : undefined;
	  		var empTableData = empTableModel ? empTableModel.getData() : undefined;
	  		var empTableDataRes = empTableData ? empTableModel.getData().results : undefined;
	  		
	  		if(empTableDataRes && empTableDataRes.length == 0)
	  			return false;
	  		else return true;
  		}
  		
  		return true;
  	},
  	
  	checkFraude: function(component) {
  		// Si:
  		// --> No esta seleccionado el check de N/A
  		// --> Es de departamento/grupo fraude
  		// ------> Debe tener un empleado añadido mínimo
  		if(!component.oCheckNA.getSelected() && 
  				(	component.currAuditHeader.ZzDepartment == "16581" ||
  					component.currAuditHeader.AudGroup.startsWith("16581"))
  				) {
  			var empTable = component.empTable;
	  		var empTableModel = empTable ? empTable.getModel() : undefined;
	  		var empTableData = empTableModel ? empTableModel.getData() : undefined;
	  		var empTableDataRes = empTableData ? empTableModel.getData().results : undefined;
	  		
	  		if(empTableDataRes && empTableDataRes.length == 0)
	  			return false;
	  		else return true;
  		}
  		
  		return true;
  	},
  	
  	saveFraudFields: function(component) {
  		var that = this;
  		//var component = sap.ui.getCore().getComponent("FraudeComp");
  		var oData = {};
  		//oData = component.currAuditHeader;
  		oData.Key = component.getCurrAudit(1);
	    // Se guara el campo N/A para Empleados
  		oData.ZzNoaplicaEmp = component.oCheckNA.getSelected();
	    
		if(oData.ZzNoaplicaEmp){ // si el check esta marcado, se envia un registro vacio
			oData.FraudUserResolution = [{}];
		} else {
		  		
	  		// Tabla empleados
	  		var empTable = component.empTable;
	  		var empTableModel = empTable ? empTable.getModel() : undefined;
	  		var empTableData = empTableModel ? empTableModel.getData() : undefined;
	  		var empTableDataRes = empTableData ? empTableModel.getData().results : undefined
	  		var employee = [];
	  		
	  		$.each(empTableDataRes, function(i,n){
	  	  		//<Property Name="Key" Type="Edm.Guid" Nullable="false" sap:creatable="false" sap:updatable="false" sap:sortable="false" sap:filterable="false"/>
	  	  		//<Property Name="ParentKey" Type="Edm.Guid" Nullable="false" sap:creatable="false" sap:updatable="false" sap:sortable="false" sap:filterable="false"/>
	  	  		//<Property Name="RootKey" Type="Edm.Guid" Nullable="false" sap:creatable="false" sap:updatable="false" sap:sortable="false" sap:filterable="false"/>
	  	  		//<Property Name="UserId" Type="Edm.String" Nullable="false" MaxLength="30" sap:label="ID" sap:creatable="false" sap:updatable="false" sap:sortable="false" sap:filterable="false"/>
	  	  		//<Property Name="Resolucion" Type="Edm.String" Nullable="false" sap:creatable="false" sap:updatable="false" sap:sortable="false" sap:filterable="false"/>
	
	  			if(n.Key)
	  				employee.push({"Key": n.Key, "ParentKey" : oData.Key, "UserId" : n.UserId , "Resolucion" : n.Resolucion });
	  			else
	  				employee.push({"ParentKey" : oData.Key, "UserId" : n.UserId , "Resolucion" : n.Resolucion });
	  		});
	
	  		oData.FraudUserResolution = employee.length > 0 ? employee : [{}];
  		}
  		
	  	// Tabla clientes
	  		
  		var clieTable = component.clieTable;
  		var clieTableModel = clieTable ? clieTable.getModel() : undefined;
  		var clieTableData = clieTableModel ? clieTableModel.getData() : undefined;
  		var clieTableDataRes = clieTableData ? clieTableModel.getData().results : undefined
  		var clients = [];
  		
  		$.each(clieTableDataRes, function(i,n){
//		  			<Property Name="Key" Type="Edm.Guid" Nullable="false" sap:creatable="false" sap:updatable="false" sap:sortable="false" sap:filterable="false"/>
//		  			<Property Name="ParentKey" Type="Edm.Guid" Nullable="false" sap:creatable="false" sap:updatable="false" sap:sortable="false" sap:filterable="false"/>
//		  			<Property Name="RootKey" Type="Edm.Guid" Nullable="false" sap:creatable="false" sap:updatable="false" sap:sortable="false" sap:filterable="false"/>
//		  			<Property Name="Nombre" Type="Edm.String" Nullable="false" sap:creatable="false" sap:updatable="false" sap:sortable="false" sap:filterable="false"/>
//		  			<Property Name="Nif" Type="Edm.String" Nullable="false" sap:creatable="false" sap:updatable="false" sap:sortable="false" sap:filterable="false"/>
//		  			<Property Name="Participacion" Type="Edm.String" Nullable="false" MaxLength="10" sap:label="Id Compañía" sap:creatable="false" sap:updatable="false" sap:sortable="false" sap:filterable="false"/>
//		  			<Property Name="ParticipacionSt" Type="Edm.String" Nullable="false" sap:creatable="false" sap:updatable="false" sap:sortable="false" sap:filterable="false"/>"
  			if(n.Key)
  				clients.push({"Key": n.Key, "ParentKey" : oData.Key, "Nombre" : n.Nombre , "Nif" : n.Nif, "Participacion" : n.Participacion });
  			else 
  				clients.push({"ParentKey" : oData.Key, "Nombre" : n.Nombre , "Nif" : n.Nif, "Participacion" : n.Participacion });
  		});
  		
  		
  		oData.FraudClientes = clients.length > 0 ? clients : [{}];
  		 

	  	// Tabla centros
  		
  		var centerTable = component.centerTable;
  		var centerTableModel = centerTable ? centerTable.getModel() : undefined;
  		var centerTableData = centerTableModel ? centerTableModel.getData() : undefined;
  		var centerTableDataRes = centerTableData ? centerTableModel.getData().results : undefined
  		var centers = [];
  		
  		$.each(centerTableDataRes, function(i,n){
//		  			<Property Name="Key" Type="Edm.Guid" Nullable="false" sap:creatable="false" sap:updatable="false" sap:sortable="false" sap:filterable="false"/>
//	  			<Property Name="ParentKey" Type="Edm.Guid" Nullable="false" sap:creatable="false" sap:updatable="false" sap:sortable="false" sap:filterable="false"/>
//	  			<Property Name="RootKey" Type="Edm.Guid" Nullable="false" sap:creatable="false" sap:updatable="false" sap:sortable="false" sap:filterable="false"/>
//	  			<Property Name="CentroId" Type="Edm.String" Nullable="false" MaxLength="30" sap:label="ID" sap:creatable="false" sap:updatable="false" sap:sortable="false" sap:filterable="false"/>
//	  			<Property Name="Name" Type="Edm.String" Nullable="false" MaxLength="100" sap:label="Nombre" sap:creatable="false" sap:updatable="false" sap:sortable="false" sap:filterable="false"/>" +
  						
  			if(n.Key)
  				centers.push({"Key": n.Key, "ParentKey" : oData.Key, "CentroId" : n.CentroId , "Name" : n.Name});
  			else 
  				centers.push({"ParentKey" : oData.Key, "CentroId" : n.CentroId , "Name" : n.Name });
  		});
  		
  		oData.FraudCentros = centers.length > 0 ? centers : [{}];
  		
  		// Se eliminan las navegaciones a otros BO
  		//delete oData.AuditToFraudCentros;
  		//delete oData.AuditToFraudClientes;
  		//delete oData.AuditToFraudUserResolution;
  		
  		// SAVE
  		var conModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/", false);
	    
	    conModel.create("/AuditDeepSet", oData, {
			async: false,
			success : function (oData, oDataResp) {
				//sap.m.MessageToast.show("Campos Fraude guardados correctamente", {duration: 1200});
				
				// Volvemos a cargar la info actual de Backend
				component.loadData();
				
				// Deshabilitamos todos los campos editables
//				this.enableDisableBtns(component, false, sap.m.ListMode.None);
//				this.lookupButtons(component, false);
				
				// Deshabilitamos el campo Resolución en table empleados
//				if(empTableDataRes){
//					$.each(empTableDataRes,function(i,n){
//						n.Editable = false;
//					}) 
//					
//					empTable.bindAggregation("", "/results", component.empTableTemplate);
//					//that.empTable.setModel(oModel);
//					empTable.updateBindings(true);
//				}
				
				// Cambiamos el icono del botón
//				sap.ui.getCore().byId(this.btnId).setIcon("sap-icon://edit");
				
				component.oPanel.setBusy(false);
				
				var dialog = new sap.m.Dialog({
					title: 'Información',
					type: 'Message',
					content: new sap.m.Text({
						text: "Datos guardados correctamente para la pestaña Fraude."
					}),
					beginButton: new sap.m.Button({
						text: 'Aceptar',
						press: function () {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});
				dialog.open();
				
	  			//that.doBackOnSave();
		  		
	       }.bind(this),
	       error: function (oError) {
	    	   component.oPanel.setBusy(false);
	    	   sap.m.MessageToast.show("Error al guardar los campos", {duration: 1200});
	       }.bind(this)
		});
  	},
  	
  	c : function() {
		var currView = that.getView();
		var navCont = currView.getParent();
		navCont.getPreviousPage().getController().onResetScreen();
		navCont.getPreviousPage().oSearch.setValue("");
		navCont.to(navCont.getPreviousPage().sId);
		navCont.getPage(currView.sId).destroy();
  	},
  	
  	onSave: function(oEvent) {
  		var that = this;
  		var component = sap.ui.getCore().getComponent("FraudeComp");

  		if(component){
  			component.oPanel.setBusy(true);
  			// Se comprueba si la auditoria es de territorial y tiene empleados
  			if(that.checkTerritorial(component))
	  		{ 
  				if(that.checkFraude(component))
	  			{
	  			//https://sapriast05.lacaixa.es:44300/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/AuditDeepSet
  				var conModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/", false);
  				
  				//AuditSet(guid'3A487BD0-47A7-4E91-8362-104EBE073353')?
	  			// Se recuperan los datos de la auditoria
				var url = "/AuditSet(guid'" + component.getCurrAudit(1) + "')";
				// Read Z
				//component.tabContainerController.oDataModel.read(url, {
				//conModel.read(url, {
				//	async: false,
				//	success : function (oData, oDataResp) {
  						this.saveFraudFields(component);
			    //   }.bind(this),
			    // error: function (oError) {
			    //	   console.log("Error recuperando datos de la auditoría");
			    //   }.bind(this)
				//});
		  			component.oPanel.setBusy(false);
	  			} else {
	  				component.oPanel.setBusy(false);
	  				alert("Para auditorias del departamento '16581 - Auditoria Del Fraude-Investigaciones Esp' es necesario informar un empleado o seleccionar la opción de N/A");
					oEvent.getSource().setPressed(true);
					oEvent.getSource().setIcon("sap-icon://save");
	  				//component.oCheckNA.setEnabled(true)
	  			}
  			} else {
  				component.oPanel.setBusy(false);
  				alert("Para auditorias del departamento '09423 - Auditoria Territorial Y Negocio' es necesario informar un empleado o seleccionar la opción de N/A");
				oEvent.getSource().setPressed(true);
				oEvent.getSource().setIcon("sap-icon://save");
				//component.oCheckNA.setEnabled(true)
  			}
  			
  		}

  	},
  	
  	doBackOnSave: function() {
		var currView = byId("detailScreen");
		var navCont = currView.getParent();
		navCont.getPreviousPage().getController().onResetScreen();
		navCont.getPreviousPage().oSearch.setValue("");
		navCont.to(navCont.getPreviousPage().sId);
		navCont.getPage(currView.sId).destroy();
  	},
  	
  	lookupButtons: function(comp, boolValue) {
  		var btnClass = sap.m.Button.getMetadata()._sClassName;
  		var hboxClass = sap.m.HBox.getMetadata()._sClassName;
  		
  		var containers = comp.oForm.getFormContainers()
  		$.each(containers, function(i,n) {
  			var element = n.getFormElements()[0]; // Así evitamos recorrer las tablas
			var fields = element.getFields();
			$.each(fields, function(k,l){
				if(l.getMetadata()._sClassName == btnClass) {
					if(l !== comp.oBtnAddEmp){
						l.setEnabled(boolValue);
					}
				} else if (l.getMetadata()._sClassName == hboxClass) {
					var items = l.getItems();
					$.each(items,function(x,y){
						if(y.getMetadata()._sClassName == btnClass) {
							y.setEnabled(boolValue);
						}
					})
					
				}
			})
  		});
  	},
  	
  	enableDisableBtns: function(component, value, mode) {
  		if(!component.oCheckNA.getSelected()){
  			component.oInputEmp.setEnabled(value);
  			component.empTable.setMode(mode);
  		}else{
  			component.oInputEmp.setEnabled(false);
  			component.empTable.setMode(sap.m.ListMode.None);
  		}
  		component.oCheckNA.setEnabled(value);
  		/**
  		 * INI Ajuste SPAU 06/11/18
  		 * Codigo antiguo
  		 *	component.oBtnAddEmp.setEnabled(!value);
  		 *
  		 * Codigo nuevo
  		 * Se habilita el botón de añadir empleado dependiendo del valor de NA (si está seleccionado o no)
  		 */
  		component.oBtnAddEmp.setEnabled(!component.oCheckNA.getSelected());
  		
  		/**
  		 * FIN Ajuste SPAU 06/11/18
  		 */
  		component.oInputCenter.setEnabled(value);
  		component.centerTable.setMode(mode);
  		//if(component.currAuditHeader.Status != "08"){
  			component.oBtnAddClie.setEnabled(value);
  			component.oInputName.setEnabled(value);
  			component.oInputNIF.setEnabled(value);
  			component.oSelectPartic.setEnabled(value);
  			component.clieTable.setMode(mode);
  			component.oBtnAddCent.setEnabled(value);
  			component.oInputCenter.setEnabled(value);
  	  		component.centerTable.setMode(mode);
  		/**}else{
  			/** INI MOD Modificar en auditorías cerradas
  			 * 08/04/2021
  			 * Codigo antiguo
  			 *    			  
		
//  			component.oBtnAddClie.setEnabled(true);
//  			component.oInputName.setEnabled(false);
//  			component.oInputNIF.setEnabled(false);
//  			component.oSelectPartic.setEnabled(false);
//  			component.empTable.setMode(sap.m.ListMode.None);
//  			component.clieTable.setMode(sap.m.ListMode.None);
//  			component.oBtnAddCent.setEnabled(true);
//  			component.oInputCenter.setEnabled(false);
//  	  		component.centerTable.setMode(sap.m.ListMode.None);
//  	  		component.oBtnAddEmp.setEnabled(true);
//  	  		component.oCheckNA.setEnabled(false);
*/
  			
  			/**
  			 *  codigo nuevo
  			 
  			// Se indican los valores de los campos inhabilitando el campo NA
  			component.oBtnAddClie.setEnabled(value);
  			component.oInputName.setEnabled(value);
  			component.oInputNIF.setEnabled(value);
  			component.oSelectPartic.setEnabled(value);
  			component.empTable.setMode(mode);
  			component.clieTable.setMode(mode);
  			component.oBtnAddCent.setEnabled(value);
  			component.oInputCenter.setEnabled(value);
  	  		component.centerTable.setMode(mode);
  	  		component.oBtnAddEmp.setEnabled(value);
  	  		component.oCheckNA.setEnabled(false);
  	  	/** FIN  MOD Modificar en auditorías cerradas 08/04/2021
  		* 
   		*/
  	  		
  		//}
  	},
  	
  	onSelectNA: function(oEvent) {
  		var component = sap.ui.getCore().getComponent("FraudeComp");
  		if(component){
  			// Recuperamos el estado del check
  			var isSelected = oEvent.getSource().getSelected();
  			
  			// Activamos/desactivamos el input
  			component.oInputEmp.setEnabled(!isSelected);
  			component.oBtnAddEmp.setEnabled(!isSelected);
  			
  			// Habilitamos los campos de editables
  			component.empTable.setMode(isSelected ? sap.m.ListMode.None : sap.m.ListMode.Delete);
  			
  			// Habilitamos el campo Resolución en table empleados
			var oModel = component.empTable.getModel();
			var data = oModel ? oModel.getData().results ? oModel.getData().results : undefined : undefined;
			if(data){
				$.each(data,function(i,n){
					n.Editable = !isSelected;
				})
				
				component.empTable.bindAggregation("", "/results", component.empTableTemplate);
				component.empTable.bindItems({path:"/results",template:component.empTableTemplate});
				component.empTable.updateBindings(true);
			}
			
			// Se ocultan / muestran los valores
			if(isSelected) {
				component.empTable.unbindAggregation("");
			} else {
				component.empTable.bindAggregation("", "/results", component.empTableTemplate);
				component.empTable.bindItems({path:"/results",template:component.empTableTemplate});
				component.empTable.updateBindings(true);
			}
			
  		}
  	},
  
});