//define a new UIComponent 
jQuery.sap.require("sap.ui.core.UIComponent");
jQuery.sap.require("sap.m.Table");
jQuery.sap.require("sap.m.VBox");
jQuery.sap.declare("tablePagination.Component");

sap.ui.define([
	"sap/ui/core/UIComponent"
], function (UIComponent) {
	"use strict";

	return UIComponent.extend("tablePagination.Component", {

		init : function () {
			// call the init function of the parent
			UIComponent.prototype.init.apply(this, arguments);
		},
		
		createContent: function(){
			//Esto es para que funcione en IE i en Fiori
			var screenWidth = window.innerWidth || document.body.clientWidth;
			var width;
			if(screenWidth >= 1280){
				width = "1280px";
			}else{
				width = screenWidth + "px";
			}
			

			//Creo la taula buida
			this.table = new sap.m.Table({
				width:width, //Canviar per un 100% si es vol responsive, pero no funcionara amb IE
		    });
			
			var table = this.table;
			
			this.oFlex = new sap.m.FlexBox({
				width:width,
				height:"100%",
				direction:"Column",
				displayInline: true,
				alignItems: sap.m.FlexAlignItems.Center,
				fitContainer:true,
				items:[
				       table
				]
			});
			
			return this.oFlex;
		},
		//En aquesta funció li passo les columnes que vull que tingui la taula en un array 
		addColumns: function(columns,numVisible){
			var table = this.table;
			//Afegeixo les columnes a la taula
			$.each(columns, function(i,value){
				if(numVisible == 0 || numVisible == undefined || numVisible > i){
					var col = new sap.m.Column({
						hAlign:"Left",
						header: new sap.m.Text({
							text:value
						})
					});
					table.addColumn(col);
				}else{
					var col = new sap.m.Column({
						hAlign:"Left",
						visible: false,
						header: new sap.m.Text({
							text:value
						})
					});
					table.addColumn(col);
				}
					
			});
		},
		//funcó per bindejar les dades a la taula
		addItemTemplate: function(a,b,c){
			this.table.bindAggregation(a,b,c);
			this.ruta = b;
		},
		//funció que fica el model de dades a la taula
		setDataModel: function(model){
			this.table.setModel(sap.ui.getCore().getModel(model));
		},
		//funció que crea el menú de paginació
		createPaginationMenu: function(model, elementsForPage, id){
		
			//Obting el numero total de files
			var numberOfRows = sap.ui.getCore().getModel(model).getData().results.length;
			var numberOfPages = Math.ceil(numberOfRows / elementsForPage);
			
			if(numberOfPages > 1){
				//Un cop tinc el model ja puc saber el nombre de files que tindre, agafo el vBox i li assigno el paginador
				var oFlex = this.oFlex;
				if(oFlex.getItems()[1]){
					oFlex.getItems()[1].destroy();
				}
				oFlex.addItem(new sap.ui.commons.Paginator({
			           numberOfPages: numberOfPages,
			    	   currentPage: 1,
			    	   page : function(oEvent) {
			    		   sap.ui.getCore().getComponent(id).refreshTableVisibility(oEvent.getParameter("targetPage"), elementsForPage);
			    		   //alert('Page event type: ' + oEvent.getParameter("type") + '\nCurrent Page: ' + oEvent.getParameter("srcPage") + '\nTarget Page: ' + oEvent.getParameter("targetPage"));
			    	   }
			       })
				);
			}
			//Ara fem visibles les files que toca i invisibles les que no
			this.refreshTableVisibility(1,elementsForPage);      
		},
		
		refreshTableVisibility: function(pageNumber, elementsForPage){
			var initialElement = elementsForPage * (pageNumber - 1); //El primer element que ha de ser visible
			var finalElement = pageNumber * elementsForPage; //L'ultim element que ha de ser visible
			var table = this.table;
			$.each(table.getItems(),function(i, value){
				if(i >= initialElement && i < finalElement)
					value.setVisible(true);
				else
					value.setVisible(false);
			});
		},
		
		refreshTablePaginationForFilteredItems: function(pageNumber, elementsForPage){
			var initialElement = elementsForPage * (pageNumber - 1); //El primer element que ha de ser visible
			var finalElement = pageNumber * elementsForPage; //L'ultim element que ha de ser visible
			var table = this.table;
			//Comprovem si el vBox te un paginador i si el te l'elimino
			var oFlex = this.oFlex;
			if(oFlex.getItems()[1]){
				oFlex.getItems()[1].destroy();
			}
			
			//Si el nombre d'elements que retorna el filtre es major al nombre d'elements per pàgina, em de crear un nou paginador
			var numberOfElements = table.getVisibleItems().length;
			if(numberOfElements > elementsForPage){
				//Obting el numero total de files
				var numberOfRows = this.table.getVisibleItems().length;
				var numberOfPages = Math.ceil(numberOfRows / elementsForPage);
				oFlex.addItem(new sap.ui.commons.Paginator({
			           numberOfPages: numberOfPages,
			    	   currentPage: 1,
			    	   page : function(oEvent) {
			    		   sap.ui.getCore().getComponent(oEvent.getSource().getParent().getParent().sId).refreshTableVisibility(oEvent.getParameter("targetPage"), elementsForPage);
			    		   //alert('Page event type: ' + oEvent.getParameter("type") + '\nCurrent Page: ' + oEvent.getParameter("srcPage") + '\nTarget Page: ' + oEvent.getParameter("targetPage"));
			    	   }
			       })
				);
				
				//refresco els items visibles de la taula
				$.each(table.getVisibleItems(),function(i, value){
					if(i >= initialElement && i < finalElement)
						value.setVisible(true);
					else
						value.setVisible(false);
				});
			}else{
				//enseño tots els items
				$.each(table.getItems(),function(i, value){
					value.setVisible(true);
				});
			}
		},
		
		setCustomToolbar: function(toolbar){
			this.table.setHeaderToolbar(toolbar);
		},
		
		setMode: function(mode){
			this.table.setMode(mode);
		},
		
		setCountFunction: function(funct){this.countFunc = funct;},
		
		getVisibleColumns: function() {
			var items = [];
			var table = this.table;
			$.each(table.getColumns(),function(i,n){ if(n.getVisible() == true){items.push(n);} });
			return items;
		},
		
		getVisibleColumnsIndexs: function() {
			var items = [];
			var table = this.table;
			$.each(table.getColumns(),function(i,n){ if(n.getVisible() == true){items.push(n._index);} });
			return items;
		},
		
		exportToExcel: function(fileName){
			//Cojo las cabeceras de la tabla.
			var CSV="";
			var headerRow = "";
			$.each(this.table.getColumns(),function(i,n){
				headerRow+= '"' + n.getAggregation("header").getProperty("text") + '";';
			});
			//headerRow.slice(0,headerRow.length - 1);
			CSV+= headerRow + '\r\n';
			
			var visibleColIdx = this.getVisibleColumnsIndexs();
			
			$.each(this.table.getItems(),function(i,n){
				var row = "";
				$.each(visibleColIdx,function(j,k){
					if(j>0)
						var value = n.getAggregation("cells")[j].getProperty("text");
						if(value == "") value = " ";
							row += '"' + value + '";';
					var value = n.getAggregation("cells")[j].getProperty("text");
				});
				CSV += row + '\r\n';
			});
			download(CSV,fileName + ".csv", "text/plain");
		}
		
	});
			
});