jQuery.sap.declare("appDataQ.Component");

sap.ui.core.UIComponent.extend("appDataQ.Component",{
	metadata:{
		includes: [
			   "utils/utils.js",
			   "utils/conUtils.js",
			   "css/style.css",
			   "utils/encodingUtils.js",
			   "model/oDataGenerator.js",
			   "utils/constants.js",
			   "utils/dynamicFieldsHelper.js",
			   "utils/matchcodeHelper.js",
			   "utils/tablefieldsHelper.js",
			   "listaFilterComponent/Component.js",
			   "tablePagination/Component.js",
			   "searchComponent/Component.js",
			   "visualitzadorColumnesComponent/Component.js",
			   "fragment/Comentario.fragment.js",
			   "fragment/ComentarioMasAdjunto.fragment.js",
			   "fragment/Conclusion.fragment.js",
			   "Download/download.min.js",
			   "lists/listComponent/Component.js",
			   "Fraude/Component.js",
			   "fragment/AddClasificacionIE.fragment.js"
		], dependencies : { // external dependencies
			libs: ["sap.ui.commons"]
		},
		config : {
			fullWidth : true
		}
	},
	
	destroy : function() {
        if(sap.ui.getCore().byId("dataQCont")) sap.ui.getCore().byId("dataQCont").destroy();
        sap.ui.core.UIComponent.prototype.destroy.apply(this, arguments);
	},
	
	createContent : function(){
		zpa.grcaud.dataqmodel.initializeConections();
		
		var oView = sap.ui.view({
			id:"dataQNavCont", 
			height: "100%", 
			viewName:"appDataQ.view.DataQNavContainer", 
			type:sap.ui.core.mvc.ViewType.JS,
			viewData : { component : this }
		});
		
		var oModel = new sap.ui.model.json.JSONModel();
        sap.ui.getCore().setModel(oModel,"modelDataQ");
        
		return oView;
	},
	
//	createDBConnection: function() {
//		this.con = {};
//	    this.con.Model = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/", false);
//	    //sap.ui.getCore().setModel(con.Model,"con");
//	},
//	
//	getDBConnection: function() {
//		return this.con.Model;
//	}
	
});

