jQuery.sap.declare("listaFilterComponent.Component");
jQuery.sap.require("sap.ui.core.UIComponent");

sap.ui.core.UIComponent.extend("listaFilterComponent.Component", {		
		metadata: {
	         properties: {
	              refObject: {
	            		type: 'string',
	            		defaultValue: ''
	              }
	         }
		},
		
	   	setRefObject: function (refObject) {
			this.setProperty("refObject", refObject, true);
			var that = this;
			var oComponent = sap.ui.getCore().getComponent(this.getRefObject());
			var confirmFunction = function(oEvent){			

			     var oTable = sap.ui.getCore().getComponent(refObject).table;
			     var mParams = oEvent.getParameters();
			     var oBinding = oTable.getBinding("");
		 
			     // apply grouping
			     var aSorters = [];
			     if (mParams.groupItem) {
			         var sPath = mParams.groupItem.getKey();
			         var bDescending = mParams.groupDescending;
			         var vGroup = function(oContext) {
			             var name = oContext.getProperty(mParams.groupItem.mProperties.key);
			             return {
			                 key: name,
			                 text: name
			             };
			         };
			         aSorters.push(new sap.ui.model.Sorter(sPath, bDescending, vGroup));
			     }
		 
			     // apply sorter
			     var sPath = mParams.sortItem.getKey();
			     var bDescending = mParams.sortDescending;
			     aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
			     oBinding.sort(aSorters);
		 
			     // apply filters
			     var filters = [];

				 $.each(oEvent.getParameters().filterItems,function(j,value2){
					var field  = oEvent.getParameters().filterItems[j].oParent.mProperties.key;
					if(field == "SubmittedDateTime") {
						var date = oEvent.getParameters().filterItems[j].mProperties.text;
						var splitted = date.split("/");
						date = splitted[2] + "/" + splitted[1] + "/" + splitted[0];
						var startDate = new Date(date);
						var endDate = new Date(date + " 23:59:59");
						var filteredData = getModel('informes').getData().results.filter(function(a){return new Date(a.SubmittedDateTime) > startDate && new Date(a.SubmittedDateTime) < endDate;});
						
						$.each(filteredData, function(k,m){
							filters.push(new sap.ui.model.Filter("Key",sap.ui.model.FilterOperator.EQ, m.Key));
						});
						
					}
					else
						filters.push(new sap.ui.model.Filter(field,sap.ui.model.FilterOperator.EQ, oEvent.getParameters().filterItems[j].mProperties.text));
				 });
				 oBinding.filter(filters);
				 
				 sap.ui.getCore().getComponent(refObject).refreshTablePaginationForFilteredItems(1,10);
			};
			
			this.dialog.attachConfirm(confirmFunction);
		},
		
		init : function () {
			// define variable for control initial loading handling
		    this._bInitialLoading = true;
			   // execute standard control method
		    sap.ui.core.UIComponent.prototype.init.apply(this,arguments);
		},
		
		createContent: function(){
			this.dialog = new sap.m.ViewSettingsDialog({});
		},
		
		addAllItems: function(sortItems, groupItems, filterItems, model,claus,table){
			
			var dialog = this.dialog;
			var that = this;
			this.sortItems = sortItems;
			this.claus = claus;
			
			$.each(sortItems, function(i,value){
				var selected = (i == 1);
				dialog.addSortItem(
					new sap.m.ViewSettingsItem({
				    	text: value,
				    	key: claus[i],
				    	selected:selected
				    })
				);
			});
			
			$.each(groupItems, function(i,value){
				dialog.addGroupItem(
					new sap.m.ViewSettingsItem({
				    	text: value,
				    	key: claus[i],
				    	selected:false
				    })
				);
			});
			
			var oModel = sap.ui.getCore().getModel(model);
			
			$.each(filterItems, function(i,value){
				//Miro els items que hi han, i si sa n'han filtrat els descarto
				var tableItems = table.getItems();
				var items = [];
				//Per cada item visible, que es un objecte, faig el que li pertoca 
				$.each(tableItems, function(j,n){
					if(!that.mirarRepetit(items,sap.ui.getCore().getModel(model).getProperty(tableItems[j].getBindingContext().sPath)[claus[i]])){
						if(claus[i] == "SubmittedDateTime")
							items.push(new sap.m.ViewSettingsItem({
								text: listaInfoUtils.convertDate(sap.ui.getCore().getModel(model).getProperty(tableItems[j].getBindingContext().sPath)[claus[i]])
							}));
						else 
							items.push(new sap.m.ViewSettingsItem({
								text: sap.ui.getCore().getModel(model).getProperty(tableItems[j].getBindingContext().sPath)[claus[i]]
							}));
					}
				});
				
				var selected = (i == 1);
				dialog.addFilterItem(
						new sap.m.ViewSettingsFilterItem({
							setModel: oModel,
							text:value,
							key: claus[i],
							items:[
							    items   
							]
						})
				);
			});
		},
		
		openDialog: function(){
			this.dialog.open();
		},
		
		mirarRepetit: function(array, item){
			var trobat = false
			if(item == undefined || item == "" || item == null) trobat = true;
			$.each(array, function(i,n){
				if(array[i].mProperties.text.toLowerCase() == item.toLowerCase()){
					trobat = true;
				}	
			});
			return trobat;
		}
//	});
	
});