sap.ui.jsfragment ("fragment.addClasificacionIE",{
	createContent: function (oController ) {
		var oFragment =  new sap.ui.comp.smarttable.SmartTable({
			id : "addClasificacionIESmartTable",
			smartFilterId : "smartFilterBar",
			tableType : "ResponsiveTable",
				useExportToExcel : false,
				useVariantManagement : false,
				useTablePersonalisation : true,
				showRowCount : true,
				persistencyKey : "SmartTableAnalytical_addFindRel",
				enableAutoBinding : true,
				class : "sapUiResponsiveContentPadding",
				demandPopin : "true", 		
				initiallyVisibleFields : "ID,Sequence,Title,TypeText,CategoryText,RankingText,StatusText,ActionCount,OrgID",
				requestAtLeastFields : "DBKey,OrgKey,ID,Sequence,Title,TypeText,CategoryText,RankingText,Status,StatusText,ActionCount,OrgID,OrgName,ImportedOrg,OrgTimestamp",
				ignoreFromPersonalisation : "DBKey,AuditGroup,AuditKey,OrgKey,OrgTimestamp,ImportedOrg,AuditTitle,Type,Status,Recommendation,Description,Criteria,CauseDescription,ConditionDescription,ConsequenceDescription,Category,Tags,CreatedBy,LastChangedBy",
				customToolbar : [
					new sap.ui.comp.smarttable.customToolbar({
						id: "customerToolBar",
						Toolbar: [
							new sap.ui.m.Toolbar({
								content:[
									new sap.m.Text({
										text : "{i18n>labelAccessibility}",
										visible : false
									})
								]
							}),
							new sap.m.Table({
								id : "addClasificacionIE",
								mode : "MultiSelect",
								ariaLabelledBy : "findhiddenText1",
								updateFinished : "onUpdateFinished",
								items : "{/ClasificacionIEData}",
								columns: [
									new sap.m.Column({
										hAlign : "Left",
										customData : [
											new sap.ui.core.CustomData({
												key : "p13nData",
												value : '\{"columnKey": "topic_text","sortProperty": "topic_text", "filterProperty": "topic_text", "columnIndex":"0"}'
											})
										],
										content: [
											new sap.m.Text({
												text : "{i18n>colTema}"
											})
										]
									}),
									new sap.m.Column({
										hAlign : "Left",
										customData : [
											new sap.ui.core.CustomData({
												key : "p13nData",
												value : '\{"columnKey": "subtopic_text","sortProperty": "subtopic_text", "filterProperty": "subtopic_text","columnIndex":"2"}'
											})
										],
										content: [
											new sap.m.Text({
												text : "{i18n>colSubTema}"
											})
										]
									}),
									
								],
								items: [
									new sap.m.ColumnListItem({
										cells: [
											new sap.m.Text({
												text : "{topic_text}",
											}),
											
											new sap.m.Text({
												text : "{subtopic_text}",
											}),
										]
									})
								]
							})
						]
					}),
					
				]
		});
		return oFragment; 
	} 
});