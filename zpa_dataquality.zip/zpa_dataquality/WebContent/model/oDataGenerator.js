
//-------------------> Connection section <------------------------//
var zpa = {};
zpa.grcaud = {};
zpa.grcaud.dataqmodel = {};

zpa.grcaud.dataqmodel.initializeConections = function(){
  zpa.grcaud.dataqmodel.con = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/", false);
  zpa.grcaud.dataqmodel.conPtl = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/", false);
  zpa.grcaud.dataqmodel.conStd = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/GRCAUD_SRV/", false);
}

zpa.grcaud.dataqmodel.editState = "";

zpa.grcaud.dataqmodel.getConection = function(name){
  switch(name){
  case"con":
    return zpa.grcaud.dataqmodel.con;
    break;
  case "ptlCon":
    return zpa.grcaud.dataqmodel.conPtl;
    break;
  case "stdCon":
    return zpa.grcaud.dataqmodel.conStd;
    break;
  }
}

zpa.grcaud.dataqmodel.models = [];
zpa.grcaud.dataqmodel.createModel = function(oData,name){
  zpa.grcaud.dataqmodel.models[name] =  oData;
}

zpa.grcaud.dataqmodel.getModel = function(name){
  return zpa.grcaud.dataqmodel.models[name];
}

//-------------------> End section <-------------------------------//

//--------------------> Data section <------------------------------//

zpa.grcaud.dataqmodel.loadData = function(oModel,auditId,group,tab_info){
  this.oPage.setBusy(true);
  var con = zpa.grcaud.dataqmodel.getConection("con");
  con.refreshSecurityToken();
  con.read("/DynDataQ_Get?ID='" + auditId + "'&GROUP='" + group + "'&TAB_INFO='" + tab_info + "'",{//2016-069
    async: false,
    success: function(oData, oDataRes){
      oModel.setData(oData);
    }.bind(this),
    error: function(oError){
      var msg = $(oError.response.body).find('message').first().text();
      switch(group){
        case "FIND":
          this.oInfoFindingMessageStrip.setText(msg);
          this.oInfoFindingMessageStrip.setType("Error");
          this.oInfoFindingMessageStrip.setVisible(true);
          break;
        case "ACTION":
          this.oInfoPlAccionMessageStrip.setText(msg);
          this.oInfoPlAccionMessageStrip.setType("Error");
          this.oInfoPlAccionMessageStrip.setVisible(true);
          break;
        default:
          this.oInfoAuditMessageStrip.setText(msg);
          this.oInfoAuditMessageStrip.setType("Error");
          this.oInfoAuditMessageStrip.setVisible(true);
          break;
      }
    }.bind(this)
  });
  this.oPage.setBusy(false);
}
//INI PPM100076335 - Pestaña clasificacionIE - VISIBILIDAD DEL CHECK CLASIFICACION IE
zpa.grcaud.dataqmodel.loadDataClasificacionIE = function(auditId,group,tab_info){
  var tab = tab_info;
  this.oPage.setBusy(true);
  var con = zpa.grcaud.dataqmodel.getConection("con");
  con.refreshSecurityToken();
  con.read("/DynDataQ_Get?ID='" + auditId + "'&GROUP='" + group + "'&TAB_INFO='" + tab_info + "'",{//2016-069
    async: false,
    success: function(oData, oDataRes){

      if(tab === "REPORT")
      {
        if(oData.results[3].Value !== "INFIE")
        {
          this.oPage.oParent.aChecks[5].setEnabled(false);
        }
      }else
      {
        if(oData.results[45].Value !== "05" && oData.results[45].Value !== "07" && oData.results[45].Value !== "08" && oData.results[45].Value !== "18")
        {
          this.oPage.oParent.aChecks[5].setEnabled(false);
        }
      }

    }.bind(this),
    error: function(oError){
    }.bind(this)
  });
  this.oPage.setBusy(false);
}
//FIN PPM100076335 - Pestaña clasificacionIE - VISIBILIDAD DEL CHECK CLASIFICACION IE

//INI PPM100077498 - Pestaña encuestas - VISIBILIDAD DEL CHECK ENCUESTAS
zpa.grcaud.dataqmodel.loadDataEncuestas = function(auditId,group,tab_info){
  var tab = tab_info;
  this.oPage.setBusy(true);
  var con = zpa.grcaud.dataqmodel.getConection("con");
  con.refreshSecurityToken();
  con.read("/DynDataQ_Get?ID='" + auditId + "'&GROUP='" + group + "'&TAB_INFO='" + tab_info + "'",{//2016-069
    async: false,
    success: function(oData, oDataRes){

      if(tab === "REPORT")
      {
        //Categoria
        if(oData.results[3].Value !== "INFSSCC" && oData.results[3].Value !== "INFINC")
        {
          if(oData.results[3].Value === "INFVO")
          {
            //Clasificacion
            if(oData.results[2].Value === "D" || oData.results[2].Value === "E")
            {
              this.oPage.oParent.aChecks[6].setEnabled(false);
            }
          }
        }
      }else
      {
        if(oData.results[45].Value !== "05" && oData.results[45].Value !== "07" && oData.results[45].Value !== "08" && oData.results[45].Value !== "18")
        {
          this.oPage.oParent.aChecks[6].setEnabled(false);
        }
      }

    }.bind(this),
    error: function(oError){
    }.bind(this)
  });
  this.oPage.setBusy(false);
}
//FIN PPM100077498 - Pestaña encuestas - VISIBILIDAD DEL CHECK ENCUESTAS


zpa.grcaud.dataqmodel.loadDataStd = function(oModel,auditKey){
  var con = zpa.grcaud.dataqmodel.getConection("stdCon");
  var arrAditTeam = [];
  this.auditTeam = {};
  con.refreshSecurityToken();
  con.read("ObjectTypeSet('AUDIT')/Roles", {//2016-069
    async: false,
    success: function(oData){
      var userRoles = [];
      for (var i = 0; i < oData.results.length; i++) {
        if(JSON.parse(oData.results[i].TeamMember) && oData.results[i].ID !== "AUD_MGR"){
          userRoles.push(oData.results[i].ID);
        }
      }
      if(userRoles.length > 0) {
        var sRoleFilter = "?$filter=RoleID eq" + "'" + userRoles[0] + "'";
        for(var j = 1; j < userRoles.length; j++) {
          sRoleFilter = sRoleFilter.concat("or RoleID eq " + "'" + userRoles[j] + "'");
        }
        sRoleFilter = sRoleFilter.concat("&$orderby=RoleID desc");
      }
      con.read("/AuditSet(guid'" + auditKey + "')/UserRoles" + sRoleFilter,
          undefined,
          undefined,
          false,
          function(data, response) {
            for (var i = 0; i < response.data.results.length; i++) {

              var isFind = false;
              for (var j = 0; j < arrAditTeam.length; j++) {
                if (arrAditTeam[j].UserID === response.data.results[i].UserID) {
                  isFind = true;
                  break;
                }
              }
              if (isFind === false) {
                arrAditTeam.push(response.data.results[i]);
              }
            }
            oModel.setData(arrAditTeam);
          }, function(oError) {
            //console.log(oError);
          });
    }.bind(this),
    error: function(oError){
      //console.log(oError);
    }.bind(this)
  });
}

zpa.grcaud.dataqmodel.loadDropdown = function(index, input, dropdownField, url, odataModel){

  var oFieldsActionsEmptyEntry = ['ZZ_FOLLOW_UP','ZZ_ORIGEN','ZZ_RELEVANCE'];

  if(!odataModel){
    var odataModel = zpa.grcaud.dataqmodel.conStd;
  }
  odataModel.read(url, undefined, undefined,
      false, jQuery.proxy(
        function(data, response) {
         
          var oModel = new sap.ui.model.json.JSONModel(data);
         input.setModel(oModel);
           var bindingInfo = {path: "/results"};
           //ocontroller.auditTypes = data.results;
           var oTemplate;
           if(dropdownField.Objtyp === "FIND"){
             switch(dropdownField.FieldName){
              case "FULL_NAME":
                data.results.splice(0,0,{FullName: "", UserID: ""});
                bindingInfo.template = new sap.ui.core.ListItem({
                  text: "{FullName}",
                  key: "{UserID}"
                });
               break;
              case "TYPE":
                bindingInfo.template = new sap.ui.core.ListItem({
                  text: "{Description}",
                  key: "{Type}"
                });
                break;
              case "CATEGORY":
                bindingInfo.template = new sap.ui.core.ListItem({
                  text: "{Description}",
                  key: "{Category}"
                });
                break;
              case "RANKING":
                bindingInfo.template = new sap.ui.core.ListItem({
                  text: "{Description}",
                  key: "{Ranking}"
                });
                break;
              default:
                bindingInfo.template = new sap.ui.core.ListItem({
                  text: "{Value}",
                  key: "{Name}"
                });
                break;
             }
           }else{
             
             /**
              *  INI MOD RTC-633272  Rafael Galán Baquero 01/03/2019
              * Código nuevo
              */
             
            // Si es un campo Z de una auditoria, se añade la primera línea vacía al dropdown  (siempre que no sea ZZ__DEPARTAMENT)
              if( (dropdownField.Objtyp == "AUDIT" && ( dropdownField.FieldName.substr(0,3) == "ZZ_" && dropdownField.FieldName != "ZZ_DEPARTMENT" ) && input.getModel().getData().results != undefined) ||(dropdownField.Objtyp == "ACTION" && (
            	   dropdownField.FieldName.substr(0,3) == "ZZ_" && oFieldsActionsEmptyEntry.includes(dropdownField.FieldName)  && input.getModel().getData().results != undefined)) ){
              var empty = {Name:"", Value: ""};
             input.getModel().getData().results.unshift(empty);
              }
             /**
              * FIN MOD RTC-633272  Rafael Galán Baquero 01/03/2019
              */
             switch(dropdownField.FieldName){
              case "TYPE":
                if(dropdownField.Objtyp === "ACTION"){
                  bindingInfo.template = new sap.ui.core.ListItem({
                    text: "{Value}",
                    key: "{Name}"
                  });
                }else{
                  bindingInfo.template = new sap.ui.core.ListItem({
                    text: "{Description}",
                    key: "{TYPE}"
                  });
                }
                break;
              case "ZZ_DEPARTMENT":
                bindingInfo.template = new sap.ui.core.ListItem({
                  text: {parts: [{
                      path: 'AuditDepartment'
                      }, {
                      path: 'Text'
                      }],
                      formatter: function(dep, depName) {
                        return dep + ' - ' + depName
                      }
                  },
                  key: "{AuditDepartment}"
                });
                break;
              case "AUD_GROUP":
                bindingInfo.template = new sap.ui.core.ListItem({
                  text: "{Value}",
                  key: "{Name}"
                });
                bindingInfo.filters = [new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.StartsWith, this[index-1].Value)];
                break;
              default:
                bindingInfo.template = new sap.ui.core.ListItem({
                  text: "{Value}",
                  key: "{Name}"
                });
                break;
           }
             
           if(dropdownField.Tab === "WORK PROGRAM"){

              bindingInfo.template = new sap.ui.core.ListItem({
                text: "{FullName}",
                key: "{UserID}"
              });

              var obj = {};

              for (var i=0, len=data.results.length; i < len; i++ ){
                  obj[data.results[i]['UserID']] = data.results[i];
              }

              data.results = new Array();
              for (var key in obj ){
                  data.results.push(obj[key]);
              }
              data.results.splice(0,0,{FullName: "", UserID: ""});

              zpa.grcaud.dataqmodel.createModel(oModel,"responsablesModel");
            }    
         
         }
         
        
         input.bindAggregation("items", bindingInfo);
        }, this), jQuery.proxy(function(
        oError) {
   }, this));
},

zpa.grcaud.dataqmodel.loadRisksTables = function(group){

  var con = zpa.grcaud.dataqmodel.getConection("stdCon");
  if(group === "AUDIT"){
    var key = listaInfoUtils.convertKeyBinToGuid(zpa.grcaud.dataqmodel.getModel("firstCallModel").getData().results[0].Value);
    var url = "AuditSet(guid'" + key + "')/Risks?$orderby=Title%20asc";
  }else{
    var key = listaInfoUtils.convertKeyBinToGuid(zpa.grcaud.dataqmodel.getModel("findingModel").getData().results[1].Value);
    //guid auditoria
    var url = "Findings(guid'" + key + "')/Risks";
  }



  this.oSorter = new sap.ui.model.Sorter("ID", false);
  this.rightFilter = new sap.ui.model.Filter({
      filters: [],
      and: true
    });

  this.chosenRisks = {risks: [], count: 0, moves: []};
//  if(group === "FIND"){
//    this.chosenRisks.initial = {};
//  }

  con.read(url, { //riesgos iniciales
    async: false,
    success: function(oData){
      var oModel =  new sap.ui.model.json.JSONModel(oData);
      this.getView().oLeftList.setModel(oModel);
      this.getView().oLeftList.getBinding("items").sort(this.oSorter);

      for(var i = 0; i < oData.results.length; i++){
        this.rightFilter.aFilters.push(
          new sap.ui.model.Filter({
            path: "ID",
            operator: "NE",
            value1: oData.results[i].ID
          })
        );
        this.chosenRisks.risks.push({ContainerPos: "0", DepField: "", DepValue: "", Editable: "true", ExternalName: "",
            FieldLabel: "", FieldLength: "100", FieldName: "KEY", FieldOrder: "0",
            Function: "", Hier: "0", IdReg: "", Length: "0", Multiple: "false", Name: "KEY",
            Objtyp: group, Options: "", Required: "false", SeqFields: "00000", Service: "", Stauxiliar: "",
            Tab: "RISKS", Type: "STRING", TypeHier: "", Value: oData.results[i].Key.replace(/-/g, ""), ValueOrig: oData.results[i].Key.replace(/-/g, ""),
            Visible: "true"});
//        if(group === "FIND"){
//          this.chosenRisks.initial[oData.results[i].Key.replace(/-/g, "")] = {ContainerPos: "0", DepField: "", DepValue: "", Editable: "true", ExternalName: "",
//              FieldLabel: "", FieldLength: "100", FieldName: "KEY", FieldOrder: "0",
//              Function: "", Hier: "0", IdReg: "", Length: "0", Multiple: "false", Name: "KEY",
//              Objtyp: "FIND", Options: "", Required: "false", SeqFields: "00000", Service: "", Stauxiliar: "",
//              Tab: "RISKS", Type: "STRING", TypeHier: "", Value: oData.results[i].Key.replace(/-/g, ""), ValueOrig: oData.results[i].Key.replace(/-/g, ""),
//              Visible: "true"};
//        }
      }

      this.chosenRisks.count = this.chosenRisks.risks.length;
      if(group === "AUDIT"){
        url = "AuditSet(guid'" + key + "')/RiskAssignments";
      }else{
        url = "Findings(guid'" + key + "')/RiskAssignments";
      }
      con.read(url, {
        async: false,
        success: function(oData){
          this.chosenRisks.assignments = oData.results
        }.bind(this),
        error: function(oError){
        }.bind(this)
      });

      if(group === "AUDIT"){
        url = "RiskExtendedSet?$filter=Scenario eq 'riskRegister' and ViewID eq 'IA' and Timestamp eq datetime'2099-12-30T23:00:00'&$inlinecount=allpages";
      }else{
        /**
         * INI Incidencia 930629 28/12/2020 U0192021
         * Cod. antiguo
         * key =  listaInfoUtils.convertKeyBinToGuid(zpa.grcaud.dataqmodel.getModel("findingModel").getData().results[zpa.grcaud.dataqmodel.getModel("findingModel").getData().results.length-1].Value);
         * 
         * cod. nuevo
        */
        // Se filtra en el modelo para obtener la key de auditoría
        var element = zpa.grcaud.dataqmodel.getModel("findingModel").getData().results.filter(function(item) { return item.Name == 'AUDIT_KEY'; });
        if ( element.length > 0)
        key =  listaInfoUtils.convertKeyBinToGuid(element[0].Value);

        /**
         * FIN Incidencia 930629 28/12/2020 U0192021
         */
        url = "AuditSet(guid'" + key + "')/Risks?$orderby=Title%20asc"

      }
      con.read(url, { //todos los riesgos
        async: false,
        success: function(oData){
          var oModel =  new sap.ui.model.json.JSONModel(oData);
          this.getView().oRightList.setModel(oModel);
          this.getView().oRightList.getBinding("items").sort(this.oSorter);
          if(this.rightFilter.aFilters.length > 0){
            this.getView().oRightList.getBinding("items").filter([this.rightFilter]);
          }
        }.bind(this),
        error: function(oError){
        }.bind(this)
      });

    }.bind(this),
    error: function(oError){
    }.bind(this)
  });

}

zpa.grcaud.dataqmodel.getResponsable = function(){
  var con = zpa.grcaud.dataqmodel.getConection("stdCon");
  var url =  "ScopeSet(guid'" + listaInfoUtils.convertKeyBinToGuid(this.KEY) + "')?$expand=UserRoles";
  con.read(url, {
    async: false,
    success: function(oData){
      if(oData.UserRoles.results.length > 0){
        byId("inp_AUDIT-WORKPROGRAM-FULL_NAME-").setSelectedKey(oData.UserRoles.results[0].UserID);
        byId("inp_AUDIT-WORKPROGRAM-FULL_NAME-").data("lastValue", oData.UserRoles.results[0].UserID);
        var found = false;
        var i = 0;
        for(var i = 0; i < byId("detailScreen").oViewData.length; i++ /*&& !found*/){ //para mandar valor original de responsable
          if(byId("detailScreen").oViewData[i].FieldName === "FULL_NAME" && byId("detailScreen").oViewData[i].SeqFields === this.Seq){ //cambiar por while en el momento que no se envien duplicados
            byId("detailScreen").oViewData[i].ValueOrig = oData.UserRoles.results[0].UserID;
            //found = true;
          }
//          i++;
        }

      }else{
        byId("inp_AUDIT-WORKPROGRAM-FULL_NAME-").data("lastValue", "#NOVALUE");
      }
    }.bind(this),
    error: function(oError){
    }.bind(this)
  });
}

zpa.grcaud.dataqmodel.saveAudit = function(oEntity, seq, parentSeq){
  var odataModel = zpa.grcaud.dataqmodel.con;
  var url = "/DynDataQDeepSet";

  var that = this;

  odataModel.create(url, oEntity, false, function(dataResp){
    if(oEntity.DynDataQ[0].Tab === "WORK PROGRAM"){ //actualizamos array de paquetes de trabajo
      for(var i = 0; i < that.getView().work.length; i++){
        if(that.getView().work[i].Seq === seq){
          that.getView().work[i].NAME = byId("inp_AUDIT-WORKPROGRAM-NAME-").getValue();
          that.getView().work[i].DESCRIPTION = byId("inp_AUDIT-WORKPROGRAM-DESCRIPTION-").getValue();
          that.getView().work[i].FULL_NAME = byId("inp_AUDIT-WORKPROGRAM-FULL_NAME-").getSelectedKey();
          for(var j = 0; j < that.getView().work.length; j++){
            if(that.getView().work[j].Seq === parentSeq){
              that.getView().work[j].NAME = byId("inp_AUDIT-WORKPROGRAM-CODE-").getValue();
              for(i = 0; i < that.getView().work.length; i++){
                if(that.getView().work[i].PARENT_SCOPE === that.getView().work[j].KEY){ //actualizamos items con el mismo ambito
                  that.getView().selectWork.getItemByKey(that.getView().work[i].Seq).setText(that.getView().work[j].CODE + " " + that.getView().work[j].NAME + " " + that.getView().work[i].CODE + " " + that.getView().work[i].NAME);
                }
              }
              break;
            }
          }
          break;
        }
      }
    }
    var dialog = new sap.m.Dialog({
      title: 'Información',
      type: 'Message',
      content: new sap.m.Text({
        text: "Datos guardados correctamente para la pestaña " + that.getView().oIconTabBar.getSelectedKey() + "."
      }),
      beginButton: new sap.m.Button({
        text: 'Aceptar',
        press: function () {
          dialog.close();
          /*var currView = this.getView();
          var navCont = currView.getParent();
          navCont.getPreviousPage().getController().onResetScreen();
          navCont.getPreviousPage().oSearch.setValue("");
          navCont.to(navCont.getPreviousPage().sId);
          navCont.getPage(currView.sId).destroy();*/
        }
      }),
      afterClose: function() {
        dialog.destroy();
      }
    });
    dialog.open();
  },function(oError){
    //console.log(oError);
    if(oError.response){
      sap.m.MessageToast.show($(oError.response.body).find('message').first().text(), {duration: 1800});
    }
  });
}

//--------------------> End section <-------------------------------//
