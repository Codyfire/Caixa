// By -> http://tomeko.net/online_tools/base64.php?lang=en

var hD='0123456789ABCDEF';
function dec2hex(d) {
    var h = hD.substr(d&15,1);
    while (d>15) {
        d>>=4;
        h=hD.substr(d&15,1)+h;
    }
    return h;
}

var keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

function base64_decode(input) {
    var output = new Array();
    var chr1, chr2, chr3;
    var enc1, enc2, enc3, enc4;
    var i = 0;

    var orig_input = input;
    input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
    if (orig_input != input)
        console.error("Warning! Characters outside Base64 range in input string ignored.");
    if (input.length % 4) {
        console.error("Error: Input length is not a multiple of 4 bytes.");
        return "";
        }

        var j=0;
        while (i < input.length) {

            enc1 = keyStr.indexOf(input.charAt(i++));
            enc2 = keyStr.indexOf(input.charAt(i++));
            enc3 = keyStr.indexOf(input.charAt(i++));
            enc4 = keyStr.indexOf(input.charAt(i++));

            chr1 = (enc1 << 2) | (enc2 >> 4);
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            chr3 = ((enc3 & 3) << 6) | enc4;

            output[j++] = chr1;
            if (enc3 != 64)
              output[j++] = chr2;
            if (enc4 != 64)
              output[j++] = chr3;

        }
        return output;
    }


var base64_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    function binary_to_base64(input) {
      var ret = new Array();
      var i = 0;
      var j = 0;
      var char_array_3 = new Array(3);
      var char_array_4 = new Array(4);
      var in_len = input.length;
      var pos = 0;
  
      while (in_len--)
      {
          char_array_3[i++] = input[pos++];
          if (i == 3)
          {
              char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
              char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
              char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
              char_array_4[3] = char_array_3[2] & 0x3f;
  
              for (i = 0; (i <4) ; i++)
                  ret += base64_chars.charAt(char_array_4[i]);
              i = 0;
          }
      }
  
      if (i)
      {
          for (j = i; j < 3; j++)
              char_array_3[j] = 0;
  
          char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
          char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
          char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
          char_array_4[3] = char_array_3[2] & 0x3f;
  
          for (j = 0; (j < i + 1); j++)
              ret += base64_chars.charAt(char_array_4[j]);
  
          while ((i++ < 3))
              ret += '=';
  
      }
  
      return ret;
    }

function convertKey(base64_text) {
        var output = base64_decode(base64_text);
        var separator = "";
        var hexText = "";
        for (i=0; i<output.length; i++) {
          hexText = hexText + separator + (output[i]<16?"0":"") + dec2hex(output[i]);
        }

        //console.log(hexText);
        return hexText;
}

function recoverKey(hex_text) {
	if(hex_text.contains("-")) {
		hex_text = hex_text.replaceAll("-","");
	}
	
    if (hex_text.length % 2) {
      alert ("Error: cleaned hex string length is odd.");   
      return "";
    }
    var binary = new Array();
    for (var i=0; i<hex_text.length/2; i++) {
      var h = hex_text.substr(i*2, 2);
      binary[i] = parseInt(h,16);        
    }
    return binary_to_base64(binary);
  } 
