zpa.grcaud.tablefield = {};

zpa.grcaud.tablefield.oModel = {
	  inputEmpFlag : true,
	  valueHelpType : "",
	  valueHelpSource : "",
	  valueModel : "",
	  dataModel: {},
},


zpa.grcaud.tablefield.Obtain = function(service) {
	zpa.grcaud.tablefield.oModel.tableFieldModel = "/sap/opu/odata/sap/GRCAUD_SRV/";
	var key = zpa.grcaud.dataqmodel.models["findingModel"].getData().results[0].ValueOrig;
	var urlAppend = "";
	switch(service){
		case "ActionPlans":
			urlAppend = "Actions";
			break;
		case "RisksFind":
			urlAppend = "Risks";
			break;
	}
	zpa.grcaud.tablefield.oModel.tableFieldSource = "/Findings(guid'" + key.substring(0,8) + "-" + key.substring(8,12) + "-" + key.substring(12,16) + "-" + key.substring(16,20) + "-" + key.substring(20) + "')/"+ urlAppend;
	
	var conModel = new sap.ui.model.odata.ODataModel(zpa.grcaud.tablefield.oModel.tableFieldModel, false);
	conModel.read(zpa.grcaud.tablefield.oModel.tableFieldSource, {
		async: false,
		success : function (oData, oDataResp) {
			zpa.grcaud.tablefield.oModel.dataModel[service] = new sap.ui.model.json.JSONModel();
			zpa.grcaud.tablefield.oModel.dataModel[service].setData(oData);
       }.bind(this),
       error: function (oError) {
       }.bind(this)
	});
 }