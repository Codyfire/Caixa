// Funciones aóadidas al tipo String en Javascript

String.prototype.contains = function(it) { return this.indexOf(it) != -1; };

String.prototype.trim = String.prototype.trim || function() {
    return this.replace(/^\s+|\s+$/,"");
}

//Funciones aóadidas al tipo Date en Javascript

Date.prototype.toClean=function(){
    if(this!==null){
            var vDay = ((this.getDate())<10)?'0'+(this.getDate()):(this.getDate()),
                    oMonths = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
                    vMonth = oMonths[this.getMonth()],
                    vYear = this.getFullYear().toString().right(2);
                    
            return vDay+' '+vMonth+' \''+vYear;
    } else {
            return '[Invalid Date]';
    }
}

function validateForm(field){
	var input = byId("inp_" + field.Objtyp + "-" + field.Tab.replace(/\s/g, '') + "-" + field.FieldName + "-" + field.DepValue);
	if(input){
		if(byId("lbl_" + field.Objtyp + "-" + field.Tab.replace(/\s/g, '') + "-" + field.FieldName + "-" + field.DepValue).getRequired()) {
			switch(input.getMetadata().getName()){
				case "sap.m.Select":
					input.removeStyleClass("selectError");
					if(input.getSelectedItem() === null){
						input.addStyleClass("selectError");
						return true;
					}
					break;
				case "sap.m.DatePicker":
					input.setValueState("None");
					if(input.getValue() === ""){
						input.setValueState("Error");
						return true;
					}
					if(field.FieldName.indexOf("END") !== -1){
						var startStr = field.FieldName.replace("END", "START");
						if(byId("inp_" + field.Objtyp + "-" + field.Tab.replace(/\s/g, '') + "-" + startStr + "-").getValue() !== ""){
							if(input.getDateValue().getTime() < byId("inp_" + field.Objtyp + "-" + field.Tab.replace(/\s/g, '') + "-" + startStr + "-").getDateValue().getTime()){
								input.setValueState("Error");
								input.setValueStateText("Fecha anterior a fecha de inicio");
								return true;
							}
						}
					}
					break;
				default:
					input.setValueState("None");
					if(input.getValue() === ""){
						if(field.Tab === "WORK PROGRAM"){
							if(byId("srch_searchProgram").getSelectedKey() !== ""){
								input.setValueState("Error");
								return true;
							}
						}else{
							input.setValueState("Error");
							return true;
						}
					}
					break;
			}
		}
		
		//Comprobacion ambas fechas campos estandar no requeridos
		if(input.getMetadata().getName() === "sap.m.DatePicker" && field.FieldName.indexOf("ZZ") === -1){
			if(input.getValue() !== ""){
				input.setValueState("None");
				if(field.FieldName.indexOf("START") !== -1){//start
					var endStr = field.FieldName.replace("START", "END");
					if(byId("inp_" + field.Objtyp + "-" + field.Tab.replace(/\s/g, '') + "-" + endStr + "-").getValue() === ""){  //start con valor y end sin valor
						byId("inp_" + field.Objtyp + "-" + field.Tab.replace(/\s/g, '') + "-" + endStr + "-").setValueState("Error");
						return true;
					}
				}
				else if(field.FieldName.indexOf("END") !== -1){//end
					var startStr = field.FieldName.replace("END", "START");
					if(byId("inp_" + field.Objtyp + "-" + field.Tab.replace(/\s/g, '') + "-" + startStr + "-").getValue() !== ""){
						if(input.getDateValue().getTime() < byId("inp_" + field.Objtyp + "-" + field.Tab.replace(/\s/g, '') + "-" + startStr + "-").getDateValue().getTime()){
							input.setValueState("Error");
							input.setValueStateText("Fecha anterior a fecha de inicio");
							return true;
						}
					}else{//
						byId("inp_" + field.Objtyp + "-" + field.Tab.replace(/\s/g, '') + "-" + startStr + "-").setValueState("Error");
						return true;
					}
				}
			}
		}
	}
	return false;
}

function checkStringByTab(tabText){
	switch(tabText){
		case zpa.grcaud.Constants.TabGroups.Risks:
			return byId("selScreen").aChecks[1].getText();
			break;
		case zpa.grcaud.Constants.TabGroups.WorkProgram:
			return byId("selScreen").aChecks[2].getText();
			break;
		case zpa.grcaud.Constants.TabGroups.Fraud:
			return byId("selScreen").aChecks[3].getText();
			break;
		case zpa.grcaud.Constants.TabGroups.Report:
			return byId("selScreen").aChecks[4].getText();
			break;
		/*INI PPM100076335 - Pestaña clasificacionIE 03/08/2022*/
		case zpa.grcaud.Constants.TabGroups.ClassificationIE:
			return byId("selScreen").aChecks[5].getText();
			break;
		/*FIN PPM100076335 - Pestaña clasificacionIE 03/08/2022*/
		/*INI PPM100077498 - Pestaña Encuestas*/
		case zpa.grcaud.Constants.TabGroups.Encuestas:
			return byId("selScreen").aChecks[6].getText();
			break;
		/*FIN PPM100077498 - Pestaña Encuestas*/
		default:
			return byId("selScreen").aChecks[0].getText();
			break;
	}
}

function tabStringByCheck(checkText){
	switch(checkText){
		case byId("selScreen").aChecks[1].getText():
			return zpa.grcaud.Constants.TabGroups.Risks;
			break;
		case byId("selScreen").aChecks[2].getText():
			return zpa.grcaud.Constants.TabGroups.WorkProgram;
			break;
		case byId("selScreen").aChecks[3].getText():
			return zpa.grcaud.Constants.TabGroups.Fraud;
			break;
		case byId("selScreen").aChecks[4].getText():
			return zpa.grcaud.Constants.TabGroups.Report;
			break;
		/*INI PPM100076335 - Pestaña clasificacionIE 03/08/2022*/
		case byId("selScreen").aChecks[5].getText():
			return zpa.grcaud.Constants.TabGroups.ClassificationIE;
			break;
		/*FIN PPM100076335 - Pestaña clasificacionIE 03/08/2022*/
		/*INI PPM100077498 - Pestaña Encuestas*/
		case byId("selScreen").aChecks[6].getText():
			return zpa.grcaud.Constants.TabGroups.Encuestas;
			break;
		/*FIN PPM100077498 - Pestaña Encuestas*/
		default:
			return zpa.grcaud.Constants.TabGroups.Info;
			break;
	}
}

function getModel(name) {
	return sap.ui.getCore().getModel(name);
}

function byId(name) {
	return sap.ui.getCore().byId(name);
}

var listaInfoUtils = {};

// Mostrar mensaje de aplicación
listaInfoUtils.showMsg = function(text) {
	 sap.m.MessageToast.show(text, {duration: 8000});
}

//Convertir fecha "1987-09-23T00:00:00" a "23/09/1987"
listaInfoUtils.convertDate = function(date){
	if(date != "") {
		var dat = new Date(date);
		var day = dat.getDate() < 10 ? '0' + dat.getDate() : '' + dat.getDate();
		var month = dat.getMonth()+1;
		month = month < 10 ? '0' + month : '' + month;
		return day + "/" + month + "/" + dat.getFullYear();
	} else { return ""; }
}

//Función para convertir una key en binario a guid.
listaInfoUtils.convertKeyBinToGuid = function(key) {
	var part1 = key.substring(0,8);
	var part2 = key.substring(8,12);
	var part3 = key.substring(12,16);
	var part4 = key.substring(16,20);
	var part5 = key.substring(20);

	var convertedKey = part1 + "-" + part2 + "-" + part3 + "-" + part4 + "-" + part5;
	
	return convertedKey;

}