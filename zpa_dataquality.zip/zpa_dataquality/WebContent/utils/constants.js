zpa.grcaud.Constants = {
		SelChecks : [
			{
				string: "Info",
				icon: "sap-icon://hint",
				enabled: true
			},
			{
				string: "Riesgos",
				icon: "sap-icon://end-user-experience-monitoring",
				enabled: false
			},
			{
				string: "Programa de trabajo",
				icon: "sap-icon://course-program",
				enabled: false
			},
			{
				string: "Fraude",
				icon: "sap-icon://burglary",
				enabled: false
			},
			{
				string: "Informes",
				icon: "sap-icon://notes",
				enabled: false
			},
			/*INI PPM100076335 - Pestaña clasificacionIE 04/08/2022*/
			{
				string: "ClasificaciónIE",
				icon: "sap-icon://notes",
				enabled: false
			},
			/*FIN PPM100076335 - Pestaña clasificacionIE 04/08/2022*/
			/*INI PPM100077498 - Pestaña Encuestas*/
			{
				string: "Encuestas",
				icon: "sap-icon://notes",
				enabled: false
			},
			/*FIN PPM100077498 - Pestaña Encuestas*/
		]
		,
		FieldTypes : {
			String : "STRING",
			Key : "KEY",
			Num: "NUM",
			Date : "DATE",
			Text : "TEXT",
			Currency: "CURR",
			Effort: "EFFORT",
			Title: "TITLE",
			FormTitle: "FORMTITLE",
			Search: "SEARCH",
			Bar: "BAR",
			MatchcodeST: "MATCHCODE_ST",
			DropdownValue: "DROPDOWNVALUE"
		},
		FieldOptions : {
			Dropdown : "DROPDOWN",
			Matchcode : "MATCHCODE",
			Label: "LABEL"
		},
		TabGroups :	{
			Info: "INFO",
			Activity: "ACTIVITY",
			Risks: "RISKS",
			WorkProgram: "WORK PROGRAM", 
			Fraud: "FRAUDE",
			Finding: "FINDING",
			Report: "REPORT",
			/*INI PPM100076335 - Pestaña clasificacionIE 03/08/2022*/
			ClassificationIE: "CLASIFICACIONIE",
			/*FIN PPM100076335 - Pestaña clasificacionIE 03/08/2022*/
			/*INI PPM100077498 - Pestaña Encuestas*/
			Encuestas: "ENCUESTAS"
			/*FIN PPM100077498 - Pestaña Encuestas*/
		},
		Hier : {
			Flat : "0",
			Table : "1"
		},
		Work: {
			Parent_scope: "00000000000000000000000000000000"
		} 
};