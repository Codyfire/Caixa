zpa.grcaud.matchcode = {};

zpa.grcaud.matchcode.oModel = {
	  inputEmpFlag : true,
	  valueHelpType : "",
	  valueHelpSource : "",
	  valueModel : "",
	  valueHelpModel : new sap.ui.model.json.JSONModel()
},
	 
zpa.grcaud.matchcode.landValueHelp = function(oEventForm, field) {
	zpa.grcaud.matchcode.oModel.inputId = oEventForm.getSource().getId();
	zpa.grcaud.matchcode.oModel.valueHelpType = "land";
	zpa.grcaud.matchcode.oModel.valueModel = "/sap/opu/odata/sap/GRCAUD_SRV/";
	zpa.grcaud.matchcode.oModel.valueHelpSource = "/DataElementSet('LAND1')/NameValuePairs";
	  if (zpa.grcaud.matchcode.oValueHelpDialog) {
		  zpa.grcaud.matchcode.oValueHelpDialog.destroy();
	  }
	  zpa.grcaud.matchcode.oEvent = $.extend(true, {}, oEventForm);
	  zpa.grcaud.matchcode._createValueHelpDialog.call(zpa.grcaud.matchcode, oEventForm);
	  zpa.grcaud.matchcode.oValueHelpDialog.open();
 },
 


zpa.grcaud.matchcode.companyValueHelp = function(oEventForm, field) {
	zpa.grcaud.matchcode.oModel.inputId = oEventForm.getSource().getId();
	zpa.grcaud.matchcode.oModel.valueHelpType = "company";
	zpa.grcaud.matchcode.oModel.valueModel = "/sap/opu/odata/sap/GRCAUD_SRV/";
	zpa.grcaud.matchcode.oModel.valueHelpSource = "/DataElementSet('GRCAUD_COMPANY_CODE')/NameValuePairs";
	  if (zpa.grcaud.matchcode.oValueHelpDialog) {
		  zpa.grcaud.matchcode.oValueHelpDialog.destroy();
	  }
	  zpa.grcaud.matchcode.oEvent  = $.extend(true, {}, oEventForm);
	  zpa.grcaud.matchcode._createValueHelpDialog.call(zpa.grcaud.matchcode);
	  zpa.grcaud.matchcode.oValueHelpDialog.open();
},

zpa.grcaud.matchcode.userValueHelp = function(oEventForm, field) {
	zpa.grcaud.matchcode.oModel.inputId = oEventForm.getSource().getId();
	zpa.grcaud.matchcode.oModel.valueHelpType = "user";
	zpa.grcaud.matchcode.oModel.valueModel = "/sap/opu/odata/sap/GRCAUD_SRV/";
	
	
	zpa.grcaud.matchcode.oModel.valueHelpSource = "/RoleSet('" + field.DepValue + "')/Users";
	  if (zpa.grcaud.matchcode.oValueHelpDialog) {
		  zpa.grcaud.matchcode.oValueHelpDialog.destroy();
	  }
	  zpa.grcaud.matchcode.oEvent = $.extend(true, {}, oEventForm);
	  zpa.grcaud.matchcode._createValueHelpDialog.call(zpa.grcaud.matchcode, oEventForm);
	  zpa.grcaud.matchcode.oValueHelpDialog.open();
},

zpa.grcaud.matchcode.findRespValueHelp = function(oEventForm, field) {
	zpa.grcaud.matchcode.oModel.inputId = oEventForm.getSource().getId();
	zpa.grcaud.matchcode.oModel.valueHelpType = "findresp";
	zpa.grcaud.matchcode.oModel.valueModel = "/sap/opu/odata/sap/GRCAUD_SRV/";
	
	
	zpa.grcaud.matchcode.oModel.valueHelpSource = "/GetValueSet?Entity='Finding'&Field='" + field.FieldName + "'";
	  if (zpa.grcaud.matchcode.oValueHelpDialog) {
		  zpa.grcaud.matchcode.oValueHelpDialog.destroy();
	  }
	  zpa.grcaud.matchcode.oEvent = $.extend(true, {}, oEventForm);
	  zpa.grcaud.matchcode._createValueHelpDialog.call(zpa.grcaud.matchcode, oEventForm);
	  zpa.grcaud.matchcode.oValueHelpDialog.open();
},

zpa.grcaud.matchcode.actionRespValueHelp = function(oEventForm, field) {
	zpa.grcaud.matchcode.oModel.inputId = oEventForm.getSource().getId();
	zpa.grcaud.matchcode.oModel.valueHelpType = "actionresp";
	zpa.grcaud.matchcode.oModel.valueModel = "/sap/opu/odata/sap/GRCAUD_SRV/";
	
	
	zpa.grcaud.matchcode.oModel.valueHelpSource = "/GetValueSet?Entity='Action'&Field='" + field.FieldName + "'";
	  if (zpa.grcaud.matchcode.oValueHelpDialog) {
		  zpa.grcaud.matchcode.oValueHelpDialog.destroy();
	  }
	  zpa.grcaud.matchcode.oEvent = $.extend(true, {}, oEventForm);
	  zpa.grcaud.matchcode._createValueHelpDialog.call(zpa.grcaud.matchcode, oEventForm);
	  zpa.grcaud.matchcode.oValueHelpDialog.open();
},


zpa.grcaud.matchcode.actionARespValueHelp = function(oEventForm, field) {
	zpa.grcaud.matchcode.oModel.inputId = oEventForm.getSource().getId();
	zpa.grcaud.matchcode.oModel.valueHelpType = "actionAresp";
	zpa.grcaud.matchcode.oModel.valueModel = "/sap/opu/odata/sap/GRCAUD_SRV/";
	
	zpa.grcaud.matchcode.oModel.valueHelpSource = "/RoleSet('ACT_RESP')/Users";
	  if (zpa.grcaud.matchcode.oValueHelpDialog) {
		  zpa.grcaud.matchcode.oValueHelpDialog.destroy();
	  }
	  zpa.grcaud.matchcode.oEvent = $.extend(true, {}, oEventForm);
	  zpa.grcaud.matchcode._createValueHelpDialog.call(zpa.grcaud.matchcode, oEventForm);
	  zpa.grcaud.matchcode.oValueHelpDialog.open();
},

 
///*
//* build value help dialog
//*/
 zpa.grcaud.matchcode._createValueHelpDialog = function(oEventForm) {
	var that = this;
	// press search button
	var searchPress = function(oEvent) {
	  	var sInput = oEvent.getSource().getParent().getContent()[0].getValue();
	   	// var sSearchPath = this.oModel.valueHelpSource + "?$filter=FullName eq " + sInput.toUpperCase();//' and Value eq '*" + sInput + "*'"; 
	    // !!CAUTION: condition uses 'and', back end implements in or'
	    var aFilters = [];
	    var aSorters = [];
	    
	    switch(that.oModel.valueHelpType){
		    case "land":
		    	aFilters.push(new sap.ui.model.Filter("Name",sap.ui.model.FilterOperator.EQ, "*" + sInput.toUpperCase() + "*"));
		    	aFilters.push(new sap.ui.model.Filter("Value",sap.ui.model.FilterOperator.EQ, "*" + sInput.toUpperCase() + "*"));
		    	break;
		    case "company":
		    	aFilters.push(new sap.ui.model.Filter("Name",sap.ui.model.FilterOperator.EQ, "*" + sInput.toUpperCase() + "*"));
		    	aFilters.push(new sap.ui.model.Filter("Value",sap.ui.model.FilterOperator.EQ, "*" + sInput.toUpperCase() + "*"));
		    	break;
		    case "user":
		    	aFilters.push(new sap.ui.model.Filter("FullName",sap.ui.model.FilterOperator.EQ, "*" + sInput.toUpperCase() + "*"));
		    	break;
		    case "actionAresp":
		    	aFilters.push(new sap.ui.model.Filter("FullName",sap.ui.model.FilterOperator.Contains, sInput.toUpperCase()));
		    	break;
		    default:
		    	break;
	    }
		
	    var conModel = new sap.ui.model.odata.ODataModel(this.oModel.valueModel, true);
		 //sap.ui.getCore().setModel(con.Model,"con");
		    
	    var oTable = oEvent.getSource().getParent().getParent();
	    //var oODataModel = sap.hpa.grcaud.oODataModelPool.get();

	    zpa.grcaud.matchcode.oModel.valueHelpModel.oData.results = undefined;
	    zpa.grcaud.matchcode.oModel.valueHelpModel.refresh(true);
	    oTable.setBusy(true);
	    
	    // Read Z
	    conModel.read(zpa.grcaud.matchcode.oModel.valueHelpSource, {
			filters : aFilters,
			sorters: aSorters,
			
			async: true,
			success : function (oData, oDataResp) {
				zpa.grcaud.matchcode.oModel.valueHelpModel.setData(oData);
				if(that.oModel.valueHelpType === "findresp" || that.oModel.valueHelpType === "actionresp"){
					oTable.getBinding("items").filter([
		                   new sap.ui.model.Filter([
		                                 new sap.ui.model.Filter("Value",sap.ui.model.FilterOperator.Contains, sInput.toUpperCase()), 
		                                 new sap.ui.model.Filter("Name",sap.ui.model.FilterOperator.Contains, sInput.toUpperCase())], false
							)
					]);
				}
		        oTable.setBusy(false);
	       }.bind(this),
	       error: function (oError) {
	       	oTable.setBusy(false);
	       }.bind(this)
		});
	    
	};	

// select an item
  var itemSelected = function(oEvent) {
   var selectedItem = oEvent.oSource.getSelectedItem().getModel().getProperty(oEvent.oSource.getSelectedItem().getBindingContext().getPath());
   var multiple = false;
   switch(zpa.grcaud.matchcode.oModel.valueHelpType){
   	case "land":
	      sap.ui.getCore().byId(zpa.grcaud.matchcode.oModel.inputId).setValue(selectedItem.Value);
	      sap.ui.getCore().byId(zpa.grcaud.matchcode.oModel.inputId).getCustomData().forEach(function(data) {
	           if (data.getKey() == "id") {
	            data.setValue(selectedItem.Name);
	           }
	      });
	      sap.ui.getCore().byId(zpa.grcaud.matchcode.oModel.inputId).setValueState(sap.ui.core.ValueState.None);
	      break;
	     // this.oModel.inputCountryFlag = true;
   	case "company":
	      sap.ui.getCore().byId(zpa.grcaud.matchcode.oModel.inputId).setValue(selectedItem.Value);
	      sap.ui.getCore().byId(zpa.grcaud.matchcode.oModel.inputId).getCustomData().forEach(function(data) {
	           if (data.getKey() == "id") {
	            data.setValue(selectedItem.Name);
	           }
	      });
	      sap.ui.getCore().byId(zpa.grcaud.matchcode.oModel.inputId).setValueState(sap.ui.core.ValueState.None);
	      
	     // this.oModel.inputCountryFlag = true;
	      break;
   	case "user":
	      sap.ui.getCore().byId(zpa.grcaud.matchcode.oModel.inputId).setValue(selectedItem.Fullname);
	      sap.ui.getCore().byId(zpa.grcaud.matchcode.oModel.inputId).getCustomData().forEach(function(data) {
	           if (data.getKey() == "id") {
	            data.setValue(selectedItem.FullName);
	           }
	      });
	      sap.ui.getCore().byId(zpa.grcaud.matchcode.oModel.inputId).setValueState(sap.ui.core.ValueState.None);
	      multiple = true;
	      break;
	case "findresp":
		sap.ui.getCore().byId(zpa.grcaud.matchcode.oModel.inputId).setValue(selectedItem.Value);
	      sap.ui.getCore().byId(zpa.grcaud.matchcode.oModel.inputId).getCustomData().forEach(function(data) {
	           if (data.getKey() == "id") {
	            data.setValue(selectedItem.Name);
	           }
	      });
	      sap.ui.getCore().byId(zpa.grcaud.matchcode.oModel.inputId).setValueState(sap.ui.core.ValueState.None);
	      break;
	case "actionresp":
		sap.ui.getCore().byId(zpa.grcaud.matchcode.oModel.inputId).setValue(selectedItem.Value);
	      sap.ui.getCore().byId(zpa.grcaud.matchcode.oModel.inputId).getCustomData().forEach(function(data) {
	           if (data.getKey() == "id") {
	            data.setValue(selectedItem.Value);
	           }
	      });
	      sap.ui.getCore().byId(zpa.grcaud.matchcode.oModel.inputId).setValueState(sap.ui.core.ValueState.None);
	      break;
	case "actionAresp":
		byId(zpa.grcaud.matchcode.oModel.inputId).setValue(selectedItem.FullName).data("tokentoput", selectedItem.ID);
	      /*byId(zpa.grcaud.matchcode.oModel.inputId).getCustomData().forEach(function(data) {
	           if (data.getKey() == "id") {
	            data.setValue(selectedItem.FullName);
	           }
	      });*/
	      byId(zpa.grcaud.matchcode.oModel.inputId).setValueState(sap.ui.core.ValueState.None);
	      multiple = true;
	      break;
   }
   
   
   var multipleMatchCode = function(){
	   zpa.grcaud.matchcode.oEvent.getSource().setValue(selectedItem.FullName);
   };
   
   var notMultipleMatchCode = function(){
	   var viewName = "detailScreen";
	   if(zpa.grcaud.matchcode.oModel.valueHelpType.indexOf("find") === 0){
		   viewName = "findingDetailScreen";
	   }else if(zpa.grcaud.matchcode.oModel.valueHelpType.indexOf("action") === 0){
		   viewName = "planesAccionDetailScreen";
	   }
	   
	   $.grep(sap.ui.getCore().byId(viewName).oViewData, function(n,i){ 
		   if (n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue == zpa.grcaud.matchcode.oModel.inputId.replace("inp_", "")) {
			   n.Value = selectedItem.Name
			   n.Stauxiliar = selectedItem.Value;
		   }
	   });
   };
   
   if(!multiple){
	   notMultipleMatchCode();
   }else{
	   multipleMatchCode();
   }
   
   zpa.grcaud.matchcode.oValueHelpDialog.close();
   
  };
	  
	// search table to be put into value help dialog
  var oSearchTable = new sap.m.Table({
	     inset : true,
	     mode : sap.m.ListMode.SingleSelectMaster,
	     growing : true,
	     growingThreshold : 50,
	     growingScrollToLoad : true,
	     headerToolbar : new sap.m.Toolbar({
		     content : [
				        new sap.m.Input({value: byId(that.oModel.inputId).getValue(), width : "300px", change : [ searchPress, this ]}),
				        new sap.m.ToolbarSpacer({width : "1em"}),
				        new sap.m.Button({  type : sap.m.ButtonType.Emphasized, 
				        					text : /*sap.hpa.grcaud.oBundle.getText("BUTTON_SEARCH")*/ "Búsqueda",
				        					press : [ searchPress, this ]})
			  ],
	     }),
		     columns : [ 
		                 new sap.m.Column({
						      width : "35%",
						      vAlign : sap.ui.core.VerticalAlign.Middle,
						      header : new sap.m.Label({}),
						     }), 
						 new sap.m.Column({
						      width : "65%",
						      vAlign : sap.ui.core.VerticalAlign.Middle,
						      header : new sap.m.Label({}),
						     }), 
			],
	     select : function(oEvent){ itemSelected.call(this, oEvent);}
  });
  
  switch (that.oModel.valueHelpType){
  	case"land": 
	  	 oSearchTable.bindItems("/results",
	      	     new sap.m.ColumnListItem({
	  	    	      cells : [ 
	  	    	                new sap.m.Text({text : "{Name}"}), 
	  	    	                new sap.m.Text({text : "{Value}"}), 
	  	    	      ],
	      	     })
	  	 );
	  	 oSearchTable.getColumns()[0].getHeader().setText("Código país/región");
	  	 oSearchTable.getColumns()[1].getHeader().setText("País/región");
	  	 break;
  	case "company":
		  	 oSearchTable.bindItems("/results",
		      	     new sap.m.ColumnListItem({
		  	    	      cells : [ 
		  	    	                new sap.m.Text({text : "{Name}"}), 
		  	    	                new sap.m.Text({text : "{Value}"}), 
		  	    	      ],
		      	     })
		  	 );
		  	 oSearchTable.getColumns()[0].getHeader().setText("Sociedad");
		  	 oSearchTable.getColumns()[1].getHeader().setText("Nombre de empresa");
		  	 break;
  	case "user":
		  	oSearchTable.getColumns()[0].setWidth("33%").getHeader().setText("SAP ID");
		  	oSearchTable.getColumns()[1].setWidth("33%").getHeader().setText("Nombre");
		  	oSearchTable.addColumn(new sap.m.Column({
				header : new sap.m.Label({
					text : "Correo electrónico"
	          })
		  	}));
		  	
		  	 oSearchTable.bindItems("/results",
		      	     new sap.m.ColumnListItem({
		  	    	      cells : [ 
		  	    	                new sap.m.Text({text : "{ID}"}), 
		  	    	                new sap.m.Text({text : "{FullName}"}),
		  	    	                new sap.m.Text({text : "{Email}"}),
		  	    	      ],
		      	     }));
		  	 break;
  	case"findresp": 
	  	 oSearchTable.bindItems("/results",
	      	     new sap.m.ColumnListItem({
	  	    	      cells : [ 
	  	    	                new sap.m.Text({text : "{Name}"}), 
	  	    	                new sap.m.Text({text : "{Value}"}), 
	  	    	      ],
	      	     })
	  	 );
	  	 oSearchTable.getColumns()[0].getHeader().setText("Nombre de campo");
	  	 oSearchTable.getColumns()[1].getHeader().setText("Valor de campo");
	  	 break;
  	case"actionresp": 
	  	 oSearchTable.bindItems("/results",
	      	     new sap.m.ColumnListItem({
	  	    	      cells : [ 
	  	    	                new sap.m.Text({text : "{Name}"}), 
	  	    	                new sap.m.Text({text : "{Value}"}), 
	  	    	      ],
	      	     })
	  	 );
	  	 oSearchTable.getColumns()[0].getHeader().setText("Nombre de campo");
	  	 oSearchTable.getColumns()[1].getHeader().setText("Valor de campo");
	  	 break;
  	case "actionAresp":
	  	oSearchTable.getColumns()[0].setWidth("33%").getHeader().setText("SAP ID");
	  	oSearchTable.getColumns()[1].setWidth("33%").getHeader().setText("Nombre");
	  	oSearchTable.addColumn(new sap.m.Column({
			header : new sap.m.Label({
				text : "Correo electrónico"
          })
	  	}));
	  	
	  	 oSearchTable.bindItems("/results",
	      	     new sap.m.ColumnListItem({
	  	    	      cells : [ 
	  	    	                new sap.m.Text({text : "{ID}"}), 
	  	    	                new sap.m.Text({text : "{FullName}"}),
	  	    	                new sap.m.Text({text : "{Email}"}),
	  	    	      ],
	      	     }));
	  	 break;
  }
  
  oSearchTable.setModel(this.oModel.valueHelpModel);
	   
	 // create value help dialog
  	zpa.grcaud.matchcode.oValueHelpDialog = new sap.m.Dialog({
	    title : /*sap.hpa.grcaud.oBundle.getText("LABEL_SEARCH_TITLE")*/ "Búsqueda",
	    stretchOnPhone:true,
	    //  stretch : jQuery.device.is.phone, // when it is phone,stretch the search box to full screen
	    contentWidth : "600px",
	    contentHeight:"300px",
	    horizontalScrolling : false,
	    rightButton : new sap.m.Button({
	    						text : /*sap.hpa.grcaud.oBundle.getText("BTN_CANCEL")*/ "Cancelar",
	    						press : jQuery.proxy(function() { zpa.grcaud.matchcode.oValueHelpDialog.close(); }, this),
	    			  }),
	    content : [ oSearchTable ],
//		beforeOpen : [ this._dialogBeforeOpen, this ],
		afterClose : [ zpa.grcaud.matchcode._dialogAfterClose, this ],
		afterOpen : [ this, zpa.grcaud.matchcode._dialogAfterOpen ],
	  }); 
},	

zpa.grcaud.matchcode._dialogAfterOpen = function(oEvent, oControl) {
    var that = this;
    document.getElementById(that.getContent()[0].getHeaderToolbar().getContent()[2].getId()).focus();
},

zpa.grcaud.matchcode._dialogAfterClose = function(oEvent) {
	zpa.grcaud.matchcode.oModel.valueHelpModel.oData.results = undefined;
	zpa.grcaud.matchcode.oModel.valueHelpModel.refresh(true);
	zpa.grcaud.matchcode.oValueHelpDialog.getContent()[0].removeSelections(true);
	zpa.grcaud.matchcode.oValueHelpDialog.getContent()[0].getHeaderToolbar().getContent()[0].setValue("");
},

zpa.grcaud.matchcode.getTokens = function(){
	if(this.Objtyp === "ACTION"){
		switch(this.FieldName.toUpperCase()){
		case "FULL_NAME":
			var conModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/GRCAUD_SRV/", false);
			var key = listaInfoUtils.convertKeyBinToGuid(zpa.grcaud.dataqmodel.getModel("actionPlanModel").getData().results[0].Value);
			var url = "Actions(guid'" + key + "')/UserRoles?$filter=%20RoleID%20eq%20%27ACT_RESP%27";
			break;
		default: 
			break;
		}
	   conModel.read(url, {
			async: false,
			success : function (oData, oDataResp) {
				this.ValueOrig = "";
				for(var i = 0; i < oData.results.length; i++){
					byId("mlt_" + this.Objtyp + "-" + this.Tab.replace(/\s/g, '') + "-" + this.FieldName + "-" + this.DepValue).getItems()[0].addItem(new sap.m.Token({
						key: oData.results[i].UserID,
						text: oData.results[i].FullName,
						delete: function(){
							if(this.getParent().getItems().length === 1){
								this.getParent().setVisible(false);
							}
							this.destroy();
						}
					}));
					if(i !== 0){
						this.ValueOrig = this.ValueOrig + ",";
					}
					this.ValueOrig = this.ValueOrig + oData.results[i].UserID;
				}
				
				if(oData.results.length === 0){
					byId("mlt_" + this.Objtyp + "-" + this.Tab.replace(/\s/g, '') + "-" + this.FieldName + "-" + this.DepValue).getItems()[0].setVisible(false);
				}
				
	      }.bind(this),
	      error: function (oError) {
	      }.bind(this)
		});
	}
	
   
}