zpa.grcaud.createDynamicFields = function(fields, oController, tabString) {
	var tabFields = [];
	var that = this;
	that.table = {};
	that.labelTable = {}; 
	that.orderTable = {};
	
	function compare(a,b) {
	  if (parseInt(a.FieldOrder) < parseInt(b.FieldOrder))
	    return -1;
	  if (parseInt(a.FieldOrder) > parseInt(b.FieldOrder))
	    return 1;
	  return 0;
	}

	fields.sort(compare);
	
	//Segun el tab para el que queremos los datos
	var oContent = [];
	var workFields = [];
	if(oController.getView().getId() === "detailScreen"){
		tabFields = $.grep(fields,function(n,i){return n.Tab == tabString});
		if(tabString === "WORK PROGRAM"){
			for(var j = 0; j < tabFields.length; j++) { //agrupacion de ambitos y subambitos para programa de trabajo por seq
			    //var key = tabFields[j].Seq.toString();
				var y = 0;
				var found = false;
			    while(y < workFields.length && !found){
			    	if(workFields[y].Seq === tabFields[j].SeqFields){
			    		workFields[y][tabFields[j].FieldName] = tabFields[j].Value;
			    		found = true;
			    	}
			    	y++;
			    }
			    if(!found){
			    	workFields[workFields.length] = {};
			    	workFields[workFields.length-1].Seq = tabFields[j].SeqFields;
			    	workFields[workFields.length-1][tabFields[j].FieldName] = tabFields[j].Value;
			    }
			}
		}
		
		
	}else{
		tabFields = fields;
		if(oController.getView().getId() === "findingDetailScreen"){
			var panes = fields.map(function(a) {return parseInt(a.ContainerPos);});
			for(var i = 0; i <= Math.max.apply(null, panes); i++){
				oContent[i] = [];
			}
		}
	}
	
	var oTables = [];
	
	// Creamos los objetos de pantalla
	$.each(tabFields, function(i,n){
		//Opciones --> DROPDOWN or MATCHCODE
		var options = n.Options; 
		var hier = n.Hier;
		
		var width = Math.round(parseInt(n.FieldLength) * 12 / 100).toString();
		if(width === "12"){
			width = "auto";
		}
		
		switch (n.Hier) {
			case zpa.grcaud.Constants.Hier.Flat:
				if(byId("lbl_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue) && n.Type !== zpa.grcaud.Constants.FieldTypes.DropdownValue){
					byId("lbl_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue).destroy();
				}
				if(byId("inp_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue) && n.Type !== zpa.grcaud.Constants.FieldTypes.DropdownValue){
					byId("inp_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue).destroy();
				}
				if(byId("srch_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue) && n.Type !== zpa.grcaud.Constants.FieldTypes.DropdownValue){
					byId("srch_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue).destroy();
				}
				switch(n.Type){
					case zpa.grcaud.Constants.FieldTypes.String:
						var oLabel = new sap.m.Label("lbl_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue, { text: n.FieldLabel, required: JSON.parse(n.Required), layoutData: new sap.ui.layout.form.GridElementData({hCells: "4"})});
						if(options == "") {
							var oInput = new sap.m.Input("inp_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue, { value: n.Value, editable: JSON.parse(n.Editable), maxLength: parseInt(n.Length), change: function(oEvent) { tabFields[i].Value = this.getValue(); }, layoutData: new sap.ui.layout.form.GridElementData({hCells: width})});
							if(n.Tab === zpa.grcaud.Constants.TabGroups.WorkProgram){
								oInput.setValue("");
							}							
							
							if(n.Objtyp === "FIND"){
								oContent[parseInt(n.ContainerPos)].push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [ oInput ], visible: JSON.parse(n.Visible)}));
							}else{
								oContent.push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [ oInput ], visible: JSON.parse(n.Visible) }));
							}
						} else {
							if(options == zpa.grcaud.Constants.FieldOptions.Dropdown) {
								
								if(n.Value === "0000000000"){ //Tab info: proveedor
									n.Value = "";
								}
								
								var oInput = new sap.m.Select("inp_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue, {
									selectedKey: n.Value,
									enabled: JSON.parse(n.Editable),
									forceSelection: false,
									change: function(oEvent) { 
										tabFields[i].Value = this.getSelectedKey();
										tabFields[i].Stauxiliar = this.getSelectedItem().getText();
										if(tabFields[i].FieldName === "ZZ_DEPARTMENT"){
											var oFilter = new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.StartsWith, this.getSelectedKey());
											byId("inp_" + tabFields[i+1].Objtyp + "-" + tabFields[i+1].Tab.replace(/\s/g, '') + "-" + tabFields[i+1].FieldName + "-"+ tabFields[i+1].DepValue).getBinding("items").filter([oFilter]);
											///INICIO RTC597256 
											var oSelectGroup = byId("inp_" + tabFields[i+1].Objtyp + "-" + tabFields[i+1].Tab.replace(/\s/g, '') + "-" + tabFields[i+1].FieldName + "-" + tabFields[i+1].DepValue);
											oSelectGroup.getBinding("items").filter([oFilter]);
											oSelectGroup.setSelectedIndex(0);
											tabFields[i+1].Value = oSelectGroup.getSelectedKey();
											tabFields[i+1].Stauxiliar = oSelectGroup.getSelectedItem().getText();
											///FIN RTC597256 
										}
										/**
										 * INI MOD PPM057146 - AUM - Nuevos estados para Findings 
										 * Rafael Galán Baquero 16/10/2020
										 */
										// Se trata, cuando se realice un cambio en los campos ZZ_VERIFICIED ó ZZ_VERIFICIED_BPI, se asignará el valor del texto en su campo de texto
										else if( tabFields[i].FieldName === 'ZZ_VERIFIED' || tabFields[i].FieldName === 'ZZ_VERIFIED_BPI'){
	                                        //Se determina el campo en el que asignar el nuevo valor del texto
                                            var oFieldTextSearch = tabFields[i].FieldName === 'ZZ_VERIFIED' ? 'ZZ_VERIFIED_TEXT' : 'ZZ_VERIFIED_TEXT_BPI';
											var oVerifiedFieldText = tabFields.filter(function(item){
												return item.FieldName == oFieldTextSearch 
												});
											
											// Se asigna el nuevo valor, como valor antiguo se asigna el que tenía
												if (oVerifiedFieldText[0]){
													oVerifiedFieldText[0].ValueOrig = oVerifiedFieldText[0].Value;
													oVerifiedFieldText[0].Value = this.getSelectedItem().getText();
													oVerifiedFieldText[0].Stauxiliar = this.getSelectedItem().getText();
												}

										}
										
										//FIN Rafael Galán Baquero  PPM057146 - AUM - Nuevos estados para Findings 16/10/2020
									},
									layoutData: new sap.ui.layout.form.GridElementData({hCells: width})
								});
								
								var url = "";
								if(n.Function.indexOf("GRCAUD_") === 0){
									url = "/DataElementSet('" + n.Function + "')/NameValuePairs";
								}else if(n.Function.indexOf("GetValueSet") === 0){
									url= "/" + n.Function;
								}else{
									if(n.FieldName.indexOf("ZZ_") === 0){
										odataModel = zpa.grcaud.dataqmodel.conPtl;
									}
									if(n.Function === "AuditSet"){
										if(n.Objtyp === "FIND"){
											/**
											 * INI Incidencia 930629 28/12/2020 U0192021
											 * Cod. antiguo 				 			
											 * var key = tabFields[tabFields.length-1].Value;
											 * 
											 * cod. nuevo
											*/
											// Se filtra en el modelo para obtener la key de auditoría
											var element = zpa.grcaud.dataqmodel.getModel("findingModel").getData().results.filter(function(item) { return item.Name == 'AUDIT_KEY'; });
				                            if(element.length > 0)
											var key =  element[0].Value;
											
											/**
											 * FIN Incidencia 930629 28/12/2020 U0192021
											 */
											
											url = "/AuditSet(guid'" + listaInfoUtils.convertKeyBinToGuid(key) + "')/UserRoles?$filter= RoleID eq 'EXE_RESP'";
										}else{
											var key = "";
											var found = false;
											var j = 0;
											while(!found &&  j < tabFields.length){
												if(tabFields[j].Value !== "#NOVALUE" && tabFields[j].FieldName === "AUDIT_KEY"){
													key = tabFields[j].Value;
													found = true;
												}
												j++;
											}
											url = "/AuditSet(guid'" + listaInfoUtils.convertKeyBinToGuid(key) + "')/UserRoles?$filter= RoleID eq 'AUD_LEAD' or RoleID eq 'AUDITOR' or RoleID eq 'CAE'&$orderby=RoleID desc";
										}
									}else{
										url = "/" + n.Function;
									}
								}
								if(n.Tab === zpa.grcaud.Constants.TabGroups.WorkProgram){
									if(!zpa.grcaud.dataqmodel.getModel("responsablesModel")){ //para evitar multiples llamadas al llegar x "FULL_NAME"s
										zpa.grcaud.dataqmodel.loadDropdown.call(tabFields, i, oInput, n, url, odataModel);
									}else{
										
											function setResponsableModel(input){
												oInput.setModel(zpa.grcaud.dataqmodel.getModel("responsablesModel"));
												var bindingInfo = {path: "/results"};
												bindingInfo.template = new sap.ui.core.ListItem({
									       			text: "{FullName}",
									       			key: "{UserID}"
									       		});
									       		
									       		var obj = {};
									       		var data = zpa.grcaud.dataqmodel.getModel("responsablesModel").getData();
									       		
									       		for (var i=0, len=data.results.length; i < len; i++ )
									       		    obj[data.results[i]['UserID']] = data.results[i];
							
									       		data.results = new Array();
									       		for (var key in obj ){
									       		    data.results.push(obj[key]);
									       		}
									       		
									       		input.bindAggregation("items", bindingInfo);
											}
											
											setResponsableModel(oInput);
											
									}
								}else{
									zpa.grcaud.dataqmodel.loadDropdown.call(tabFields, i, oInput, n, url, odataModel);
								}
								if(n.Objtyp === "FIND"){
									oContent[parseInt(n.ContainerPos)].push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [ oInput ], visible: JSON.parse(n.Visible) }));
								}else{
									oContent.push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [ oInput ], visible: JSON.parse(n.Visible) }));
								}
								
							} else if (options == zpa.grcaud.Constants.FieldOptions.Matchcode) {
								
								if(n.Multiple === "false"){
									var oInput = new sap.m.Input("inp_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue,
											{
												visible: JSON.parse(n.Visible), 
												editable: JSON.parse(n.Editable),
												value: n.Stauxiliar,
												valueHelpOnly: true,
												showValueHelp: true,
												showSuggestion: true,
												tooltip: n.FieldLabel,
												customData: [ new sap.ui.core.CustomData({key: "id",value: n.Value}),],
												valueHelpRequest: function(oEvent){
													[zpa.grcaud.matchcode[n.Function](oEvent, n), oController]
												},
												layoutData : new sap.ui.layout.form.GridElementData({hCells : width}),
									});
									
									if(n.Objtyp === "FIND"){
										oContent[parseInt(n.ContainerPos)].push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [ oInput ] }));
									}else{
										oContent.push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [ oInput ] }));
									}
								
								}else{
									if(!byId("mlt_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue)){
//										
										var hbox = new sap.m.HBox("mlt_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue,{
											visible: JSON.parse(n.Visible),
											layoutData: new sap.ui.layout.form.GridElementData({hCells: width}),
											items: [
											        new sap.m.FlexBox({
											        	width: "50%",
											        	wrap: sap.m.FlexWrap.Wrap,
											        }).addStyleClass("multMatchcodeTokens"),
											        new sap.m.Input({
											        	editable: JSON.parse(n.Editable),
											        	value: "",
											        	valueHelpOnly: true,
														showValueHelp: true,
														showSuggestion: true,
														valueHelpRequest: function(oEvent){
															[zpa.grcaud.matchcode[n.Function](oEvent, n), oController]
														},
											        }),
											        new sap.m.Button({
											        	enabled: JSON.parse(n.Editable),
											        	icon: "sap-icon://add",
											        	press: function(oEvent){
											        		var input = oEvent.getSource().getParent().getItems()[1];
											        		if(input.getValue() !== ""){
											        			oEvent.getSource().getParent().getItems()[0].setVisible(true);
												        		oEvent.getSource().getParent().getItems()[0].addItem(new sap.m.Token({
																	key: input.data("tokentoput"),
																	text: input.getValue(),
																	delete: function(){
																		if(this.getParent().getItems().length === 1){
																			this.getParent().setVisible(false);
																		}
																		this.destroy();
																	}
																}));
												        		input.setValue("");
											        		}
											        	}
											        }).addStyleClass("multMatchcodeButton"),
											        ]
										});
										
										zpa.grcaud.matchcode.getTokens.call(n);
									}else{
//										//añadimos
										byId("mlt_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue).getItems()[0].addItem(new sap.m.Token({
											editable: JSON.parse(n.Editable),
											key: n.Value,
											text: n.Value,
											delete: function(){
												this.destroy();
											}
										}));
									}
									if(n.Objtyp === "FIND"){
										oContent[parseInt(n.ContainerPos)].push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [ byId("mlt_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue) ], visible: JSON.parse(n.Visible) }));
									}else{
										oContent.push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [ byId("mlt_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue) ], visible: JSON.parse(n.Visible) }));
									}
								}
								
							} 
//							else if (options == zpa.grcaud.Constants.FieldOptions.Label) {
//								if(n.Objtyp === "FIND"){
//									oContent[parseInt(n.ContainerPos)].push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [], visible: JSON.parse(n.Visible) }));
//								}else{
//									oContent.push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [], visible: JSON.parse(n.Visible) }));
//								}
//							}
						}
						break;
					case zpa.grcaud.Constants.FieldTypes.Key:
						break;
					case zpa.grcaud.Constants.FieldTypes.Num:
						var oLabel = new sap.m.Label("lbl_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue, { text: n.FieldLabel, layoutData: new sap.ui.layout.form.GridElementData({hCells: "4"})});
						var oInput = new sap.m.Input("inp_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue, { type: sap.m.InputType.Number, editable: JSON.parse(n.Editable), value: JSON.parse(n.Value), maxLength: parseInt(n.Length), change: function(oEvent) { tabFields[i].Value = this.getValue(); }, layoutData: new sap.ui.layout.form.GridElementData({hCells: width})});
						
						if(n.Objtyp === "FIND"){
							oContent[parseInt(n.ContainerPos)].push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [ oInput ], visible: JSON.parse(n.Visible) }));
						}else{
							oContent.push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [ oInput ], visible: JSON.parse(n.Visible) }));
						}
						break;
					case zpa.grcaud.Constants.FieldTypes.Currency:
						
						var value = "";
						if(n.Value != "") {
							value = JSON.parse(n.Value);
						}
						
						var oLabel = new sap.m.Label("lbl_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue, { text: n.FieldLabel, layoutData: new sap.ui.layout.form.GridElementData({hCells: "4"})});
						var oInput = new sap.m.Input("inp_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue, { type: sap.m.InputType.Number, editable: JSON.parse(n.Editable), value: value, maxLength: parseInt(n.Length), change: function(oEvent) { tabFields[i].Value = this.getValue(); }, layoutData: new sap.ui.layout.form.GridElementData({hCells: width})});
						
						if(n.Objtyp === "FIND"){
							oContent[parseInt(n.ContainerPos)].push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [ oInput, new sap.m.Text({text: "EUR"}) ], visible: JSON.parse(n.Visible) }));
						}else{
							oContent.push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [ oInput, new sap.m.Text({text: "EUR"}) ], visible: JSON.parse(n.Visible) }));
						}
						break;
					case zpa.grcaud.Constants.FieldTypes.Effort:
						
						var value = n.Value;
						if(value != "") {
							value =  JSON.parse(n.Value);
						}
						
						var oLabel = new sap.m.Label("lbl_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue, { text: n.FieldLabel, layoutData: new sap.ui.layout.form.GridElementData({hCells: "4"})});
						var oInput = new sap.m.Input("inp_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue, { type: sap.m.InputType.Number, editable: JSON.parse(n.Editable), value: value, maxLength: parseInt(n.Length), change: function(oEvent) { tabFields[i].Value = this.getValue(); }, layoutData: new sap.ui.layout.form.GridElementData({hCells: width})});
						
						if(n.Objtyp === "FIND"){
							oContent[parseInt(n.ContainerPos)].push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [ oInput, new sap.m.Text({text: "Día/persona"}) ], visible: JSON.parse(n.Visible) }));
						}else{
							oContent.push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [ oInput, new sap.m.Text({text: "Día/persona"}) ], visible: JSON.parse(n.Visible) }));
						}
						break;
					case zpa.grcaud.Constants.FieldTypes.Date:
						var oLabel = new sap.m.Label("lbl_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue, { text: n.FieldLabel, required: JSON.parse(n.Required), layoutData: new sap.ui.layout.form.GridElementData({hCells: "4"})});
						if(n.Value === "00000000"){
							n.Value = "";
							n.ValueOrig = "";
						}
						var oDatePicker = new sap.m.DatePicker("inp_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue, {value: n.Value, valueFormat: "yyyyMMdd", displayFormat: "dd/MM/yyyy", editable: JSON.parse(n.Editable), change: function(oEvent) { tabFields[i].Value = this.getValue(); }, layoutData: new sap.ui.layout.form.GridElementData({hCells: width})});
						
						if(n.Objtyp === "FIND"){
							oContent[parseInt(n.ContainerPos)].push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [ oDatePicker ], visible: JSON.parse(n.Visible) }));
						}else{
							oContent.push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [ oDatePicker ], visible: JSON.parse(n.Visible) }));
						}
						break;	
					case zpa.grcaud.Constants.FieldTypes.Text:					
						var oLabel = new sap.m.Label("lbl_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue, { text: n.FieldLabel,  required: JSON.parse(n.Required), layoutData: new sap.ui.layout.form.GridElementData({hCells: "4"})});
						var oInput = new sap.m.TextArea("inp_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue, { value: n.Value, rows: 5, editable: JSON.parse(n.Editable), maxLength: parseInt(n.Length), change: function(oEvent) { tabFields[i].Value = this.getValue(); }, layoutData: new sap.ui.layout.form.GridElementData({hCells: width})});
						if(n.Tab === zpa.grcaud.Constants.TabGroups.WorkProgram){
							oInput.setValue("");
						}
						if(n.Objtyp === "FIND"){
							oContent[parseInt(n.ContainerPos)].push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [ oInput ], visible: JSON.parse(n.Visible) }));
						}else{
							oContent.push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [ oInput ], visible: JSON.parse(n.Visible) }));
						}
						break;
						
					case zpa.grcaud.Constants.FieldTypes.FormTitle:		
						//Título para añadir en los formularios
						var oLabel = new sap.m.Label("lbl_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue, { text: n.FieldLabel,  required: JSON.parse(n.Required), layoutData: new sap.ui.layout.form.GridElementData({hCells: "4"})});
						var oEmptyLabel = new sap.m.Label("emptLbl_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue, { text: " ",  required: JSON.parse(n.Required), layoutData: new sap.ui.layout.form.GridElementData({hCells: "4"}), visible: false});
						if(n.Objtyp === "FIND"){
							oContent[parseInt(n.ContainerPos)].push( new sap.ui.layout.form.FormElement({ label: oEmptyLabel, fields: [oLabel], visible: JSON.parse(n.Visible) }));
						}else{
							oContent.push( new sap.ui.layout.form.FormElement({ label: oEmptyLabel, fields: [oLabel], visible: JSON.parse(n.Visible) }));
						}
//						if(n.Objtyp === "FIND"){
//							oContent[parseInt(n.ContainerPos)].push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [], visible: JSON.parse(n.Visible) }));
//						}else{
//							oContent.push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [], visible: JSON.parse(n.Visible) }));
//						}
						break;
					case zpa.grcaud.Constants.FieldTypes.Title:
						if(n.Objtyp === "FIND"){
							oContent[parseInt(n.ContainerPos)].push(n.FieldLabel);
						}else{
							oContent.push(n.FieldLabel);
						}
						break;
					case zpa.grcaud.Constants.FieldTypes.Search:
						var oLabel = new sap.m.Label("lbl_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue, { text: n.FieldLabel, layoutData: new sap.ui.layout.form.GridElementData({hCells: "4"})});
						var oInput = new sap.m.SearchField("srch_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue, { value: n.Value, rows: 5, editable: JSON.parse(n.Editable), maxLength: parseInt(n.Length), search: function(){/*console.log(this);*/}, layoutData: new sap.ui.layout.form.GridElementData({hCells: width})});
						if(n.Objtyp === "FIND"){
							oContent[parseInt(n.ContainerPos)].push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [ oInput ], visible: JSON.parse(n.Visible) }));
						}else{
							oContent.push( new sap.ui.layout.form.FormElement({ label: oLabel, fields: [ oInput ], visible: JSON.parse(n.Visible) }));
						}
						break;
						
					case zpa.grcaud.Constants.FieldTypes.DropdownValue:
						
						var odataModel = zpa.grcaud.dataqmodel.conStd;
						
						var url = "";

						switch(n.Function){
							case "UserRoles":
								var url = "/Findings"
								var key = tabFields[1].Value;
								if(n.Objtyp === "AUDIT"){
									url = "";
									key = "";
								}
								
								url = url + "(guid'" + listaInfoUtils.convertKeyBinToGuid(key) + "')/UserRoles?$filter= RoleID eq 'EXE_RESP'";
								break;
							default:
								break;
						}
						if(n.Objtyp === "FIND"){
						odataModel.read(url, undefined, undefined,
						    false, jQuery.proxy(
						      function(data, response) {
						    	  var y = 0;
						    	  var found = false;
						    	  if(data.results.length > 0){
							    	  while(y < tabFields.length && !found){
											if(tabFields[y].FieldName === n.FieldName && tabFields[y].DepValue === n.DepValue){
												byId("inp_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue).setSelectedKey(data.results[0].UserID);
												tabFields[y].Value = data.results[0].UserID;
												tabFields[y].ValueOrig = data.results[0].UserID;
												found = true;
											}
											y++;
							    	  }
						    	  }
						      }, this), jQuery.proxy(function(oError) {
						      }, this)
						      );
						}
						
						break;
						
					default:
						break;
					
				};
				break;
				
			case zpa.grcaud.Constants.Hier.Table:
				
				if(!that.table[n.Service]){ //Mas de una tabla
					
					that.table[n.Service] = new sap.m.Table({
						mode: "None",
						width : "100%",
						height : "100%",
					});
					
					zpa.grcaud.tablefield.Obtain(n.Service);
					
					that.table[n.Service].setModel(zpa.grcaud.tablefield.oModel.dataModel[n.Service]);
					var template = new sap.m.ColumnListItem();
					that.table[n.Service].bindItems("/results", template);
					
					oTables.push(that.table[n.Service]);
				}
				
				switch(n.TypeHier){
					case "00":
						that.labelTable[n.Service] = new sap.m.Bar({contentLeft:[new sap.m.Label({text: n.FieldLabel + " (" + zpa.grcaud.tablefield.oModel.dataModel[n.Service].getData().results.length + ")"})]});
						oTables.splice(oTables.length-1, 0, that.labelTable[n.Service]);
						break;
						
					case "01":
						that.table[n.Service].addColumn(new sap.m.Column({
							header : new sap.m.Label({
			                text : n.FieldLabel
				            })
				        }));
						
						for(var i = 0; i < that.table[n.Service].getItems().length; i++){
							that.table[n.Service].getItems()[i].insertCell(new sap.m.Text({
						            text : "{"+ n.ExternalName +"}"
						          }), n.FieldOrder);
						}
						
						break;
				}				
				
				break;
			default:
				break;
		}

	});
	
	return {content: oContent,
		tables: oTables,
		work: workFields
	};
}