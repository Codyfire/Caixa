var listaInformes = {};

listaInformes.tableCols = {
  	buscarPersonas: ["Matricula", "Nombre"],
  	buscarCentros: ["Centro", "Responsable"],
  	listaCentros: ["Empresa", "Departamento", "Nombre Departamento"],
  	buscarListas: ["Id", "Departamento", "Grupo", "Nombre de Lista"],
  	listarAlertas: ["Tipo", "Borrar"],
  	riesgos: ["Tipo", "Descripcion"],
  	buscarTipoAlerta: ["Tipo"],
  	buscarContratos: ["Tipo", "Descripcion"],
  	buscarInformes: ["Numero de Informe", "Titulo de Informe", "Fechas de distribucion", "Departamento"],
  	buscarCodigos: ["Código", "Descripción", "Borrar"]
  	
}

listaInformes.tableCels = {
	buscarPersonas:  ["{UserId}", "{FullName}"],
  	buscarCentros:   ["{name}", "{responsable}"],
  	listaCentros: ["{Company}", "{Department}", "{DepartmentName}"],
  	buscarListas: ["{id}", "{area}", "{grupo}", "{name}"],
  	listarAlertas:["{key}"],
  	riesgos: ["{tipo}", "{Desc}"],
  	buscarTipoAlerta: ["{key}"],
  	buscarContratos: ["{id}", "{desc}"],
  	buscarCodigos: ["{codigo}", "{desc}"]
}

listaInformes.conParams = {
	oDataUrlLocal: "proxy/https/sapriast05.lacaixa.es:44300/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/",
	oDataUrl: "/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/",
	users: "/InfoPermUsersSet",
	user: "/InfoPermUsersSet",
	deleteUsers: "/InfoPermUsersSet({0})", 
	updateUsers: "/InfoPermUsersSet({0})",
	userNotas: "/InfoUserSet",
	notas: "/NoteSet",
	ldap: "/InfoUsersLDAPSet",
	centros: "/InfoDepartmentsSet",
	codigosConclusion: "/InfoCodConclusionSet",
	searchPeople: "/searchPeople?srcValue={0}",
	joinPeople: "/PeopleInActivitySet",
	myActivities: "/getMyActivities?month={0}&year={1}",
	peopleInActGrp: "/getPeopleInActGrp?typeSearch={0}&idSearch={1}",
}


function getServiceUrl() {
	return listaInformes.conParams.oDataUrl;
}

function getLocalServiceUrl() {
	return listaInformes.conParams.oDataUrlLocal;
}

function getListaUsuarios() {
	return listaInformes.conParams.users;
}

function getDeleteUsersUrl(){
	return listaInformes.conParams.deleteUsers;
}

function getUpdateUsersUrl(){
	return listaInformes.conParams.updateUsers;
}

function getNotasUsuarioUrl(){
	return listaInformes.conParams.notas;
}

function getUserUrl(){
	return listaInformes.conParams.user;
}

function getUserNotasUrl(){
	return listaInformes.conParams.userNotas;
}

function getLDAPUrl(){
	return listaInformes.conParams.ldap;
}

function getCentroUrl(){
	return listaInformes.conParams.centros;
}

function getCodigosConclusionUrl(){
	return listaInformes.conParams.codigosConclusion;
}

function formatUrl(source, params) {
	
	// source -> String con parametros {0},{1}...
	// params -> Array con los valores ["Hello","World!"]
	
	// Replace all params in function
	if(params) {
	    $.each(params,function (i, n) {
		    if(n != undefined && n != null) {
			    source = source.replace(new RegExp("\\{" + i + "\\}", "g"), function () {
			            return '\'' + n + '\'';
			        });
		    }
	    })
	}

	// Other params will be replace by ''
    source = source.replace(new RegExp("\\{[0-9]+\\}", "g"), function () {
            return '\'\'';
    });
    
    return source;
}