sap.ui.controller("appDataQ.controller.SelScreen", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf zadminuser.main
*/
	onInit: function() {
		var checks = this.getView().aChecks;
		for(var i = 0; i < checks.length; i++ ){
			this.getView().oForm.getFormContainers()[1].addFormElement(new sap.ui.layout.form.FormElement({
				label: "",
				fields: [checks[i]]
			}));
		}
		
	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf zadminuser.main
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf zadminuser.main
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf zadminuser.main
*/
//	onExit: function() {
//
//	}
	
	onAuditSearch: function(oEvent) {
		
		if(oEvent.getParameter("query") != "" && !oEvent.getParameter("clearButtonPressed")) {
			this.onResetScreen();
			var oModel = new sap.ui.model.json.JSONModel();
			zpa.grcaud.dataqmodel.loadData.call(this.getView(), oModel, this.getView().oSearch.getValue(), "AUDIT", "");
				
			if(oModel.getData().results){
				if(oModel.getData().results.length>0){
					zpa.grcaud.dataqmodel.createModel(oModel,"copyModel");
					//Modelo para obtener los datos de la primera llamada a backend
					zpa.grcaud.dataqmodel.createModel(oModel, "firstCallModel");
					this.getView().oInfoAuditMessageStrip.setText("Auditoría encontrada");
					this.getView().oInfoAuditMessageStrip.setType("Success");
					this.getView().oInfoAuditMessageStrip.setVisible(true);
					this.getView().oCheckAll.setEnabled(true);
					$.each(this.getView().aChecks,function(i,n){
						n.setEnabled(true);
					});
					//INI PPM100076335 - Pestaña clasificacionIE - VISIBILIDAD DEL CHECK CLASIFICACION IE
					//zpa.grcaud.dataqmodel.loadDataClasificacionIE.call(this.getView(), this.getView().oSearch.getValue(), "AUDIT", "REPORT");
					//zpa.grcaud.dataqmodel.loadDataClasificacionIE.call(this.getView(), this.getView().oSearch.getValue(), "AUDIT", "INFO");
					//FIN PPM100076335 - Pestaña clasificacionIE - VISIBILIDAD DEL CHECK CLASIFICACION IE
					
					//INI PPM100077498 - Pestaña encuestas - VISIBILIDAD DEL CHECK ENCUESTAS
					zpa.grcaud.dataqmodel.loadDataEncuestas.call(this.getView(), this.getView().oSearch.getValue(), "AUDIT", "REPORT");
					zpa.grcaud.dataqmodel.loadDataEncuestas.call(this.getView(), this.getView().oSearch.getValue(), "AUDIT", "INFO");
					//FIN PPM100077498 - Pestaña encuestas - VISIBILIDAD DEL CHECK ENCUESTAS
					zpa.grcaud.dataqmodel.editState = "AUDIT";
				}else{
					//this.showSearchError("AUDIT");
				}
			}else{
				//this.showSearchError("AUDIT");
			}
		}
		
	},
	
	onFindingSearch: function(oEvent){
		if(oEvent.getParameter("query") != "" && !oEvent.getParameter("clearButtonPressed")) {
			this.onResetScreen();
			var oModel = new sap.ui.model.json.JSONModel();
			zpa.grcaud.dataqmodel.loadData.call(this.getView(), oModel, this.getView().oSearchFinding.getValue(),"FIND", "");
			if(oModel.getData().results){
				if(oModel.getData().results.length>0){
					zpa.grcaud.dataqmodel.createModel(oModel,"findingModel");
					this.getView().oInfoFindingMessageStrip.setText("Finding encontrado");
					this.getView().oInfoFindingMessageStrip.setType("Success");
					this.getView().oInfoFindingMessageStrip.setVisible(true);
					this.getView().aChecks[0].setEnabled(true);
					this.getView().aChecks[1].setEnabled(true);
					zpa.grcaud.dataqmodel.editState = "FINDING";
				}else{
					//this.showSearchError("FINDING");
				}
			}else{
				//this.showSearchError("FINDING");
			}
		}
	},
	
	onPlAccionSearch: function(oEvent){
		if(oEvent.getParameter("query") != "" && !oEvent.getParameter("clearButtonPressed")) {
			this.onResetScreen();
			var oModel = new sap.ui.model.json.JSONModel();
			zpa.grcaud.dataqmodel.loadData.call(this.getView(), oModel, this.getView().oSearchPlAccion.getValue(),"ACTION", "");
			if(oModel.getData().results){
				if(oModel.getData().results.length>0){
					zpa.grcaud.dataqmodel.createModel(oModel,"actionPlanModel");
					this.getView().oInfoPlAccionMessageStrip.setText("Plan de acción encontrado");
					this.getView().oInfoPlAccionMessageStrip.setType("Success");
					this.getView().oInfoPlAccionMessageStrip.setVisible(true);
					this.getView().aChecks[0].setEnabled(true); //INI PPM100076801
					zpa.grcaud.dataqmodel.editState = "ACTION";
				}else{
					//this.showSearchError("ACTION");
				}
			}else{
				//this.showSearchError("ACTION");
			}
		}
	},
	
	showSearchError: function(type){
		switch(type){
			case "FINDING":
				this.getView().oInfoFindingMessageStrip.setText("Finding no encontrado");
				this.getView().oInfoFindingMessageStrip.setType("Error");
				this.getView().oInfoFindingMessageStrip.setVisible(true);
				break;
			case "ACTION":
				this.getView().oInfoPlAccionMessageStrip.setText("Plan de acción no encontrado");
				this.getView().oInfoPlAccionMessageStrip.setType("Error");
				this.getView().oInfoPlAccionMessageStrip.setVisible(true);
				break;
			default:
				this.getView().oInfoAuditMessageStrip.setText("Auditoría no encontrada");
				this.getView().oInfoAuditMessageStrip.setType("Error");
				this.getView().oInfoAuditMessageStrip.setVisible(true);
				break;
		}
		
	},
	
	onEdit: function(oEvent) {
		if(zpa.grcaud.dataqmodel.editState == ""){
			var dialog = new sap.m.Dialog({
				title: 'Información',
				type: 'Message',
					content: new sap.m.Text({
						text: "Debe buscar un objeto antes de editar."
					}),
				beginButton: new sap.m.Button({
					text: 'Aceptar',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});
			dialog.open();
		}else if(zpa.grcaud.dataqmodel.editState == "AUDIT"){
			var aChecks = this.getView().aChecks;
			var tab_info = "";
			var editFields = $.grep(aChecks,function(n,i){
				if(n.getSelected()){
					if(i !== 0 && tab_info !== ""){
						tab_info = tab_info + ",";
					}
					tab_info = tab_info + tabStringByCheck(n.getText());
				}
				return n.getSelected() == true});
			
			if(editFields.length == 0){
				var dialog = new sap.m.Dialog({
					title: 'Información',
					type: 'Message',
						content: new sap.m.Text({
							text: "Debe seleccionar los campos a editar."
						}),
					beginButton: new sap.m.Button({
						text: 'Aceptar',
						press: function () {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});
				dialog.open();
			}else{
				
//				if(editFields.length === aChecks.length){
//					tab_info = "Select_all";
//				}
				
				var oModel = new sap.ui.model.json.JSONModel();
				zpa.grcaud.dataqmodel.loadData.call(this.getView(), oModel, this.getView().oSearch.getValue(), "AUDIT", tab_info);
				zpa.grcaud.dataqmodel.createModel(oModel,"copyModel");
				var navCont = sap.ui.getCore().byId("dataQCont");
				if(navCont) {
					 var view = sap.ui.view({id:"detailScreen", viewName:"appDataQ.view.DetailScreen", type:sap.ui.core.mvc.ViewType.JS, viewData: zpa.grcaud.dataqmodel.getModel("copyModel").getData().results});
					 if(navCont.getPage("detailScreen"))
						 navCont.destroyPage("detailScreen");
					 navCont.addPage(view);
					 navCont.to("detailScreen");
				}
			}
		}else if(zpa.grcaud.dataqmodel.editState == "FINDING"){
			var aChecks = this.getView().aChecks;
			var tab_info = "";
			var editFields = $.grep(aChecks,function(n,i){
				if(n.getSelected()){
					if(i !== 0 && tab_info !== ""){
						tab_info = tab_info + ",";
					}
					tab_info = tab_info + tabStringByCheck(n.getText());
				}
				return n.getSelected() == true});
			
			if(editFields.length == 0){
				var dialog = new sap.m.Dialog({
					title: 'Información',
					type: 'Message',
						content: new sap.m.Text({
							text: "Debe seleccionar los campos a editar."
						}),
					beginButton: new sap.m.Button({
						text: 'Aceptar',
						press: function () {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});
				dialog.open();
			}else{
				var navCont = sap.ui.getCore().byId("dataQCont");
				if(navCont) {
					 var view = sap.ui.view({id:"findingDetailScreen", viewName:"appDataQ.view.FindingDetailScreen", type:sap.ui.core.mvc.ViewType.JS, viewData: zpa.grcaud.dataqmodel.getModel("findingModel").getData().results});
					 if(navCont.getPage("findingDetailScreen"))
						 navCont.destroyPage("findingDetailScreen");
					 navCont.addPage(view);
					 navCont.to("findingDetailScreen");
				}
			}
		}else if(zpa.grcaud.dataqmodel.editState == "ACTION"){
			var navCont = sap.ui.getCore().byId("dataQCont");
			if(navCont) {
				 var view = sap.ui.view({id:"planesAccionDetailScreen", viewName:"appDataQ.view.PlanesAccionDetailScreen", type:sap.ui.core.mvc.ViewType.JS, viewData: zpa.grcaud.dataqmodel.getModel("actionPlanModel").getData().results});
				 if(navCont.getPage("planesAccionDetailScreen"))
					 navCont.destroyPage("planesAccionDetailScreen");
				 navCont.addPage(view);
				 navCont.to("planesAccionDetailScreen");
			}
		}
	},
	
	onResetScreen: function(){
		var oView = this.getView();
		oView.oCheckAll.setEnabled(false);
		oView.oCheckAll.setSelected(false);
		$.each(oView.aChecks,function(i,n){n.setEnabled(false)});
		$.each(oView.aChecks,function(i,n){n.setSelected(false)});
		oView.oInfoAuditMessageStrip.setVisible(false);
		oView.oInfoFindingMessageStrip.setVisible(false);
		oView.oInfoPlAccionMessageStrip.setVisible(false);
		zpa.grcaud.dataqmodel.editState = "";
	}
});