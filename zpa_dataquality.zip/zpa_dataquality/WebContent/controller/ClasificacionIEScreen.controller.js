sap.ui.controller("appDataQ.controller.ClasificacionIEScreen", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf zadminuser.main
*/
	onInit: function() {
		
	},


	doBack: function(oEvent) {
		var currView = this.getView();
//		JSON.stringify(oModel) === JSON.stringify(zpa.grcaud.dataqmodel.getModel("copyModel").getData().results) ? changes = false: changes = true;
		var dialog = new sap.m.Dialog({
			title: 'Información',
			type: 'Message',
				content: new sap.m.Text({
					text: "Está seguro que desea salir? Se perderan los cambios no guardados."
				}),
			beginButton: new sap.m.Button({
				text: 'Aceptar',
				press: function () {
					dialog.close();
					var navCont = currView.getParent();
					navCont.getPreviousPage().getController().onResetScreen();
					navCont.getPreviousPage().oSearch.setValue("");
					navCont.to(navCont.getPreviousPage().sId);
					navCont.getPage(currView.sId).destroy();
				}
			}),
			endButton: new sap.m.Button({
				text: 'Cancelar',
				press: function () {
					dialog.close();
				}
			}),
			afterClose: function() {
				dialog.destroy();
			}
		});
		dialog.open();
	},
});