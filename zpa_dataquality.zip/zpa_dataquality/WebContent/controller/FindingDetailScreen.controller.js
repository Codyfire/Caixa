sap.ui.controller("appDataQ.controller.FindingDetailScreen", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf zadminuser.main
*/
	onInit: function() {
		var checks = byId("selScreen").aChecks;
		var that = this;
		var countSelected = 0;
		
		for(var i = 0; i < checks.length; i++){
			if(checks[i].getSelected()){
				//var current = checks[i].getText().replace(/\s/g, ''); 
				var item = new sap.m.IconTabFilter({
					icon: zpa.grcaud.Constants.SelChecks[i].icon,
					text: byId("selScreen").aChecks[i].getText(),
					key: byId("selScreen").aChecks[i].getText(),
					//visible: byId("selScreen").aChecks[i].getSelected(),
					content: []
				});
				switch(tabStringByCheck(checks[i].getText())) {
					case zpa.grcaud.Constants.TabGroups.Risks:
						zpa.grcaud.dataqmodel.loadRisksTables.call(this, "FIND");
						item.addContent(this.getView().oDynamicSideContent);
						break;
					
					default:
						item.addContent(this.getView().aForms[countSelected]);
						if(this.getView().aTables[countSelected].length !== 0){
							item.addContent(this.getView().aTables[countSelected]);
						}
						break;
				}
				
				this.getView().oIconTabBar.addItem(item);
				
				countSelected++;
			}
			
			
		}
	},
	
	leftToRightRisk: function(oEvent){
		var selected = oEvent.getSource().getBindingContext().getObject();
		var path = oEvent.getSource().getBindingContext().getPath();
		var index = parseInt(path.substring(path.lastIndexOf('/') +1));
		
		this.getView().oLeftList.getModel().getData().results.splice(index, 1);
		this.rightFilter.aFilters.splice(index, 1);
		
		this.getView().oLeftList.getModel().updateBindings(true);
		if(this.rightFilter.aFilters.length > 0){
			this.getView().oRightList.getBinding("items").filter([this.rightFilter]);
		}else{
			this.getView().oRightList.getBinding("items").filter();
		}
		/**	INI Ajustes SPAU 08/11/18
		 **  Código antiguo
		 *  
		 * this.chosenRisks.moves.push({key: selected.Key.replace(/-/g, ""), action: "delete"});
		 * 
		 ** Código nuevo
		 * Se pasa la Key a Mayúsculas para que no muestre error al pasar a RAW 16 en el back  
		 */
		this.chosenRisks.moves.push({key: selected.Key.replace(/-/g, "").toUpperCase(), action: "delete"});
		/**
		 * FIN Ajustes SPAU 08/11/18
		 */
		
	},
	
	rightToLeftRisk: function(oEvent){
		var selected = oEvent.getSource().getBindingContext().getObject();
		this.getView().oLeftList.getModel().getData().results.push(selected);
		this.rightFilter.aFilters.push(
			new sap.ui.model.Filter({
				path: "ID",
				operator: "NE",
				value1: selected.ID
			})
		);
		this.getView().oLeftList.getModel().updateBindings(true);
		this.getView().oRightList.getBinding("items").filter([this.rightFilter]);
		
		/**	INI Ajustes SPAU 08/11/18
		 **  Código antiguo
		 *  
		 * this.chosenRisks.moves.push({key: selected.Key.replace(/-/g, ""), action: "add"});
		 * 
		 ** Código nuevo
		 * Se pasa la Key a Mayúsculas para que no muestre error al pasar a RAW 16 en el back  
		 */
		this.chosenRisks.moves.push({key: selected.Key.replace(/-/g, "").toUpperCase(), action: "add"});
		/**
		 * FIN Ajustes SPAU 08/11/18
		 */
		
	},
	
	onSearchRisk: function(oEvent){
		var con = zpa.grcaud.dataqmodel.getConection("stdCon");
		//Inicio modificación 537572 - AUM (EVR) Findings sense risc assignat
		//Codigo antiguo
		//var url = "RiskExtendedSet?$filter=Scenario eq 'riskRegister' and ViewID eq 'IA' and Timestamp eq datetime'2099-12-30T23:00:00'&search=*" + oEvent.getSource().getValue() + "*&$inlinecount=allpages";
		//Código Nuevo
		var key =  listaInfoUtils.convertKeyBinToGuid(zpa.grcaud.dataqmodel.getModel("findingModel").getData().results[zpa.grcaud.dataqmodel.getModel("findingModel").getData().results.length-1].Value);
		var	url = "AuditSet(guid'" + key + "')/Risks?$orderby=Title%20asc&search=*" + oEvent.getSource().getValue() + "*";
		//Fin Modificación 537572 - AUM (EVR) Findings sense risc assignat
		con.read(url, {
			async: false,
			success: function(oData){
				var oModel =  new sap.ui.model.json.JSONModel(oData);
				this.getView().oRightList.setModel(oModel);
				if(this.rightFilter.aFilters.length > 0){
					this.getView().oRightList.getBinding("items").filter([this.rightFilter]);
				}
				this.getView().oRightList.getBinding("items").sort(this.oSorter);
			}.bind(this),
			error: function(oError){
			}.bind(this)
		});
	},
	
	
	doBack: function(oEvent) {
		var currView = this.getView();
		var navCont = currView.getParent();
		navCont.getPreviousPage().getController().onResetScreen();
		navCont.getPreviousPage().oSearchFinding.setValue("");
		navCont.to(navCont.getPreviousPage().sId);
		navCont.getPage(currView.sId).destroy();
	},
	
	getRisksData: function(){
//		var moves = this.chosenRisks.moves;
//		var initial = this.chosenRisks.initial; 
//		var final = initial;
//		for(var i = 0; i < moves.length; i++){
//			if(moves[i].action === "add"){
//				if(!final[moves[i].key]){ //añadido nuevo
//					final[moves[i].key] = {ContainerPos: "0", DepField: "", DepValue: "", Editable: "true", ExternalName: "",
//							FieldLabel: "", FieldLength: "100", FieldName: "KEY", FieldOrder: "0",
//							Function: "", Hier: "0", IdReg: "", Length: "0", Multiple: "false", Name: "KEY",
//							Objtyp: "FIND", Options: "", Required: "false", SeqFields: "00000", Service: "", Stauxiliar: "",
//							Tab: "RISKS", Type: "STRING", TypeHier: "", Value: moves[i].key, ValueOrig: "",
//							Visible: "true"};
//				}else{ //inicial reañadido
//					final[moves[i].key].Value = final[moves[i].key].ValueOrig;
//				}
//				
//			}else{ //delete
//				if(!initial[moves[i].key]){ //borramos nuevo
//					delete final[moves[i].key];
//				}else{ //borramos inicial
//					final[moves[i].key].Value = "";
//				}
//				
//			}
//		}
//		return Object.values(final);
		for(var i = 0; i < this.chosenRisks.moves.length; i++){
			for(var j = 0; j < this.chosenRisks.risks.length; j++){
				var found = false;
				/**
				 * INI Ajuste SPAU 09/11/18
				 * Código antiguo
				
				 *if(this.chosenRisks.moves[i].key === this.chosenRisks.risks[j].ValueOrig || this.chosenRisks.moves[i].key === this.chosenRisks.risks[j].Value){					
				
				 * Codigo nuevo
				 * Se modifica el IF para que compare por las keys en mayúsculas de la lista de riesgos
				 */
					if(this.chosenRisks.moves[i].key === this.chosenRisks.risks[j].ValueOrig.toUpperCase() || this.chosenRisks.moves[i].key === this.chosenRisks.risks[j].Value.toUpperCase()){
				/**
				 * FIN Ajuste SPAU 09/11/18 
				 */
						
					found = true;
					if(this.chosenRisks.moves[i].action === "delete"){
						if(j < this.chosenRisks.count){ //inicial borrado
							for(var y = 0; y < this.chosenRisks.assignments.length; y++){
								if(this.chosenRisks.assignments[y].ReferenceKey.replace(/-/g, "") === this.chosenRisks.risks[j].Value){ //en un principio tiene la key del riesgo
									this.chosenRisks.risks[j].Value = "";
									/**
									 * INI Ajuste SPAU 09/11/18
									 * Código antiguo
									 * 
									 * this.chosenRisks.risks[j].ValueOrig = this.chosenRisks.assignments[y].Key.replace(/-/g, ""); //ponemos la key de la asociacion
									 * 
									 * Se añade la Key en mayúsculas
									 * Código nuevo
									*/
									this.chosenRisks.risks[j].ValueOrig = this.chosenRisks.assignments[y].Key.replace(/-/g, "").toUpperCase(); //ponemos la key de la asociacion
									/**
									 * FIN Ajuste SPAU 09/11/18 
									 */
									break;
								}
							}
						}else{
							this.chosenRisks.risks.splice(j, 1);
						}
					}else{//riesgo inicial reañadido
						for(var y = 0; y < this.chosenRisks.assignments.length; y++){
							if(this.chosenRisks.assignments[y].Key.replace(/-/g, "") === this.chosenRisks.risks[j].ValueOrig){ //hasta ahora tenia la key de la asociacion ya que se iba a borrar
								this.chosenRisks.risks[j].ValueOrig = this.chosenRisks.assignments[y].ReferenceKey.replace(/-/g, ""); //para poder encontrarlo en los movimientos
								this.chosenRisks.risks[j].Value = this.chosenRisks.risks[j].ValueOrig;
								break;
							}
						}
					}
					break;
				}
			}
			if(!found){
				//if de comprobar accion innecesario, si no lo encuentra solo puede añadir
				this.chosenRisks.risks.push({ContainerPos: "0", DepField: "", DepValue: "", Editable: "true", ExternalName: "",
					FieldLabel: "", FieldLength: "100", FieldName: "KEY", FieldOrder: "0",
					Function: "", Hier: "0", IdReg: "", Length: "0", Multiple: "false", Name: "KEY",
					Objtyp: "FIND", Options: "", Required: "false", SeqFields: "00000", Service: "", Stauxiliar: "",
					Tab: "RISKS", Type: "STRING", TypeHier: "", Value: this.chosenRisks.moves[i].key, ValueOrig: "",
					Visible: "true"});
			}
		}
		
	},
	
	doSave: function(oEvent) {
		var that = this;
		var oEntity = {};
		var error = false;
		oEntity.DynDataQ = $.extend(true, [], this.getView().oViewData);
		
		//if(this.chosenRisks){ //Risks
		if(this.getView().oIconTabBar.getSelectedKey() === byId("selScreen").aChecks[1].getText()){
			this.getRisksData();
			oEntity.DynDataQ = oEntity.DynDataQ.concat(this.chosenRisks.risks);
		}
		
		for(var i = oEntity.DynDataQ.length - 1; i >= 0; i--){
			if(tabStringByCheck(that.getView().oIconTabBar.getSelectedKey()) === oEntity.DynDataQ[i].Tab){ //guardar por pestaña
				switch(that.getView().oIconTabBar.getSelectedKey()){
					case byId("selScreen").aChecks[1].getText(): //risks
						
						break;
					default: //info
						
						break;
				}
				delete oEntity.DynDataQ[i].__metadata;
				var checkerror = validateForm(oEntity.DynDataQ[i]);
				if(checkerror){
					error = true;
				}
			}else{
				oEntity.DynDataQ.splice(i, 1);
			}
		}
		
		if(!error){
			var key = recoverKey(zpa.grcaud.dataqmodel.getModel("findingModel").getData().results[1].Value); 
			var url = "/DynDataQDeepSet";
			oEntity.Key = key;
			
			var odataModel = zpa.grcaud.dataqmodel.con;
			odataModel.create(url, oEntity, false, function(dataResp){
				zpa.grcaud.dataqmodel.loadRisksTables.call(that, "FIND");
				//zpa.grcaud.dataqmodel.loadRisksTables("FIND");
				
				var dialog = new sap.m.Dialog({
					title: 'Información',
					type: 'Message',
						content: new sap.m.Text({
							text: "Datos guardados correctamente."
						}),
					beginButton: new sap.m.Button({
						text: 'Aceptar',
						press: function () {
							dialog.close();
//							var currView = that.getView();
//							var navCont = currView.getParent();
//							navCont.getPreviousPage().getController().onResetScreen();
//							navCont.getPreviousPage().oSearch.setValue("");
//							navCont.to(navCont.getPreviousPage().sId);
//							navCont.getPage(currView.sId).destroy();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});
				dialog.open();
			},function(oError){
				//console.log(oError);
				if(oError.response){
					sap.m.MessageToast.show($(oError.response.body).find('message').first().text(), {duration: 1800});
				}
			});
		}else{
				var dialog = new sap.m.Dialog({
					title: 'Información',
					type: 'Message',
					state: 'Error',
					content: new sap.m.Text({
						text: "Revise los campos marcados en rojo."
					}),
					beginButton: new sap.m.Button({
						text: 'Aceptar',
						press: function () {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});
				dialog.open()
		}
		
	}

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf zadminuser.main
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf zadminuser.main
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf zadminuser.main
*/
//	onExit: function() {
//
//	}
	
});