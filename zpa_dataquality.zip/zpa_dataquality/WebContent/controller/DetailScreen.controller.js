sap.ui.controller("appDataQ.controller.DetailScreen", {

/**
 * Called when a controller is instantiated and its View controls (if available)
 * are already created. Can be used to modify the View before it is displayed,
 * to bind event handlers and do other one-time initialization.
 * 
 * @memberOf appDataQ.controller.DetailScreen
 */
	onInit: function() {
		
		
		
		var checks = byId("selScreen").aChecks;
		var that = this;
		var countSelected = 0;
		
		for(var i = 0; i < checks.length; i++){
			if(checks[i].getSelected()){
				// var current = checks[i].getText().replace(/\s/g, '');
				var item = new sap.m.IconTabFilter({
					icon: zpa.grcaud.Constants.SelChecks[i].icon,
					text: byId("selScreen").aChecks[i].getText(),
					key: byId("selScreen").aChecks[i].getText(),
					// visible: byId("selScreen").aChecks[i].getSelected(),
					content: []
				});
				
				switch(tabStringByCheck(checks[i].getText())) {
					case zpa.grcaud.Constants.TabGroups.Fraud:
						var oComp  = sap.ui.getCore().createComponent({
							id: "FraudeComp",
					        name: "Fraude"
					    });
						
						this.oComp = oComp;
						
						// Se crea un contenedor para el componente
						var oCompCont = new sap.ui.core.ComponentContainer({
							 component: oComp,
						});
						
						item.addContent(oCompCont);
						break;
					/* INI PPM100076335 - Pestaña clasificacionIE 03/08/2022 */
					case zpa.grcaud.Constants.TabGroups.ClassificationIE:
						
						/*
						 * if(byId("lbl_search")){ byId("lbl_search").destroy();
						 * byId("srch_search").destroy(); }
						 */
						
						var that = this;
						var auxThis = this;
						var work = this.getView().work;
						
// //INI COMPONENT
// var oComp = sap.ui.getCore().createComponent({
// id: "ClasificacionIEComp",
// name: "ClasificacionIE"
// });
//						
// this.oComp = oComp;
//						
// // Se crea un contenedor para el componente
// var oCompCont = new sap.ui.core.ComponentContainer({
// component: oComp,
// });
//						
// item.addContent(oCompCont);
						
						// FIN COMPONENT
						/*
						 * var oLabel = new sap.m.Label("lbl_search", { text:
						 * "Programa de trabajo", layoutData: new
						 * sap.ui.layout.form.GridElementData({hCells: "4"})});
						 * this.getView().selectWork = new sap.m.Text({ text :
						 * "SOY EPICO" })
						 */
						/* INI PPM100076335 - Pestaña clasificacionIE 05/08/2022 */
						
						var modelAux = [];
						this.getView().setModel(new sap.ui.model.json.JSONModel(modelAux),"clasificacionIE");


						
						this.getView().Tabla = new sap.m.Table({
							  id:"tableClasificacionIE",
							  noDataText:"tableNoDataText",
							  updateFinished : "onUpdateFinished",
							  headerToolbar : [
							                  new sap.m.Toolbar({
							                  content:[
							                	  
							                	  new sap.m.HBox({
							                		  justifyContent : "End",
							                		  width : "100%",
							                		  items: [
							                			  new sap.m.Button({
									                		    icon: "sap-icon://add",
									                		    id: "addClassIE",
									                		    press: function(oEvent){
									 							   
									 							   var oSource = oEvent.getSource();
									 							   
									 							   // var
																	// sectionBindingModel
																	// =
																	// this.getView().getModel("sectionBindingConfig");
									 							   // this.findingKey
																	// =
																	// this.getView().getBindingContext().getObject().DBKey;
									 							   
//									 							   if(that.addClasificacionIESmartTable){
//									 								  that.addClasificacionIESmartTable.destroy();
//									 								}
									 							   
									 							   // Cargamos
																	// el
																	// fragment
									 							  that.addClasificacionIESmartTable = sap.ui.xmlfragment("appDataQ.fragment.AddClasificacionIEA", that);
// if (!auxThis._oDialogAdvSearch) {
// auxThis._oDialogAdvSearch =
// sap.ui.xmlfragment("appDataQ.fragment.AddClasificacionIEA", auxThis);
// auxThis.getView().addDependent(auxThis._oDialogAdvSearch);
// }
// auxThis._oDialogAdvSearch.open();
										 				        
										 				        
// var that = auxThis;
									 							   
									 							 // Realizar
																	// llamada
																	// al back
																	// para
																	// obtener
																	// el
																	// listado
																	// de
																	// findinds
																	// relacionados
									 								var ClasificacionIEModel = new sap.ui.model.odata.v2.ODataModel(
									 										"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false // //"ZGRCAUD_ENH_SRV"
									 									
									 								);
									 								
									 								var oData = {},
									 								aBatchOperations = [];
									 						
									 								// Limpiamos
																	// los
																	// registros
																	// seleccionados
																	// por si
																	// los
																	// hubiera
																	// de
																	// navegaciones
																	// anteriores
									 								try {
									 									that.getView().getContent()[0].getContent()[1].removeSelections();
									 								} catch (err) {}
									 						
									 								// limpiamos
																	// la tabla
																	// por si
																	// hubiera
																	// registros
																	// de
																	// consultas
																	// anteriores
// that.sModelData.ClasificacionIEData = [];
									 								
// that.tableContentModel.refresh();
									 								
									 								var aFilters = [];
									 								// aFilters.push(new
																	// sap.ui.model.Filter("ID",
																	// sap.ui.model.FilterOperator.GE,
																	// "2017"));
									 								//ClasificacionIEModel.read("/ZGRCAUD_CV_IE", {
									 								var sauditKey = listaInfoUtils.convertKeyBinToGuid(zpa.grcaud.dataqmodel.getModel("firstCallModel").getData().results[0].Value);
									 								ClasificacionIEModel.read("/ZGRCAUD_CV_IEBYAUDIT(p_audit=guid'"+ sauditKey +"')/Set", {
									 								// actionModel.read("/ZGRCAUD_CV_ACTRELTOFIND(p_find=guid'"
																	// +
																	// this.findingKey
																	// +
																	// "')/Set",
																	// {
									 								    // filters:
																		// aFilters,
									 									success: function (data, response) {
									 										
									 										data.results.sort(function(a, b) {
									 											  if (a.ID < b.ID) {
									 											    return 1;
									 											  }
									 											  if (a.ID > b.ID) {
									 											    return -1;
									 											  }
									 											  return 0;
									 											});
									 						
									 										if (data && data.results && data.results.length > 0) {				
									 											that.sModelData.ClasificacionIEData = data.results;
									 											that.tableContentModel.refresh();																											
									 										} else {
									 											console.log({ err: "No results" });
									 										}
									 										that.oValueHelpDialog.setBusy(false);
									 									},
									 									failed: function (oData, response) {
									 										that.oValueHelpDialog.setBusy(false);
									 										alert("Failed to get InputHelpValues from service!");
									 									},
									 								});
									 							   
									 							   
									 							   // this.addClasificacionIESmartTable.setModel(this.tableContentModel);
// var i18nModel = that.getView().getModel( "i18n");
// that.addClasificacionIESmartTable.setModel(i18nModel, "i18n");
									 								var oController = that;
									 							   
									 							   that.oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
									 									// title:
																		// this.getView().getModel("i18n").getResourceBundle().getText("labelLimitations"),
									 								   	title: "Clasificacion IE",
									 									supportMultiselect: true,
									 									supportRanges: false,
									 									supportRangesOnly: false,
									 									key: "subtopic_text",
									 									descriptionKey: "topic_text",
									 									stretch: sap.ui.Device.system.phone,
									 									contentHeight:"100%",
									 									
									 									ok: function(oOkEvent) {
									 										var aSelectedTokens = oOkEvent.getParameter("tokens");
									 										var PRUEBA = that.getView().getModel("clasificacionIE").getData();
									 										// oController.assignClasificacionIEToAudit(aSelectedTokens);
// sap.ui.getCore().
									 										that.getView().getParent().getParent().getParent().getController().getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(aSelectedTokens), "aSelectedTokens");
									 										
									 										for(var i = 0; i < aSelectedTokens.length; i++)
									 										{
									 											for(var j = 0; j < aSelectedTokens[i].mAggregations.customData.length; j++)
									 											{
									 												if(aSelectedTokens[i].mAggregations.customData[j] !== undefined)
									 												{
									 													var Tema = aSelectedTokens[i].mAggregations.customData[j].mProperties.value.topic_text;
									 													var Subtema = aSelectedTokens[i].mAggregations.customData[j].mProperties.value.subtopic_text;
									 													var idTema = aSelectedTokens[i].mAggregations.customData[j].mProperties.value.topic;
									 													var idSubTema = aSelectedTokens[i].mAggregations.customData[j].mProperties.value.subtopic;
									 												}
									 												
									 												//Validación Temas Repetidos
									 												for(var a = 0; a < PRUEBA.length; a++)
									 												{
									 													if(idSubTema === PRUEBA[a].Subtopic)
									 													{
									 														var dialog = new sap.m.Dialog({
									 									    					title: 'Información',
									 									    					type: 'Message',
									 									    						content: new sap.m.Text({
									 									    							text: "Algunos temas/subtemas seleccionados ya han sido a\u00f1adidos"
									 									    						}),
									 									    					endButton: new sap.m.Button({
									 									    						text: 'Aceptar',
									 									    						press: function () {
									 									    							dialog.close();
									 									    						}
									 									    					}),
									 									    					afterClose: function() {
									 									    						dialog.destroy();
									 									    					}
									 									    				});
									 									    				dialog.open();
								 									    					return;
									 													}
									 												}
									 												
									 												
									 												/*if(Tema !== undefined && Subtema !== undefined && Tema !== "" && Subtema !== "")
									 													PRUEBA.push({TopicText: Tema, SubtopicText: Subtema});*/
									 												if(Tema !== undefined && Subtema !== undefined && idTema !== undefined && idSubTema !== undefined && Tema !== "" && Subtema !== "" && idTema !== "" && idSubTema !== "")
									 													PRUEBA.push({TopicText: Tema, SubtopicText: Subtema, Topic: idTema, Subtopic: idSubTema});
									 							
									 											}
									 											
									 										}
									 										that.getView().getModel("clasificacionIE").setData(PRUEBA);
									 										that.getView().getModel("clasificacionIE").refresh();
									 										/*
																			 * var
																			 * Tema =
																			 * aSelectedTokens[1].mAggregations.customData[0].mProperties.value.topic_text
																			 * var
																			 * Subtema =
																			 * aSelectedTokens[1].mAggregations.customData[0].mProperties.value.subtopic_text
																			 */
									 										// var
																			// objeto
																			// =
																			// {TopicText:
																			// Tema,
																			// SubtopicTextt:
																			// Subtema};
									 										
									 										// sap.ui.getCore().byId("tableClasificacionIE").getModel("clasificacionIE").getData().results.push({TopicText:
																			// Tema,
																			// SubtopicText:
																			// Subtema});
// sap.ui.getCore().byId("tableClasificacionIE").getBinding("items").refresh();
									 										
									 										that.oValueHelpDialog.close();
									 										that.addClasificacionIESmartTable.destroy();
									 										that.oValueHelpDialog.destroy();
									 										// this.close();
									 									},
									 						
									 									cancel: function() {
									 										this.close();
									 										that.addClasificacionIESmartTable.destroy();
									 										that.oValueHelpDialog.destroy();
									 									},
									 						
									 									afterClose: function() {
									 										this.destroy();
									 									}
									 								});
									 							   
									 							   var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
									 									advancedMode: true,
									 									filterBarExpanded: false,
									 									showGoOnFB: !sap.ui.Device.system.phone,
									 									search: function() {
									 										oController.searchToBeAssignedTable();
									 									}
									 								});
									 							   
									 							   if (oFilterBar.setBasicSearch) {
									 									that.oBasicSearch = new sap.m.SearchField({
									 										id: "basicSearch",
									 										showSearchButton: sap.ui.Device.system.phone,
									 										// placeholder:
																			// this.getView().getModel("i18n").getResourceBundle().getText("labelSearchFindingPlaceHolder"),
									 										placeholder: "Buscar Clasificaciones",
									 										search: function() {
									 											oController.oValueHelpDialog.getFilterBar().search();
									 										}
									 									});
									 									oFilterBar.setBasicSearch(that.oBasicSearch);
									 								}
									 							   
									 							   // Abertura
																	// del
																	// dialogo
									 							   	that.oValueHelpDialog.setFilterBar(oFilterBar);
									 								that.oValueHelpDialog.setTable(that.addClasificacionIESmartTable.mAggregations.content[0]._oTable);
									 								that.oValueHelpDialog.setModel(that.tableContentModel);
									 								oSource.addDependent(that.oValueHelpDialog);
									 								that.oValueHelpDialog.open();
									 								// DESCOMENTAR
																	// DESPUES
																	// PARA
																	// CLASIFICACION
																	// IE CUANDO
																	// EXITEN
																	// LAS
																	// FUNCIONES
									 								that.oValueHelpDialog.setBusy(true);
									 							   
									 						  },
									                		    visible: true
									                	  
									                	  }),
									                	  new sap.m.Button({
									                		    icon: "sap-icon://save",
									                		    press: function() {
									                		    	if(this.validateData() === false) return; //Validación de Campos
									                		    	//that.validateData();
									                				var findingKey = listaInfoUtils.convertKeyBinToGuid(zpa.grcaud.dataqmodel.getModel("firstCallModel").getData().results[0].Value);
									                				var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false);
									                				//var that = this;
									                				/*var Incidencia = this.getView().byId("comboIncidencia").getValue();
									                				var ResponsableIncidencia = this.getView().byId("comboResponsableIncidencia").getSelectedKey();
									                				var Impacto = this.getView().byId("inputImpacto").getValue();*/
									                				
									                				var Incidencia = that.getView().Content2.getItems()[0].getItems()[0].getItems()[1].getItems()[0].getValue();
													           		var ResponsableIncidencia = that.getView().Content2.getItems()[0].getItems()[0].getItems()[1].getItems()[1].getSelectedKey();
													           		var Impacto = that.getView().Content2.getItems()[1].getItems()[1].getValue();
									                				
									                				var itemsTabla = that.getView().Tabla.getItems();
									                				var Topics_IE = [];				
									                				
									                				for (var i = 0; i < itemsTabla.length; i++) {
									                					var aux2 = {};
									                					aux2.ParentKey = findingKey;
									                					aux2.Topic = itemsTabla[i].getCells()[4].getText();
									                					aux2.Subtopic = itemsTabla[i].getCells()[5].getText();
									                					aux2.Main = itemsTabla[i].getCells()[2].getSelected();
									                					Topics_IE.push(aux2);	
									                				}
									                				var ImpactoLong;
									                				var Incident_IE = [];
									                				var aux = {};
									                				aux.ParentKey = findingKey;
									                				aux.Incident = (Incidencia === "Si") ? "Y" : "N";
									                				aux.ResInc = ResponsableIncidencia;
									                				ImpactoLong = (Impacto === "") ? "0" : Impacto.toString().replace(/\./g,'');
									                				aux.Impact = (ImpactoLong === "") ? "0" : ImpactoLong.toString().replace(/\,/g,'.');
									                				Incident_IE.push(aux);
									                				
									                				var objeto = {};
									                				objeto.Key = findingKey;
									                				objeto.Incident_IE = Incident_IE;
									                				objeto.Topics_IE = Topics_IE;
									                				
									                				oDataModel.create("/IESet", objeto, {
									                					async: true,
									                					success : function (oData) {
									                				  		that.getDataFromOdata();
									                			       }.bind(this),
									                			       error: function (oError) {
									                			       }.bind(this)
									                				});	
									                		      
									                		    },
									                		    visible: false
									                	  
									                	  }),
							                		  ]
							                	  }),
							                	  
							                	  ]
							                  })
											  ],
											  columns:[
											          new sap.m.Column({
											        	  width : "36%",
											        	  header:[
											                  new sap.m.Label({
											                  text:"Tema"
											                  })
											                  ]
											          }),new sap.m.Column({
											        	width : "36%",
											          	header:[
											                  new sap.m.Label({
											                  text:"Subtema"
											                  })
											                  ]
											          }),new sap.m.Column({
											        	  width : "8%",
											        	  header:[
											                  new sap.m.Label({
											                  text:"Principal"
											                  })
											                  ]
											          }),
											          ,new sap.m.Column({
											          })
											          ]
											  });
						//INI PPM100076335 01/05/2022
						this.getView().Tabla.bindAggregation("items", "clasificacionIE>/", new sap.m.ColumnListItem({
					        cells:[
					               new sap.m.Text({
					               text:"{clasificacionIE>TopicText}"
					               }),
					               new sap.m.Text({
					               text:"{clasificacionIE>SubtopicText}"
					               }),
					               new sap.m.RadioButton({
					               selected: "{= ${clasificacionIE>Main} === true ? true : false}"
					               }),
					               new sap.m.Button({
						               icon:"sap-icon://delete",
						               press: function(oEvent){
						            	   
						            	   //that.ClasificacionIE_DEL();
						            	   //var that = this;
							           		var keyObservacion = listaInfoUtils.convertKeyBinToGuid(zpa.grcaud.dataqmodel.getModel("firstCallModel").getData().results[0].Value);
							           		if(that.validateData() === false) return; //Validación de Campos
							           		var oDataModel = new sap.ui.model.odata.ODataModel(
							           				"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",
							           			false
							           		);

							           		//var Incidencia = this.getView().byId("comboIncidencia").getValue();
							           		var Incidencia = that.getView().Content2.getItems()[0].getItems()[0].getItems()[1].getItems()[0].getValue();
							           		//var ResponsableIncidencia = this.getView().byId("comboResponsableIncidencia").getSelectedKey();
							           		var ResponsableIncidencia = that.getView().Content2.getItems()[0].getItems()[0].getItems()[1].getItems()[1].getSelectedKey();
							           		//var Impacto = this.getView().byId("inputImpacto").getValue();
							           		var Impacto = that.getView().Content2.getItems()[1].getItems()[1].getValue();
							           			
							           		var id = oEvent.getParameters().id;
							           		var numTabla = id.substr(id.length - 1);
							           		//var itemsTabla = this.getView().byId("tableClasificacionIE").getItems();
							           		var itemsTabla = that.getView().Tabla.getItems(); //Items de la tabla
							           		var Topics_IE = [];
							           		
							           	//Validamos que el tema seleccionado no sea borrado si es principal
							    			if(itemsTabla[numTabla].getCells()[2].getSelected() === true)
							    			{
							    				var dialog = new sap.m.Dialog({
							    					title: 'Información',
							    					type: 'Message',
							    						content: new sap.m.Text({
							    							text: "No es posible borrar el Tema/Subtema principal"
							    						}),
							    					endButton: new sap.m.Button({
							    						text: 'Aceptar',
							    						press: function () {
							    							dialog.close();
							    						}
							    					}),
							    					afterClose: function() {
							    						dialog.destroy();
							    					}
							    				});
							    				dialog.open();
							    				//MessageUtil.showMsg("msgTypeFailed", "Seleccione una incidencia");
							    				return false;
							    			}
							           					
							           		for (var i = 0; i < itemsTabla.length; i++) 
							           		{			
							           			if(itemsTabla[i] !== itemsTabla[numTabla])
							           			{
							           				var aux2 = {};
							           				aux2.ParentKey = keyObservacion;
							           				aux2.Topic = itemsTabla[i].getCells()[4].getText();
							           				aux2.Subtopic = itemsTabla[i].getCells()[5].getText();
							           				aux2.Main = itemsTabla[i].getCells()[2].getSelected();
							           				Topics_IE.push(aux2);	
							           			}
							           			
							           		}
							           		var ImpactoLong;
							           		var Incident_IE = [];
							           		var aux = {};
							           		aux.ParentKey = keyObservacion;
							           		aux.Incident = (Incidencia === "Si") ? "Y" : "N";
							           		aux.ResInc = ResponsableIncidencia;
							           		ImpactoLong = (Impacto === "") ? "0" : Impacto.toString().replace(/\./g,'');
											aux.Impact = (ImpactoLong === "") ? "0" : ImpactoLong.toString().replace(/\,/g,'.');
							           		Incident_IE.push(aux);
							           		
							           		var objeto = {};
							           		objeto.Key = keyObservacion;
							           		objeto.Incident_IE = Incident_IE;
							           		objeto.Topics_IE = Topics_IE;
							           		
							           		oDataModel.create("/IESet", objeto, {
							           			async: true,
							           			success : function (oData) {
							           		  		that.getDataFromOdata();
							           		  		
								           		  	var dialog = new sap.m.Dialog({
								        				title: 'Información',
								        				type: 'Message',
								        				content: new sap.m.Text({
								        					text: "Datos Clasificación IE borrados correctamente"
								        				}),
								        				beginButton: new sap.m.Button({
								        					text: 'Aceptar',
								        					press: function () {
								        						dialog.close();
								        					}
								        				}),
								        				afterClose: function() {
								        					dialog.destroy();
								        				}
								        			});
								        			dialog.open();
							           	       }.bind(this),
							           	       error: function (oError) {
							           	    	   that._oDataError(oError);
							           	       }.bind(this)
							           		});
						               }
					               }),
					               new sap.m.ObjectIdentifier({
					            	   text:"{clasificacionIE>Topic}",
					            	   visible: false
					               }),
					               new sap.m.ObjectIdentifier({
					            	   text:"{clasificacionIE>Subtopic}",
					            	   visible: false
					               })
					               ]
					        })
						);
						//END PPM100076335 01/05/2022
						this.getView().Content2 = new sap.m.HBox({
	                		  justifyContent : "Center",
	                		  alignItems : "Center",
	                		  layoutData: new sap.m.FlexItemData({
            						alignSelf: sap.m.FlexAlignSelf.Center,styleClass: "marginClasificacionIE"}),
	                		  items: [
	                			  new sap.m.VBox({
			                		    class: "sapUiSmallMarginEnd",
			                		    items: [
				                			  new sap.m.HBox({
				                				  layoutData: new sap.m.FlexItemData({
				              						alignSelf: sap.m.FlexAlignSelf.Center,styleClass: "marginClasificacionIE"}),
				                				  items: [
						                			  new sap.m.VBox({
						                				  items: [
								                			  new sap.m.Label({
								                				  text: "Incidencia:",
								                				  required: true,
								                				  layoutData: new sap.m.FlexItemData({
									              						alignSelf: sap.m.FlexAlignSelf.Center,styleClass: "marginClasificacionIE"})
										                	  
										                	  }),
										                	  new sap.m.Label({
								                				  text: "Responsable Incidencia:",
								                				  required: true,
								                				  layoutData: new sap.m.FlexItemData({
									              						alignSelf: sap.m.FlexAlignSelf.Center,styleClass: "marginClasificacionIE"})
										                	  
										                	  })
								                		  ]
								                	  
								                	  }),
								                	  new sap.m.VBox({
								                		  items: [
								                			  new sap.m.ComboBox({
								                				  id: "comboIncidencia",
								                				  width: "300px",
								                				  items: [
								                                        // path:
																		// "{ComboBoxModel>/}",
								                                        // template:
								                                        /*new sap.ui.core.Item({
								                                            key: "X",
								                                            text: "Si"
								                                        }),
								                                        new sap.ui.core.Item({	
									                                            key: "NO",
									                                            text: "No"
								                                        })*/
								                					  // INI PPM100076335 - Cambio 'X' -> Y, '' -> N
								                					  	new sap.ui.core.Item({
								                                            key: "Y",
								                                            text: "Si"
								                                        }),
								                                        new sap.ui.core.Item({	
									                                        key: "N",
									                                        text: "No"
								                                        })
								                                        // FIN PPM100076335
								                                        
								                                    ]  
										                	  
										                	  }),
										                	  new sap.m.ComboBox({
										                		  id: "cmbResponsableIncidencias",
										                		  width: "300px",
										                		  items: {
								                                        path: "cmbResponsableIncidencias>/",
								                                        template:new sap.ui.core.Item({
								                                            key: "{cmbResponsableIncidencias>res_inc}",
								                                            text: "{cmbResponsableIncidencias>res_inc_text}"
								                                        })
								                                        
										                	  		}  
										                	  
										                	  })
								                		  ]
								                	  
								                	  }),
						                		  ]
						                	  
						                	  })
				                		  ]
			                	  
			                	  }),
			                	  new sap.m.HBox({
			                		  items: [
			                			  new sap.m.Label({
			                				  id: "inputImpacto",
			                				  text: "Impacto:",
			                				  layoutData: new sap.m.FlexItemData({
				              						alignSelf: sap.m.FlexAlignSelf.Center,styleClass: "marginClasificacionIE"})
					                	  
					                	  }),
					                	  new sap.m.Input({
			                				  
					                	  
					                	  })
			                		  ]
			                	  })
	                		  ]
	                	  })

						
						 
	                	
	              		
						this.getView().aForms[countSelected].getFormContainers()[0].insertFormElement(new sap.ui.layout.form.FormElement({ label: oLabel, fields: [this.getView().selectWork], tabla: this.getView().Tabla }), 0);
						// item.addContent(this.getView().aForms[countSelected]);
						// INI PPM100076335 29/08/2022
						item.addContent(item.addClasificacionIESmartTable);
						// FIN PPM100076335 29/08/2022
						item.addContent(this.getView().Tabla);
						item.addContent(this.getView().Content2);
						/* FIN PPM100076335 - Pestaña clasificacionIE 05/08/2022 */
						if(this.getView().aTables[countSelected].length !== 0){
							item.addContent(this.getView().aTables[countSelected]);
						}
						
						
						  // FUNCION DE AÑADIR NUEVOS ELEMENTOS AL POP-UP DE
							// CLASIFICACION IE
						  
						// FIN PPM100076335 25/08/2022
						
						
						break;
					/* FIN PPM100076335 - Pestaña clasificacionIE 03/08/2022 */
					
					/*INI PPM100077498 - Pestaña Encuestas*/	
					case zpa.grcaud.Constants.TabGroups.Encuestas:
						
						var that = this;
						var auxThis = this;
						var work = this.getView().work;
						
						var modelAux = [];
						this.getView().setModel(new sap.ui.model.json.JSONModel(modelAux),"encuestas");


						
						this.getView().Tabla = new sap.m.Table({
							  id:"tableEncuestas",
							  noDataText:"tableNoDataText",
							  updateFinished : "onUpdateFinished",
							  headerToolbar : [
							                  new sap.m.Toolbar({
							                  content:[							                	  
							                	  new sap.m.HBox({
							                		  id: "HBoxTablaEncuestas",
							                		  justifyContent : "End",
							                		  width : "100%",
							                		  items: [
							                			  new sap.m.CheckBox({
							                				  text: "NA",
							                				  selected: false,
							                				  select: function(oEvent){
							                					  
							                					  if(oEvent === "activoNA") that.getView().Tabla.setVisible(true);
							                					  
							                					  if(that.getView().Tabla.getVisible() === true)
							                					  {
							                						  that.getView().Tabla.getHeaderToolbar().getContent()[0].setVisible(false); 				//Toolbar
							                						  that.getView().Tabla.setVisible(false);													//Tabla Encuestas
							                						  that.getView().Tabla.getHeaderToolbar().getContent()[0].getItems()[0].setSelected(false);	//CheckNATabla
							                						  that.getView().Content3.setVisible(true);
							                						  that.getView().Content3.getItems()[0].getItems()[0].getItems()[0].setSelected(true)
							                					  }
							                					  else
							                					  {
							                						  that.getView().Tabla.getHeaderToolbar().getContent()[0].setVisible(true);
							                						  that.getView().Tabla.setVisible(true);
							                						  that.getView().Content3.setVisible(false);
							                						  that.getView().Content3.getItems()[0].getItems()[0].getItems()[0].setSelected(false);
							                					  }
							                				  }
							                			  }),
							                					  
							                			  new sap.m.Button({
									                		    icon: "sap-icon://add",									                		    
									                		    press: function(oEvent){
									 							   
									 							   var oSource = oEvent.getSource();

									 							  that.addEncuestasSmartTable = sap.ui.xmlfragment("appDataQ.fragment.addEncuestas", that);

										 							var EncuestasModel = new sap.ui.model.odata.v2.ODataModel(
										 									"/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/",false ////"ZGRCAUD_ENH_SRV"
										 								
										 							);
									 								
									 								var oData = {},
									 								aBatchOperations = [];

									 								try {
									 									that.getView().getContent()[0].getContent()[1].removeSelections();
									 								} catch (err) {}

									 								var aFilters = [];

									 								var sauditKey = listaInfoUtils.convertKeyBinToGuid(zpa.grcaud.dataqmodel.getModel("firstCallModel").getData().results[0].Value);

									 								var oController = that;
									 							   
									 							   that.oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
									 									// title:
																		// this.getView().getModel("i18n").getResourceBundle().getText("labelLimitations"),
									 								   	title: "Usuarios de Encuestas",
									 									supportMultiselect: true,
									 									supportRanges: false,
									 									supportRangesOnly: false,
									 									key: "UserId",
									 									descriptionKey: "FullName",
									 									stretch: sap.ui.Device.system.phone,
									 									contentHeight:"100%",
									 									
									 									ok: function(oOkEvent) {
									 										var aSelectedTokens = oOkEvent.getParameter("tokens");
									 										var PRUEBA = that.getView().getModel("encuestas").getData();

									 										that.getView().getParent().getParent().getParent().getController().getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(aSelectedTokens), "aSelectedTokens");
									 										
									 										for(var i = 0; i < aSelectedTokens.length; i++)
									 										{
									 											for(var j = 0; j < aSelectedTokens[i].mAggregations.customData.length; j++)
									 											{
									 												if(aSelectedTokens[i].mAggregations.customData[j] !== undefined)
									 												{
									 													var UserId = aSelectedTokens[i].mAggregations.customData[j].mProperties.value.UserId;
									 													var FullName = aSelectedTokens[i].mAggregations.customData[j].mProperties.value.FullName;
									 													var Email = aSelectedTokens[i].mAggregations.customData[j].mProperties.value.Email;
									 												}

									 												if(UserId !== undefined && FullName !== undefined && Email !== undefined && UserId !== "" && FullName !== "" && Email !== "")
									 													PRUEBA.push({user_id: UserId, Full_Name: FullName, Email: Email, langu: "ES"});
									 							
									 											}
									 											
									 										}
									 										PRUEBA.sort(function(a, b) {
									 											  if (a.user_id < b.user_id) {
									 											    return 1;
									 											  }
									 											  if (a.user_id > b.user_id) {
									 											    return -1;
									 											  }
									 											  return 0;
									 											});
									 										that.getView().getModel("encuestas").setData(PRUEBA);
									 										that.getView().getModel("encuestas").refresh();
									 										
									 										that.oValueHelpDialog.close();
									 										that.addEncuestasSmartTable.destroy();
									 										that.oValueHelpDialog.destroy();
									 										// this.close();
									 									},
									 						
									 									cancel: function() {
									 										this.close();
									 										that.addEncuestasSmartTable.destroy();
									 										that.oValueHelpDialog.destroy();
									 									},
									 						
									 									afterClose: function() {
									 										this.destroy();
									 									}
									 								});
									 							   
									 							   var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
									 									advancedMode: true,
									 									filterBarExpanded: false,
									 									showGoOnFB: !sap.ui.Device.system.phone,
									 									search: function() {
									 										
									 										var UsuarioEscrito = oController.oBasicSearch.mProperties.value;
									 										var aFilters = [];
									 										var filtro = "?$filter=(substringof('" + UsuarioEscrito + "',FullName))";
									 										var url = "/RoleSet(RoleId='AUD',RoleDepId='')/Users";
									 										var aFilters = [];
									 										aFilters.push(new sap.ui.model.Filter("FullName",sap.ui.model.FilterOperator.Contains, UsuarioEscrito.toUpperCase()));
									 										EncuestasModel.read(url, {
									 											    filters: aFilters,
									 												success: function (data, response) {
									 													
									 													data.results.sort(function(a, b) {
									 														  if (a.UserId < b.UserId) {
									 														    return 1;
									 														  }
									 														  if (a.UserId > b.UserId) {
									 														    return -1;
									 														  }
									 														  return 0;
									 														});
									 									
									 													if (data && data.results && data.results.length > 0) {				
									 														that.sModelData.EncuestasData = data.results;
									 														that.tableContentModel.refresh();																											
									 													} else {
									 														console.log({ err: "No results" });
									 													}
									 													that.oValueHelpDialog.setBusy(false);
									 												},
									 												failed: function (oData, response) {
									 													that.oValueHelpDialog.setBusy(false);
									 													alert("Failed to get InputHelpValues from service!");
									 												},
									 											});
									 										//oController.searchToBeAssignedTable();
									 									}
									 								});
									 							   
									 							   if (oFilterBar.setBasicSearch) {
									 									that.oBasicSearch = new sap.m.SearchField({
									 										id: "basicSearch",
									 										showSearchButton: sap.ui.Device.system.phone,
									 										// placeholder:
																			// this.getView().getModel("i18n").getResourceBundle().getText("labelSearchFindingPlaceHolder"),
									 										placeholder: "Buscar Usuarios",
									 										search: function() {
									 											oController.oValueHelpDialog.getFilterBar().search();
									 										}
									 									});
									 									oFilterBar.setBasicSearch(that.oBasicSearch);
									 								}
									 							   	that.oValueHelpDialog.setFilterBar(oFilterBar);
									 								that.oValueHelpDialog.setTable(that.addEncuestasSmartTable);
									 								that.oValueHelpDialog.setModel(that.tableContentModel);
									 								oSource.addDependent(that.oValueHelpDialog);
									 								that.oValueHelpDialog.open();
									 								
									 								//that.oValueHelpDialog.setBusy(true);
									 							   
									 						  },
									                		    visible: true
									                	  
									                	  }),
									                	  new sap.m.Button({
									                		    icon: "sap-icon://save",
									                		    press: function() {

									                				var findingKey = listaInfoUtils.convertKeyBinToGuid(zpa.grcaud.dataqmodel.getModel("firstCallModel").getData().results[0].Value);
									                				var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false);								                				
									                				var itemsTabla = that.getView().Tabla.getItems();
									                				
									                		      
									                		    },
									                		    visible: false
									                	  
									                	  }),
							                		  ]
							                	  }),
							                	  
							                	  ]
							                  })
											  ],
											  columns:[
											          new sap.m.Column({
											        	  header:[
											                  new sap.m.Label({
											                  text:"Usuario"
											                  })
											                  ]
											          }),new sap.m.Column({
											          	header:[
											                  new sap.m.Label({
											                  text:"Nombre"
											                  })
											                  ]
											          }),new sap.m.Column({
											        	  header:[
											                  new sap.m.Label({
											                  text:"Email"
											                  })
											                  ]
											          }),new sap.m.Column({
											        	  header:[
											                  new sap.m.Label({
											                  text:"Idioma"
											                  })
											                  ]
											          }),
											          ,new sap.m.Column({
											          })
											          ]
											  });
						
						this.getView().Tabla.bindAggregation("items", "encuestas>/", new sap.m.ColumnListItem({
					        cells:[
					               new sap.m.Text({
					               text:"{encuestas>user_id}"
					               }),
					               new sap.m.Text({
					               text:"{encuestas>Full_Name}"
					               }),
					               new sap.m.Text({
						               text:"{encuestas>Email}"
						           }),
						           new sap.m.ComboBox({
		                				  selectedKey: "{encuestas>langu}",
		                				  items: [
		                                        new sap.ui.core.Item({
		                                            key: "CA",
		                                            text: "Catalán"
		                                        }),
		                                        new sap.ui.core.Item({	
			                                            key: "ES",
			                                            text: "Español"
		                                        }),
		                                        new sap.ui.core.Item({	
		                                            key: "PT",
		                                            text: "Portugués"
	                                        })
		                                        
		                                    ]  
				                	  
				                   }),
					               new sap.m.Button({
						               icon:"sap-icon://delete",
						               press: function(oEvent){

						            	  //var that = this;
							           	  var keyObservacion = listaInfoUtils.convertKeyBinToGuid(zpa.grcaud.dataqmodel.getModel("firstCallModel").getData().results[0].Value);           									           		
							      		  
							      		  //Realizar llamada al back para obtener el listado de encuestas
							      		  var encuestasModel = new sap.ui.model.odata.v2.ODataModel(
							      			  "/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
							      		  );
							      		  
							      		  var id = oEvent.getParameters().id;
							      		  var numTabla = id.substr(id.length - 1);
							      		  var itemsTabla = that.getView().Tabla.getItems();
							      		  var userKey = that.getView().Tabla.getItems()[numTabla].getCells()[5].getText()
							      		  
							      		  var url = "/ZGRCAUD_CV_Survey(guid'"+userKey+"')";
							      		  
							      		  encuestasModel.remove(url, {
							      			  success : function () {					
							      					//Refrescamos tabla principal de Encuestas
							      					that.getDataFromOdataEncuestas();
							      					//MessageUtil.showMsg("msgTypeSuccessful", that.getView().getModel("i18n").getResourceBundle().getText("msgBorradoUsuario"));
							      					listaInfoUtils.showMsg("Se ha borrado correctamente el comentario")
							      		       },
							      		     error: function (oError) {
										    	   that._oDataError(oError);
										       }.bind(this),
							      				failed: function (oData, response) {
							      					alert("Failed to get InputHelpValues from service!");
							      				},
							      			});
						               }
					               }),
					               new sap.m.ObjectIdentifier({
					            	   text:"{encuestas>db_key}",
					            	   visible: false
					               })
					             ]
					        })
						);
						
						this.getView().Content3 = new sap.m.HBox({
							  width: "100%",
							  visible: false,
	                		  /*layoutData: new sap.m.FlexItemData({
          						alignSelf: sap.m.FlexAlignSelf.Center,styleClass: "marginClasificacionIE"}),*/
	                		  items: [
	                			  new sap.m.VBox({
	                				  width: "100%",
			                		  items: [
						                	  new sap.m.HBox({
						                		  width: "100%",
						                		  justifyContent : "End",
						                		  alignItems : "End",
						                		  items: [
						                			  new sap.m.CheckBox({
						                				  text: "NA",
						                				  selected: true,
						                				  select: function(oEvent){
						                					  
						                					  if(oEvent === "activoNA") that.getView().Tabla.setVisible(true);
						                					  
						                					  if(that.getView().Tabla.getVisible() === true)
						                					  {
						                						  that.getView().Tabla.getHeaderToolbar().getContent()[0].setVisible(false); 				//Toolbar
						                						  that.getView().Tabla.setVisible(false);													//Tabla Encuestas
						                						  that.getView().Tabla.getHeaderToolbar().getContent()[0].getItems()[0].setSelected(false);	//CheckNATabla
						                						  that.getView().Content3.setVisible(true);
						                						  that.getView().Content3.getItems()[0].getItems()[0].getItems()[0].setSelected(true)
						                					  }
						                					  else
						                					  {
						                						  that.getView().Tabla.getHeaderToolbar().getContent()[0].setVisible(true);
						                						  that.getView().Tabla.setVisible(true);
						                						  that.getView().Content3.setVisible(false);
						                						  that.getView().Content3.getItems()[0].getItems()[0].getItems()[0].setSelected(false);
						                					  }
						                				  }
						                			  }),
						                			  new sap.m.Button({
											               icon:"sap-icon://delete",
											               press: function(oEvent){
			
											            	  //var that = this;
												         		  
											         		  var sauditKey = listaInfoUtils.convertKeyBinToGuid(zpa.grcaud.dataqmodel.getModel("firstCallModel").getData().results[0].Value);
											         		  var dbKey = that.getView().Content3.getItems()[0].getItems()[2].mProperties.text;
											         		  //Realizar llamada al back para obtener el listado de encuestas
											         		  var encuestasModel = new sap.ui.model.odata.v2.ODataModel(
											         			  "/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
											         		  );

											         			encuestasModel.remove("/ZGRCAUD_CV_SurveyNote(guid'"+dbKey+"')", {
										         					success : function (oData) {
										         						that.getDataFromOdataEncuestas();
										         						that.getDataNA();
										         						
										         						var dialog = new sap.m.Dialog({
													    					title: 'Información',
													    					type: 'Message',
													    						content: new sap.m.Text({
													    							text: "Se ha borrado correctamente el comentario"
													    						}),
													    					endButton: new sap.m.Button({
													    						text: 'Aceptar',
													    						press: function () {
													    							dialog.close();
													    						}
													    					}),
													    					afterClose: function() {
													    						dialog.destroy();
													    					}
													    				});
													    				dialog.open();
										         						//MessageUtil.showMsg("msgTypeSuccessful", this.getView().getModel("i18n").getResourceBundle().getText("Comentario Borrado Correctamente"));
										         			       }.bind(this),
										         			       error: function (oError) {
										         			    	  that._oDataError(oError);
										         			       }.bind(this)
										         				});
											               }
										               }),
						                		  ]
						                	  }),
						                	  
						                	  /*new sap.m.HBox({
						                		  width: "100%",
						                		  items: [
						                			  new sap.m.TextArea({
									                		//id: "textAreaNA",
									                		width: "100%",
									                		type: "text"
									                		
									                	  }),
									                	  
								                	  new sap.m.ObjectIdentifier({
								                		   //id: "dbKey",
								                		   text: "",	 
										            	   visible: false
										               })
						                		  ]
						                	  }),*/
						                	  
						                	  new sap.m.TextArea({
							                		id: "textAreaNA",
							                		width: "100%",
							                		type: "text"
							                		
							                	  }),
							                	  
						                	  new sap.m.ObjectIdentifier({
						                		   id: "dbKey",
						                		   text: "",	 
								            	   visible: false
								               })
			                	 
			                	  ]}),
			                	  
	                		  ]
	                	  })
					
						this.getView().aForms[countSelected].getFormContainers()[0].insertFormElement(new sap.ui.layout.form.FormElement({ label: oLabel, fields: [this.getView().selectWork], tabla: this.getView().Tabla }), 0);
						item.addContent(this.getView().Tabla);
						item.addContent(this.getView().Content3);
						if(this.getView().aTables[countSelected].length !== 0){
							item.addContent(this.getView().aTables[countSelected]);
						}
						
						
					break;
					/*FINI PPM100077498 - Pestaña Encuestas*/		
					
					/* INI PPM100076801 - Pestaña Limitaciones 08/08/2022 */
					case zpa.grcaud.Constants.TabGroups.Limitaciones:
						this.getView().Tabla = new sap.m.Table({
							  id:"tableLimitations",
							  mode:"MultiSelect",
							  ariaLabelledBy:"hiddenText",
							  items:"{path: 'limitations>/'}",
							  noDataText:"No hay entradas disponibles",
							  headerToolbar : [
							                  new sap.m.Toolbar({
							                  id:'limitationsToolbar',
							                  width:"100%",
							                  content:[
							                	  new sap.m.Input({
							                		  id:"inputLimitations",
							                		  placeholder:"Escriba Limitacion",
							                		  width:"90%"  
							                	  }),
							                	  new sap.m.HBox({
							                		  justifyContent : "End",
							                		  width : "10%",
							                		  items: [
							                			  new sap.m.Button({
							                				    id:"btn_addLimitations",
							                				    icon:"sap-icon://add",
							                				    press: function() {
										                		     
									                		    },
							                				    visible:true,
									                	  }),
									                	  new sap.m.Button({
									                		  	id:"btn_EditLimitations",
									                		    icon:"sap-icon://edit",
									                		    press: function() {
									                		      
									                		    },
									                		    visible: true
									                	  
									                	  }),
									                	  new sap.m.Button({
									                		  	id:"btn_SaveLimitations",
									                		    icon:"sap-icon://save",
									                		    press: function() {
									                		      
									                		    },
									                		    visible: false
									                	  
									                	  }),
							                		  ]
							                	  }),
							                	  
							                	  ]
							                  })
											  ],
											  columns:[
											          new sap.m.Column({
											        	  id:"colLimitations",
											        	  width:"90%",
											        	  header:[
											                  new sap.m.Label({
											                  text:""
											                  })
											                  ]
											          }),new sap.m.Column({
											        	id:"colLimitationsDel",
											          	header:[
											                  new sap.m.Label({
											                  text:""
											                  })
											                  ],
											            customData:[
											                new sap.ui.core.CustomData({
														    key:"DB_KEY",
														    value:'\{"columnKey": "DB_KEY"}'
											                }),
											                  ],
											               
											          	
											          }),new sap.m.Column({
											        	  visible:false,
											        	  header:[
											                  new sap.m.Label({
											                  text:""
											                  })
											                  ]
											          })
											          ],
											  items:[
											        new sap.m.ColumnListItem({
											        cells:[
											               new sap.m.Input({
											               value:"{limitations>limitation}",
											               editable:false
											               }),
											               new sap.m.Button({
											               id:"btn_RemoveLimitationsRow",
											               icon:"sap-icon://delete",
											               press:"Limitations_DEL",
											               visible:true
											               }),
											               new sap.m.ObjectIdentifier({
											               text:"{limitations>db_key}",
											               visible:false
											               })											               
											               ]
											        })
											        ]
											  });
						this.getView().aForms[countSelected].getFormContainers()[0].insertFormElement(new sap.ui.layout.form.FormElement({ label: oLabel, fields: [this.getView().selectWork], tabla: this.getView().Tabla }), 0);
						// item.addContent(this.getView().aForms[countSelected]);
						item.addContent(this.getView().Tabla);
						/* FIN PPM100076335 - Pestaña clasificacionIE 05/08/2022 */
						if(this.getView().aTables[countSelected].length !== 0){
							item.addContent(this.getView().aTables[countSelected]);
						}
						break;
					/* FIN PPM100076801 - Pestaña Limitaciones 08/08/2022 */
						
						
					case zpa.grcaud.Constants.TabGroups.Risks:
						zpa.grcaud.dataqmodel.loadRisksTables.call(this, "AUDIT");
						item.addContent(this.getView().oDynamicSideContent);
						break;
					
					case zpa.grcaud.Constants.TabGroups.WorkProgram: // se
																		// podria
																		// juntar
																		// con
																		// el
																		// default
																		// con
																		// un
																		// simple
																		// if
																		// pero
																		// queda
																		// mas
																		// ordenado
																		// asi
							
							if(byId("lbl_searchProgram")){
								byId("lbl_searchProgram").destroy();
								byId("srch_searchProgram").destroy();
							}
							var that = this;
							var work = this.getView().work;
							var oLabel = new sap.m.Label("lbl_searchProgram", { text: "Programa de trabajo", layoutData: new sap.ui.layout.form.GridElementData({hCells: "4"})});
							this.getView().selectWork = new sap.m.Select("srch_searchProgram", {rows: 5, layoutData: new sap.ui.layout.form.GridElementData({hCells: "auto"}), forceSelection: false,
								change: function(){
									if(this.getSelectedKey() !== ""){
										byId("inp_AUDIT-WORKPROGRAM-DESCRIPTION-").getParent().setVisible(true);
										byId("inp_AUDIT-WORKPROGRAM-CODE-").getParent().setVisible(true);
										byId("inp_AUDIT-WORKPROGRAM-CODE-").setValueState("None");
										byId("inp_AUDIT-WORKPROGRAM-NAME-").getParent().setVisible(true);
										byId("inp_AUDIT-WORKPROGRAM-NAME-").setValueState("None");
										byId("inp_AUDIT-WORKPROGRAM-FULL_NAME-").getParent().setVisible(true);
									}
									
									for(var i = 0; i < work.length; i++){
										if(work[i].Seq === this.getSelectedKey()){
											var j = 0;
											var found = false;
											while(j < work.length && !found){
												if(work[j].KEY === work[i].PARENT_SCOPE){ // buscamos
																							// valores
																							// del
																							// programa
																							// de
																							// trabajo
																							// para
																							// ambito
																							// y
																							// subambito
													byId("inp_AUDIT-WORKPROGRAM-DESCRIPTION-").setValue(work[i].DESCRIPTION);
													byId("inp_AUDIT-WORKPROGRAM-CODE-").setValue(work[j].NAME);
													byId("inp_AUDIT-WORKPROGRAM-NAME-").setValue(work[i].NAME);
													zpa.grcaud.dataqmodel.getResponsable.call(work[i]);
													found = true;
												}
												j++;
											}
										}
									}
								}
							});
							
							for(var j = 0; j < work.length; j++){
								if(work[j].KEY && work[j].PARENT_SCOPE === zpa.grcaud.Constants.Work.Parent_scope){ // añadimos
																													// item
																													// en
																													// select
																													// si
																													// es
																													// subambito
									var itemStr = work[j].CODE + " " + work[j].NAME;
									for(var z = 0; z < work.length; z++){ // buscamos
																			// el
																			// ambito
																			// para
																			// el
																			// subambito
										if(work[z].PARENT_SCOPE === work[j].KEY){
											this.getView().selectWork.addItem(new sap.ui.core.Item({
												key: work[z].Seq,
												text: work[j].CODE + " " + work[j].NAME + " " + work[z].CODE + " " + work[z].NAME
												})
											);
										}
									}
								}
							}
					
							this.getView().aForms[countSelected].getFormContainers()[0].insertFormElement(new sap.ui.layout.form.FormElement({ label: oLabel, fields: [this.getView().selectWork] }), 0);
							
							item.addContent(this.getView().aForms[countSelected]); 
							if(this.getView().aTables[countSelected].length !== 0){
								item.addContent(this.getView().aTables[countSelected]);
							}
							
							break;
					default:
					
						item.addContent(this.getView().aForms[countSelected]);
						if(this.getView().aTables[countSelected].length !== 0){
							item.addContent(this.getView().aTables[countSelected]);
						}
						
						break;
				}
				
				this.getView().oIconTabBar.addItem(item);
				
				countSelected++;
			}
			
			
			
		}
		
		// INI PPM100076335 25/08/2022
		// Carga del combo responsable de incidencias
		  this.tableContentModel = new sap.ui.model.json.JSONModel();
		  this.sModelData = {
				  ClasificacionIEData: [],
				  EncuestasData: [],
		  	};
		  this.tableContentModel.setData(this.sModelData);
		  this.getComboIncidencias();
		  //INI PPM100076801 
		  this.getDataFromOdata();
		//END PPM100076801 
		// FIN PPM100076335 25/08/2022
		 
		/*INI PPM100077498 - Pestaña Encuestas*/
		  this.getDataFromOdataEncuestas();
		  this.getDataNA();
	    /*FIN PPM100077498 - Pestaña Encuestas*/
	},

/**
 * Similar to onAfterRendering, but this hook is invoked before the controller's
 * View is re-rendered (NOT before the first rendering! onInit() is used for
 * that one!).
 * 
 * @memberOf appDataQ.controller.DetailScreen
 */
// onBeforeRendering: function() {
//
// },

/**
 * Called when the View has been rendered (so its HTML is part of the document).
 * Post-rendering manipulations of the HTML could be done here. This hook is the
 * same one that SAPUI5 controls get after being rendered.
 * 
 * @memberOf appDataQ.controller.DetailScreen
 */
	onAfterRendering: function() {
		var oComp = sap.ui.getCore().getComponent("FraudeComp")
		
		if(oComp) {
			oComp.setParticipa();
		}
	},

	onUpdateFinished: function(){
		//console.log("onUpdateFinished");
	},
	
	// INI PPM100076801
	
	//Funcion de error
	_oDataError: function (oError, fFunction) {
		var message, data;

		try {
			// lo formateamos a JSON
			data = $.parseJSON(oError.responseText);
			message = "";

			// obtengo el nombre del servicio
			// if(data.error.innererror.application) {  /*JPM*/
			// 	service = data.error.innererror.application.service_id;  /*JPM*/
			// }  /*JPM*/
			// obtengo el mensaje de error
			if (data.error.innererror.errordetails && data.error.innererror.errordetails.length > 0) {
				for (var i = 0; i < data.error.innererror.errordetails.length; i++) {
					if (data.error.innererror.errordetails[i].code !== "/IWBEP/CX_SD_GEN_DPC_BUSINS") {
						// message += data.error.innererror.errordetails[i].code + " - " + data.error.innererror.errordetails[i].message + "\n";  /*JPM*/
						message += data.error.innererror.errordetails[i].message + "\n";
					}
				}
			} else {
				message += data.error.message.value;
			}
		} catch (err) {
			// si el formateo a JSON falla, lo intentamos formatear a XML
			data = $.parseXML(oError.responseText);
			var $xml = $(data);
			var $message = $xml.find("innererror").find("message");
			if (!$message.text()) {
				$message = $xml.find("message");
			}
			//var $service = $xml.find( "service_id" ); /*JPM*/
			message = $message.text();
			//service = $service.text(); /*JPM*/
		}

		// quitamos el busy de espera
		if (this.getView()) {
			this.getView().setBusy(false);
		}

		// Mostramos el mensaje de error por pantalla
		sap.m.MessageBox.alert(message, {
			icon: sap.m.MessageBox.Icon.ERROR,
			/*title: "Error on service " + service,*/
			title: "Error",
			/*JPM*/
			onClose: function () {
				// si existe se ejecuta la funcion pasada como parametro
				if (fFunction) {
					fFunction();
				}
			}
		});
	},
 
	
	//FUNCIÓN DE REFRESCO DE DATOS LA TABLA PRINCIPAL CLASIFICACIONIE
	getDataFromOdata: function(){
		
		//this.onSetVisibilityAction();	
		var that = this;
		
		//Damos formato para los números del impacto
		/*var formatOptions = {
			maxFractionDigits: 0,
			maxIntegerDigits: 29,
			minFractionDigits: 0,
			minIntegerDigits: 0
		}
		var oFloatFormat = NumberFormat.getFloatInstance(formatOptions);*/
		
		var oData = {},
			aBatchOperations = [];										
		
		var sauditKey = listaInfoUtils.convertKeyBinToGuid(zpa.grcaud.dataqmodel.getModel("firstCallModel").getData().results[0].Value);
		
		//var sauditKey = sap.ui.getCore().getModel("auditKeyModel").getData().id
		//var url = "/IESet(Key=guid'" + sauditKey + "')";
		var aFilters = [];
		aFilters.push(new sap.ui.model.Filter("Key", sap.ui.model.FilterOperator.EQ, sauditKey));
		var url = "/IESet";
		var Expand = ["Incident_IE", "Topics_IE"];
		
		//Realizar llamada al back para obtener el listado de findinds relacionados
		var clasificacionIEModel = new sap.ui.model.odata.v2.ODataModel(
				"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
			);
		
		clasificacionIEModel.read(url, {
			filters: aFilters,
			urlParameters: {$expand: Expand},
			success: function (data, response) {
				
				/*if(that.getView().byId("tableClasificacionIE")){
				that.getView().byId("tableClasificacionIE").removeSelections();
				}*/
				
				//Carga de datos
				that.getView().getModel("clasificacionIE").setData(data.results[0].Topics_IE.results);
				
				//that.getView().byId("comboResponsableIncidencia").setSelectedKey(data.results[0].Incident_IE.ResInc);
				//var Incidencia = this.getView().Content2.getItems()[0].getItems()[0].getItems()[1].getItems()[0].getValue();
	       		that.getView().Content2.getItems()[0].getItems()[0].getItems()[1].getItems()[1].setSelectedKey(data.results[0].Incident_IE.ResInc)
	       		that.getView().Content2.getItems()[1].getItems()[1].setValue(Number.parseFloat(data.results[0].Incident_IE.Impact).toFixed(2).toString().replace(/\./g,','));
	       		//that.getView().byId("inputImpacto").setValue(data.results[0].Incident_IE.Impact);
	       		
				/*if(data.results[0].Incident_IE.Incident === "X")
				{
					//that.getView().byId("comboIncidencia").setSelectedKey(data.results[0].Incident_IE.Incident);
					that.getView().Content2.getItems()[0].getItems()[0].getItems()[1].getItems()[0].setSelectedKey(data.results[0].Incident_IE.Incident);
				}*/
				that.getView().Content2.getItems()[0].getItems()[0].getItems()[1].getItems()[0].setSelectedKey(data.results[0].Incident_IE.Incident);
				
				/*if(that.modelClasificacionIE) {
						//that.modelClasificacionIE.setData(data.results);
						that.getView().getModel("clasificacionIE").setData(data.results[0].Topics_IE.results);
						that.modelClasificacionIE.setData(data.results[0].Topics_IE.results);
						that.getView().byId("tableClasificacionIE").setModel(that.modelClasificacionIE,"clasificacionIE");
						that.modelClasificacionIE.refresh();
					}
					that.editData = [];
					var modelTitleClasificacionIE = {};
					that.editData = [];														      			      		
	      			modelTitleClasificacionIE.title = that.getOwnerComponent().getModel("i18n").getResourceBundle().getText("clasificacionIESectionTitle");
  					that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(modelTitleClasificacionIE), "clasificacionIETitle");
	      			that.getOwnerComponent().getModel("clasificacionIETitle").refresh();*/
					
			},
			failed: function (oData, response) {
				alert("Failed to get InputHelpValues from service!");
			},
		});
	},
	
	//FUNCIÓN DE GUARDADO DE CLASIFICACION IE
	ClasificacionIE_SAVE: function()
	{
		var that = this;
		if(that.validateData() === false) return; //Validación de Campos
		//that.validateData();
		var findingKey = listaInfoUtils.convertKeyBinToGuid(zpa.grcaud.dataqmodel.getModel("firstCallModel").getData().results[0].Value);
		var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false);
		
		var Incidencia = that.getView().Content2.getItems()[0].getItems()[0].getItems()[1].getItems()[0].getValue();
   		var ResponsableIncidencia = that.getView().Content2.getItems()[0].getItems()[0].getItems()[1].getItems()[1].getSelectedKey();
   		var Impacto = that.getView().Content2.getItems()[1].getItems()[1].getValue();
		
		var itemsTabla = that.getView().Tabla.getItems();
		var Topics_IE = [];				
		
		for (var i = 0; i < itemsTabla.length; i++) {
			var aux2 = {};
			aux2.ParentKey = findingKey;
			aux2.Topic = itemsTabla[i].getCells()[4].getText();
			aux2.Subtopic = itemsTabla[i].getCells()[5].getText();
			aux2.Main = itemsTabla[i].getCells()[2].getSelected();
			Topics_IE.push(aux2);	
		}
		var ImpactoLong;
		var Incident_IE = [];
		var aux = {};
		aux.ParentKey = findingKey;
		aux.Incident = (Incidencia === "Si") ? "Y" : "N";
		aux.ResInc = ResponsableIncidencia;
		ImpactoLong = (Impacto === "") ? "0" : Impacto.toString().replace(/\./g,'');
		aux.Impact = (ImpactoLong === "") ? "0" : ImpactoLong.toString().replace(/\,/g,'.');
		Incident_IE.push(aux);
		
		var objeto = {};
		objeto.Key = findingKey;
		objeto.Incident_IE = Incident_IE;
		objeto.Topics_IE = Topics_IE;
		
		oDataModel.create("/IESet", objeto, {
			async: true,
			success : function (oData) {
		  		that.getDataFromOdata();
		  		
		  		var dialog = new sap.m.Dialog({
    				title: 'Información',
    				type: 'Message',
    				content: new sap.m.Text({
    					text: "Datos Clasificación IE guardados correctamente"
    				}),
    				beginButton: new sap.m.Button({
    					text: 'Aceptar',
    					press: function () {
    						dialog.close();
    					}
    				}),
    				afterClose: function() {
    					dialog.destroy();
    				}
    			});
    			dialog.open();
	       }.bind(this),
	       error: function (oError) {
	    	   that._oDataError(oError);
	       }.bind(this)
		});
	},
	
	//FUNCIONES DE BORRADO PARA CLASIFICACION IE
	ClasificacionIE_DEL: function(oEvent){
		var that = this;
		var keyObservacion = listaInfoUtils.convertKeyBinToGuid(zpa.grcaud.dataqmodel.getModel("firstCallModel").getData().results[0].Value);
		
		var oDataModel = new sap.ui.model.odata.ODataModel(
				"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",
			false
		);
		
		var Incidencia = this.getView().byId("comboIncidencia").getValue();
		var ResponsableIncidencia = this.getView().byId("comboResponsableIncidencia").getSelectedKey();
		var Impacto = this.getView().byId("inputImpacto").getValue();
		
		var id = oEvent.getParameters().id;
		var numTabla = id.substr(id.length - 1);
		var itemsTabla = this.getView().byId("tableClasificacionIE").getItems();
		var Topics_IE = [];
					
		for (var i = 0; i < itemsTabla.length; i++) 
		{			
			if(itemsTabla[i] !== itemsTabla[numTabla])
			{
				var aux2 = {};
				aux2.ParentKey = keyObservacion;
				aux2.Topic = itemsTabla[i].getCells()[4].getText();
				aux2.Subtopic = itemsTabla[i].getCells()[5].getText();
				aux2.Main = itemsTabla[i].getCells()[2].getSelected();
				Topics_IE.push(aux2);	
			}
			
		}
		
		var Incident_IE = [];
		var aux = {};
		aux.ParentKey = keyObservacion;
		aux.Incident = (Incidencia === "Si") ? "Y" : "N";
		aux.ResInc = ResponsableIncidencia;
		aux.Impact = (Impacto === "") ? "0" : Impacto;
		Incident_IE.push(aux);
		
		var objeto = {};
		objeto.Key = keyObservacion;
		objeto.Incident_IE = Incident_IE;
		objeto.Topics_IE = Topics_IE;
		
		oDataModel.create("/IESet", objeto, {
			async: true,
			success : function (oData) {
		  		this.getDataFromOdata();
	       }.bind(this),
	       error: function (oError) {
	       }.bind(this)
		});	
											
	},
	
	/*INI PPM100077498 - Pestaña Encuestas*/
	//FUNCIÓN DE REFRESCO DE DATOS LA TABLA PRINCIPAL ENCUESTAS
	getDataFromOdataEncuestas:function(){
		
		var that = this;
		var oData = {},
			aBatchOperations = [];
		
		var sauditKey = listaInfoUtils.convertKeyBinToGuid(zpa.grcaud.dataqmodel.getModel("firstCallModel").getData().results[0].Value);
		var url = "/GRCAUD_CV_Audit(guid'"+sauditKey+"')/to_Survey";
		
		//Realizar llamada al back para obtener el listado de encuestas
		var encuestasModel = new sap.ui.model.odata.v2.ODataModel(
				"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
			);
		
		encuestasModel.read(url, {
			success: function (data, response) {
				data.results.sort((a,b) =>b.crea_date_time - a.crea_date_time);
				that.getView().getModel("encuestas").setData(data.results);
				
				if(that.getView().byId("tableEncuestas")){
				that.getView().byId("tableEncuestas").removeSelections();
			}
			
					/*if(that.modelEncuestas) {
						that.modelEncuestas.setData(data.results);
						that.getView().byId("tableEncuestas").setModel(that.modelEncuestas,"encuestas");
						that.modelEncuestas.refresh();
					}
					that.editData = [];
					var modelTitleEncuestas = {};
					that.editData = [];														      			      		
	      			modelTitleEncuestas.title = that.getOwnerComponent().getModel("i18n").getResourceBundle().getText("encuestasSectionTitle");
 					that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(modelTitleEncuestas), "encuestasTitle");
	      			that.getOwnerComponent().getModel("encuestasTitle").refresh();
	      			that.getView().byId("tableEncuestas").setBusy(false)*/
					
			},
			failed: function (oData, response) {
				alert("Failed to get InputHelpValues from service!");
			},
		});
	},
	
	//FUNCIÓN DE REFRESCO DE DATOS ZONA COMENTARIOS
	getDataNA: function()
	{
		var that = this;
		var oData = {},
			aBatchOperations = [];										
		
		var sauditKey = listaInfoUtils.convertKeyBinToGuid(zpa.grcaud.dataqmodel.getModel("firstCallModel").getData().results[0].Value);
		var url = "/GRCAUD_CV_Audit(guid'"+sauditKey+"')/to_SurveyNote";
		
		//Realizar llamada al back para obtener el listado de encuestas
		var encuestasModel = new sap.ui.model.odata.v2.ODataModel(
				"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
			);
		
		encuestasModel.read(url, {
			success: function (data, response) {
				
				if(data.results[0])
				{
					that.getView().Content3.getItems()[0].getItems()[1].setValue(data.results[0].Text);
					that.getView().Content3.getItems()[0].getItems()[2].setText(data.results[0].DBKey);
				}else
				{
					that.getView().Content3.getItems()[0].getItems()[1].setValue("");
					that.getView().Content3.getItems()[0].getItems()[2].setText("");
				}
	
				if(data.results[0] && data.results[0].Text !== "")
				{
					that.onNA_Encuestas("activoNA");
				}
				
			}
		})
	},
	
	  //FUNCION DE GUARDADO DE USUARIOS EN LA TABLA
	  onSave_Encuestas: function()
	  {
		  var that = this;
		  var auditKey = listaInfoUtils.convertKeyBinToGuid(zpa.grcaud.dataqmodel.getModel("firstCallModel").getData().results[0].Value);		  
		  var encuestasModel = new sap.ui.model.odata.ODataModel(
				  "/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
			  );
		  var itemsTabla = that.getView().Tabla.getItems();  
		  var aBatchOperations = [];
			
			for(var i = 0; i < itemsTabla.length; i++)
			{
				if(itemsTabla[i].getCells()[5].getText() === "")
				{
					var objeto = {};
					objeto.db_key = auditKey;
					objeto.parent_key = auditKey;
					objeto.user_id = itemsTabla[i].getCells()[0].getText();
					objeto.Full_Name = itemsTabla[i].getCells()[1].getText();
					objeto.Email = itemsTabla[i].getCells()[2].getText();
					objeto.langu = itemsTabla[i].getCells()[3].getSelectedKey();
					
					encuestasModel.create("/ZGRCAUD_CV_Survey", objeto, {
							method: "POST",
							success : function (oData) {
								var dialog = new sap.m.Dialog({
									title: 'Información',
									type: 'Message',
									content: new sap.m.Text({
										text: "Usuarios guardados correctamente"
									}),
									beginButton: new sap.m.Button({
										text: 'Aceptar',
										press: function () {
											dialog.close();
										}
									}),
									afterClose: function() {
										dialog.destroy();
									}
								});
								dialog.open();
					       }.bind(this),
					       error: function (oError) {
					    	   that._oDataError(oError);
					       }.bind(this)
						});
				}
				else{
					var objeto = {};
					objeto.db_key = itemsTabla[i].getCells()[5].getText();
					objeto.parent_key = auditKey;
					objeto.user_id = itemsTabla[i].getCells()[0].getText();
					objeto.Full_Name = itemsTabla[i].getCells()[1].getText();
					objeto.Email = itemsTabla[i].getCells()[2].getText();
					objeto.langu = itemsTabla[i].getCells()[3].getSelectedKey();
					
					encuestasModel.update("/ZGRCAUD_CV_Survey(guid'"+auditKey+"')", objeto, {
							//async: true,
							method: "POST",
							success : function (oData) {
								var dialog = new sap.m.Dialog({
									title: 'Información',
									type: 'Message',
									content: new sap.m.Text({
										text: "Usuarios guardados correctamente"
									}),
									beginButton: new sap.m.Button({
										text: 'Aceptar',
										press: function () {
											dialog.close();
										}
									}),
									afterClose: function() {
										dialog.destroy();
									}
								});
								dialog.open();
				       }.bind(this),
					       error: function (oError) {
					    	   that._oDataError(oError);
					       }.bind(this)
						});
				}
			}
			/*var dialog = new sap.m.Dialog({
				title: 'Información',
				type: 'Message',
				content: new sap.m.Text({
					text: "Usuarios guardados correctamente"
				}),
				beginButton: new sap.m.Button({
					text: 'Aceptar',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});
			dialog.open();*/
			this.getDataFromOdataEncuestas();
			this.getDataNA();

	  },
	  
		//FUNCION DE GUARDADO NA
	  onSaveNA: function(oEvent)
	  {
		  var that = this;
		  
		  var sauditKey = listaInfoUtils.convertKeyBinToGuid(zpa.grcaud.dataqmodel.getModel("firstCallModel").getData().results[0].Value);
		  var dbKey = that.getView().Content3.getItems()[0].getItems()[2].mProperties.text;
		  //Realizar llamada al back para obtener el listado de encuestas
		  var encuestasModel = new sap.ui.model.odata.v2.ODataModel(
			  "/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
		  );

		  //Creacion Comentario
		  if(dbKey === "")
		  {
			  var objeto = {};
				objeto.HostKey = sauditKey;
				objeto.Text = that.getView().Content3.getItems()[0].getItems()[1].getValue();
				objeto.Type = "SURVEYNOTE";
				
				encuestasModel.create("/ZGRCAUD_CV_SurveyNote", objeto, {
					method: "POST",
					success : function (oData) {
						that.getDataFromOdataEncuestas();
						that.getDataNA();
						var dialog = new sap.m.Dialog({
							title: 'Información',
							type: 'Message',
							content: new sap.m.Text({
								text: "Comentario guardado correctamente"
							}),
							beginButton: new sap.m.Button({
								text: 'Aceptar',
								press: function () {
									dialog.close();
								}
							}),
							afterClose: function() {
								dialog.destroy();
							}
						});
						dialog.open();
						//MessageUtil.showMsg("msgTypeSuccessful", this.getView().getModel("i18n").getResourceBundle().getText("Comentario guardado Correctamente"));
			       }.bind(this),
			       error: function (oError) {
			    	   that._oDataError(oError);
			       }.bind(this)
				});
		  }else //Edicion Comentario
		  {
			  var objeto = {};
				objeto.DBKey = dbKey;
				objeto.HostKey = sauditKey;
				objeto.Text = that.getView().Content3.getItems()[0].getItems()[1].getValue();
				objeto.Type = "SURVEYNOTE";
				
				encuestasModel.update("/ZGRCAUD_CV_SurveyNote(DBKey=guid'"+dbKey+"')", objeto, {
					//async: true,
					method: "POST",
					success : function (oData) {
						that.getDataFromOdataEncuestas();
						that.getDataNA();
						var dialog = new sap.m.Dialog({
							title: 'Información',
							type: 'Message',
							content: new sap.m.Text({
								text: "Comentario Editado correctamente"
							}),
							beginButton: new sap.m.Button({
								text: 'Aceptar',
								press: function () {
									dialog.close();
								}
							}),
							afterClose: function() {
								dialog.destroy();
							}
						});
						dialog.open();
						//MessageUtil.showMsg("msgTypeSuccessful", this.getView().getModel("i18n").getResourceBundle().getText("Comentario editado Correctamente"));
			       }.bind(this),
			       error: function (oError) {
			    	   that._oDataError(oError);
			       }.bind(this)
				});
		  }
		  
	  },
	  
	//VISIBLIDAD DE CAMPOS
	  onNA_Encuestas: function(oEvent){
		  
		  var that = this;
		  
		  if(oEvent === "activoNA") that.getView().Tabla.setVisible(true);
		  
		  if(that.getView().Tabla.getVisible() === true)
		  {
			  that.getView().Tabla.getHeaderToolbar().getContent()[0].setVisible(false); 				//Toolbar
			  that.getView().Tabla.setVisible(false);													//Tabla Encuestas
			  that.getView().Tabla.getHeaderToolbar().getContent()[0].getItems()[0].setSelected(false);	//CheckNATabla
			  that.getView().Content3.setVisible(true);
			  that.getView().Content3.getItems()[0].getItems()[0].getItems()[0].setSelected(true)
		  }
		  else
		  {
			  that.getView().Tabla.getHeaderToolbar().getContent()[0].setVisible(true);
			  that.getView().Tabla.setVisible(true);
			  that.getView().Content3.setVisible(false);
			  that.getView().Content3.getItems()[0].getItems()[0].getItems()[0].setSelected(false);
		  }
			  
	  },
	
	
	// FUNCION DE BUSQUEDAD PARA POP-UP DE PLANES DE ACCION RELACIONADOS
	  searchToBeAssignedTableEncuestas: function() {
			var oController = this;
			var oTableSearchState = [];
			var oTableSearchStateFilter = [];
			var oBindingInfo = {};
			var sSearchString = oController.oBasicSearch.getValue();
			oTableSearchState = [
				new sap.ui.model.Filter("topic_text", sap.ui.model.FilterOperator.Contains, sSearchString),
				new sap.ui.model.Filter("subtopic_text", sap.ui.model.FilterOperator.Contains, sSearchString),
				new sap.ui.model.Filter("ActionTypeText", sap.ui.model.FilterOperator.Contains, sSearchString),
				new sap.ui.model.Filter("StatusText", sap.ui.model.FilterOperator.Contains, sSearchString)
			];
			oTableSearchStateFilter = new sap.ui.model.Filter(oTableSearchState, false);
			oBindingInfo = oController.addClasificacionIESmartTable.mAggregations.content[0]._oTable.getBindingInfo("items");
			oBindingInfo.filters = oTableSearchStateFilter;
			oController.addClasificacionIESmartTable.mAggregations.content[0]._oTable.bindAggregation("items", oBindingInfo);					
	  },
	/*FIN PPM100077498 - Pestaña Encuestas*/
	
/**
 * Called when the Controller is destroyed. Use this one to free resources and
 * finalize activities.
 * 
 * @memberOf appDataQ.controller.DetailScreen
 */
// onExit: function() {
//
// }
	
	leftToRightRisk: function(oEvent){
		var selected = oEvent.getSource().getBindingContext().getObject();
		var path = oEvent.getSource().getBindingContext().getPath();
		var index = parseInt(path.substring(path.lastIndexOf('/') +1));
		
		this.getView().oLeftList.getModel().getData().results.splice(index, 1);
		this.rightFilter.aFilters.splice(index, 1);
		
		this.getView().oLeftList.getModel().updateBindings(true);
		if(this.rightFilter.aFilters.length > 0){
			this.getView().oRightList.getBinding("items").filter([this.rightFilter]);
		}else{
			this.getView().oRightList.getBinding("items").filter();
		}
		
		/**
		 * INI Ajustes SPAU 08/11/18 * Código antiguo
		 * this.chosenRisks.moves.push({key: selected.Key.replace(/-/g, ""),
		 * action: "delete"});
		 * 
		 * Código nuevo Se pasa la Key a Mayúsculas para que no muestre error al
		 * pasar a RAW 16 en el back
		 */
		this.chosenRisks.moves.push({key: selected.Key.replace(/-/g, "").toUpperCase(), action: "delete"});
		/**
		 * FIN Ajustes SPAU 08/11/18
		 */
		
	},
	
	rightToLeftRisk: function(oEvent){
		var selected = oEvent.getSource().getBindingContext().getObject();
		this.getView().oLeftList.getModel().getData().results.push(selected);
		this.rightFilter.aFilters.push(
			new sap.ui.model.Filter({
				path: "ID",
				operator: "NE",
				value1: selected.ID
			})
		);
		this.getView().oLeftList.getModel().updateBindings(true);
		this.getView().oRightList.getBinding("items").filter([this.rightFilter]);
		
		/**
		 * INI Ajustes SPAU 08/11/18 * Código antiguo
		 * 
		 * this.chosenRisks.moves.push({key: selected.Key.replace(/-/g, ""),
		 * action: "add"});
		 *  * Código nuevo Se pasa la Key a Mayúsculas para que no muestre error
		 * al pasar a RAW 16 en el back
		 */		    
			this.chosenRisks.moves.push({key: selected.Key.replace(/-/g, "").toUpperCase(), action: "add"});
		/**
		 * FIN Ajustes SPAU 08/11/18
		 */
		
	},
	
	onSearchRisk: function(oEvent){
		var con = zpa.grcaud.dataqmodel.getConection("stdCon");
		var url = "RiskExtendedSet?$filter=Scenario eq 'riskRegister' and ViewID eq 'IA' and Timestamp eq datetime'2099-12-30T23:00:00'&search=*" + oEvent.getSource().getValue() + "*&$inlinecount=allpages";
		con.read(url, {
			async: false,
			success: function(oData){
				var oModel =  new sap.ui.model.json.JSONModel(oData);
				this.getView().oRightList.setModel(oModel);
				if(this.rightFilter.aFilters.length > 0){
					this.getView().oRightList.getBinding("items").filter([this.rightFilter]);
				}
				this.getView().oRightList.getBinding("items").sort(this.oSorter);
			}.bind(this),
			error: function(oError){
			}.bind(this)
		});
	},
	
	doBack: function(oEvent) {
		var oModel = this.getView().oViewData;
		var changes = false;
		var that = this;
		$.each(zpa.grcaud.dataqmodel.getModel("copyModel").getData().results,function(i,n){
// console.log(n);
			if(n.ValueOrig != n.Value)changes = true;
		});
		
// JSON.stringify(oModel) ===
// JSON.stringify(zpa.grcaud.dataqmodel.getModel("copyModel").getData().results)
// ? changes = false: changes = true;
		if(changes){
			var dialog = new sap.m.Dialog({
				title: 'Información',
				type: 'Message',
					content: new sap.m.Text({
						text: "Está seguro que desea salir? Se perderan los cambios no guardados."
					}),
				beginButton: new sap.m.Button({
					text: 'Aceptar',
					press: function () {
						dialog.close();
						var currView = that.getView();
						var navCont = currView.getParent();
						navCont.getPreviousPage().getController().onResetScreen();
						navCont.getPreviousPage().oSearch.setValue("");
						navCont.to(navCont.getPreviousPage().sId);
						navCont.getPage(currView.sId).destroy();
					}
				}),
				endButton: new sap.m.Button({
					text: 'Cancelar',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});
			dialog.open();
		}else{
			var currView = that.getView();
			var navCont = currView.getParent();
			navCont.getPreviousPage().getController().onResetScreen();
			navCont.getPreviousPage().oSearch.setValue("");
			navCont.to(navCont.getPreviousPage().sId);
			navCont.getPage(currView.sId).destroy();
		}
	},
	
	
	doSave: function() {
		
		var that = this;
		var oEntity = {};
		oEntity.DynDataQ = $.extend(true, [], this.getView().oViewData);
		
		var error = false;
		
		// if(this.getView().selectWork){ //Work program
		var selectedProgram = ""; 
		if(this.getView().oIconTabBar.getSelectedKey() === byId("selScreen").aChecks[2].getText()){
			if(this.getView().selectWork.getSelectedKey() !== ""){
				selectedProgram = this.getView().selectWork.getSelectedKey();
				var seq = "";
				var parentSeq  = "";
				var i = 0;
				var j = 0;
				var found = false;
				var foundParent = false;
				while(i < this.getView().work.length && !found){
					if(this.getView().work[i].Seq === this.getView().selectWork.getSelectedKey()){
						seq = this.getView().work[i].Seq;
						found = true;
						while(j < this.getView().work.length && !foundParent){
							if(this.getView().work[j].KEY === this.getView().work[i].PARENT_SCOPE){
								parentSeq = this.getView().work[j].Seq;
								foundParent = true;
							}
							j++;
						}
					}
					i++;
				}
			}
		}

		// if(this.chosenRisks){ //Risks
		if(this.getView().oIconTabBar.getSelectedKey() === byId("selScreen").aChecks[1].getText()){
			for(var i = 0; i < this.chosenRisks.moves.length; i++){
				for(var j = 0; j < this.chosenRisks.risks.length; j++){
					var found = false;
					/**
					 * INI Ajuste SPAU 09/11/18 Código antiguo
					 * if(this.chosenRisks.moves[i].key ===
					 * this.chosenRisks.risks[j].ValueOrig ||
					 * this.chosenRisks.moves[i].key ===
					 * this.chosenRisks.risks[j].Value){
					 * 
					 * Código nuevo Se compara con las keys en mayúsculas (para
					 * adecuar el código para que no falle en el back )
					 */
					if(this.chosenRisks.moves[i].key === this.chosenRisks.risks[j].ValueOrig.toUpperCase() || this.chosenRisks.moves[i].key === this.chosenRisks.risks[j].Value.toUpperCase()){
					/**
					 * FIN Ajuste SPAU 09/11/18
					 */
						found = true;
						if(this.chosenRisks.moves[i].action === "delete"){
							if(j < this.chosenRisks.count){ // inicial borrado
								for(var y = 0; y < this.chosenRisks.assignments.length; y++){
									if(this.chosenRisks.assignments[y].ReferenceKey.replace(/-/g, "") === this.chosenRisks.risks[j].Value){ // en
																																			// un
																																			// principio
																																			// tiene
																																			// la
																																			// key
																																			// del
																																			// riesgo
										this.chosenRisks.risks[j].Value = "";
										/**
										 * INI Ajuste SPAU 09/11/18 Código
										 * antiguo
										 * 
										 * this.chosenRisks.risks[j].ValueOrig =
										 * this.chosenRisks.assignments[y].Key.replace(/-/g,
										 * ""); //ponemos la key de la
										 * asociacion Código nuevo pasamos la
										 * Key en maýusculas
										 */
										this.chosenRisks.risks[j].ValueOrig = this.chosenRisks.assignments[y].Key.replace(/-/g, "").toUpperCase(); // ponemos
																																					// la
																																					// key
																																					// de
																																					// la
																																					// asociacion
										/**
										 * FIN Ajuste SPAU 09/11/18
										 */
										break;
									}
								}
							}else{
								this.chosenRisks.risks.splice(j, 1);
							}
						}else{// riesgo inicial reañadido
							for(var y = 0; y < this.chosenRisks.assignments.length; y++){
								if(this.chosenRisks.assignments[y].Key.replace(/-/g, "") === this.chosenRisks.risks[j].ValueOrig){ // hasta
																																	// ahora
																																	// tenia
																																	// la
																																	// key
																																	// de
																																	// la
																																	// asociacion
																																	// ya
																																	// que
																																	// se
																																	// iba
																																	// a
																																	// borrar
									this.chosenRisks.risks[j].ValueOrig = this.chosenRisks.assignments[y].ReferenceKey.replace(/-/g, ""); // para
																																			// poder
																																			// encontrarlo
																																			// en
																																			// los
																																			// movimientos
									this.chosenRisks.risks[j].Value = this.chosenRisks.risks[j].ValueOrig;
									break;
								}
							}
						}
						break;
					}
				}
				if(!found){
					// if de comprobar accion innecesario, si no lo encuentra
					// solo puede añadir
					this.chosenRisks.risks.push({ContainerPos: "0", DepField: "", DepValue: "", Editable: "true", ExternalName: "",
						FieldLabel: "", FieldLength: "100", FieldName: "KEY", FieldOrder: "0",
						Function: "", Hier: "0", IdReg: "", Length: "0", Multiple: "false", Name: "KEY",
						Objtyp: "AUDIT", Options: "", Required: "false", SeqFields: "00000", Service: "", Stauxiliar: "",
						Tab: "RISKS", Type: "STRING", TypeHier: "", Value: this.chosenRisks.moves[i].key, ValueOrig: "",
						Visible: "true"});
				}
			}
			
			oEntity.DynDataQ = oEntity.DynDataQ.concat(this.chosenRisks.risks);
		}
		
		// oEntity.DynDataQ = $.grep(oEntity.DynDataQ,function(n,i){return
		// that.getView().oIconTabBar.getSelectedKey().toUpperCase()});
		
		for(var i = oEntity.DynDataQ.length - 1; i >= 0; i--){
			if(tabStringByCheck(that.getView().oIconTabBar.getSelectedKey()) === oEntity.DynDataQ[i].Tab){ // guardar
																											// por
																											// pestaña
				switch(that.getView().oIconTabBar.getSelectedKey()){
					case byId("selScreen").aChecks[1].getText(): // risks
						
						break;
					case byId("selScreen").aChecks[2].getText(): // work
																	// program
						
						if(selectedProgram !== ""){
							switch(oEntity.DynDataQ[i].FieldName){
							case "DESCRIPTION":
								if(oEntity.DynDataQ[i].SeqFields === seq){
									oEntity.DynDataQ[i].Value = byId("inp_AUDIT-WORKPROGRAM-DESCRIPTION-").getValue();
								}else{
									oEntity.DynDataQ[i].Value = oEntity.DynDataQ[i].ValueOrig;
								}
								break;
							case "CODE":
								oEntity.DynDataQ[i].Value = oEntity.DynDataQ[i].ValueOrig;
								break;
							case "NAME":
								switch(oEntity.DynDataQ[i].SeqFields){
									case parentSeq:
										oEntity.DynDataQ[i].Value = byId("inp_AUDIT-WORKPROGRAM-CODE-").getValue();
										break;
									case seq:
										oEntity.DynDataQ[i].Value = byId("inp_AUDIT-WORKPROGRAM-NAME-").getValue();
										break;
									default:
										oEntity.DynDataQ[i].Value = oEntity.DynDataQ[i].ValueOrig;
										break;
								}
								break;
							case "FULL_NAME":
								if(oEntity.DynDataQ[i].SeqFields === seq){
									oEntity.DynDataQ[i].Value = byId("inp_AUDIT-WORKPROGRAM-FULL_NAME-").getSelectedKey();
									oEntity.DynDataQ[i].ValueOrig = byId("inp_AUDIT-WORKPROGRAM-FULL_NAME-").data("lastValue");
									byId("inp_AUDIT-WORKPROGRAM-FULL_NAME-").data("lastValue", oEntity.DynDataQ[i].Value);
								}else{
									oEntity.DynDataQ[i].Value = oEntity.DynDataQ[i].ValueOrig; // para
																								// los
																								// #NOVALUE
								}
								break;
							default:
								break;
						}
						
						}
						break;
					case byId("selScreen").aChecks[3].getText():
						
						break;
					default: // info
						
						break;
				}
				delete oEntity.DynDataQ[i].__metadata;
				var checkerror = validateForm(oEntity.DynDataQ[i]);
				if(checkerror){
					error = true;
				}
			}else{
				oEntity.DynDataQ.splice(i, 1);
			}
		}
	
		if(!error){
			
			var key = recoverKey(zpa.grcaud.dataqmodel.getModel("firstCallModel").getData().results[0].Value); 
			oEntity.Key = key;
			
			if(this.getView().oIconTabBar.getSelectedKey() !== byId("selScreen").aChecks[3].getText() && this.getView().oIconTabBar.getSelectedKey() !== byId("selScreen").aChecks[5].getText() && this.getView().oIconTabBar.getSelectedKey() !== byId("selScreen").aChecks[6].getText()){ // fraude y clasificacion IE //PPM100077498 ENCUESTAS
				if(this.getView().oIconTabBar.getSelectedKey() !== byId("selScreen").aChecks[2].getText() || (this.getView().oIconTabBar.getSelectedKey() === byId("selScreen").aChecks[2].getText() && selectedProgram !== "")){ 
					zpa.grcaud.dataqmodel.saveAudit.call(this, oEntity, seq, parentSeq);
				}else{
					var dialog = new sap.m.Dialog({
						title: 'Información',
						type: 'Message',
						state: 'Warning',
						content: new sap.m.Text({
							text: "No ha seleccionado ningún paquete de trabajo."
						}),
						beginButton: new sap.m.Button({
							text: 'Aceptar',
							press: function () {
								dialog.close();
							}
						}),
						afterClose: function() {
							dialog.destroy();
						}
					});
					dialog.open();
				}
			
			}
			//#PPM100076335 - Pestaña clasificacionIE
			else if(this.getView().oIconTabBar.getSelectedKey() === byId("selScreen").aChecks[5].getText())
			{
				that.ClasificacionIE_SAVE();
			}
			//PPM100077498 - Pestaña encuestas GUARDADO
			else if(this.getView().oIconTabBar.getSelectedKey() === byId("selScreen").aChecks[6].getText())
			{
				if(that.getView().Tabla.getVisible() === true)
				{
					that.onSave_Encuestas();
				}
				else
				{
					that.onSaveNA();
				}
				
			}
			else{
				// Parte de la función save para el tab de Fraude
				var fraudeComp = sap.ui.getCore().getComponent("FraudeComp");
				if(fraudeComp) {
					var fraudeCompController = sap.ui.getCore().getComponent("FraudeComp").oController;
					
					fraudeCompController.onSave();
				}
			}
			
			
		
		}else{
			var dialog = new sap.m.Dialog({
				title: 'Información',
				type: 'Message',
				state: 'Error',
				content: new sap.m.Text({
					text: "Revise los campos marcados en rojo."
				}),
				beginButton: new sap.m.Button({
					text: 'Aceptar',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});
			dialog.open();
		}
  		// End parte función tab fraude
  	
	},
	
	// INI PPM100076335 25/08/2022
	// FUNCION PARA COMBO DE RESPONSABLE DE LA INCIDENCIA
	  getComboIncidencias: function(){
		
		  var that = this;
		  
		  var ClasificacionIEModel = new sap.ui.model.odata.v2.ODataModel(
					"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false // //"ZGRCAUD_ENH_SRV"
				
			);
		  
		  ClasificacionIEModel.read("/ZGRCAUD_CV_RINC", {
					success: function (data, response) {						
					// 31/08/2022 AQUI ES DONDE PETA JUSTO POR EL MODELO
					that.getView().setModel(new sap.ui.model.json.JSONModel(data.results), "cmbResponsableIncidencias");
		      		that.getView().getModel("cmbResponsableIncidencias").refresh();
					},
					failed: function (oData, response) {
						alert("Failed to get InputHelpValues from service!");
					},
				});
		  
	  },
	  // Carga de la tabla principal
	  
	  
	// FUNCION DE BUSQUEDAD PARA POP-UP DE PLANES DE ACCION RELACIONADOS
	  searchToBeAssignedTable: function() {
			var oController = this;
			var oTableSearchState = [];
			var oTableSearchStateFilter = [];
			var oBindingInfo = {};
			var sSearchString = oController.oBasicSearch.getValue();
			oTableSearchState = [
				new sap.ui.model.Filter("topic_text", sap.ui.model.FilterOperator.Contains, sSearchString),
				new sap.ui.model.Filter("subtopic_text", sap.ui.model.FilterOperator.Contains, sSearchString),
				new sap.ui.model.Filter("ActionTypeText", sap.ui.model.FilterOperator.Contains, sSearchString),
				new sap.ui.model.Filter("StatusText", sap.ui.model.FilterOperator.Contains, sSearchString)
			];
			oTableSearchStateFilter = new sap.ui.model.Filter(oTableSearchState, false);
			oBindingInfo = oController.addClasificacionIESmartTable.mAggregations.content[0]._oTable.getBindingInfo("items");
			oBindingInfo.filters = oTableSearchStateFilter;
			oController.addClasificacionIESmartTable.mAggregations.content[0]._oTable.bindAggregation("items", oBindingInfo);					
	  },
	  
	  //FUNCION DE VALIDACION DE CAMPOS OBLIGATORIOS
	  validateData: function()
		{
			var Incidencia = this.getView().Content2.getItems()[0].getItems()[0].getItems()[1].getItems()[0].getValue();
       		var ResponsableIncidencia = this.getView().Content2.getItems()[0].getItems()[0].getItems()[1].getItems()[1].getSelectedKey();
       		var tablaPrincipal = this.getView().Tabla.getModel("clasificacionIE").getData();
			var error = 1;
			
			//Comprobamos si los campos de Incidencia, Responsable, Impacto, Temas están rellenos y que haya un principal.
			//TEMAS Y PRINCIPAL
			for(var i = 0; i < tablaPrincipal.length; i++)
			{
				//TEMA
				if(tablaPrincipal[i] === undefined || tablaPrincipal[i] === 0)
				{
					var dialog = new sap.m.Dialog({
						title: 'Información',
						type: 'Message',
							content: new sap.m.Text({
								text: "Seleccione un tema"
							}),
						endButton: new sap.m.Button({
							text: 'Aceptar',
							press: function () {
								dialog.close();
							}
						}),
						afterClose: function() {
							dialog.destroy();
						}
					});
					dialog.open();
					//MessageUtil.showMsg("msgTypeFailed", "Seleccione un tema");
					return false;
				}
				//PRINCIPAL
				if(error !== 0)
				{
					/*for(var j = 0; j <= this.getView().Tabla.getItems().length; j++)
					{
						if(this.getView().Tabla.getItems()[j].getCells()[2].mProperties.selected !== true)	error = 1;
						else error = 0;
					}*/
					if(this.getView().Tabla.getItems()[i].getCells()[2].mProperties.selected !== true)	error = 1;
					else error = 0;
				}
			}
			
			//INCIDENCIA
			if(Incidencia === "")
			{
				var dialog = new sap.m.Dialog({
					title: 'Información',
					type: 'Message',
						content: new sap.m.Text({
							text: "Seleccione una incidencia"
						}),
					endButton: new sap.m.Button({
						text: 'Aceptar',
						press: function () {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});
				dialog.open();
				//MessageUtil.showMsg("msgTypeFailed", "Seleccione una incidencia");
				return false;
			}

			//RESPONSABLE INCIDENCIA
			if(ResponsableIncidencia === "")
			{
				var dialog = new sap.m.Dialog({
					title: 'Información',
					type: 'Message',
						content: new sap.m.Text({
							text: "Seleccione un responsable de incidencia"
						}),
					endButton: new sap.m.Button({
						text: 'Aceptar',
						press: function () {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});
				dialog.open();
				//MessageUtil.showMsg("msgTypeFailed", "Seleccione un responsable de incidencia");
				return false;
			}
			//PRINCIPAL
			if(error === 1)
			{
				var dialog = new sap.m.Dialog({
					title: 'Información',
					type: 'Message',
						content: new sap.m.Text({
							text: "Seleccione un tema como principal"
						}),
					endButton: new sap.m.Button({
						text: 'Aceptar',
						press: function () {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});
				dialog.open();
				//MessageUtil.showMsg("msgTypeFailed", "Seleccione un responsable de incidencia");
				return false;
			}


		},
	  


});