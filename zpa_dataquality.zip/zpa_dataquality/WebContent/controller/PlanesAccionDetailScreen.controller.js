sap.ui.controller("appDataQ.controller.PlanesAccionDetailScreen", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf zadminuser.main
*/
	onInit: function() {
		
		
		var checks = byId("selScreen").aChecks;
		var that = this;
		var countSelected = 0;
		
		for(var i = 0; i < checks.length; i++){
			if(checks[i].getSelected()){
				// var current = checks[i].getText().replace(/\s/g, '');
				var item = new sap.m.IconTabFilter({
					icon: zpa.grcaud.Constants.SelChecks[i].icon,
					text: byId("selScreen").aChecks[i].getText(),
					key: byId("selScreen").aChecks[i].getText(),
					// visible: byId("selScreen").aChecks[i].getSelected(),
					content: []
				});
				
				switch(tabStringByCheck(checks[i].getText())) {
				case zpa.grcaud.Constants.TabGroups.Limitaciones:
					this.getView().Tabla = new sap.m.Table({
						  id:"tableLimitations",
						  mode:"MultiSelect",
						  ariaLabelledBy:"hiddenText",
						  items:"{path: 'limitations>/'}",
						  noDataText:"No hay entradas disponibles",
						  headerToolbar : [
						                  new sap.m.Toolbar({
						                  id:'limitationsToolbar',
						                  width:"100%",
						                  content:[
						                	  new sap.m.Input({
						                		  id:"inputLimitations",
						                		  placeholder:"Escriba Limitacion",
						                		  width:"90%"  
						                	  }),
						                	  new sap.m.HBox({
						                		  justifyContent : "End",
						                		  width : "10%",
						                		  items: [
						                			  new sap.m.Button({
						                				    id:"btn_addLimitations",
						                				    icon:"sap-icon://add",
						                				    press: function() {
									                		     
								                		    },
						                				    visible:true,
								                	  }),
								                	  new sap.m.Button({
								                		  	id:"btn_EditLimitations",
								                		    icon:"sap-icon://edit",
								                		    press: function() {
								                		      
								                		    },
								                		    visible: true
								                	  
								                	  }),
								                	  new sap.m.Button({
								                		  	id:"btn_SaveLimitations",
								                		    icon:"sap-icon://save",
								                		    press: function() {
								                		      
								                		    },
								                		    visible: false
								                	  
								                	  }),
						                		  ]
						                	  }),
						                	  
						                	  ]
						                  })
										  ],
										  columns:[
										          new sap.m.Column({
										        	  id:"colLimitations",
										        	  width:"90%",
										        	  header:[
										                  new sap.m.Label({
										                  text:""
										                  })
										                  ]
										          }),new sap.m.Column({
										        	id:"colLimitationsDel",
										          	header:[
										                  new sap.m.Label({
										                  text:""
										                  })
										                  ],
										            customData:[
										                new sap.ui.core.CustomData({
													    key:"DB_KEY",
													    value:'\{"columnKey": "DB_KEY"}'
										                }),
										                  ],
										               
										          	
										          }),new sap.m.Column({
										        	  visible:false,
										        	  header:[
										                  new sap.m.Label({
										                  text:""
										                  })
										                  ]
										          })
										          ],
										  items:[
										        new sap.m.ColumnListItem({
										        cells:[
										               new sap.m.Input({
										               value:"{limitations>limitation}",
										               editable:false
										               }),
										               new sap.m.Button({
										               id:"btn_RemoveLimitationsRow",
										               icon:"sap-icon://delete",
										               press:"Limitations_DEL",
										               visible:true
										               }),
										               new sap.m.ObjectIdentifier({
										               text:"{limitations>db_key}",
										               visible:false
										               })											               
										               ]
										        })
										        ]
										  });
					this.getView().oForms[countSelected].getFormContainers()[0].insertFormElement(new sap.ui.layout.form.FormElement({ label: oLabel, fields: [this.getView().selectWork], tabla: this.getView().Tabla }), 0);
					// item.addContent(this.getView().aForms[countSelected]);
					item.addContent(this.getView().Tabla);
					/* FIN PPM100076335 - Pestaña clasificacionIE 05/08/2022 */
					if(this.getView().aTables[countSelected].length !== 0){
						item.addContent(this.getView().aTables[countSelected]);
					}
					break;
				}
			}
		}
	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf zadminuser.main
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf zadminuser.main
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf zadminuser.main
*/
//	onExit: function() {
//
//	}
	
	onSave: function() {
		var that = this;
		var oEntity = {};
		oEntity.DynDataQ = this.getView().oViewData;
		var found = false;
		var error = false;
		
		$.each(oEntity.DynDataQ,function(i,n){
			var checkerror = validateForm(oEntity.DynDataQ[i]);
			if(checkerror){
				error = true;
			}
		});
		
		if(!error){
			$.each(oEntity.DynDataQ,function(i,n){
				delete n.__metadata;
				if(n.Options === zpa.grcaud.Constants.FieldOptions.Matchcode && JSON.parse(n.Multiple)){
					var tokens = byId("mlt_" + n.Objtyp + "-" + n.Tab.replace(/\s/g, '') + "-" + n.FieldName + "-" + n.DepValue).getItems()[0].getItems();
					n.Value = "";
					var visited = {};
					for(var y = 0; y < tokens.length; y++){
						if(visited[tokens[y].getKey()]){
							found = true;
							var dialog = new sap.m.Dialog({
								title: "Información",
								type: "Message",
								state: "Warning",
									content: new sap.m.Text({
										text: "El usuario " +  tokens[y].getText() + " ya está asignado como Responsable de la acción. No se han guardado los cambios."
									}),
								beginButton: new sap.m.Button({
									text: 'Aceptar',
									press: function () {
										dialog.close();
									}
								}),
								afterClose: function() {
									dialog.destroy();
								}
							});
							dialog.open();
							break;
						}
						visited[tokens[y].getKey()] = true;
						if(y !== 0){
							n.Value = n.Value + ",";
						}
						n.Value = n.Value + tokens[y].getKey();
					}
				}
			});
		}
		
		
		
		if(!error && !found){
			var key = recoverKey(zpa.grcaud.dataqmodel.getModel("actionPlanModel").getData().results[0].Value); 
			var url = "/DynDataQDeepSet";
			oEntity.Key = key; 
			
			var odataModel = zpa.grcaud.dataqmodel.con;
			odataModel.create(url, oEntity, false, function(dataResp){
				//console.log(dataResp);
				var dialog = new sap.m.Dialog({
					title: 'Información',
					type: 'Message',
						content: new sap.m.Text({
							text: "Datos guardados correctamente."
						}),
					beginButton: new sap.m.Button({
						text: 'Aceptar',
						press: function () {
							dialog.close();
							var currView = that.getView();
							var navCont = currView.getParent();
							navCont.getPreviousPage().getController().onResetScreen();
							navCont.getPreviousPage().oSearch.setValue("");
							navCont.to(navCont.getPreviousPage().sId);
							navCont.getPage(currView.sId).destroy();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});
				dialog.open();
			},function(oError){
				//console.log(oError);
				if(oError.response){
					sap.m.MessageToast.show($(oError.response.body).find('message').first().text(), {duration: 1800});
				}
			});
		}else{
			if(error){
				var dialog = new sap.m.Dialog({
					title: 'Información',
					type: 'Message',
					state: 'Error',
					content: new sap.m.Text({
						text: "Revise los campos marcados en rojo."
					}),
					beginButton: new sap.m.Button({
						text: 'Aceptar',
						press: function () {
							dialog.close();
						}
					}),
					afterClose: function() {
						dialog.destroy();
					}
				});
				dialog.open()
			}
		}
	},
	
	doBack: function(oEvent) {
		var currView = this.getView();
//		JSON.stringify(oModel) === JSON.stringify(zpa.grcaud.dataqmodel.getModel("copyModel").getData().results) ? changes = false: changes = true;
		var dialog = new sap.m.Dialog({
			title: 'Información',
			type: 'Message',
				content: new sap.m.Text({
					text: "Está seguro que desea salir? Se perderan los cambios no guardados."
				}),
			beginButton: new sap.m.Button({
				text: 'Aceptar',
				press: function () {
					dialog.close();
					var navCont = currView.getParent();
					navCont.getPreviousPage().getController().onResetScreen();
					navCont.getPreviousPage().oSearch.setValue("");
					navCont.to(navCont.getPreviousPage().sId);
					navCont.getPage(currView.sId).destroy();
				}
			}),
			endButton: new sap.m.Button({
				text: 'Cancelar',
				press: function () {
					dialog.close();
				}
			}),
			afterClose: function() {
				dialog.destroy();
			}
		});
		dialog.open();
	},
	
});