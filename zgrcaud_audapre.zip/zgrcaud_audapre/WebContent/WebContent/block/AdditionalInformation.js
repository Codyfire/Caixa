/*
 * Copyright (C) 2009-2020 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([ "sap/uxap/BlockBase" ], function(B) {
	"use strict";
	return B.extend("sap.grc.acs.aud.audit.execute.extended.block.AdditionalInformation", {
		metadata : {
			views : {
				Collapsed : {
					viewName : "sap.grc.acs.aud.audit.execute.extended.block.view.AdditionalInfo",
					type : "XML"
				}, 
				Expanded : {
					viewName : "sap.grc.acs.aud.audit.execute.extended.block.view.AdditionalInfo",
					type : "XML"
				}
			}
		}
	});
});
