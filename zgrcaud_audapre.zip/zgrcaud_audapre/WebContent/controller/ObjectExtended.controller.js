/*
 * Copyright (C) 2009-2020 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
		"sap/grc/acs/aud/audit/controller/BaseController",
		"sap/ui/model/json/JSONModel",
		"sap/ui/core/routing/History",
		"sap/grc/acs/aud/audit/model/formatter",
		"sap/uxap/ObjectPageHeaderActionButton",
		"sap/grc/acs/lib/aud/extension/utils/FieldExtensibilityUtil",
		"sap/grc/acs/lib/aud/utils/MenuItemUtils",
		"sap/grc/acs/lib/aud/utils/MessageUtil"
	], function (
		BaseController,
		JSONModel,
		History,
		formatter,
		ObjectPageHeaderActionButton,
		FieldExtensibilityUtil,
		MenuItemUtils,
		MessageUtil) {
	"use strict";

	return BaseController.extend("sap.grc.acs.aud.audit.approvereport.extended.controller.ObjectExtended", {
								  
		// Section ID array for section navigation
		// GeneralSection must be the fist one in the array, do not change the order
 
//			_aValidSectionIds : ["generalSection", "workProgramSection", "workingPaperSection", "findingSection","reportSection", "activitySection"],
		//_aValidSectionIds : ["generalSection", "workProgramSection", "workingPaperSection", "findingSection","findingRelSection","reportSection","listsSection","additionalInfoSection", "activitySection"],
		
		//INI PPM100076335 - Pestaña clasificacionIE 29/07/2022 
		_aValidSectionIds : ["generalSection", "workProgramSection", "workingPaperSection", "findingSection","findingRelSection","reportSection","clasificacionIESection","encuestasSection","listsSection","additionalInfoSection", "activitySection"],
		
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf src.sap.grc.acs.aud.audit.view.Object
		 */
			onInit: function() {
				var iOriginalBusyDelay,
					oViewModel = new JSONModel({
						busy : true,
						delay : 0,
						isSectionNavigation: false
					});
		
				if (this.getRouter()) {
					this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);
				}	
				this.oMenuItemModelData = {
					MenuItem: []
				};
				// Store original busy indicator delay, so it can be restored later on
				iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
				//Set binding mode
				oViewModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
				this.setModel(oViewModel, "objectView");
	
				//Model used to manipulate menu in list
				//this.setModel(oObjectMenuModel, "objectMenu");
				
				//Set app title
				var sTitle = this.getResourceBundle().getText("objectTitle");
				this.getView().byId("objectPage").setTitle(sTitle);
				
				var oModel = this.getOwnerComponent().getModel("i18n");
				var oModeli18nm = this.getOwnerComponent().getModel("i18nm");
				oModel.enhance({bundleName:oModeli18nm.oData.bundleName}) ; 

				this.getOwnerComponent().setModel(oModel, "i18n");
				
				var oExtensionModel = new sap.ui.model.json.JSONModel();
				this.setModel(oExtensionModel, "extensionModel");
				
				// // Store original busy indicator delay, so it can be restored later on
				// iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
				// this.setModel(oViewModel, "objectView");
				this.getOwnerComponent().getModel().metadataLoaded().then(function () {
						// Restore original busy indicator delay for the object view
						oViewModel.setProperty("/delay", iOriginalBusyDelay);
					}
				);
				sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.audit.EventBus","refreshMenuItem", this.refreshMenuItem, this);
			},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf src.sap.grc.acs.aud.audit.view.Object
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf src.sap.grc.acs.aud.audit.view.Object
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf src.sap.grc.acs.aud.audit.view.Object
		 */
		onExit: function() {
			sap.ui.getCore().getEventBus().unsubscribe("sap.grc.acs.aud.audit.EventBus","refreshMenuItem", this.refreshMenuItem, this);
		},
		
		/**
		 * Event handler for loading data when using object view in flexible layout. 
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the worklist route.
		 * @public
		 * @param {string} sChannel event channel
		 * @param {string} sEvent event name
		 * @param {object} oData auditable item binding info
		 */
		loadData: function(oData, sTitle) {
			this.byId("objectPage").setShowHeader(false);
			if(sTitle){
				this.byId("objectPage").setTitle(sTitle);
			}
			this.isFlexibleLayout = true;
			this.objectId = oData.objectId;
			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetaDataLoaded.bind(this));
		},
			/* =========================================================== */
			/* internal methods                                            */
			/* =========================================================== */
		
			/**
			 * Binds the view to the object path.
			 * @function
			 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
			 * @private
			 */
			_onObjectMatched : function (oEvent) {
				this.sObjectId =  oEvent.getParameter("arguments").objectId;
				sap.ui.getCore().setModel(new sap.ui.model.json.JSONModel({id : this.sObjectId}), "auditKeyModel")
				var oObjectPage = this.byId("objectPage");
				if(!this.isNavButtonPressHandlerAttached){
					oObjectPage.attachNavButtonPress(this.onNavBack.bind(this));
					oObjectPage.setShowNavButton(true);
					this.isNavButtonPressHandlerAttached = true;
				}
				
				var oQuery = oEvent.getParameter("arguments")["?query"];
				if(oQuery && oQuery.section){
					
					if (oQuery && this._aValidSectionIds.indexOf(oQuery.section) > -1){
						this.getModel("objectView").setProperty("/selectedSection", oQuery.section);
						// if(oQuery.subSection && this._aValidSubsectionIds.indexOf(oQuery.subSection)){
						// 	this.getModel("objectView").setProperty("/selectedSubSection", oQuery.subSection);
						// 	this.getView().byId("generalSection").setSelectedSubSection(this.getView().byId(this.getView().getId() + "--" + oQuery.subSection));
						// }
						if(oQuery.wpaPhase){
							this.getModel("objectView").setProperty("/wpaPhase", oQuery.wpaPhase);
							if(oQuery.workPackageKey){
								this.getModel("objectView").setProperty("/workPackageKey", oQuery.workPackageKey);
							}
						}
						this.getView().byId("ObjectPageLayout").setSelectedSection(this.getView().byId(this.getView().getId() + "--" + oQuery.section));
						if(this.getModel("objectView").getProperty("/isSectionNavigation")){
							this.getView().setBusy(false);
							this.getModel("objectView").setProperty("/isSectionNavigation", false);
							return;
						}
					} else {
						//If section id does not exist, display general section by default 
						this.getRouter().navTo("object", {
							objectId: this.sObjectId,
							intentService: this.getOwnerComponent().getModel("intentConfig").getData().service,
							query: {
								section : this._aValidSectionIds[0]
							}
						},true /*no history*/);
						return;
					}
				}
				var sIntentService = this.getOwnerComponent().getModel("intentConfig").getData().service;

      			//Realizar llamada al back para obtener el listado de findinds relacionados
      			var findModel = new sap.ui.model.odata.v2.ODataModel(
      					"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
      				);
      			
      			var sAuditKey = this.sObjectId;

      			var url = "/AuditSet(guid'" + sAuditKey + "')/AuditToMyFindRel"; 

      			var that = this;
      			var data = [];
      			var modelTitleFindRel = {};
      			
      			that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(data),"MyFindingRel");      			      			
      			modelTitleFindRel.title = that.getModel("i18nm").getResourceBundle().getText("findingRelSectionTitle");	
      			that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(data), "findRelTitle");
      			modelTitleFindRel.count = '0';

      			/* INI PPM100076335 - Pestaña clasificacionIE*/
      			var modelTitleClasificacionIE = {};
      			that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(data),"MyClasificacionIE");      			      			
      			modelTitleClasificacionIE.title = that.getModel("i18n").getResourceBundle().getText("clasificacionIESectionTitle");	
      			that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(data), "clasificacionIETitle");
      			/* FIN PPM100076335 - Pestaña clasificacionIE*/
      			 
      			/* INI PPM100077498 - Pestaña Encuestas*/
      			var modelTitleEncuestas = {};
      			that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(data),"MyEncuestas");      			      			
      			modelTitleEncuestas.title = that.getModel("i18n").getResourceBundle().getText("encuestasSectionTitle");	
      			that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(data), "encuestasTitle");
      			/* FIN PPM100077498 - Pestaña Encuestas*/
      			
      			findModel.read(url, {
      				success: function (data, response) { 
      					
      					if (data && data.results && data.results.length > 0) {
      						
      						that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(data.results),"MyFindingRel");
      						modelTitleFindRel.count = data.results.length;
      						
      						//PPM100076335 - Pestaña clasificacionIE
      						that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(data.results),"MyClasificacionIE");
      						
      						//PPM100077498 - Pestaña Encuestas
      						that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(data.results),"MyEncuestas");
      						  
      					} else {
      						console.log({ err: "No results" });
      					}
      					modelTitleFindRel.title = modelTitleFindRel.title +'('+modelTitleFindRel.count+')';
      					that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(modelTitleFindRel), "findRelTitle");
      					
      					//PPM100076335 - Pestaña clasificacionIE
      					that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(modelTitleClasificacionIE), "clasificacionIETitle");
      					
      					//PPM100077498 - Pestaña Encuestas
      					that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(modelTitleEncuestas), "encuestasSectionTitle");
      					
      				},
      				failed: function (oData, response) {
      					alert("Failed to get InputHelpValues from service!");
      				},
      				
      				
      			});	
				

				this.getModel().metadataLoaded().then( function() {
					var sObjectPath = this.getModel().createKey(sIntentService, {
						DBKey :  this.sObjectId
					});
					sObjectPath = "/" + sObjectPath;
					this._bindView(sObjectPath);
				}.bind(this));
			},

			/**
			 * Binds the view to the object path.
			 * @function
			 * @param {string} sObjectPath path to the object to be bound
			 * @private
			 */
			_bindView : function (sObjectPath) {

				var that = this;
				var oViewModel = this.getModel("objectView"),
					oDataModel = this.getModel();
				this.getView().byId("activityBlock").destroyCustomData();
				this.getView().byId("activityBlock").addCustomData(new sap.ui.core.CustomData({
					key: "componentID",
					value: this.getOwnerComponent().getId()
				}));
				oViewModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
				var sExpandString = "to_Count,to_MenuItems,to_RoleConfig,to_FttplByPhase,to_AuditTSP,to_AuditType";
				// if(this.getModel("intentConfig").getData().intent === "AuditEngagement-execute"){
					sExpandString = sExpandString + ",to_FinalReportByAudit,to_DraftReportByAudit,to_ReportList,to_ReportForSubmission,to_ReportsByAudit";
				// }
					sap.ui.getCore().getEventBus().publish("sap.grc.aud.audit.EventBus","setObsRelVisibilityinf");
									 
                     oViewModel.setProperty("/busy", false);
//INI UPGRADE prebollo 10.06.2021
//                     var loadDataZ = function(){
//                   	  oDataModel.metadataLoaded().then(function(){
//                   		  oViewModel.setProperty("/busy", false);
//                   			//Realizar llamada al back para obtener el listado de findinds relacionados
//                   			var findModel = new sap.ui.model.odata.v2.ODataModel(
//                   					"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
//                   				);
//                   			
//                   			var sAuditKey = that.sObjectId;
//
//                   			var url = "/AuditSet(guid'" + sAuditKey + "')/AuditToMyFindRel";
//
//                   			
//                   			var data = [];
//                   			that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(data),"MyFindingRel");
//                   			var modelTitleFindRel = [];
//                   			modelTitleFindRel.title = that.getModel("i18nm").getResourceBundle().getText("findingRelSectionTitle");	
//                   			modelTitleFindRel.count = '0';
//                			
//        	
//                   			findModel.read(url, {
//                   				success: function (data, response) {
//                   					
//                   					if (data && data.results && data.results.length > 0) {
//                   						
//                   						that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(data.results),"MyFindingRel");                 															                   						 
//                   						 modelTitleFindRel.count = data.results.length;
//                   					} else {
//                   						console.log({ err: "No results" });
//                   					}
//                   					that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(modelTitleFindRel), "findRelTitle")
//                   				},
//                   				failed: function (oData, response) {
//                   					alert("Failed to get InputHelpValues from service!");
//                   				},
//                   				 
//                   				
//                   			});
//                   			
//                   	  });
//                     };                 
//FIN UPGRADE prebollo 10.06.2021  					 
				this.getView().bindElement({
					path: sObjectPath,
					parameters: {
						expand: sExpandString
					},
					
					events: {
						change: this._onBindingChange.bind(this),
						dataRequested: function () {
							oDataModel.metadataLoaded().then(function () {
								// Busy indicator on view should only be set if metadata is loaded,
								// otherwise there may be two busy indications next to each other on the
								// screen. This happens because route matched handler already calls '_bindView'
								// while metadata is loaded.
								oViewModel.setProperty("/busy", true);
								
								
	
							});
						},
						dataReceived: function () {
							oViewModel.setProperty("/busy", false);
						}
					}
				});
// 					
			},
			
			_setSharOptions: function(oResourceBundle, oViewModel, sObjectId, sObjectName){
				oViewModel.setProperty("/shareOnJamTitle", sObjectName);
				oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
				oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));	
			},
			
			_onBindingChange : function () {
				this.getModel("objectView").setProperty("/busy", true);
				sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.audit.EventBus", "userRoleModelDataUpdateFinished");
				sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.audit.EventBus", "displayWorkingPaperList");
				sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.audit.EventBus", "displayAuditableItemRefreshBtn");
				
				var oView = this.getView(),
					oViewModel = this.getModel("objectView"),
					oElementBinding = oView.getElementBinding();

				// No data for the binding
				if (!oElementBinding.getBoundContext()) {
					if(this.bIsNavToNotFound === true) {
						this.getRouter().getTargets().display("objectNotFound");
					}
					return;
				}
				
				//get file template phase data
				var oFileTemplateList = this.getView().getBindingContext().getObject("to_FttplByPhase");
				var oFileTemplateDetail = {};
				var oFileTemplatePhaseData = [];
				for (var j = 0; j < oFileTemplateList.length; j++) {
					var sFilePath = "/" + oFileTemplateList[j];
					oFileTemplateDetail = this.getView().getBindingContext().getObject(sFilePath);
					if(oFileTemplatePhaseData.indexOf(oFileTemplateDetail.Phase) < 0){
						oFileTemplatePhaseData.push(oFileTemplateDetail.Phase);
					}
				}
				var oFileTemplatePhaseModel = new sap.ui.model.json.JSONModel(oFileTemplatePhaseData);
				this.setModel(oFileTemplatePhaseModel, "fileTemplatePhaseModel");
				
				//set report form model
				var oDraftReportList = [];
				oDraftReportList = this.getView().getBindingContext().getObject("to_DraftReportByAudit");
				var sReportPath = "";
				var oDraftOData = [];
				var oDraftDetail = {};
				if(oDraftReportList !== null){
					for (var k = 0; k < oDraftReportList.length; k++) {
						sReportPath = "/" + oDraftReportList[k];
						oDraftDetail = this.getView().getBindingContext().getObject(sReportPath);
						oDraftOData.push(oDraftDetail);
					}
				}
				oDraftOData.sort(function(a, b){
					return b.SubmittedDateTime - a.SubmittedDateTime;
				});
				var oDraftReportModel = new sap.ui.model.json.JSONModel(oDraftOData[0]);
				this.setModel(oDraftReportModel, "DraftReportByAudit");
				var oFinalReportList = [];
			    oFinalReportList = this.getView().getBindingContext().getObject("to_FinalReportByAudit");
			    sReportPath = "";
				var oFinalOData = [];
				var oFinalDetail = {};
				if(oFinalReportList !== null){
					for (k = 0; k < oFinalReportList.length; k++) {
						sReportPath = "/" + oFinalReportList[k];
						oFinalDetail = this.getView().getBindingContext().getObject(sReportPath);
						oFinalOData.push(oFinalDetail);
					}
				}
				oFinalOData.sort(function(a, b){
					return b.SubmittedDateTime - a.SubmittedDateTime;
				});
				var oFinalReportModel = new sap.ui.model.json.JSONModel(oFinalOData[0]);
				this.setModel(oFinalReportModel, "FinalReportByAudit");

				//update report section display
				sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.audit.EventBus", "refreshReport");

				var oResourceBundle = this.getResourceBundle(),
					oObject = oView.getBindingContext().getObject(),
					sObjectId = oObject.ID,
					sObjectKey = oObject.DBKey,
					sObjectName = oObject.Title,
					sObjectStatus = oObject.Status,
					sAuditType = oObject.Type,
				    sIntent = this.getOwnerComponent().getModel("intentConfig").getData().intent;
				
				//set share options text
				this._setSharOptions(oResourceBundle, oViewModel, sObjectId, sObjectName);
				//get menuitem data
				var oMenuItemList = this.getView().getBindingContext().getProperty("to_MenuItems");
				var sPath = "";
				var oMenuItemsList = [];
				var oMenuItemDetail = {};
				for (var i = 0; i < oMenuItemList.length; i++) {
					sPath = "/" + oMenuItemList[i];
					oMenuItemDetail = this.getView().getBindingContext().getObject(sPath);
					oMenuItemsList.push(oMenuItemDetail);
				}
				this.oMenuItemsList = oMenuItemsList;
	
				var oI18nModel = this.getOwnerComponent().getModel("i18n");
				var sObjectType = sap.grc.acs.aud.audit.util.constant.ObjectType.Audit;
				
				//set extensibility model data
				var oExtensionModel = this.getModel("extensionModel");
				var oMenuItemConfigData = this.getOwnerComponent().getModel("menuItemConfig").getData();
				this.oMenuItemModel = this.getOwnerComponent().getModel("menu");
				
				this.composeMenuItemModelData(oMenuItemsList, oI18nModel, sObjectKey, sObjectType, oMenuItemConfigData);
				
				if (this.isFlexibleLayout) {
				var that = this;
				var oHeader = this.getView().byId("objectPageHeader");
				this.oButtonSetFullScreen = new ObjectPageHeaderActionButton({
					icon: "sap-icon://full-screen",
					tooltip: "Set Full Screen",
					press: that.onSetFullScreen.bind(that)
				});
				this.oButtonExitFullScreen = new ObjectPageHeaderActionButton({
					tooltip: "Exit Full Screen",
					press: that.onExitFullScreen.bind(that),
					icon: "sap-icon://exit-full-screen",
					visible: false
				});
				this.oButtonClose = new ObjectPageHeaderActionButton({
					icon: "sap-icon://decline",
					press: that.onCloseColumn.bind(that)
				});
				oHeader.addAction(this.oButtonSetFullScreen);
				oHeader.addAction(this.oButtonExitFullScreen);
				oHeader.addAction(this.oButtonClose);
				
				var bIsStatusBasedConfig = false;
				if(sObjectStatus === "00") {
					bIsStatusBasedConfig = true;
				}
				
				oExtensionModel.setData(
					FieldExtensibilityUtil.getExtensionFieldsStatus("Audit",
						sAuditType, sObjectStatus, this.getModel().getServiceMetadata(), oMenuItemConfigData, this.getOwnerComponent(), sIntent, bIsStatusBasedConfig),
					true);
			}else{
				oExtensionModel.setData(
					FieldExtensibilityUtil.getExtensionFieldsStatus("Audit",
						sAuditType, sObjectStatus, this.getModel().getServiceMetadata(), oMenuItemConfigData, this.getOwnerComponent(), sIntent),
					true);	
			}
																		  

				//update work paper section display
				var oData = oView.getBindingContext().getObject();
				sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.audit.EventBus", "changeScopeSchema",oData);
				
				// Por defecto ponemos la sección Clasificación IE a visible, en caso de no cumplir con las condiciones se ocultará
				this.getView().byId("clasificacionIESection").setVisible(true);
				
				//INI PPM100076335 - Pestaña clasificacionIE / LA PESTAÑA NO APARECE SI EL ESTADO ES DISTINTO A ENVIADO
				if(oData.Status !== "05" && oData.Status !== "07" && oData.Status !== "08" && oData.Status !== "18")
				{
					this.getView().byId("clasificacionIESection").setVisible(false);
				}
				//Comprobamos si la categoria es Informe Final Enviado
				if(oFinalOData.length)
				{
					//INI MMM PPM 100090915 - AUM - Nueva categoría de informe 
					if(oFinalOData[0].FinalCategory !== "INFIE"&&oFinalOData[0].FinalCategory !== "MEMOIE")
					{
					//FIN MMM PPM 100090915 - AUM - Nueva categoría de informe
					
						this.getView().byId("clasificacionIESection").setVisible(false);
					}
				}
				//FIN PPM100076335 - Pestaña clasificacionIE
				
				//INI PPM100077498 - Pestaña Encuestas / LA PESTAÑA NO APARECE SI EL ESTADO ES DISTINTO A ENVIADO
				
				// Por defecto ponemos la sección Encuestas a visible, en caso de no cumplir con las condiciones se ocultará
				this.getView().byId("encuestasSection").setVisible(true);
				
				if(oData.Status !== "05" && oData.Status !== "07" && oData.Status !== "08" && oData.Status !== "18")
				{
					this.getView().byId("encuestasSection").setVisible(false);
				}
				//Comprobación de categoría y clasificación
				if(oFinalOData.length)
				{
					if(oFinalOData[0].FinalCategory !== "INFSSCC" && oFinalOData[0].FinalCategory !== "INFINC")
					{
						if(oFinalOData[0].FinalCategory === "INFVO")
						{
							if(oFinalOData[0].FinalRating === "D" || oFinalOData[0].FinalRating === "E")
							{
								this.getView().byId("encuestasSection").setVisible(false);
							}
						}
						else
						{
							this.getView().byId("encuestasSection").setVisible(false);
						}
					}
				}
				//FIN PPM100077498 - Pestaña Encuestas

				// If has default displayed section and no selected section exists
				// navigate to the corresponding default section
				var oSectionConfigs = this.getView().getModel("intentConfig").getData().sectionConfig;
				var oActionPhaseMapping = this.getView().getModel("appConfig").getData().actionPhaseMapping;
				var isDefaultSectionSelected = false;
				if(!this.getModel("objectView").getProperty("/selectedSection")){
					for(var iMenuItem in oMenuItemsList){
						for(var sSection in oSectionConfigs){
							var oSectionConfig = oSectionConfigs[sSection];
							if(oSectionConfig.triggeringAction && oSectionConfig.visible
								&& oSectionConfig.triggeringAction.indexOf(oMenuItemsList[iMenuItem].Action) > -1
								&& this._aValidSectionIds.indexOf(sSection) > -1){
									
								var oQuery = {
									section : sSection
								};
								this.getModel("objectView").setProperty("/selectedSection", sSection);
				
								if(oActionPhaseMapping[oMenuItemsList[iMenuItem].Action]){
									oQuery.wpaPhase = oActionPhaseMapping[oMenuItemsList[iMenuItem].Action];
									this.getModel("objectView").setProperty("/wpaPhase", oQuery.wpaPhase);
								}
								
								this.getView().setBusy(true);
								
								jQuery.sap.delayedCall(1000, this, this._navToDefaultSection, [sObjectKey, oQuery]);
				
								isDefaultSectionSelected = true;
								break;
							}
						}
						if(isDefaultSectionSelected){
							break;
						}
					}
				}
				
				// update work paper section display 
				// must be raised after selected section and working paper phase is set
				sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.audit.EventBus", "refreshWorkPaper");
				//Inicio PRL 16.09.2021:Pasamos la carga del object binding al initialize, llamamos a este metodo
				sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.audit.EventBus", "initializeListsinf");
				//Fin PRL 16.09.2021
				// Ini RGB 01/12/2021 
				sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.audit.EventBus","initInfoaditionalAudPre"); 
				sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.audit.EventBus","getFindRelPre");
				//Fin RGB 01/12/2021
				//INI PPM100076335 - Pestaña clasificacionIE - Recarga por publish - subscribe
				sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.audit.EventBus","getDataIE_audapre");
				//FIN PPM100076335 - Pestaña clasificacionIE
				//INI PPM100077498 - Pestaña Encuestas - Recarga por publish - subscribe
				sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.audit.EventBus","getDataEncuestas_audapre");
				//FIN PPM100077498 - Pestaña Encuestas
				
				// Everything went fine.
				oViewModel.setProperty("/busy", false);            
			},
			
			refreshMenuItem: function(){
				var sObjectId = this.getView().getBindingContext().getProperty("DBKey");
				this.getView().byId("objectPageHeader").setBusy(true);
				var oBindingContext = this.getView().getBindingContext();
				var oHeaderButtCountBeforeRefresh = this.getView().byId("objectPageHeader").getActions().length;
				if(oBindingContext){
					var sPath = oBindingContext.getPath() + "/to_MenuItems"; 
					var oDataModel = this.getModel();
					oDataModel.read(sPath, {
						success: jQuery.proxy(function(response){
							var oMenuItemsList = response.results;
							var oI18nModel = this.getModel("i18n");
							var sObjectType = sap.grc.acs.aud.audit.util.constant.ObjectType.Audit;
							var oMenuItemConfigData = this.getOwnerComponent().getModel("menuItemConfig").getData();
							this.composeMenuItemModelData(oMenuItemsList, oI18nModel, sObjectId, sObjectType, oMenuItemConfigData);
							//refresh delegated action
							MenuItemUtils.refreshDelegatedAction(this, oMenuItemsList , "to_MenuItems",this.oMenuItemsList);
							//if this audit is mid-page of audit plan, add full screen button
							if (this.isFlexibleLayout) {
								var that = this;
								var oHeaderAfterRefresh = this.getView().byId("objectPageHeader");
								if(oHeaderAfterRefresh.getActions().length !== oHeaderButtCountBeforeRefresh){
									this.oButtonSetFullScreen = new ObjectPageHeaderActionButton({
										icon: "sap-icon://full-screen",
										tooltip: "Set Full Screen",
										press: that.onSetFullScreen.bind(that)
									});
									this.oButtonExitFullScreen = new ObjectPageHeaderActionButton({
										tooltip: "Exit Full Screen",
										press: that.onExitFullScreen.bind(that),
										icon: "sap-icon://exit-full-screen",
										visible: false
									});
									this.oButtonClose = new ObjectPageHeaderActionButton({
										icon: "sap-icon://decline",
										press: that.onCloseColumn.bind(that)
									});
									oHeaderAfterRefresh.addAction(this.oButtonSetFullScreen);
									oHeaderAfterRefresh.addAction(this.oButtonExitFullScreen);
									oHeaderAfterRefresh.addAction(this.oButtonClose);
								}
							}
							this.getView().byId("objectPageHeader").setBusy(false);
						}, this)
					});
				}
				sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.audit.EventBus", "refreshInfoAditional");
				//Inicio PRL 16.09.2021:Pasamos la carga del object binding al initialize, llamamos a este metodo
				sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.audit.EventBus", "initializeListsinf");
				//Fin PRL 16.09.2021
			},
			
			composeMenuItemModelData: function(oMenuItemsList, oI18nModel, sObjectId, sObjectType, oMenuItemConfigData){
				var oAdditionalInfo = {
					"sectionArray": [
						"findingSection",
						"findingRelSection",
						"reportSection",
						"dimensionSection",
						"adtblSection",
						"riskSection",
						"organizationSection",
						"header"
					],
					"userRoleSection":{
						bIsToolBarRequired: true,
						bIsTitleRequired: false,
						titleText: "",
						id:"userRoleSectionToolbarSpacer"
					},
					"findingSection": {
						bIsToolBarRequired: true,
						bIsTitleRequired: false,
						bIsSearchBoxRequired: true,
						bIsPersonalizationRequired: true,
						sPersonalizationId: "auditFindingBlockPersonalization",
						sSearchHandler: "onSearch",
						titleText: "",
						id: "findingSectionToolBarSpacer"
					},
					"findingRelSection": {
						bIsToolBarRequired: true,
						bIsTitleRequired: false,
						bIsSearchBoxRequired: true,
						bIsPersonalizationRequired: true,
						sPersonalizationId: "auditFindingBlockPersonalization",
						sSearchHandler: "onSearch",
						titleText: this.getOwnerComponent().getModel("i18nm").getResourceBundle().getText("findingRelSectionTitle"),
						id: "findingRelSectionToolBarSpacer"
					},
								 		
					"reportSection": {
						bIsToolBarRequired: true,
						bIsTitleRequired: false,
						titleText: "",
						id: "reportSectionToolBarSpacer"
					},
					"workingPaperSection": {
						bIsToolBarRequired: true,
						bIsTitleRequired: false,
						titleText: "",
						id: "wpsSectionToolBarSpacer"
					},
					"dimensionSection": {
						bIsToolBarRequired: true,
						bIsTitleRequired: false,
						bIsSearchBoxRequired: true,
						bIsPersonalizationRequired: true,
						sPersonalizationId: "dimensionTableSetting",
						sSearchHandler: "onSearch",
						titleText: "",
						id: "dimensionSectionToolBarSpacer"
					},
					"adtblSection": {
						bIsToolBarRequired: true,
						bIsTitleRequired: false,
						bIsSearchBoxRequired: true,
						bIsPersonalizationRequired: true,
						sPersonalizationId: "adtblTableSetting",
						sSearchHandler: "onSearch",
						titleText: "",
						id: "adtblSectionToolBarSpacer"
					},
					"riskSection": {
						bIsToolBarRequired: true,
						bIsTitleRequired: false,
						bIsSearchBoxRequired: true,
						bIsPersonalizationRequired: true,
						sPersonalizationId: "riskTableSetting",
						sSearchHandler: "onSearch",
						titleText: "",
						id: "riskSectionToolBarSpacer"
					},
					"organizationSection": {
						bIsToolBarRequired: true,
						bIsTitleRequired: false,
						bIsSearchBoxRequired: true,
						bIsPersonalizationRequired: true,
						sPersonalizationId: "organizationTableSetting",
						sSearchHandler: "onSearch",
						titleText: "",
						id: "organizationSectionToolBarSpacer"
					},
					"header":{
						bIsShareButtonRequired: true,
						sShareButtonId: "shareButtonId",
						sShareIcon: "sap-icon://action"
					}
				};
				this.oMenuItemModelData = MenuItemUtils.setMenuItemModelData(oMenuItemsList, oI18nModel, sObjectId, sObjectType, oMenuItemConfigData,
					this.oMenuItemModel, oAdditionalInfo);
			},
			
			_navToDefaultSection: function(sObjectId, oQuery){
				this.getModel("objectView").setProperty("/isSectionNavigation", true);
				this.getRouter().navTo("object", {
					objectId: sObjectId,
					intentService : this.getOwnerComponent().getModel("intentConfig").getData().service,
					query: oQuery
				}, true /*without history*/);
			},
			/* =========================================================== */
			/* internal methods                                            */
			/* =========================================================== */
			_onMetaDataLoaded: function() {
				var sIntentService = this.getOwnerComponent().getModel("intentConfig").getData().service;
				var sObjectPath = this.getModel().createKey(sIntentService, {
					DBKey: this.objectId
				});
				sObjectPath = "/" + sObjectPath;
				this._bindView(sObjectPath);
			},

			createHeaderButton: function(sId, oContext) {
				return MenuItemUtils.createButtonTemplate(sId, oContext, this,"","to_MenuItems",this.oMenuItemsList, true);
			},
			
			onSectionSelect: function(oEvent){
				var sSectionId = oEvent.getParameter("section").getId().split("-")[oEvent.getParameter("section").getId().split("-").length - 1];
				
				// Do nothing when audit object page is open from audit plan
				// Do nothing when selecting general section since navigate to subsection function is not supported yet
				if(this.getOwnerComponent().isFromFlexibleColumnLayout
					|| sSectionId === this._aValidSectionIds[0]
					|| oEvent.getParameter("section").getId() === this.getView().byId("ObjectPageLayout").getSelectedSection()){
					return;
				}
				
				this.getModel("objectView").setProperty("/isSectionNavigation", true);
				
				var oQuery = {
					section : sSectionId
				};
				
				if(this.getView().getModel("objectView").getProperty("/wpaPhase")){
					oQuery.wpaPhase = this.getView().getModel("objectView").getProperty("/wpaPhase");
				}
				if(this.getView().getModel("objectView").getProperty("/workPackageKey")){
					oQuery.workPackageKey = this.getView().getModel("objectView").getProperty("/workPackageKey");
				}
				
				var oCtx = this.getView().getBindingContext();
				this.getRouter().navTo("object", {
					objectId: oCtx.getProperty("DBKey"),
					intentService : this.getOwnerComponent().getModel("intentConfig").getData().service,
					query: oQuery
				}, true /*without history*/);
				this.subSectionId = null;
			},
			
			handleHeaderButtonPress: function(oData) {
				var oDataModel = this.getOwnerComponent().getModel();
				var sSuccessTextID = "MSG_EXE_ACT_AUDIT_" + oData.sActionName.toUpperCase() + "_SUCCESS";
				var sErrorTextID = "MSG_EXE_ACT_AUDIT_" + oData.sActionName.toUpperCase() + "_FAIL";
				//get Delegatee
				var oParameter = {};
					oParameter.Delegatee = "";
				for(var i = 0; i < this.oMenuItemsList.length; i++){
					if(this.oMenuItemsList[i].Action === oData.sActionName){
						oParameter.Delegatee = this.oMenuItemsList[i].Delegatee;
						break;
					}
				}
				oDataModel.setUseBatch(false);
				this.getView().setBusy(true);
				oDataModel.callFunction(
					sap.grc.acs.aud.audit.util.constant.FuncImport.ExecuteAction, {
						urlParameters: {
							Action: oData.sActionName,
							Comment: oData.sComment,
							Key: oData.sKey,
							ObjectType: oData.sObjectType,
							Parameter: encodeURI(JSON.stringify(oParameter))
						},
						method: "POST",
						async: true,
						success: jQuery.proxy(
							function() {
								MessageUtil.showMsg("msgTypeSuccessful", this.getResourceBundle().getText(sSuccessTextID));
								sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.audit.EventBus", "auditListRefresh");
								if(this.getView().getBindingContext()){
									this.getModel().invalidateEntry(this.getView().getBindingContext());
								}
								this.getView().setBusy(false);
								this.bIsNavToNotFound = false;
								this.onNavBack(null, true);
							}, this),
						error: jQuery.proxy(
							function(oError) {
								if (oError.responseText) {
									var sErrorMessage = "";
									// Add try-catch in case responseText is in xml format
									try {
										var oJsonError = JSON.parse(oError.responseText);
										sErrorMessage = oJsonError.error.message.value;
									} catch (e) {
										sErrorMessage = oError.responseText;
									}
									MessageUtil.showMsg("msgTypeFailed", this.getResourceBundle().getText(sErrorTextID) + "\r\n" + sErrorMessage);
									this.getView().getModel().refresh();
									this.getView().setBusy(false);
								}
							}, this)
					});
			},
			
			AUDIT_DELETE_ROOT: function() {
				var oController = this;
				var sMessage = this.getResourceBundle().getText("MSG_DELETE_AUDIT");
				MessageUtil.showMsg("msgTypeConfirm", sMessage,
					this.getResourceBundle().getText("LABEL_CONFIRM_DELETE_AUDIT"),
					jQuery.proxy(function(oReturn) {
						if (oReturn === "OK") {
							oController.deleteAudit(oController);
						}
					}, this));
			},
			
			deleteAudit: function() {
				var oDataModel = this.getView().getModel();
				var sDeletePath = this.getView().getBindingContext().getPath();
				var oController = this;
	
				oDataModel.remove(sDeletePath, {
					success: jQuery.proxy(function(oData, oResponse) {
						MessageUtil.showMsg("msgTypeSuccessful", this.getResourceBundle().getText("MSG_DELETE_AUDIT_SUCCESS"));
						oController.onNavBack(null, true);
					}, this),
					error: jQuery.proxy(function(oError) {
						// var sMessage = this.getResourceBundle().getText("MSG_DELETE_AUDIT_FAIL") + "\n" + oError.message;
						// MessageUtil.showMsg("msgTypeFailed", sMessage);
					}, this),
					async: true
				});
			},
			
			AUDIT_SUBMIT_AUDIT_ANNOUNCEMENT: function (oEvent, oAdditionalInfo) {
				this.auditKey = oAdditionalInfo.objectKey;
				this.actionName = oAdditionalInfo.actionName;
				this._setModelToAnnLetterDialog();
			},
			
			_setModelToAnnLetterDialog: function(){
				var sPath = "/GRCAUD_CV_WPACatByAudit(DBKey=guid'" + this.auditKey + "',Code='B')/to_WorkingPapers";
				var oDataModel = this.getView().getModel();
				this.getView().setBusy(true);
				//get submission announcement letter data
				oDataModel.setUseBatch(false);
				oDataModel.read(sPath, {
					async: true,
					success: jQuery.proxy(function(response) {
						oDataModel.setUseBatch(true);
						var oAnnLetterOData = response.results;
						var oAnnouncementOData = [];
						for(var i=0; i<oAnnLetterOData.length; i++){
							if(oAnnLetterOData[i].Repository !== "LINK"){
								oAnnouncementOData.push(oAnnLetterOData[i]);
							}
						}
						if(oAnnouncementOData.length === 0){
							MessageUtil.showMsg("msgTypeConfirm", 
								this.getResourceBundle().getText("TIT_EXE_ACT_SUBMIT_AUDIT_ANNOUNCEMENT"),
								this.getResourceBundle().getText("submitAnnLetterTitle"), 
								jQuery.proxy(function(oReturn) {
									if (oReturn === "OK") {
										sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.audit.EventBus","getAnnLetterTemplate");
									}
								},this)
							);
						}else{
							if (this.submitAnnLetterDialog) {
								this.submitAnnLetterDialog.destroy();
							}
							this.submitAnnLetterDialog = sap.ui.xmlfragment("sap.grc.acs.aud.audit.fragment.SubmitAnnouncementLetter", this);
							this.getView().addDependent(this.submitAnnLetterDialog);
							this.submitAnnLetterDialog.open();
							this.submitAnnLetterDialog.setBusy(true);
							oAnnouncementOData.sort(function(a, b){
								return b.LastChangedAt - a.LastChangedAt;
							});
							var oModel = new sap.ui.model.json.JSONModel(oAnnouncementOData);
							//set submission dialog model
			            	this.submitAnnLetterDialog.setModel(oModel, "annLetterDialog"); 
			            	//set latested announcement letter as default submission letter 
							sap.ui.getCore().byId("selectAnnLetter").setSelectedKey(oAnnouncementOData[0].WorkingPaperKey);
							this.submitAnnLetterDialog.setBusy(false);
						}
		            	this.getView().setBusy(false);
					}, this)
				}); 
			},
			
			cancelSubmitAnnLetter: function(){
				this.submitAnnLetterDialog.close();
			},
			
			confirmSubmitAnnLetter: function(){
				var AnnKey = sap.ui.getCore().byId("selectAnnLetter").getSelectedKey(); //working paper key
				var optionalComment = sap.ui.getCore().byId("optionalNote4AnnLetter").getValue();
				var sAnnLetterPath = "/GRCAUD_CV_AuditAnnouncement";
				var data = { 
					AnnouncementKey: AnnKey,
					ParentKey: this.auditKey
				};
				this.getView().setBusy(true);
				this.submitAnnLetterDialog.setBusy(true);
				var oDataModel = this.getView().getModel();
				oDataModel.setUseBatch(false);
				oDataModel.create(sAnnLetterPath, data, {
					success:jQuery.proxy(function(){
						oDataModel.setUseBatch(true);
						var oParameters = {};
						//get Delegatee
						oParameters.Delegatee = "";
						for(var i = 0; i < this.oMenuItemsList.length; i++){
							if(this.oMenuItemsList[i].Action === "SUBMIT_AUDIT_ANNOUNCEMENT"){
								oParameters.Delegatee = this.oMenuItemsList[i].Delegatee;
								break;
							}
						}
						var sPathToExecuteAction = sap.grc.acs.aud.audit.util.constant.MenuItemExecutionSet,
								oMenuItemExecution = {};
								oMenuItemExecution.Key = this.auditKey;
								oMenuItemExecution.ObjectType = "AUDIT";
								oMenuItemExecution.ActionName = "SUBMIT_AUDIT_ANNOUNCEMENT";
								oMenuItemExecution.Comment = optionalComment;
								oMenuItemExecution.Parameter = encodeURI(JSON.stringify(oParameters));
								this.getView().getModel().create(sPathToExecuteAction, oMenuItemExecution,{
								 success:jQuery.proxy(function(){
								  			MessageUtil.showMsg("msgTypeSuccessful", this.getResourceBundle().getText("MSG_EXE_ACT_AUDIT_SUBMIT_AUDANN_SUCCESS"));
											sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.audit.EventBus","auditListRefresh");
											this.getView().setBusy(false);
											this.bIsNavToNotFound = false;
											this.onNavBack(null, true);
								  }, this),
								  async:true
								});
					  }, this),
					  error:jQuery.proxy(function(oError){
								if (oError.responseText) {
									var oJsonError = JSON.parse(oError.responseText);
									var errorMessage = oJsonError.error.message.value;
									MessageUtil.showMsg("msgTypeFailed", this.getResourceBundle().getText("MSG_EXE_ACT_AUDIT_SUBMIT_AUDANN_FAIL") + "\r\n" + errorMessage);
									this.getView().getModel().refresh();
									this.getView().setBusy(false);
								}
					  }, this)
				} );
				this.submitAnnLetterDialog.setBusy(false);
				this.submitAnnLetterDialog.close();
				this.getView().setBusy(false);
			},
	
			AUDIT_SUBMIT_DRAFT_REPORT: function (oEvent, oAdditionalInfo) {
				this.auditKey = oAdditionalInfo.objectKey;
				this.actionName = oAdditionalInfo.actionName;
				this._setModelToDialog();
			},

			AUDIT_SUBMIT_FINAL_REPORT: function (oEvent, oAdditionalInfo) {
				this.auditKey = oAdditionalInfo.objectKey;
				this.actionName = oAdditionalInfo.actionName;
				this._setModelToDialog();
			},
	
			onSelectReportChange: function (oEvent) {
				var reportKey = oEvent.getSource().getSelectedKey();
				this._setSubmissionReportData(reportKey);
				this.submitReportDialog.setBusy(false);
			},	
			
			_setModelToDialog: function() {
				this.getView().setBusy(true);
				var oSubmissionList = this.getView().getBindingContext().getObject("to_ReportForSubmission");
				var sPath = "";
				var oSubmissionOData = [];
				var oSubmissionDetail = {};
				for (var i = 0; i < oSubmissionList.length; i++) {
					sPath = "/" + oSubmissionList[i];
					oSubmissionDetail = this.getView().getBindingContext().getObject(sPath);
					oSubmissionOData.push(oSubmissionDetail);
				}
				if(oSubmissionOData.length === 0){
						MessageUtil.showMsg("msgTypeFailed", 
						this.getResourceBundle().getText("MSG_PROCEDURE_NOT_COMPLETED"));
				}else{
					if (this.submitReportDialog) {
						this.submitReportDialog.destroy();
					}
					this.submitReportDialog = sap.ui.xmlfragment("sap.grc.acs.aud.audit.fragment.SubmitReportDialog", this);
					var oTitle = "";
					if(this.actionName === "SUBMIT_DRAFT_REPORT"){
						oTitle = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("submitDraftReportTitle");
					}else{
						oTitle = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("submitFinalReportTitle");
					}
					this.submitReportDialog.setTitle(oTitle);
					this.getView().addDependent(this.submitReportDialog);
					this.submitReportDialog.open();
					oSubmissionOData.sort(function(a, b){
						return b.LastChangedAt - a.LastChangedAt;
					});
					var oModel = new sap.ui.model.json.JSONModel(oSubmissionOData);
					//set submission dialog model
	            	this.submitReportDialog.setModel(oModel, "reportDialog"); 
	            	this._setSubmissionReportData(oSubmissionOData[0].WorkingPaperKey);
				}
				this.getView().setBusy(false);
				this.submitReportDialog.setBusy(false);
			},
			
			_setSubmissionReportData: function(sRepKey){
				this.submitReportDialog.setBusy(true);
				var oReportsList = this.getView().getBindingContext().getObject("to_ReportsByAudit");
				var sPath = "";
				var oReportsOData = [];
				var oReportsDetail = {};
				for (var i = 0; i < oReportsList.length; i++) {
					sPath = "/" + oReportsList[i];
					oReportsDetail = this.getView().getBindingContext().getObject(sPath);
					oReportsOData.push(oReportsDetail);
				}
				var oFlag = true;
				for (var j = 0; j < oReportsOData.length; j++) {
					if (oReportsOData[j].WorkingPaperKey === sRepKey) {
						sap.ui.getCore().byId("selectReportCategory").setSelectedKey(oReportsOData[j].Category);
						sap.ui.getCore().byId("rating").setSelectedKey(oReportsOData[j].Rating);
						sap.ui.getCore().byId("executiveSummary").setValue(oReportsOData[j].Summary);
						oFlag = false;
						break;
					}
				}
				if(oFlag && oReportsOData[0]){
					sap.ui.getCore().byId("selectReportCategory").setSelectedKey(oReportsOData[0].Category);
					sap.ui.getCore().byId("rating").setSelectedKey(oReportsOData[0].Rating);
					sap.ui.getCore().byId("executiveSummary").setValue(oReportsOData[0].Summary);
				}
			},
	
			cancelSubmitReport: function () {
				this.submitReportDialog.close();
			},
			
			onChangeCheckSubmitReport: function(oEvent){
				var oSource = oEvent.getSource().getProperty("selectedKey");
				if(oSource === ""){
					oEvent.getSource().setValueState(sap.ui.core.ValueState.Error);
				}else{
					oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
				}
			},
	
			confirmSubmitReport: function () {
				var ratingKey = sap.ui.getCore().byId("rating").getSelectedKey();
				var categoryKey = sap.ui.getCore().byId("selectReportCategory").getSelectedKey();
				var WPAKey = sap.ui.getCore().byId("selectReport").getSelectedKey();
				var execSummary = sap.ui.getCore().byId("executiveSummary").getValue();
				var actionComment = sap.ui.getCore().byId("optionalNote").getValue();
				if(ratingKey === "" || categoryKey === "" || WPAKey === ""){
					if(ratingKey === ""){
						sap.ui.getCore().byId("rating").setValueState(sap.ui.core.ValueState.Error);
					}
					if(categoryKey === ""){
						sap.ui.getCore().byId("selectReportCategory").setValueState(sap.ui.core.ValueState.Error);
					}
					if(WPAKey === ""){
						sap.ui.getCore().byId("selectReport").setValueState(sap.ui.core.ValueState.Error);
					}
					MessageUtil.showMsg("msgTypeFailed", this.getResourceBundle().getText("MSG_REQUIRED_FIELD"));
					return;
				}
				var oParameters = {
					Report: WPAKey,
					Category: categoryKey,
					Rating: ratingKey,
					ExecutiveSummary: execSummary
				};
				//get Delegatee
				oParameters.Delegatee = "";
				for(var i = 0; i < this.oMenuItemsList.length; i++){
					if(this.oMenuItemsList[i].Action === this.actionName){
						oParameters.Delegatee = this.oMenuItemsList[i].Delegatee;
						break;
					}
				}
				var sAction = this.actionName;
				var sSuccessTextID = "MSG_EXE_ACT_AUDIT_" + sAction.toUpperCase() + "_SUCCESS";
				var sErrorTextID = "MSG_EXE_ACT_AUDIT_" + sAction.toUpperCase() + "_FAIL";
				this.getView().setBusy(true);
				this.submitReportDialog.setBusy(true);
				var oDataModel = this.getOwnerComponent().getModel();
				oDataModel.setUseBatch(false);
				// menuitemexectionset create
				var sPathToExecuteAction = sap.grc.acs.aud.audit.util.constant.MenuItemExecutionSet,
					oMenuItemExecution = {};
					oMenuItemExecution.Key = this.getView().getBindingContext().getObject().DBKey;
					oMenuItemExecution.ObjectType = "AUDIT";
					oMenuItemExecution.ActionName = sAction;
					oMenuItemExecution.Comment = actionComment;
					oMenuItemExecution.Parameter = encodeURI(JSON.stringify(oParameters));
				oDataModel.create(sPathToExecuteAction, oMenuItemExecution,{
					  success:jQuery.proxy(function(){
					  			oDataModel.setUseBatch(true);
					  			MessageUtil.showMsg("msgTypeSuccessful", this.getResourceBundle().getText(sSuccessTextID));
								sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.audit.EventBus","auditListRefresh");
								this.getView().setBusy(false);
								this.bIsNavToNotFound = false;
								this.onNavBack(null, true);
					  }, this),
					  error:jQuery.proxy(function(oError){
								if (oError.responseText) {
									var oJsonError = JSON.parse(oError.responseText);
									var errorMessage = oJsonError.error.message.value;
									MessageUtil.showMsg("msgTypeFailed", this.getResourceBundle().getText(sErrorTextID) + "\r\n" + errorMessage);
									this.getView().getModel().refresh();
									this.getView().setBusy(false);
								}
					  }, this),
					  async:true
					});
				this.submitReportDialog.setBusy(false);
				this.submitReportDialog.close();
			},
			
			_resetSectionNavigationInformation: function(){
				this.getModel("objectView").setProperty("/selectedSection", null);
				this.getModel("objectView").setProperty("/wpaPhase", null);
				this.getModel("objectView").setProperty("/workPackageKey", null);
			},
			
			_formatChartValue: function (sValue) {
				return parseFloat(sValue);
			},
			
			onNavBack : function(oEvent, isToWorkListPage) {
				this._resetSectionNavigationInformation();
				var sPreviousHash = History.getInstance().getPreviousHash(),
					oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
				if (!isToWorkListPage && (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation() || this.getOwnerComponent().isAppToAppNavigation())) {
					history.go(-1);
				}else if (this.isFlexibleLayout) {
					sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.auditplan.EventBus", "closeColumn", {
						id: this.getView().getId(),
						objectType: "Audit"
					});
					sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.auditplan.EventBus", "refreshAuditList");
				}else {
					this.getRouter().navTo("worklist", {}, true);
				}
				sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.audit.EventBus", "resetBlockToDisplayMode");
				
			},
			
			getPlannedTimePeriod:function(start,end){
				if (start !== null && end !== null) {
					start = formatter.formatRecordDate(start);
					end = formatter.formatRecordDate(end);	
					return formatter.formatDate(start) + " - " + formatter.formatDate(end);
				}
				return "";
			},
			
			formatAdtblSectionHeaderWithCount: function(sAdtblSectionCount) {
				return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("auditableItemSectionTitle", [sAdtblSectionCount]);
			},

			onSetFullScreen: function () {
				this.setFCLFullScreenMode();
				sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.auditplan.EventBus", "setColumnFullScreen", {
					id: this.getView().getId()
				});
			},
			setFCLFullScreenMode: function () {
				this.oButtonSetFullScreen.setVisible(false);
				this.oButtonClose.setVisible(false);
				this.oButtonExitFullScreen.setVisible(true);
			},
			onExitFullScreen: function () {
				this.setFCLThreeColumnsMode();
				sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.auditplan.EventBus", "exitFullScreen");
			},
			setFCLThreeColumnsMode: function () {
				this.oButtonSetFullScreen.setVisible(true);
				this.oButtonClose.setVisible(true);
				this.oButtonExitFullScreen.setVisible(false);
			},
			onCloseColumn: function () {
				sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.auditplan.EventBus", "closeColumn", {
					id: this.getView().getId(),
					objectType: "Audit"
				});
			}

	});

});
