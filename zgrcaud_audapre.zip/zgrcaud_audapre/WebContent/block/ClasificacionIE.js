/*
 * Copyright (C) 2009-2020 SAP SE or an SAP affiliate company. All rights reserved.
 */
//PPM100076335 - Pestaña clasificacionIE 27/07/2022
sap.ui.define([ "sap/uxap/BlockBase" ], function(B) {
	"use strict";
	return B.extend("sap.grc.acs.aud.audit.approvereport.extended.block.ClasificacionIE", {
		metadata : {
			views : {
				Collapsed : {
					viewName : "sap.grc.acs.aud.audit.approvereport.extended.block.view.ClasificacionIE",
					type : "XML"
				}, 
				Expanded : {
					viewName : "sap.grc.acs.aud.audit.approvereport.extended.block.view.ClasificacionIE",
					type : "XML"
				}
			}
		}
	});
});
