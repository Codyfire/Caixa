sap.ui.define([  "sap/ui/core/mvc/Controller",
"sap/grc/acs/aud/audit/approvereport/extended/block/util/listsUtils",
	"sap/grc/acs/aud/audit/approvereport/extended/block/util/encodingUtils",
	"sap/grc/acs/aud/audit/approvereport/extended/block/model/oDataGeneratorList",
	"sap/grc/acs/aud/audit/approvereport/extended/block/util/Enhancements",
], function(Controller,UtilList,Util,Model,enh) { 
	"use strict";
	return Controller.extend("sap.grc.acs.aud.audit.approvereport.extended.block.controller.Delegados",{
		onInit: function () {
			console.log("En Delegados controller");			
		},
		
		formatTextName: function(fullName, delegadoDel){
			if(delegadoDel != undefined) {
    			if(JSON.parse(delegadoDel))
	    			this.getParent().getAggregation("items")[1].addStyleClass("lineThrough");
	    		else 
	    			this.getParent().getAggregation("items")[1].removeStyleClass("lineThrough");
    		}
    		
    		this.getParent().setVisible(true);
    		return fullName != undefined ? fullName : "";
		},
		
		onDeleteItem: function(oEvent){
//			var bindingContext = oEvent.getSource().getBindingContext().sPath;
//            var viewName = oEvent.getSource().getParent().getParent().getParent().getParent().getParent();
//            var table = viewName.byId('tableDelegados');
//            var oModel = table.getModel();                        
//            var dele = oModel.getProperty(bindingContext);  
//            viewName.byId('tableDelegados').getModel().getProperty(bindingContext).DelegadoDel = true;
//           // oEvent.getSource().getParent().getAggregation("items")[1].addStyleClass("lineThrough");
//            viewName.byId('tableDelegados').updateBindings(true);
			var bindingContext = oEvent.getSource().getBindingContext().sPath;
            var viewName = oEvent.getSource().getParent().getParent().getParent().getParent().getParent();
            var table = viewName.byId('tableDelegados');
            var oModel = table.getModel();                        
            var dele = oModel.getProperty(bindingContext);           
           var oData = oModel.getData();

           $.each(oData.results, function(i,n){ 
       		if(n.UserId == dele.UserId) {
       			n.DelegadoDel = 'true';       			       		
       		}        		       		
       	});
           
           oModel.setData(oData);
            //oEvent.getSource().getParent().getAggregation("items")[1].removeStyleClass("lineThrough");
    		table.setModel(oModel);
    		table.updateBindings(true);
        		
		},
		
		onAddItem : function(oEvent){
			var bindingContext = oEvent.getSource().getBindingContext().sPath;
            var viewName = oEvent.getSource().getParent().getParent().getParent().getParent().getParent();
            var table = viewName.byId('tableDelegados');
            var oModel = table.getModel();                        
            var dele = oModel.getProperty(bindingContext);           
           var oData = oModel.getData();

           $.each(oData.results, function(i,n){ 
       		if(n.UserId == dele.UserId) {
       			n.DelegadoDel = 'false';       			       		
       		}        		       		
       	});
           
           oModel.setData(oData);
            //oEvent.getSource().getParent().getAggregation("items")[1].removeStyleClass("lineThrough");
    		table.setModel(oModel);
    		table.updateBindings(true);
            
            
        },
        //Inicio PRL 04.06.2021	        
    	onAdd: function() {
    		var o18nmModel = new sap.ui.model.resource.ResourceModel({ bundleUrl:"sap/grc/acs/aud/audit/approvereport/extended/i18n/i18n.properties" }).getResourceBundle();
    		var oController = this;
    		var oEntity;
    		//Preparo els filtres amb els valors
    		var oModel = new sap.ui.model.json.JSONModel();
    		sap.ui.getCore().setModel(oModel,"ldap");
    		
    		if(sap.ui.getCore().getComponent('searchComponent')) {
    			sap.ui.getCore().getComponent('searchComponent').destroy();
    		}
    		
    		var oComp  = sap.ui.getCore().createComponent({
    			id: "searchComponent",
    	        name: "sap.grc.acs.aud.audit.approvereport.extended.block.searchComponent"
    	    });
    		
    		// Función de añadir resultados a las tablas
    		var addFunct =function() {
    			var selItems = this.getParent().getContent()[1].getSelectedItems();
    			
    			if(selItems.length == 0) { alert(o18nmModel.getText("select_option")); }
    			else {
    				if(mirarDelegadoRepetides(selItems,oController.getView())){
    					//Han intentat inserir una persona repetida
    					var dialog = new sap.m.Dialog({
    						title: o18nmModel.getText("info"),
    						type: 'Message',
    							content: new sap.m.Text({
    								text: o18nmModel.getText("repeated_person")
    							}),
    						beginButton: new sap.m.Button({
    							text: o18nmModel.getText("accept"),
    							press: function () {
    								dialog.close();
    							}
    						}),
    						endButton: new sap.m.Button({
    							text: o18nmModel.getText("cancel"),
    							press: function () {
    								dialog.close();
    							}
    						}),
    						afterClose: function() {
    							dialog.destroy();
    						}
    					});
    					dialog.open();
    				}else{
    					var viewName = oController.getView();
    		        	var list = viewName.byId('tableDelegados');
    		        	//var listTemplate = sap.ui.getCore().template;
    		        	
    					$.each(selItems,function(i,n){
    		        		var bindingContext = selItems[i].getBindingContext().sPath;
    		        		var matricula = sap.ui.getCore().getModel("ldap").getProperty(bindingContext).UserId;
    			        	var nombre = sap.ui.getCore().getModel("ldap").getProperty(bindingContext).FullName;
    			        
    			        var	oEntity = {};
    			        	oEntity.FullName = nombre;
    			        	oEntity.UserId = matricula;
//    			        	if(list.getModel().getData().results)
    			        	if(list.getModel().getData() !== null && list.getModel().getData().results)
    			        	{
    			        		list.getModel().getData().results.push(oEntity);
    			        	}
    			        	else {    			    			        
//    			        		list.getModel().getData().results = [];
//    			        		list.getModel().getData().results.push(oEntity);
    			        		var oData = {};
    			        		oData.results = [];
    			        			var oModel = new sap.ui.model.json.JSONModel();
    			        			oData.results.push(oEntity);
			                        oModel.setData(oData);			                       
			                        list.setModel(oModel);    
    			        	}
    			        	//anadirObjetoADelegados(oEntity, list);
    		        	});
    		        	//byId("delegados").setModel(sap.ui.getCore().getModel("delegados"));
    					list.bindAggregation("items","/results", viewName.templateTable);
    					list.bindItems("/results/", viewName.templateTable);
    		        	this.getParent().destroy();
    				}
    			}};
    			
    		var addSearchFunct = function(){
    			//Agafo el valor del serchfield
    			var text = this.getParent().getContent()[0].getProperty("value");
    			//var url = "/InfoUsersLDAPSet";
    			var url = "/RoleSet(RoleId='AUD',RoleDepId='')/Users"
    			if(text != ""){
    				var aFilters = [];
    				aFilters.push(new sap.ui.model.Filter("FullName",sap.ui.model.FilterOperator.Contains, text.toUpperCase()));
    				//Hacemos la llamada al ldap
    				addDelegadosLdap(url, aFilters);
    			}

    		}		
    		// Cabecera, Binding Posiciones, Modo de Lista, Binding Aggregation, Path, Model, AddFunction
    		oComp.setupInicial(["Matricula", "Nombre"],  ["{UserId}", "{FullName}"], "MultiSelect", "", "/results", "ldap", addFunct,addSearchFunct);
    		
    		// Se crea un contenedor para el componente
    		var oCompCont = new sap.ui.core.ComponentContainer({
    			 component: oComp,
    		});

    	}
//Fin PRL 04.06.2021    
	})
})