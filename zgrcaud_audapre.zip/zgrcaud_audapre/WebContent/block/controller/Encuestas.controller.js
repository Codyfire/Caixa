/*
 * Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(
 [
  "sap/grc/acs/aud/finding/controller/BaseController",
  "sap/grc/acs/lib/aud/utils/MenuItemUtils",
  "sap/grc/acs/lib/aud/utils/ComponentUtil",
  "sap/grc/acs/lib/aud/utils/MessageUtil",
  "sap/grc/acs/aud/audit/approvereport/extended/block/util/encodingUtils",
  "sap/m/MessageBox"
 ],
 function(BaseController, MenuItemUtils, ComponentUtil, MessageUtil, Util, MessageBox) {
  "use strict";

  return BaseController.extend("sap.grc.acs.aud.audit.approvereport.extended.block.controller.Encuestas", { 
	  
	  
	  onInit: function() {
		  // INI IRC 16/11/2022 Generamos todos los componentes de la vista en variables del controlador para evitar errores en los routing con publish/subscribe
		  // Inicializamos variables
		  this.tableEncuestas = this.getView().byId("tableEncuestas");
		  this.dbKey = this.getView().byId("dbKey");
		  this.textAreaNAA = this.getView().byId("textAreaNAA");
		  this.chk_NaEncuestasTextArea = this.getView().byId("chk_NaEncuestasTextArea");
		  this.btn_NaSave = this.getView().byId("btn_NaSave");
		  this.btn_NaDel = this.getView().byId("btn_NaDel");
		  this.chk_NaEncuestas = this.getView().byId("chk_NaEncuestas");
		  this.btn_addEncuestas = this.getView().byId("btn_addEncuestas");	
		  this.btn_SaveEncuestas = this.getView().byId("btn_SaveEncuestas");
		  // FIN IRC 16/11/2022
		  
		  this._Component = ComponentUtil.getComponentById(this.getView().getId());
		  this.modelEncuestas = this._Component.getModel("MyEncuestas");
		  this.tableEncuestas.setModel(this.modelEncuestas,"encuestas");
		  
		  this.tableContentModel = new sap.ui.model.json.JSONModel();
		  this.sModelData = {
				  EncuestasData: [],
		  	};
		  this.tableContentModel.setData(this.sModelData);
		  
		  // Carga de datos necesarios
		  //this.getData();
		  
		  //sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.audit.EventBus","getDataEncuestas_audapre", this.getData, this);
		  sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.audit.EventBus","getDataEncuestas_audapre", this.initialize, this);
		  this.initialize(this);
	  
	  },
	  
	  initialize: function(oController) {
			
			//Inicio PRL 16.09.2021: Solo informamos el objectBinding si se ha cargado el contexto
			var that = this;
			if(this.getOwnerComponent()){
			this.getOwnerComponent().mAggregations.rootControl.mAggregations.content[0].mAggregations.pages.forEach(function(e,i,a){
				if(e.sId.indexOf('object') !== -1){
				var binding = e.getBindingContext();				
				if(binding != undefined){
					that.objectBinding = e.getBindingContext().getObject();
				}	
			//Fin PRL 16.09.2021		
            }
			})};
			this.grcaudController = oController;  
			
			// Fetching Distribution List
			this.getData();
			//sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.audit.EventBus","getInTeamLists", this._checkEnabledTeamAdd, this);
			
		},
	  
	  getData: function() {
		//Carga de la tabla principal
		  this.getDataFromOdata();
		  
		//Carga de la encuesta
		  this.getDataNA();
		  
		  //Visibilidad de Botones
		  this.onVisiblidadBotones();
	  },
	  
	//FUNCION DE AÑADIR NUEVOS ELEMENTOS AL POP-UP DE CLASIFICACION IE
	  onAdd_Encuestas: function(oEvent){
		   
		   var oSource = oEvent.getSource();
		   
		   var sectionBindingModel = this.getView().getModel("sectionBindingConfig");

		   if(this.addEncuestasSmartTable){
				this.addEncuestasSmartTable.destroy();
			}
		   
		   //Cargamos el fragment 
		   this.addEncuestasSmartTable = sap.ui.xmlfragment("sap.grc.acs.aud.audit.approvereport.extended.block.fragment.addEncuestas", this);
		   var that = this;
		   
		 //Realizar llamada al back para obtener el listado de findinds relacionados
			var EncuestasModel = new sap.ui.model.odata.v2.ODataModel(
					"/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/",false ////"ZGRCAUD_ENH_SRV"
				
			);
			
			var oData = {},
			aBatchOperations = [];
	
			//Limpiamos los registros seleccionados por si los hubiera de navegaciones anteriores
			try {
				that.getView().getContent()[0].getContent()[1].removeSelections();
			} catch (err) {}
	
			//limpiamos la tabla por si hubiera registros de consultas anteriores
			that.sModelData.EncuestasData = [];
			that.tableContentModel.refresh();
					   
		   
		   //this.addEncuestasSmartTable.setModel(this.tableContentModel);
			var i18nModel = this.getView().getModel( "i18n");
			this.addEncuestasSmartTable.setModel(i18nModel, "i18n");
			var oController = this;
		   
		   this.oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				//title: this.getView().getModel("i18n").getResourceBundle().getText("labelLimitations"),
			   	title: "Usuario",
				supportMultiselect: true,
				supportRanges: false,
				supportRangesOnly: false,
				key: "UserId",
				descriptionKey: "FullName",
				stretch: sap.ui.Device.system.phone,
				contentHeight:"100%",
				
				ok: function(oOkEvent) {
					var aSelectedTokens = oOkEvent.getParameter("tokens");
	
					//oController.assignEncuestasToAudit(aSelectedTokens);
					//var modeloEncuestas = that.getView().getModel("encuestas").getData();
					that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(aSelectedTokens), "aSelectedTokens");
					
					//Hacemos esto para poder mostrarlos por pantalla
					for(var i = 0; i < aSelectedTokens.length; i++)
					{
						for(var j = 0; j < aSelectedTokens[i].mAggregations.customData.length; j++)
						{
							if(aSelectedTokens[i].mAggregations.customData[j] !== undefined)
							{
								var UserId = aSelectedTokens[i].mAggregations.customData[j].mProperties.value.UserId;
								var FullName = aSelectedTokens[i].mAggregations.customData[j].mProperties.value.FullName;
								var Email = aSelectedTokens[i].mAggregations.customData[j].mProperties.value.Email;
								//var idSubTema = aSelectedTokens[i].mAggregations.customData[j].mProperties.value.subtopic;
							}
							
							
							if(UserId !== undefined && FullName !== undefined && Email !== undefined && UserId !== "" && FullName !== "" && Email !== "")
								that.tableEncuestas.getModel("encuestas").getData().push({user_id: UserId, Full_Name: FullName, Email: Email, langu: "ES"});
								//modeloEncuestas.push({idUsuario: UserId, nombreUsuario: FullName, email: Email});
						}
						
					}
					/*that.tableEncuestas.getModel("encuestas").getData().sort(function(a, b) {
						  if (a.user_id < b.user_id) {
						    return 1;
						  }
						  if (a.user_id > b.user_id) {
						    return -1;
						  }
						  return 0;
						});
					that.tableEncuestas.sort()*/
					
					that.getView().getModel("encuestas").refresh();
					that.byId("tableEncuestas").getBinding("items").refresh()
					that.oValueHelpDialog.close();
					// this.close();
				},
	
				cancel: function() {
					this.close();
				},
	
				afterClose: function() {
					this.destroy();
				}
			});
		   
		   var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
			    id: "filtrosUser",
				advancedMode: true,
				width: "100%",
				filterBarExpanded: false,
				showGoOnFB: !sap.ui.Device.system.phone,
				search: function(oEvent) {
					//oController.searchToBeAssignedTable();
					var UsuarioEscrito = oController.oBasicSearch.mProperties.value;
					var aFilters = [];
					//aFilters.push(new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.GE, "2017"));
					//var url = "?$filter=(substringof('CESAR',FullName)";
					var filtro = "?$filter=(substringof('" + UsuarioEscrito + "',FullName))";
					var url = "/RoleSet(RoleId='AUD',RoleDepId='')/Users"
					//var strFilter = formatUrl(url);
					//aFilters.push(new sap.ui.model.Filter("substringof('CESAR',FullName)"));
					//EncuestasModel.read("/RoleSet(RoleId='AUD',RoleDepId='')/Users"+url , {
					
					var aFilters = [];
					aFilters.push(new sap.ui.model.Filter("FullName",sap.ui.model.FilterOperator.Contains, UsuarioEscrito.toUpperCase()));
					
					EncuestasModel.read(url, {
					//actionModel.read("/ZGRCAUD_CV_ACTRELTOFIND(p_find=guid'" + this.findingKey + "')/Set", {
					    filters: aFilters,
						success: function (data, response) {
							
							/*data.results.sort(function(a, b) {
								  if (a.UserId < b.UserId) {
								    return 1;
								  }
								  if (a.UserId > b.UserId) {
								    return -1;
								  }
								  return 0;
								});*/
			
							if (data && data.results && data.results.length > 0) {				
								that.sModelData.EncuestasData = data.results;
								that.tableContentModel.refresh();																											
							} else {
								console.log({ err: "No results" });
							}
							that.oValueHelpDialog.setBusy(false);
						},
						failed: function (oData, response) {
							that.oValueHelpDialog.setBusy(false);
							alert("Failed to get InputHelpValues from service!");
						},
					});
				}
			});
		   
		   if (oFilterBar.setBasicSearch) {
				this.oBasicSearch = new sap.m.SearchField({
					id: "basicSearch",
					width: "100%",
					showSearchButton: sap.ui.Device.system.phone,
					//placeholder: this.getView().getModel("i18n").getResourceBundle().getText("labelSearchFindingPlaceHolder"),
					placeholder: "Buscar Usuarios",
					search: function() {
						oController.oValueHelpDialog.getFilterBar().search();
					}
				});
				oFilterBar.setBasicSearch(this.oBasicSearch);
			}
		   
		   //Abertura del dialogo
		   	this.oValueHelpDialog.setFilterBar(oFilterBar);
			this.oValueHelpDialog.setTable(this.addEncuestasSmartTable);
			this.oValueHelpDialog.setModel(this.tableContentModel);
			oSource.addDependent(this.oValueHelpDialog);
			this.oValueHelpDialog.open();
			//DESCOMENTAR DESPUES PARA CLASIFICACION IE CUANDO EXITEN LAS FUNCIONES
			//this.oValueHelpDialog.setBusy(true);
		   
	  },
	  
	  //FUNCION DE GUARDADO DE USUARIOS EN LA TABLA
	  onSave_Encuestas: function()
	  {
		  var that = this;
		  var auditKey = sap.ui.getCore().getModel("auditKeyModel").getData().id;		  
		  var encuestasModel = new sap.ui.model.odata.ODataModel(
				  "/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
			  );
		  var itemsTabla = this.tableEncuestas.getItems();		  
		  var aBatchOperations = [];
			
			for(var i = 0; i < itemsTabla.length; i++)
			{
				if(itemsTabla[i].getCells()[5].getText() === "")
				{
					var objeto = {};
					objeto.db_key = auditKey;
					objeto.parent_key = auditKey;
					objeto.user_id = itemsTabla[i].getCells()[0].getText();
					objeto.Full_Name = itemsTabla[i].getCells()[1].getText();
					objeto.Email = itemsTabla[i].getCells()[2].getText();
					objeto.langu = itemsTabla[i].getCells()[3].getSelectedKey();
					
					encuestasModel.create("/ZGRCAUD_CV_Survey", objeto, {
							method: "POST",
							success : function (oData) {
								MessageUtil.showMsg("msgTypeSuccessful", this.getView().getModel("i18n").getResourceBundle().getText("msgGuardadoUsuario"));
					       }.bind(this),
					       error: function (oError) {
					    	   that._oDataError(oError);
					       }.bind(this)
						});
				}
				else{
					var objeto = {};
					objeto.db_key = itemsTabla[i].getCells()[5].getText();
					objeto.parent_key = auditKey;
					objeto.user_id = itemsTabla[i].getCells()[0].getText();
					objeto.Full_Name = itemsTabla[i].getCells()[1].getText();
					objeto.Email = itemsTabla[i].getCells()[2].getText();
					objeto.langu = itemsTabla[i].getCells()[3].getSelectedKey();
					
					encuestasModel.update("/ZGRCAUD_CV_Survey(guid'"+auditKey+"')", objeto, {
							//async: true,
							method: "POST",
							success : function (oData) {
								MessageUtil.showMsg("msgTypeSuccessful", this.getView().getModel("i18n").getResourceBundle().getText("msgGuardadoUsuario"));
				       }.bind(this),
					       error: function (oError) {
					    	   that._oDataError(oError);
					       }.bind(this)
						});
				}
			}
			//MessageUtil.showMsg("msgTypeSuccessful", this.getView().getModel("i18n").getResourceBundle().getText("msgGuardadoUsuario"));
			this.getDataFromOdata();
			this.getDataNA();

	  },

	  
	  //FUNCION DE BORRADO DE USUARIOS EN LA TABLA
	  onDel_Encuestas: function(oEvent)
	  {
		  var that = this;
		  
		  //Realizar llamada al back para obtener el listado de encuestas
		  var encuestasModel = new sap.ui.model.odata.v2.ODataModel(
			  "/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
		  );
		  
		  var id = oEvent.getParameters().id;
		  var numTabla = id.substr(id.length - 1);
		  var itemsTabla = this.tableEncuestas.getItems();
		  var userKey = itemsTabla[numTabla].getCells()[5].getText();
		  
		  var url = "/ZGRCAUD_CV_Survey(guid'"+userKey+"')";
		  
		  encuestasModel.remove(url, {
			  success : function () {					
					//Refrescamos tabla principal de Encuestas
					that.getDataFromOdata();
					MessageUtil.showMsg("msgTypeSuccessful", that.getView().getModel("i18n").getResourceBundle().getText("msgBorradoUsuario"));
		       },
		       error: function (oError) {
		    	   that._oDataError(oError);
		       }.bind(this),
				failed: function (oData, response) {
					alert("Failed to get InputHelpValues from service!");
				},
			});
		  
	  },
	  
	//FUNCION DE GUARDADO NA
	  onSaveNA: function(oEvent)
	  {
		  var that = this;
		  
		  var sauditKey = sap.ui.getCore().getModel("auditKeyModel").getData().id;
		  var dbKey = this.dbKey.getText();
		  //Realizar llamada al back para obtener el listado de encuestas
		  var encuestasModel = new sap.ui.model.odata.v2.ODataModel(
			  "/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
		  );

		  if(dbKey === "")
		  {
			  var objeto = {};
				//objeto.DBkey = sauditKey;
				objeto.HostKey = sauditKey;
				objeto.Text = this.textAreaNAA.getValue();
				objeto.Type = "SURVEYNOTE";
				
				encuestasModel.create("/ZGRCAUD_CV_SurveyNote", objeto, {
					//async: true,
					method: "POST",
					success : function (oData) {
						that.getDataFromOdata();
						that.getDataNA();
						MessageUtil.showMsg("msgTypeSuccessful", this.getView().getModel("i18n").getResourceBundle().getText("msgComentarioGuardado"));
			       }.bind(this),
			       error: function (oError) {
			    	  that._oDataError(oError);
			       }.bind(this)
				});
		  }else //Edicion Comentario
		  {
			  var objeto = {};
				objeto.DBKey = dbKey;
				objeto.HostKey = sauditKey;
				objeto.Text = this.textAreaNAA.getValue();
				objeto.Type = "SURVEYNOTE";
				
				//encuestasModel.update("/ZGRCAUD_CV_SurveyNote", objeto, {
				encuestasModel.update("/ZGRCAUD_CV_SurveyNote(DBKey=guid'"+dbKey+"')", objeto, {
					//async: true,
					method: "POST",
					success : function (oData) {
						that.getDataFromOdata();
						that.getDataNA();
						MessageUtil.showMsg("msgTypeSuccessful", this.getView().getModel("i18n").getResourceBundle().getText("msgComentarioEditado"));
			       }.bind(this),
			       error: function (oError) {
			    	   that._oDataError(oError);
			       }.bind(this)
				});
		  }
		  
	  },
	  
	  //FUNCION DE BORRADO NA
	  onDeleteNA: function(oEvent)
	  {
		  var that = this;

		  var dbKey = this.dbKey.getText();
		  //Realizar llamada al back para obtener el listado de encuestas
		  var encuestasModel = new sap.ui.model.odata.v2.ODataModel(
			  "/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
		  );

			encuestasModel.remove("/ZGRCAUD_CV_SurveyNote(guid'"+dbKey+"')", {
					success : function (oData) {
						that.getDataFromOdata();
						that.getDataNA();
						MessageUtil.showMsg("msgTypeSuccessful", this.getView().getModel("i18n").getResourceBundle().getText("msgComentarioBorrado"));
			       }.bind(this),
			       error: function (oError) {
			    	   that._oDataError(oError);
			       }.bind(this)
				});
		  
	  },
	  
	  //VISIBLIDAD DE CAMPOS
	  onNA_Encuestas: function(oEvent){
		  
		  if(oEvent === "") this.tableEncuestas.setVisible(false);

		  if(this.tableEncuestas.getVisible() === true || oEvent === "activoNA")
		  {
			  this.chk_NaEncuestasTextArea.setVisible(true);
			  this.chk_NaEncuestasTextArea.setSelected(true);
			  this.textAreaNAA.setVisible(true);
			  this.btn_NaSave.setVisible(true);
			  this.tableEncuestas.setVisible(false);
			  this.btn_NaDel.setVisible(true);
		  }
		  else
		  {
			  this.textAreaNAA.setVisible(false);
			  this.chk_NaEncuestasTextArea.setVisible(false);
			  this.tableEncuestas.setVisible(true);
			  this.chk_NaEncuestas.setSelected(false);
			  this.btn_NaSave.setVisible(false);
			  this.btn_NaDel.setVisible(false);
		  }
			  
	  },

	//FUNCIÓN DE REFRESCO DE DATOS LA TABLA PRINCIPAL
		getDataFromOdata:function(){
			
			var that = this;
			var oData = {},
				aBatchOperations = [];										
			
			var sauditKey = sap.ui.getCore().getModel("auditKeyModel").getData().id
			var url = "/GRCAUD_CV_Audit(guid'"+sauditKey+"')/to_Survey";
			
			//Realizar llamada al back para obtener el listado de encuestas
			var encuestasModel = new sap.ui.model.odata.v2.ODataModel(
					"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
				);
			
			encuestasModel.read(url, {
				success: function (data, response) {
					data.results.sort((a,b) =>b.crea_date_time - a.crea_date_time);
					if(that.tableEncuestas){
					that.tableEncuestas.removeSelections();
				}
				
						if(that.modelEncuestas) {
							that.modelEncuestas.setData(data.results);
							that.tableEncuestas.setModel(that.modelEncuestas,"encuestas");
							that.modelEncuestas.refresh();
						}
						that.editData = [];
						var modelTitleEncuestas = {};
						that.editData = [];														      			      		
		      			modelTitleEncuestas.title = that.getOwnerComponent().getModel("i18n").getResourceBundle().getText("encuestasSectionTitle");
	 					that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(modelTitleEncuestas), "encuestasTitle");
		      			that.getOwnerComponent().getModel("encuestasTitle").refresh();
		      			that.tableEncuestas.setBusy(false);
		      			
		      			//Volvemos a revisar la visibilidad de los botones e integrantes de la tabla
		      			that.onVisiblidadBotones();
						
				},
				failed: function (oData, response) {
					alert("Failed to get InputHelpValues from service!");
				},
			});
		},
		
		//FUNCIÓN DE REFRESCO DE DATOS ZONA COMENTARIOS
		getDataNA: function()
		{
			var that = this;
			var oData = {},
				aBatchOperations = [];										
			
			var sauditKey = sap.ui.getCore().getModel("auditKeyModel").getData().id
			var url = "/GRCAUD_CV_Audit(guid'"+sauditKey+"')/to_SurveyNote";
			
			//Realizar llamada al back para obtener el listado de encuestas
			var encuestasModel = new sap.ui.model.odata.v2.ODataModel(
					"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
				);
			
			encuestasModel.read(url, {
				success: function (data, response) {
					
					if(data.results[0])
					{
						that.textAreaNAA.setValue(data.results[0].Text);
						that.dbKey.setText(data.results[0].DBKey);
					}else
					{
						that.textAreaNAA.setValue("");
						that.dbKey.setText("");
					}
					
					/*if(data.results[0] && data.results[0].Text !== "")
					{
						that.onNA_Encuestas("activoNA");
					}*/
					let activo = (data.results[0] && data.results[0].Text !== "") ? "activoNA" : "";
					that.onNA_Encuestas(activo);
					
				}
			})
		},
		
		//FUNCION DE VISIBILIDAD PARA LOS BOTONES
		onVisiblidadBotones: function(){
			var itemsTabla = this.tableEncuestas.getItems();
			var createEnabled,deleteEnabled;
			var that = this;
			var dbKey = sap.ui.getCore().getModel("auditKeyModel").getData().id;
			var sPath = "/GRCAUD_CV_ApproveAuditReport(guid'"+dbKey+"')/to_MenuItems";
			this.getOwnerComponent().getModel().read(sPath, {
			success: function (data, response) {
		
					var elements = []; 
					elements = data.results.filter( item => item.SectionID == 'SURVEY');
					
					if (elements !== undefined & elements.length > 0) {
						Array.prototype.forEach.call(elements, item=>{
							if(item.Action === 'CRE_USER_SURVEY_TO_AUDIT_ASMNT'){
								
									createEnabled = item.Enable;																
								
							}else if(item.Action === 'DEL_USER_SURVEY_TO_AUDIT_ASMNT'){
								deleteEnabled = item.Enable;
							}													
						});													
					}
					
					if(that.btn_addEncuestas){					
						if( createEnabled == "X"){
							that.btn_addEncuestas.setVisible(true);
							that.btn_addEncuestas.setEnabled(true);
							that.btn_SaveEncuestas.setVisible(true);
							that.btn_SaveEncuestas.setEnabled(true);
							that.textAreaNAA.setEnabled(true);
							that.btn_NaSave.setEnabled(true);
							that.btn_NaDel.setEnabled(true);
							that.chk_NaEncuestasTextArea.setEnabled(true);
							that.chk_NaEncuestas.setEnabled(true);
							for(var i = 0; i < that.tableEncuestas.getItems().length; i++)
							{
								if(that.tableEncuestas.getItems()[i] && that.tableEncuestas.getItems()[i] !== undefined)
								{
									that.tableEncuestas.getItems()[i].getCells()[3].setEnabled(true);
								}
							}
						}else{
							that.btn_addEncuestas.setVisible(false);
							that.btn_addEncuestas.setEnabled(false);
							that.btn_SaveEncuestas.setVisible(false);
							that.btn_SaveEncuestas.setEnabled(false);
							that.textAreaNAA.setEnabled(false);
							that.btn_NaSave.setEnabled(false);
							that.btn_NaDel.setEnabled(false);
							that.chk_NaEncuestasTextArea.setEnabled(false);
							that.chk_NaEncuestas.setEnabled(false);
							for(var i = 0; i < that.tableEncuestas.getItems().length; i++)
							{
								if(that.tableEncuestas.getItems()[i] && that.tableEncuestas.getItems()[i] !== undefined)
								{
									that.tableEncuestas.getItems()[i].getCells()[3].setEnabled(false);
								}
							}
							
						};
						
						if( deleteEnabled == "X"){
							if(that.getView().byId("colEncuestasDel"))
								that.getView().byId("colEncuestasDel").setVisible(true);
						}else{
							if(that.getView().byId("colEncuestasDel"))
								that.getView().byId("colEncuestasDel").setVisible(false);
						};
					};

			},
			failed: function (oData, response) {
				that.tableEncuestas.setBusy(false)
			}
		
		});
	},
	
	//Funcion de error
	_oDataError: function (oError, fFunction) {
		var message, data;

		try {
			// lo formateamos a JSON
			data = $.parseJSON(oError.responseText);
			message = "";

			// obtengo el nombre del servicio
			// if(data.error.innererror.application) {  /*JPM*/
			// 	service = data.error.innererror.application.service_id;  /*JPM*/
			// }  /*JPM*/
			// obtengo el mensaje de error
			if (data.error.innererror.errordetails && data.error.innererror.errordetails.length > 0) {
				for (var i = 0; i < data.error.innererror.errordetails.length; i++) {
					if (data.error.innererror.errordetails[i].code !== "/IWBEP/CX_SD_GEN_DPC_BUSINS") {
						// message += data.error.innererror.errordetails[i].code + " - " + data.error.innererror.errordetails[i].message + "\n";  /*JPM*/
						message += data.error.innererror.errordetails[i].message + "\n";
					}
				}
			} else {
				message += data.error.message.value;
			}
		} catch (err) {
			// si el formateo a JSON falla, lo intentamos formatear a XML
			data = $.parseXML(oError.responseText);
			var $xml = $(data);
			var $message = $xml.find("innererror").find("message");
			if (!$message.text()) {
				$message = $xml.find("message");
			}
			//var $service = $xml.find( "service_id" ); /*JPM*/
			message = $message.text();
			//service = $service.text(); /*JPM*/
		}

		// quitamos el busy de espera
		if (this.getView()) {
			this.getView().setBusy(false);
		}

		// Mostramos el mensaje de error por pantalla
		MessageBox.alert(message, {
			icon: MessageBox.Icon.ERROR,
			/*title: "Error on service " + service,*/
			title: "Error",
			/*JPM*/
			onClose: function () {
				// si existe se ejecuta la funcion pasada como parametro
				if (fFunction) {
					fFunction();
				}
			}
		});
	},
  
  });
  })