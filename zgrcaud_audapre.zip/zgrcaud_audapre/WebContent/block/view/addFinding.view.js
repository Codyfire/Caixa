jQuery.sap.registerModulePath("grcaud.resources.js.enhancements.findRel",
		oShell.getUI5Path()+"grcaud/resources/js/enhancements/findRel");
//jQuery.sap.require("grcaud.resources.js.enhancements.findRel.Component");

sap.ui.jsview("resources.js.enhancements.findRel.addFindRel", {
	
	 /**
//     * Specifies the Controller belonging to this View. In the case that it is
//     * not implemented, or that "null" is returned, this View does not have a
//     * Controller.
//     * 
//     * @memberOf grcaud.finding.list
//     */
    getControllerName : function() {
        return "resources.js.enhancements.findRel.addFindRel";
    },
    
    onBeforeShow: function (oEvent){
    	this.getController().onBeforeShow(oEvent);
    },
    
    createContent : function(oController) {
    	var oBundle;
        
        if (sap.hpa.grcaud && sap.hpa.grcaud.oBundle) {
        	oBundle = sap.hpa.grcaud.oBundle;
        }
        else {
        	var sBundleURL = sap.hpa.grcaud.Utility.getUI5Path() + "grcaud/resources/i18n/i18n.properties";
    		var sLocale = sap.ui.getCore().getConfiguration().getLanguage();
        	oBundle = jQuery.sap.resources({
    			url : sBundleURL,
    			locale : sLocale
    		});	
        }
        
        //Encabezado con botón hacia atrás
    	
        this.programPage = new sap.m.Page({
			id : this.createId("program_page"),
			title : sap.hpa.grcaud.enh_oBundle.getText("FIND_ADD_TITLE"),
			showHeader : true,
			showNavButton : true,
			content : [],
			navButtonPress : [ oController.pressNavBack, oController ],
			footer : new sap.m.Bar({
                contentRight : [
                    new sap.m.Button({
                        text : sap.hpa.grcaud.oBundle.getText("BTN_OK"),
                        tooltip : sap.hpa.grcaud.oBundle.getText("BTN_OK"),
                        press : [ oController.handleOKBtnPress,
                                oController ]
                    }),
                    new sap.m.Button({
                        text : sap.hpa.grcaud.oBundle.getText("BTN_CANCEL"),
                        tooltip : sap.hpa.grcaud.oBundle.getText("BTN_CANCEL"),
                        press : [ oController.handleCancelBtnPress,
                                oController ]
                    }) ]
				})
		});
        
        //barra de busqueda
        var searchField = new sap.m.SearchField({search:[ oController.filterModel, oController]});
        
        //tabla
        this.oLabelFindingTableHeader = new sap.m.Label({
        	text:sap.hpa.grcaud.enh_oBundle.getText("FIND_ADD_TITLE")
        });
        
        var oTable = new sap.m.Table("addFindRelTable", {
        	mode: sap.m.ListMode.MultiSelect,
            growing : false,
            growingThreshold : 2,
            inset : false,
            growingScrollToLoad : false,
//            headerToolbar:new sap.m.Toolbar({
//    			content:[
//    			  //this.oLabelFindingTableHeader,
//    			  new sap.m.ToolbarSpacer()
//    			  //,this.oButtonAdd
//    			  //,this.oButtonEdit
//    			  //,this.oButtonSave
//    			  //,this.oButtonCancel
//    			         ]
//    		}),
            columns : [ new sap.m.Column({
                header : new sap.m.Label({
                    text : oBundle.getText("COL_FINDING_ID")
                    })
            }), 
            new sap.m.Column({
                header : new sap.m.Label({
                    text : oBundle.getText("COL_TITLE")
                })
            }), 
            new sap.m.Column({
                header : new sap.m.Label({
                    text : oBundle.getText("COL_TYPE")
                })
            }), 
            new sap.m.Column({
                header : new sap.m.Label({
                    text : oBundle.getText("COL_RANKING")
                })
            }),
            new sap.m.Column({
            	visible : false
            })
           
            ],
            updateFinished:[oController._updateTableHeader,oController],
            
            noDataText: sap.hpa.grcaud.oBundle.getText("MSG_NO_FINDINGS")
        });
        
        //PENDIENTE DEFINIR BIEN EL BINDEO A LA ESTRUCTURA CORRECTA
        oTable.bindItems({
			 //path:   "Findings",
       	 path: "/FindingsData",
			 factory :jQuery.proxy(this._setTemplate,this),
			 sorter:[new sap.ui.model.Sorter("ID",false,false)]
			 });
       //return oTable;
        
//        //insertar en el contenido
        this.programPage.addContent(searchField);
        this.programPage.addContent(oTable);
        
        return this.programPage;
    },
    
    /*display mode template*/
	_displayTemplate:function(sId, oContext){
		var oController = this.getController();
		var sItem = new sap.m.ColumnListItem({
			//visible: oContext.getProperty("Visible"),
			visible: true,
			cells:[
   		        new sap.m.Text({
                    text : "{Id}"
                }), 
				new sap.m.Text({
                    text : "{Title}"
                }),
				new sap.m.Text({
                    text : "{TypeDescr}"
                }), 
                new sap.m.Text({
                    text : "{RankingDescr}"
                })
	        ]
		});
		//sItem.setType(sap.m.ListType.Navigation);
		//sItem.attachPress(this.getController()._findingClicked, this.getController());
		return sItem;
	},
	
	/**
	 * jQuery factory function for template select
	 * **/
	_setTemplate : function(sId, oContext) {
		var oController = this.getController();
		var oTemplate = null;
		if(oController.controlMode === oController.mode.oEdit){
			oTemplate = this._editTemplate(sId, oContext);
		}
		else{
			oTemplate = this._displayTemplate(sId, oContext);
		}
		return oTemplate;
	},
	
	/*edit mode template*/
	_editTemplate:function(sId, oContext){
		var oController = this.getController();
		var sItem = new sap.m.ColumnListItem({
			//visible: oContext.getProperty("Visible"),
			visible: true,
	        vAlign: sap.ui.core.VerticalAlign.Middle,
			cells:[
   		        new sap.m.Text({
                          text : "{ID}"
                    }),                   
                    new sap.m.Text({
                          text : "{Title}"
                    }), 
      				new sap.m.Input({
    					type:sap.m.InputType.Number,
    					maxLength:5,
    					//value:oContext.getProperty("Seq"),
    					value: this._formatFindingSeq(oContext.getProperty("Seq")),
    					editable: (oContext.getProperty("Status") === "")? true:false,
    					liveChange:[oController.editFindingSeq,oController]
    				}),                      
                    new sap.m.Text({
                          text : "{TypeDescription}",
                    }), new sap.m.Text({
                          text : "{CategoryDescription}",
                          textAlign: sap.ui.core.TextAlign.Center
                    }), new sap.m.Text({
                          text : "{RankingDescription}",
                          textAlign: sap.ui.core.TextAlign.Center
                    }), new sap.m.Text({
                    	  text : "{StatusDescription}",
                    	  textAlign : sap.ui.core.TextAlign.Center
                    }), new sap.m.Text({
                    	  //width: "1em",
                          text : "{ActionCount}",
                          textAlign: sap.ui.core.TextAlign.Center
                    }),
 		       new sap.ui.core.Icon({
					src : sap.hpa.grcaud.constant.UIConfig.IconOfDelete,
					decorative: false,
					color:sap.hpa.grcaud.constant.UIConfig.IconColorRed,
					size:sap.hpa.grcaud.constant.UIConfig.IconSize,
					tooltip:sap.hpa.grcaud.oBundle.getText("ACTION_DELETE_SCOPE"),
					visible: (oContext.getProperty("Status") === "")? true:false,
					press:[this.getController()._deleteFindingClick,  this.getController()]
 		      
				})
   		        ]
		});
		return sItem;
	},	
	
	_destroyDuplicate:function(id){
		if (this.byId(id)) {
			this.byId(id).destroy();
		}
		return;
	},
	
	_formatFindingSeq: function(_sFindingSeq) {
		var sResult = "",
			sFindingSeq = _sFindingSeq + "";
		if (sFindingSeq) {
			while(sFindingSeq.length < 5) {
				sFindingSeq = '0' +  sFindingSeq;
			}
			sResult = sFindingSeq;
		}
		return sResult;
	}
	
});