/*
 * Copyright (C) 2009-2020 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
	"sap/grc/acs/aud/audit/controller/Create.controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/grc/acs/aud/audit/model/formatter",
	"sap/grc/acs/lib/aud/extension/utils/FieldExtensibilityUtil",
	"sap/grc/acs/lib/aud/utils/CommonUtil",
	"sap/grc/acs/lib/aud/utils/MessageUtil"
], function (
	BaseController,
	JSONModel, 
	History,
	formatter,
	FieldExtensibilityUtil,
	CommonUtil,
	MessageUtil) {
	"use strict";

	return BaseController.extend("sap.grc.acs.aud.audit.initiate.extended.controller.Create", {

		_decimalFormatMapping: {
			" ": {
				decimalSeparator: ",",
				groupingSeparator: "."
			},
			X: {
				decimalSeparator: ".",
				groupingSeparator: ","
			},
			Y: {
				decimalSeparator: ",",
				groupingSeparator: " "
			}
		},
		

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf src.sap.grc.acs.aud.audit.view.Create
		 */
		onInit: function () {
			 this.oEnhancements = {};

			/*** INI UPGRADE 12/05/2021 
			 * Constantes utilizadas para enhancements
			 ***/
			 this.oEnhancements.constants = {
			    con : {
			      portal : "/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/",
			      enh : "/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",
			      std : "/sap/opu/odata/sap/GRCAUD_SRV/"
			    },
			    Aum0028 : {
			      Employee : "Empleados",
			      Client : "Clientes",
			      Center: "Centros",
			      empTable : {
			        Employee : "Empleado",
			        Resolution : "Resolución"
			      },
			      clieTable: {
			        Name: "Nombre",			        
			        Nif:"NIF/CIF",			        
			        Participation : "Participación"
			      },
			      centerTable: {
			        Id: "SAP ID",
			        Title: "Título",
			        Center: "Centro"
			      }
			    },
			    Aum0002 : {
			      auditGroup : "09423", // Territoriales
			      auditGroup2 : "16581", // Fraude
			      company : "A001",
			      zfield : "zz_report_id",
			      auditType: "VO" // Visita Oficina
			    },
			    Aum0010 : {
			      deptUrl : "/InfoDepAuditSet",			    
			      grpUrl : "/GRCAUD_CV_AuditGroup"      			     
			    },
			    Aum0011 : {
			      temasUrl : "/InfoThemesSet",
			      createTemas : "/ActionSet",
			      getTemas : "/ActionSet",
			      getAssignaments : "/ActionSet",
			      deleteTema : "/AssignmentSet"
			    }
			};
			/*** FIN UPGRADE 12/05/2021 
			 ***/

			if (this.getRouter() && this.getRouter().getRoute("create")) {
				this.getRouter().getRoute("create").attachPatternMatched(this._onRoutePatterMatched, this);
			}

			this.isFromAuditPlan = false;

			var oViewModel = new sap.ui.model.json.JSONModel({
				title: "",
				isFromAuditPlan: this.isFromAuditPlan
			});
			this.setModel(oViewModel, "viewModel");

			var oExtensionModel = new sap.ui.model.json.JSONModel();
			this.setModel(oExtensionModel, "extensionModel");
			/**
			 * INI UPGRADE Condicionar campos grupo auditoria con departamento -  12/05/2021
			 * old
			 * this.aTextTypedField = ["Title", "Type", "AuditGroup", "Category", "Country", "Company", "Scope"];
			 * new
			 * Se incluye el campo zz_department para que lo valide   
			 **/
			
			this.aTextTypedField = ["Title", "Type", "AuditGroup", "Category", "Country", "Company", "Scope", "zz_department"];
			
			this.aFloatTypedField = ["EstimatedEffort", "EstimatedCost"];

			this.getView().byId("inputTag").addValidator(this._validateTag.bind(this));
			sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.audit.EventBus", "createExtensionFieldRefresh", this._createExtensionGroup,
				this);
		},
		
		
		/**
		 * INI UPGRADE Condicionar campos grupo auditoria con departamento -  12/05/2021
		 **/
		getDepartmentDesc : function(deptValue) {
		  var value = "";

		  if(deptValue)
		  {
		    if(deptValue != "") {
		      // Cargamos los grupos de Backend
		      var conModel = new sap.ui.model.odata.ODataModel('ZGRCAUD_PORTAL_SRV', false);
		      conModel.read( this.oEnhancements.constants.Aum0010.deptUrl, {
		        async: false,
		        success : function (oData, oDataResp) {
		          var obj = $.grep(oData.results, function(n,i){
		            if(n.AuditDepartment == deptValue) {
		              return n
		            }
		          });
		          if(obj.length > 0)
		        	  value =  obj[0].Text; 
		           }.bind(this),
		           error: function (oError) {
		             
		           }.bind(this)
		      });
		    }
		  }
		    
		  return value;
		},

		// Método que obtiene los departamentos 
		getDepartments : function(oDataModel) {
						
			// Se informa el filtro para que muestre sólo los activos
			var aFilters = [];
			 aFilters.push(new sap.ui.model.Filter("Active",sap.ui.model.FilterOperator.EQ, true));			
			 var oSelect = this.getView().byId('inputzz_department');
	    	  oSelect.setBusy(true); 
		      // Cargamos los grupos de Backend
			 
		    var conModel = new sap.ui.model.odata.ODataModel(this.oEnhancements.constants.con.portal, false);
		    conModel.read(this.oEnhancements.constants.Aum0010.deptUrl, {

		    	// Se añade el filtro para que muestre sólo los activos en la llamada
		    	filters : aFilters,		    	 
		      async: false,
		      success : function (oData, oDataResp) {

		    	  var oModelDepartment = new sap.ui.model.json.JSONModel();
		    	   oModelDepartment.setData(oData.results);		    	   
		    	  this.getView().setModel( oModelDepartment,'oModelZdept');
		    	  
		    	  var oTemplate = new sap.ui.core.ListItem(
			               {
			                	text : "{Text}",
			                    key : "{AuditDepartment}"

			               });

		    	  
		    	  
			             oSelect.setModel(oModelDepartment);
			             oSelect.bindItems("/",oTemplate);
			             oSelect.setBusy(false);		            

		    	  
		         }.bind(this),
		         error: function (oError) {
		           oSelect.setBusy(false);
		         }.bind(this)
		    });

		},

		//  Método que setea el grupo según el departamento
		setDepartmentGroup : function(oController, oSelect, sValue, selVaue) {
			var that = this;
		  if(sValue) {
			  var oSelect = this.getView().byId('inputAuditGroup');
			  oSelect.setBusy(true);
	
				//PRL01092021 Cambiar la llamada para filtrar grupos			
			    //var oDataModel = new sap.ui.model.odata.ODataModel(this.oEnhancements.constants.con.std, false);
				
			    //oDataModel.read( this.oEnhancements.constants.Aum0010.grpUrl, undefined,undefined,true,		    
	        var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/", false);
			    oDataModel.read( "/InfoGroupActiveSet", undefined,undefined,true,	
	//PRL01092021	
		 				
			 
		        jQuery.proxy(
		            function(oData,response) {

		            	var aFilters = [];    
		            	oData.results.forEach(function(value){
			            	if( value.AuditGroup.indexOf(sValue) !== -1 ) 
				            	aFilters.push(new sap.ui.model.Filter({ path: "AuditGroup", operator: sap.ui.model.FilterOperator.EQ,value1: value.AuditGroup})) ;
				            });
	                	   
	               	var oBinding = oSelect.getBinding('items');
	               oBinding.filter(aFilters);
			       oSelect.setBusy(false);	
			       
		            }, this), 
		            function() { oSelect.setBusy(false);
		        });
		  }
		},
		// Se condiciona el grupo al seleccionar el departamento
		onSelectZdeptChange:function(oEvent) {
			var sDept = oEvent.getSource().setSelectedKey(oEvent.getParameter("selectedItem").getKey());
			this.setDepartmentGroup(this,oEvent.getSource(),oEvent.getParameter("selectedItem").getKey());
		},
		
		// Evento que se propaga cuando se selecciona un grupo
		onSelectZGroup : function(oEvent){
			if(oEvent.getParameter("selectedItem") !== null){

			oEvent.getSource().setBusy(true);

			oEvent.getSource().setSelectedItem( oEvent.getParameter("selectedItem"),false).attachChange(this._liveChanged, this);	
			oEvent.getSource().setBusy(false);
			}
			 if( !this.getView().byId("inputCompany").getValue() == "" || !this.getView().byId("inputCompany").getValue() == undefined)
	              this.toggleReportIdEnable(this, this.oEnhancements.constants.Aum0002.zfield, this.oEnhancements.constants.Aum0002.company, this.getView().byId("inputCompany").getValue(),'00',this.getView().byId("inputCompany").getValue(),'',this.getView().byId("inputType").getSelectedKey());

		},
		_liveChanged : function() {
            this.uiChanged = true;
          },
          
          //Numeración, notas, título y conclusiones del informe 
          toggleReportIdEnable : function(oController, sField, sValue, sCompany, sStatusKey, sAuditType) {

        	    // En estos estados no es necesario realizar nada
        	    if(sStatusKey != undefined) {
        	      var notValidStatus = ["07", "08", "09", "18"];
        	        var status = $.grep(notValidStatus, function(n,i){ if(n == sStatusKey) return n; })
        	        if(status.length > 0) return; 
        	    }

        	  
        	      var enabled = false;

        	      // Tipo Visita Oficina == true -> manual (habilitar)
        	      if (sAuditType.indexOf(this.oEnhancements.constants.Aum0002.auditType) > -1) {
        	        enabled = true;
        	      } else {
        	        if(sCompany) {
        	          if ( sCompany.toUpperCase() === sValue ) //  Sociedad A001 == true -> automatica (deshabilitar)
        	          {
        	            enabled = false; 

        	          } else { // ELSE -> manual (habilitar)
        	            enabled = true;
        	          }
        	        }
        	      }

        	      if(oController.getView().byId('smartForm') != undefined) {
        	    	  var formContainers = oController.getView().byId('smartForm').getAggregation('content').getAggregation('formContainers');
        	              
        	          if(formContainers) {
        	          $.each(formContainers,function(i,n) {
        	            var elements = n.getFormElements();
        	           $.each(elements, function(j,m){
        	             var fields = m.getFields();
        	             $.each(fields, function(k,l){
        	               if(l.sId.indexOf(sField) != -1){
        	                 if(enabled) {
        	                   l.setEnabled(true);
        	                 } else {
        	                   l.setEnabled(false);
        	                   if (sStatusKey == undefined || sStatusKey == null || sStatusKey == "00" )
        	                   {
        	                     l.setValue("");
        	                   }
        	                 }
        	               }
        	             });
        	           }); 
        	          });
        	        }
        	      } else {
        	        if(enabled) {
        	          sap.ui.getCore().byId('cdfAudit__form6ZZ_REPORT_ID').setEnabled(true);
        	       } else {
        	         if (sStatusKey == undefined || sStatusKey == null || sStatusKey == "00" )
        	         {
        	           sap.ui.getCore().byId('cdfAudit__form6ZZ_REPORT_ID').setValue("");
        	         }
        	         sap.ui.getCore().byId('cdfAudit__form6ZZ_REPORT_ID').setEnabled(false);
        	       }

        	      }

        	    //  }
        	},


          
		/**
		 * FIN UPGRADE Condicionar campos grupo auditoria con departamento -  12/05/2021
		 **/
		
		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf src.sap.grc.acs.aud.audit.view.Object
		 */
		onExit: function () {
			sap.ui.getCore().getEventBus().unsubscribe("sap.grc.acs.aud.audit.EventBus", "createExtensionFieldRefresh", this._createExtensionGroup,
				this);
			if (this.getView().getBindingContext()) {
				this._destoryFields();
			}
		},

		onNavBack: function () {
			this._destoryFields();
			this._resetUIState();
			this._clearFieldValueStatus();

			if (this.isFromAuditPlan) {
				sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.auditplan.EventBus", "closeColumn", {
					id: this.getView().getId(),
					objectType: "AuditCreation"
				});
			} else {
				var sPreviousHash = History.getInstance().getPreviousHash(),
					oCrossAppNavigator = this.getOwnerComponent().getCrossAppNavigator();
				if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation() || this.getOwnerComponent().isAppToAppNavigation()) {
					history.go(-1);
				} else {
					this.getRouter().navTo("worklist", {}, true);
				}
			}

		},

		_destoryFields: function () {
			this.getModel().deleteCreatedEntry(this.getView().getBindingContext());
			this.getView().setBindingContext(null);
			var oExtensionGroup = this.getView().byId("extensionGroup");
			oExtensionGroup.destroyGroupElements();
		},

		loadData: function (oData, sTitle) {

			this.getView().byId("ObjectPageLayout").setShowAnchorBar(true);

			this.getView().byId("createAuditPage").setShowHeader(false);

			this.isFromAuditPlan = true;
			this.getModel("viewModel").setData({
				title: sTitle,
				isFromAuditPlan: this.isFromAuditPlan
			});
			this.auditPlanKey = oData.key;
			this.oAuditPlanStartTime = oData.startDate.getTime();
			this.oAuditPlanEndTime = oData.endDate.getTime();

			var aAuditableItems = [];

			for (var i = 0; i < oData.data.length; i++) {
				aAuditableItems.push(oData.data[i].getBindingContext().getProperty());
			}
			var oAuditableItemTable = this.getView().byId("auditableItemsTable");
			oAuditableItemTable.setVisible(true);
			var oModel = new JSONModel(aAuditableItems);
			oAuditableItemTable.setModel(oModel);
			oAuditableItemTable.bindItems("/", oAuditableItemTable.getItems()[0].clone());

			var aReferencyKey = [],
				oAdtblData = oModel.getData(),
				oTableSearchState = [],
				oTableSearchStateFilter = {};
			for (var j = 0; j < oAdtblData.length; j++) {
				if (aReferencyKey.indexOf(oAdtblData[j].ReferenceKey) < 0) {
					aReferencyKey.push(oAdtblData[j].ReferenceKey);
					oTableSearchState.push(new sap.ui.model.Filter("ReferenceKey", sap.ui.model.FilterOperator.EQ, oAdtblData[j].ReferenceKey));
				}
			}

			oTableSearchStateFilter = new sap.ui.model.Filter(oTableSearchState, false);

			this.loadScopedOrgs(oData.key, oTableSearchStateFilter);

			this.loadScopedDims(oData.key, oTableSearchStateFilter);

			this.getModel().metadataLoaded().then(this._bindView.bind(this));
		},

		/**
		 * Binds the view to the create path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'create'
		 * @private
		 */
		_onRoutePatterMatched: function () {
			this.getModel("viewModel").setData({
				title: this.getModel("i18n").getResourceBundle().getText("titCreateAudit"),
				isFromAuditPlan: this.isFromAuditPlan
			});
			if (!this.isNavBackButtonPressHandlerAttached) {
				this.getView().byId("createAuditPage").attachNavButtonPress(this.onNavBack.bind(this));
				this.getView().byId("createAuditPage").setShowNavButton(true);
				this.isNavBackButtonPressHandlerAttached = true;
			}
			this.getModel().metadataLoaded().then(this._bindView.bind(this));
		},

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound
		 * @private
		 */
		_bindView: function () {

			this.bEstimatedFieldError = false;

			this.getView().setBindingContext(null);
			this.getView().setBusy(true);
			this.getModel().setDeferredGroups(["createAudit", "createAuditData"]);
			var oBindingContext = this.getModel().createEntry("GRCAUD_CV_Audit", {
				groupId: "createAuditData"
			});
			this.getView().setBindingContext(oBindingContext);

			this.getModel().read("/GRCAUD_IV_Currency", {
				success: this._setCurrency.bind(this)
			});
			this._createExtensionGroup("", "", {
				auditType: ""
			});
			//se obtienen los departamentos activos
			this.getDepartments(this.getModel());
		},

		_createExtensionGroup: function (sChannel, sEvent, oData) {
			var sIntent = this.getOwnerComponent().getModel("intentConfig").getData().intent,
				oExtensionModel = this.getModel("extensionModel"),
				oMenuItemConfigData = this.getOwnerComponent().getModel("menuItemConfig").getData(),
				sObjectStatus = "00";

			oExtensionModel.setData(
				FieldExtensibilityUtil.getExtensionFieldsStatus("Audit",
					oData.auditType, sObjectStatus, this.getModel().getServiceMetadata(), oMenuItemConfigData, this.getOwnerComponent(), sIntent),
				true);

			var oExtensionGroup = this.getView().byId("extensionGroup");
			FieldExtensibilityUtil.createExtensionGroup("Audit", oExtensionGroup, this.getOwnerComponent(), sap.grc.acs.lib.aud.utils.Constant.Mode
				.CREATE);
			
			// Se oculta el campo CDF departamento y se configura como opcional 	
			var departmentModel = this.getModel("extensionModel").getData().zz_department;
			departmentModel.mandatory = false;
			departmentModel.visible = false;
		},

		onAuditTypeSelectionChange: function (oEvent) {
			var sAuditType = oEvent.getParameter("selectedItem").getKey();
			var oAuditType = oEvent.getParameter("selectedItem").getBindingContext().getObject();
			this._setFieldVisibility(oAuditType);
			this.getView().byId("extensionGroup").destroyGroupElements();
			sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.audit.EventBus", "createExtensionFieldRefresh", {
				auditType: sAuditType
			});
		},

		_setFieldVisibility: function (oAuditType) {
			if (oAuditType.CostAssignType === "IO") {
				this.getView().byId("labelInternalOrder").setVisible(true);
				this.getView().byId("inputInternalOrder").setVisible(true);
			} else {
				this.getView().byId("labelInternalOrder").setVisible(false);
				this.getView().byId("inputInternalOrder").setVisible(false);
			}
		},

		_setCurrency: function (oData) {
			for (var counter = 0; counter < oData.results.length; counter++) {
				if (oData.results[counter].application === "AUD") {
					this.getView().byId("inputEstimatedCost").setDescription(oData.results[counter].currency);
					break;
				}
			}
			this.getView().setBusy(false);
		},

		onCreateBtnPress: function () {
			if (this._validateUI()) {

				if (this.oAuditNewData.PlannedStartDate) {
					var oToday = new Date();
					oToday.setHours(0);
					oToday.setMinutes(0);
					oToday.setSeconds(0);
					oToday.setMilliseconds(0);
					oToday.setDate(oToday.getDate() - 1);
					oToday = this._formatEditDateTime(oToday);

					if (oToday.getTime() >= this.oAuditNewData.PlannedStartDate.getTime()) {
						sap.m.MessageBox.warning(this.getModel("i18n").getResourceBundle().getText("MSG_AUDIT_DATE_PAST"), {
							actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
							initialFocus: sap.m.MessageBox.Action.NO,
							onClose: jQuery.proxy(function (sButton) {
								if (sButton === sap.m.MessageBox.Action.YES) {
									this._checkAuditPlanPeriodCover();
								}
							}, this)
						});
						return;
					}
				}
				this._checkAuditPlanPeriodCover();
			}
		},

		onCancelBtnPress: function () {
			this.onNavBack();
		},

		//input validation
		_validateUI: function () {
			this._collectAuditData();
			this._resetUIState();

			this.bFieldIsEmpty = false;
			this.bFieldError = this.bEstimatedFieldError;

			var i = 0;

			for (i = 0; i < this.aTextTypedField.length; i++) {
				this._validateTextTypedField(this.aTextTypedField[i]);
			}

			for (i = 0; i < this.aFloatTypedField.length; i++) {
				this._validateFloatTypedField(this.aFloatTypedField[i]);
			}

			if (this.getView().byId("labelPlanedTimePeriod").getRequired() && (!this.oAuditNewData.PlannedStartDate || !this.oAuditNewData.PlannedEndDate)) {
				this.getView().byId("inputPlanedTimePeriod").setValueState(sap.ui.core.ValueState.Error);
				this.bFieldIsEmpty = true;
			}

			/**
			 * INI UPGRADE 14/05/2021 
			 *  Se comprueba si la sociedad está vacía
			 */
			if (this.getView().byId("inputCompany").getRequired() && !this.oAuditNewData.Company ) {
				this.getView().byId("inputCompany").setValueState(sap.ui.core.ValueState.Error);
				this.bFieldIsEmpty = true;
			}
			
			/**
			 * FIN UPGRADE 14/05/2021 
			 */ 
			
						

			// validate cdf fields
			this.aFields = this.getOwnerComponent().aFields;
			for (i = 0; i < this.aFields.length; i++) {
				var bCDFError = false;
				if (this.aFields[i].isExtensionField) {
					var sExtensionLabelIdPrefix = sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud.utils.Constant.DIALOGID
						.EXTENSION_LABEL;
					var sExtensionInputIdPrefix = sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud.utils.Constant.DIALOGID
						.EXTENSION_INPUT;

					if (sap.ui.getCore().byId(sExtensionInputIdPrefix + this.aFields[i].name).getValueStateText) {

						if (sap.ui.getCore().byId(sExtensionInputIdPrefix + this.aFields[i].name).getValueStateText() && sap.ui.getCore().byId(
								sExtensionInputIdPrefix + this.aFields[i].name).getValueStateText() !== "" && sap.ui.getCore().byId(sExtensionInputIdPrefix +
								this.aFields[i].name).getValueState() === sap.ui.core.ValueState.Error) {
							this.bFieldError = true;
							bCDFError = true;
						}

						if (sap.ui.getCore().byId(sExtensionInputIdPrefix + this.aFields[i].name).setValueStateText() && sap.ui.getCore().byId(
								sExtensionInputIdPrefix + this.aFields[i].name).setValueStateText() !== "" && sap.ui.getCore().byId(sExtensionInputIdPrefix +
								this.aFields[i].name).getValueState() === sap.ui.core.ValueState.Error) {
							this.bFieldError = true;
						}

						if (this._validateRequiredCDF(sExtensionLabelIdPrefix, sExtensionInputIdPrefix, this.aFields[i].name)) {
							this.bFieldIsEmpty = true;
						}

						if (bCDFError) {
							sap.ui.getCore().byId(sExtensionInputIdPrefix + this.aFields[i].name).setValueState(sap.ui.core.ValueState.Error);
						}
					} else {
						if (this._validateRequiredCDF(sExtensionLabelIdPrefix, sExtensionInputIdPrefix, this.aFields[i].name)) {
							this.bFieldIsEmpty = true;
						}
					}
				}
			}

			if (this.bFieldIsEmpty) {
				MessageUtil.showMsg("msgTypeFailed", this.getModel("i18n").getResourceBundle().getText("MSG_REQUIRED_FIELD"));
				return false;
			}
			if (this.bFieldError) {
				MessageUtil.showMsg("msgTypeFailed", this.getModel("i18n").getResourceBundle().getText("MSG_ERROR_NOT_HANDLE"));
				return false;
			}

			return true;
		},

		_validateTextTypedField: function (sFieldName) {
			var sLableId = "label" + sFieldName,
				sInputId = "input" + sFieldName;
			if (this.getView().byId(sLableId).getRequired() && (!this.oAuditNewData[sFieldName] || this.oAuditNewData[sFieldName] === "")) {
				this.getView().byId(sInputId).setValueState(sap.ui.core.ValueState.Error);
				this.bFieldIsEmpty = true;
			}
		},

		_validateFloatTypedField: function (sFieldName) {
			var sLableId = "label" + sFieldName,
				sInputId = "input" + sFieldName;
			if (this.getView().byId(sLableId).getRequired() && !this.oAuditNewData[sFieldName]) {
				this.getView().byId(sInputId).setValueState(sap.ui.core.ValueState.Error);
				this.bFieldIsEmpty = true;
			}
		},

		_validateRequiredCDF: function (sLabelId, sInputId, sFieldName) {
			var bCDFIsEmpty = false;
			if (sap.ui.getCore().byId(sInputId + sFieldName).setValueState) {
				sap.ui.getCore().byId(sInputId + sFieldName).setValueState(sap.ui.core.ValueState.None);
			}
			if (sap.ui.getCore().byId(sLabelId + sFieldName).getRequired() && (!this.oAuditNewData[sFieldName] || this.oAuditNewData[
					sFieldName] === "")) {
				if (sap.ui.getCore().byId(sInputId + sFieldName).setValueState) {
					sap.ui.getCore().byId(sInputId + sFieldName).setValueState(sap.ui.core.ValueState.Error);
				}
				bCDFIsEmpty = true;
			}
			return bCDFIsEmpty;
		},

		_checkAuditPlanPeriodCover: function () {
			if (this.isFromAuditPlan) {
				var oPlanedStatDate = this.getView().byId("inputPlanedTimePeriod").getDateValue().getTime(),
					oPlanedEndDate = this.getView().byId("inputPlanedTimePeriod").getSecondDateValue().getTime();
				var isTimeNotCover = ((this.oAuditPlanStartTime > oPlanedEndDate) || (this.oAuditPlanEndTime < oPlanedStatDate)) ? true : false;
				if (isTimeNotCover) {
					sap.m.MessageBox.warning(this.getModel("i18n").getResourceBundle().getText("MSG_AUDIT_PLAN_DATE_NOT_COVER"), {
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						initialFocus: sap.m.MessageBox.Action.NO,
						onClose: jQuery.proxy(function (sButton) {
							if (sButton === sap.m.MessageBox.Action.YES) {
								this.getView().setBusy(true);
								this._createAudit(this);
							}
						}, this)
					});
					return;
				}
			}
			this.getView().setBusy(true);
			this._createAudit(this);
		},

		_collectAuditData: function () {
			this.oAuditNewData = {};
			this.oAuditNewData.Title = this.getView().byId("inputTitle").getValue();
			this.oAuditNewData.Type = this.getView().byId("inputType").getSelectedKey();
			this.oAuditNewData.AuditGroup = this.getView().byId("inputAuditGroup").getSelectedKey();
			/**
			 * INI UPGRADE 14/05/2021 
			 *  Se añade el campo departamento
			 */ 
			
			this.oAuditNewData.zz_department = this.getView().byId("inputzz_department").getSelectedKey();
			/**
			 * FIN UPGRADE 14/05/2021 
			 *  Se añade el campo departamento
			 */ 
			this.oAuditNewData.Category = this.getView().byId("inputCategory").getSelectedKey();
			this.oAuditNewData.Company = this.getView().byId("inputCompany").getValue();
			this.oAuditNewData.Country = this.getView().byId("inputCountry").getValue();
			this.oAuditNewData.OrderNumber = this.getView().byId("inputInternalOrder").getValue();
			if (this.getView().byId("inputEstimatedEffort").getValue() !== "") {
				this.oAuditNewData.EstimatedEffort = this._formatNumber(this.getView().byId("inputEstimatedEffort").getValue());
			}
			if (this.getView().byId("inputEstimatedCost").getValue() !== "") {
				this.oAuditNewData.EstimatedCost = this._formatNumber(this.getView().byId("inputEstimatedCost").getValue());
			}
			this.oAuditNewData.Currency = this.getView().byId("inputEstimatedCost").getDescription();
			var oPlannedStartDate = this.getView().byId("inputPlanedTimePeriod").getDateValue();
			var oPlannedEndDate = this.getView().byId("inputPlanedTimePeriod").getSecondDateValue();
			if (oPlannedStartDate && oPlannedEndDate) {
				this.oAuditNewData.PlannedStartDate = this._formatEditDateTime(oPlannedStartDate);
				this.oAuditNewData.PlannedEndDate = this._formatEditDateTime(oPlannedEndDate);
			}
			this.oAuditNewData.Scope = this.getView().byId("inputScope").getValue();

			if (this.isFromAuditPlan) {
				this._collectAuditPlanAuditData();
			} else {
				// collect tags
				var aTokens = this.getView().byId("inputTag").getTokens();
				if (aTokens.length > 0) {
					this.aTags = [];
					for (var i = 0; i < aTokens.length; i++) {
						this.aTags.push(aTokens[i].getText());
					}
					this.oAuditNewData.Tags = this.aTags.join(";");
				}
			}

			this._setAuditCDFData();
		},

		_formatEditDateTime: function (oDateTime) {
			var oDate = new Date();
			var iOffset = oDate.getTimezoneOffset();
			return new Date(oDateTime.getTime() - iOffset * 60000);
		},

		_formatNumber: function (sValue) {
			var sFormat = sap.ui.getCore().getConfiguration().getFormatSettings().getLegacyNumberFormat(),
				oFloatFormat;
			if (sFormat) {
				oFloatFormat = this._decimalFormatMapping[sFormat];
			} else {
				oFloatFormat = this._decimalFormatMapping.X;
			}
			var oFloatFormatter = sap.ui.core.format.NumberFormat.getFloatInstance({
				decimalSeparator: oFloatFormat.decimalSeparator,
				groupingSeparator: oFloatFormat.groupingSeparator,
				parseAsString: true
			});
			var sNumberValue = oFloatFormatter.parse(sValue);
			return sNumberValue;
		},

		_collectAuditPlanAuditData: function () {

			var i;

			var auditableItems = this.getView().byId("auditableItemsTable").getModel().getData();
			if (auditableItems.length !== 0) {
				var auditableItem = {};
				this.oAuditNewData.to_AuditableItems = [];
				for (i = 0; i < auditableItems.length; i++) {
					auditableItem = {};
					auditableItem.MasterReference = auditableItems[i].MasterReference;
					this.oAuditNewData.to_AuditableItems.push(auditableItem);
				}
			}

			var scopedOrgItems = this.getView().byId("orgTable").getItems();
			if (scopedOrgItems.length > 0) {
				this.oAuditNewData.to_Organizations = [];
				for (i = 0; i < scopedOrgItems.length; i++) {
					var scopedOrg = {};
					scopedOrg.OrgKey = scopedOrgItems[i].getBindingContext().getProperty("OrganizationKey");
					this.oAuditNewData.to_Organizations.push(scopedOrg);
				}
			}

			var scopedDimItems = this.getView().byId("dimTable").getItems();
			if (scopedDimItems.length > 0) {
				this.oAuditNewData.to_Dimensions = [];
				for (i = 0; i < scopedDimItems.length; i++) {
					var scopedDim = {};
					scopedDim.DimensionKey = scopedDimItems[i].getBindingContext().getProperty("DimensionKey");
					this.oAuditNewData.to_Dimensions.push(scopedDim);
				}
			}

			var tags = this.getView().byId("inputTag").getTokens();
			if (tags.length !== 0) {
				var tag = {};
				this.oAuditNewData.to_Tags = [];
				for (i = 0; i < tags.length; i++) {
					tag = {};
					tag.TagName = tags[i].getKey();
					this.oAuditNewData.to_Tags.push(tag);
				}
			}
		},

		_setAuditCDFData: function () {
			this.aFields = this.getOwnerComponent().aFields;
			var oCDFData = FieldExtensibilityUtil.saveCDFInCreateMode(this.aFields);
			for (var key in oCDFData) {
				this.oAuditNewData[key] = oCDFData[key];
			}
		},

		_createAudit: function () {
			var oDataModel = this.getModel();
			var oData = this.oAuditNewData;
			oData.DBKey = CommonUtil.generateGuid();

			var sAuditPath = "/GRCAUD_CV_Audit";
			if (this.isFromAuditPlan) {
				sAuditPath = "/GRCAUD_CV_AuditByAuditPlan";
				oData.DBKey = this.auditPlanKey;
			}

			oDataModel.create(sAuditPath, oData, {
				groupId: "createAudit"
			});

			oDataModel.submitChanges({
				groupId: "createAudit",
				success: jQuery.proxy(function (oDataNew) {
					oDataModel.setDeferredGroups(oDataModel.getDeferredGroups().concat(["changes"]));
					if (oDataNew.__batchResponses[0].message) {
						this.getView().setBusy(false);
					} else {
						MessageUtil.showMsg("msgTypeSuccessful", this.getModel("i18n").getResourceBundle().getText("MSG_CREATE_AUDIT_SUCCESS"));
						this.getView().setBusy(false);
						oDataModel.refresh();
						this.onCancelBtnPress();
						if (this.isFromAuditPlan) {
							sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.auditplan.EventBus", "refreshAuditList");
							sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.auditplan.EventBus", "refreshGeneralInformation");
						}
					}
				}, this),
				error: jQuery.proxy(function () {
					oDataModel.setDeferredGroups(oDataModel.getDeferredGroups().concat(["changes"]));
					this.getView().setBusy(false);
					MessageUtil.showMsg("msgTypeFailed", this.getModel("i18n").getResourceBundle().getText("MSG_CREATE_AUDIT_FAIL"));
				}, this)
			});
		},

		// Reset field error status
		// estimate cost and effort field status is changed during input
		_resetUIState: function () {
			var oView = this.getView();
			oView.byId("inputTitle").setValueState(sap.ui.core.ValueState.None);
			oView.byId("inputType").setValueState(sap.ui.core.ValueState.None);
			oView.byId("inputAuditGroup").setValueState(sap.ui.core.ValueState.None);
			oView.byId("inputCategory").setValueState(sap.ui.core.ValueState.None);
			oView.byId("inputCountry").setValueState(sap.ui.core.ValueState.None);
			oView.byId("inputCompany").setValueState(sap.ui.core.ValueState.None);
			oView.byId("inputTag").setValueState(sap.ui.core.ValueState.None);
			oView.byId("inputPlanedTimePeriod").setValueState(sap.ui.core.ValueState.None);
			oView.byId("inputScope").setValueState(sap.ui.core.ValueState.None);
			/**
			 * INI UPGRADE Condicionar campos grupo auditoria con departamento -  14/05/2021
			 **/
			//Se limpia el estado del campo departamento
			oView.byId("inputzz_department").setValueState(sap.ui.core.ValueState.None);
			/**
			 * FIN UPGRADE Condicionar campos grupo auditoria con departamento -  14/05/2021
			 **/
		},

		// clear field value and estimate cost and effort field status
		// used during nav back, with _resetUIState
		_clearFieldValueStatus: function () {
			this.getView().byId("inputEstimatedEffort").setValueState(sap.ui.core.ValueState.None);
			this.getView().byId("inputEstimatedCost").setValueState(sap.ui.core.ValueState.None);
			this.getView().byId("inputTag").removeAllTokens();
			this.getView().byId("inputCountry").setDescription("");
			this.getView().byId("inputCompany").setDescription("");
		},

		handleCountryValueHelp: function (oEvent) {
			this.inputId = oEvent.getSource().getId();
			this._openValueHelpDialog("LAND1");
		},

		handleCompanyValueHelp: function (oEvent) {
			this.inputId = oEvent.getSource().getId();
			this._openValueHelpDialog("GRCAUD_COMPANY_CODE");
			
		},

		_openValueHelpDialog: function (sValue) {
			var sItemsBindingPath = "/DataElementSet('" + sValue + "')/NameValuePairs";
			if (this._ValueHelpDialog) {
				this._ValueHelpDialog.destroy();
			}
			this._ValueHelpDialog = new sap.m.SelectDialog({
				title: "{i18n>titSearchDialog}",
				items: {
					path: sItemsBindingPath,
					template: new sap.m.StandardListItem({
						title: "{Name}",
						description: "{Value}"
					})
				},
				growingThreshold: 20,
				search: this.handleSearch.bind(this),
				cancel: this.handleValueHelpClose.bind(this),
				confirm: this.handleValueHelpClose.bind(this)
			});
			this.getView().addDependent(this._ValueHelpDialog);
			this._ValueHelpDialog.open();
		},

		// search in company and country value help dialog
		handleSearch: function (oEvent) {
			var sQuery = oEvent.getParameter("value");
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, sQuery));
			aFilters.push(new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.Contains, sQuery));
			oEvent.getSource().getBinding("items").filter(aFilters, sap.ui.model.FilterType.Application);
		},

		// Triggered when value help dialog of field Company and Coutry close
		handleValueHelpClose: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem");
			if (oSelectedItem) {
				var oInputField = this.getView().byId(this.inputId);
				oInputField.setValue(oSelectedItem.getTitle());
				oInputField.setValueState(sap.ui.core.ValueState.None);
				oInputField.setDescription(oSelectedItem.getDescription());
				
				/**
				 * INI UPGRADE Condicionar campos grupo auditoria con departamento -  14/05/2021
				 **/
				// Cuando se realice el cambio de sociedad, se comprueba el informe
				if(this.inputId.indexOf('inputCompany') != -1) { 
				this.toggleReportIdEnable(this, this.oEnhancements.constants.Aum0002.zfield, this.oEnhancements.constants.Aum0002.company,  oInputField.getValue(), '00', 	this.getView().byId("inputType").getSelectedItem().getKey());
				}
				
				/**
				 * FIN UPGRADE Condicionar campos grupo auditoria con departamento -  14/05/2021
				 **/
			}
			oEvent.getSource().getBinding("items").filter([]);
		},

		// Handler of event suggestionItemSelected of field Country and Company
		onSuggestionItemSelected: function (oEvent) {
			var oSelectedItem = oEvent.getParameter("selectedItem");
			if (oSelectedItem) {
				oEvent.getSource().setValue(oSelectedItem.getKey());
				oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
				oEvent.getSource().setDescription(oSelectedItem.getAdditionalText());
			}
		},

		// Handler of event suggest of field company and country
		handleSuggest: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = [];
			if (sTerm) {
				aFilters.push(new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, sTerm));
				aFilters.push(new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.Contains, sTerm));
			}
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},

		// Handler of event suggest of field Tags
		handleSuggestTags: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = [];
			if (sTerm) {
				aFilters.push(new sap.ui.model.Filter("TagName", sap.ui.model.FilterOperator.Contains, sTerm));
			}
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},

		_validateTag: function (args) {
			var sText = args.text;
			if (sText.indexOf(";") !== -1) {
				MessageUtil.showMsg("msgTypeFailed", this.getModel("i18n").getResourceBundle().getText("TAGS_MSG_FORBIDDEN_CHAR"));
				return sap.m.MultiInput.WaitForAsyncValidation;
			} else {
				return new sap.m.Token({
					key: sText,
					text: sText
				});
			}
		},

		_estimatedNumberParse: function (sValue, isParseAsString) {
			var sFormat = sap.ui.getCore().getConfiguration().getFormatSettings().getLegacyNumberFormat();
			if (sFormat) {
				sFormat = this._decimalFormatMapping[sFormat];
			} else {
				sFormat = this._decimalFormatMapping.X;
			}
			var oFloatFormatter = sap.ui.core.format.NumberFormat.getFloatInstance({
				parseAsString: isParseAsString,
				decimalSeparator: sFormat.decimalSeparator,
				groupingSeparator: sFormat.groupingSeparator
			});
			return oFloatFormatter.parse(sValue);
		},

		onEstimatedInputChange: function (oEvent) {
			var iNumberLength = parseInt(oEvent.getSource().data().numberLength, 10);
			oEvent.getSource().setValueStateText().setValueState(sap.ui.core.ValueState.None);
			this.bEstimatedFieldError = false;
			var sValue = oEvent.getParameter("value");
			if (sValue === "") {
				return;
			}
			var fValue = this._estimatedNumberParse(sValue, false);
			if (isNaN(fValue)) {
				this.bEstimatedFieldError = true;
				oEvent.getSource().setValueStateText(this.getModel("i18n").getResourceBundle().getText("MSG_CREATE_AUDIT_INVALID_NUMBER_INPUT"))
					.setValueState(sap.ui.core.ValueState.Error);
			} else {
				if (fValue < 0) {
					this.bEstimatedFieldError = true;
					oEvent.getSource().setValueStateText(this.getModel("i18n").getResourceBundle().getText("MSG_CREATE_AUDIT_NEGATIVE_NUMBER"))
						.setValueState(sap.ui.core.ValueState.Error);
				}
				var sStringFormatValue = this._estimatedNumberParse(sValue, true);
				if (sStringFormatValue.split(".")[0].length > iNumberLength) {
					this.bEstimatedFieldError = true;
					oEvent.getSource().setValueStateText(this.getModel("i18n").getResourceBundle().getText("MSG_CREATE_AUDIT_NUMBER_TOO_LONG",
						iNumberLength)).setValueState(sap.ui.core.ValueState.Error);
				}
				if (sStringFormatValue.split(".")[1] && sStringFormatValue.split(".")[1].length >
					2) {
					this.bEstimatedFieldError = true;
					oEvent.getSource().setValueStateText(this.getModel("i18n").getResourceBundle().getText("MSG_CREATE_AUDIT_FRACTION_TOO_LONG",
						iNumberLength)).setValueState(sap.ui.core.ValueState.Error);
				}
			}
		},

		addAuditableItems: function () {
			var sPath = "/" + this.getOwnerComponent().getModel("intentConfig").getData().auditableItemSectionService;

			if (this.oToBeAddedAuditableItemsSmartTable) {
				this.oToBeAddedAuditableItemsSmartTable.destroy();
			}
			this.oToBeAddedAuditableItemsSmartTable = sap.ui.xmlfragment(
				"sap.grc.acs.aud.audit.fragment.AddAuditableItems", this);

			this.oToBeAddedAuditableItemsSmartTable.attachBeforeRebindTable(this.onRebindAssignAuditableItemTable.bind(this));
			this.oToBeAddedAuditableItemsSmartTable.setTableBindingPath(sPath);

			var that = this;
			this.oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				title: this.getView().getModel("i18n").getResourceBundle().getText("titAddAuditableItem"),
				supportMultiselect: true,
				supportRanges: false,
				supportRangesOnly: false,
				key: "ID",
				descriptionKey: "Title",
				stretch: sap.ui.Device.system.phone,

				ok: function (oOkEvent) {
					var aSelectedTokens = oOkEvent.getParameter("tokens");
					that.addAuditableItemsToList(aSelectedTokens);
				},

				cancel: function () {
					this.close();
				},

				afterClose: function () {
					this.destroy();
				},

				afterOpen: function () {
					that.oToBeAddedAuditableItemsSmartTable.rebindTable();
				}
			});
			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterBarExpanded: true,
				showGoOnFB: !sap.ui.Device.system.phone,
				search: function () {
					that.oToBeAddedAuditableItemsSmartTable.rebindTable();
				}
			});

			if (oFilterBar.setBasicSearch) {
				this.oBasicSearch = new sap.m.SearchField({
					//id: "basicSearch",
					showSearchButton: sap.ui.Device.system.phone,
					placeholder: this.getView().getModel("i18n").getResourceBundle().getText("labelSearchAuditableItemsPlaceHolder"),
					search: function () {
						that.oValueHelpDialog.getFilterBar().search();
					}
				});
				oFilterBar.setBasicSearch(this.oBasicSearch);
			}

			this.getView().addDependent(this.oValueHelpDialog);

			this.oValueHelpDialog.setFilterBar(oFilterBar);
			this.oValueHelpDialog.setTable(this.oToBeAddedAuditableItemsSmartTable);
			this.oValueHelpDialog.open();
		},

		_getToBeAssignedAuditableItemTableBasicFilter: function () {
			var sPlanKey = this.auditPlanKey;

			var oTableSearchState = [
				new sap.ui.model.Filter("DBKey", sap.ui.model.FilterOperator.EQ, sPlanKey)
			];

			var oAuditableItemTable = this.getView().byId("auditableItemsTable");
			var aAssignedAuditableItems = oAuditableItemTable.getModel().getData();
			for (var i = 0; i < aAssignedAuditableItems.length; i++) {
				oTableSearchState.push(new sap.ui.model.Filter("MasterReference", sap.ui.model.FilterOperator.NE, aAssignedAuditableItems[i].MasterReference));
			}
			var oTableBasicFilter = new sap.ui.model.Filter(oTableSearchState, true);
			return oTableBasicFilter;
		},

		onRebindAssignAuditableItemTable: function (oEvent) {
			var oTableBasicFilter = this._getToBeAssignedAuditableItemTableBasicFilter();

			var sSearchString = this.oBasicSearch.getValue();
			var oTableSearchState = [
				new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.Contains, sSearchString),
				new sap.ui.model.Filter("Title", sap.ui.model.FilterOperator.Contains, sSearchString)
			];
			var oTableSearchStateFilter = new sap.ui.model.Filter(oTableSearchState, false);
			oTableSearchStateFilter = new sap.ui.model.Filter([oTableSearchStateFilter, oTableBasicFilter], true);

			oEvent.getParameters().bindingParams.filters = [oTableSearchStateFilter];
		},

		addAuditableItemsToList: function (aSelectedTokens) {
			if (aSelectedTokens.length === 0) {
				MessageUtil.showMsg("msgTypeFailed", this.getModel("i18n").getResourceBundle().getText("MSG_CREATE_AUDIT_SELECT_ONE"));
				return;
			}
			var flag = false;
			var oModel = this.getView().byId("auditableItemsTable").getModel();
			for (var i = 0; i < aSelectedTokens.length; i++) {
				for (var j = 0; j < oModel.getData().length; j++) {
					if (aSelectedTokens[i].data("row").MasterReference === oModel.getData()[j].MasterReference) {
						flag = true;
						break;
					}
				}
				if (!flag) {
					oModel.getData().push(aSelectedTokens[i].data("row"));
					MessageUtil.showMsg("msgSuccessful", this.getModel("i18n").getResourceBundle().getText("MSG_ADD_ADTBL_SUCCESSFUL"));
				}
				flag = false;
			}
			this.oValueHelpDialog.close();
			oModel.refresh();
			this.refreshScopedObjects("AA");
		},

		removeAuditableItems: function () {
			var aSelectedItem, i, j, oItem, oAuditableItemKey, oData;

			aSelectedItem = this.getView().byId("auditableItemsTable").getSelectedItems();
			if (aSelectedItem.length) {
				var oModel = this.getView().byId("auditableItemsTable").getModel();
				for (i = aSelectedItem.length - 1; i >= 0; i--) {
					oItem = aSelectedItem[i];
					oAuditableItemKey = oItem.getBindingContext().getProperty("AuditableItemKey");
					oData = oModel.getData();
					for (j = 0; j < oData.length; j++) {
						if (oData[j].AuditableItemKey === oAuditableItemKey && oData.splice(j, 1).length !== 0) {
							break;
						}
					}
				}
				this.getView().byId("auditableItemsTable").removeSelections();
				oModel.refresh();
				this.refreshScopedObjects("RA");
			} else {
				MessageUtil.showMsg("msgTypeFailed", this.getModel("i18n").getResourceBundle().getText("MSG_CREATE_AUDIT_SELECT_ONE"));
			}
		},

		loadScopedOrgs: function (sAuditPlanKey, oTableFilter) {

			var orgItems = [{
				AuditPlanKey: "",
				ReferenceKey: "",
				ScopedKey: "",
				OrganizationKey: "",
				OrganizationID: "",
				OrganizationName: "",
				OrganizationGroupText: "",
				OrganizationTypeText: "",
				OrganizationGroup: "",
				OrganizationType: ""
			}];

			var oOrgTable = this.getView().byId("orgTable");
			var oDataModel = this.getView().getModel();
			var sOrgPath = "/GRCAUD_CV_AuditPlan(DBKey=guid'" + sAuditPlanKey + "')/to_ScopedOrg";

			var orgModel = oOrgTable.getModel();
			if (orgModel.hasOwnProperty("sServiceUrl")) {
				orgModel = new JSONModel(orgItems);
				oOrgTable.setModel(orgModel);
				oOrgTable.bindItems("/", oOrgTable.getItems()[0].clone());
			}

			oDataModel.read(sOrgPath, {
				filters: [oTableFilter],
				success: jQuery.proxy(function (orgData) {
					var orgTemplate = orgItems[0],
						orgKey = [];
					orgItems = [];
					for (var i = 0; i < orgData.results.length; i++) {
						if (orgKey.indexOf(orgData.results[i].OrganizationKey) >= 0) {
							continue;
						} else {
							orgKey.push(orgData.results[i].OrganizationKey);
						}
						var orgItem = Object.create(orgTemplate);
						for (var j in orgItem) {
							if (orgData.results[i][j]) {
								orgItem[j] = orgData.results[i][j];
							}
						}
						orgItems.push(orgItem);
					}
					orgModel.setData(orgItems);
					oOrgTable.setModel(orgModel);
					orgModel.refresh();

				}),
				error: jQuery.proxy(function (oError) {
					if (oError.responseText) {
						var sErrorMessage = "";
						// Add try-catch in case responseText is in xml format
						try {
							var oJsonError = JSON.parse(oError.responseText);
							sErrorMessage = oJsonError.error.message.value;
						} catch (e) {
							sErrorMessage = oError.responseText;
						}
						MessageUtil.showMsg("msgTypeFailed", sErrorMessage);
					}
				})
			});
		},

		loadScopedDims: function (sAuditPlanKey, oTableFilter) {

			var dimItems = [{
				AuditPlanKey: "",
				ReferenceKey: "",
				ScopedKey: "",
				DimensionKey: "",
				DimensionID: "",
				DimensionName: "",
				DimDescription: "",
				DimensionTypeText: "",
				DimRiskScore: "",
				DimensionType: ""
			}];

			var oDimTable = this.getView().byId("dimTable");
			var oDataModel = this.getView().getModel();
			var sDimPath = "/GRCAUD_CV_AuditPlan(DBKey=guid'" + sAuditPlanKey + "')/to_ScopedDim";

			var dimModel = oDimTable.getModel();
			if (dimModel.hasOwnProperty("sServiceUrl")) {
				dimModel = new JSONModel(dimItems);
				oDimTable.setModel(dimModel);
				oDimTable.bindItems("/", oDimTable.getItems()[0].clone());
			}

			oDataModel.read(sDimPath, {
				filters: [oTableFilter],
				success: jQuery.proxy(function (dimData) {
					var dimTemplate = dimItems[0],
					    dimKey = []; 
					dimItems = [];
					for (var i = 0; i < dimData.results.length; i++) {
						if (dimKey.indexOf(dimData.results[i].DimensionKey) >= 0) {
							continue;
						} else {
							dimKey.push(dimData.results[i].DimensionKey);
						}
						var dimItem = Object.create(dimTemplate);
						for (var j in dimItem) {
							if (dimData.results[i][j]) {
								dimItem[j] = dimData.results[i][j];
							}
						}
						dimItems.push(dimItem);
					}
					dimModel.setData(dimItems);
					oDimTable.setModel(dimModel);
					dimModel.refresh();

				}),
				error: jQuery.proxy(function (oError) {
					if (oError.responseText) {
						var sErrorMessage = "";
						// Add try-catch in case responseText is in xml format
						try {
							var oJsonError = JSON.parse(oError.responseText);
							sErrorMessage = oJsonError.error.message.value;
						} catch (e) {
							sErrorMessage = oError.responseText;
						}
						MessageUtil.showMsg("msgTypeFailed", sErrorMessage);
					}
				})
			});

		},

		refreshScopedObjects: function (code) {
			var oAdtblData = this.getView().byId("auditableItemsTable").getModel().getData();

			var aReferencyKey = [],

				aRefKeySearchState = [],
				aOrgKeySearchState = [],
				aDimKeySearchState = [],

				oOrganizationKeyFilter = {},
				oDimensionKeyFilter = {},
				oReferenceKeyFilter = {},

				oOrgTableFilter = {},
				oDimTableFilter = {};

			var removedOrgKeys = this._getRemovedOrgKeys();
			var removedDimKeys = this._getRemovedDimKeys();
			var refKeyFound = false,
				orgKey = {},
				dimKey = {};

			// Filter Reference Key
			if (oAdtblData.length > 0) {
				for (var i = 0; i < oAdtblData.length; i++) {
					if (aReferencyKey.indexOf(oAdtblData[i].ReferenceKey) < 0) {
						aReferencyKey.push(oAdtblData[i].ReferenceKey);
						aRefKeySearchState.push(new sap.ui.model.Filter("ReferenceKey", sap.ui.model.FilterOperator.EQ, oAdtblData[i].ReferenceKey));
					}
				}
			} else {
				aRefKeySearchState.push(new sap.ui.model.Filter("ReferenceKey", sap.ui.model.FilterOperator.EQ,
					"00000000-0000-0000-0000-000000000000"));
			}
			oReferenceKeyFilter = new sap.ui.model.Filter(aRefKeySearchState, false);

			// RemovedOrgKeys
			for (orgKey in removedOrgKeys) {
				refKeyFound = false;
				for (var j = 0; j < aReferencyKey.length; j++) {
					if (removedOrgKeys[orgKey].ReferenceKey === aReferencyKey[j]) {
						refKeyFound = true;
						break;
					}
				}
				if (code === "AA" && refKeyFound) {
					delete removedOrgKeys[orgKey];
				}
			}

			// RemovedDimKeys
			for (dimKey in removedDimKeys) {
				refKeyFound = false;
				for (var k = 0; k < aReferencyKey.length; k++) {
					if (removedDimKeys[dimKey].ReferenceKey === aReferencyKey[k]) {
						refKeyFound = true;
						break;
					}
				}

				if (code === "AA" && refKeyFound) {
					delete removedDimKeys[dimKey];
				}
			}

			// Filter Organization Key
			for (orgKey in removedOrgKeys) {
				aOrgKeySearchState.push(new sap.ui.model.Filter("OrganizationKey", sap.ui.model.FilterOperator.NE, orgKey));
			}
			if (aOrgKeySearchState.length > 0) {
				oOrganizationKeyFilter = new sap.ui.model.Filter(aOrgKeySearchState, true);
				oOrgTableFilter = new sap.ui.model.Filter([oReferenceKeyFilter, oOrganizationKeyFilter], true);
			} else {
				oOrgTableFilter = oReferenceKeyFilter;
			}

			// Filter Dimension Key
			for (dimKey in removedDimKeys) {
				aDimKeySearchState.push(new sap.ui.model.Filter("DimensionKey", sap.ui.model.FilterOperator.NE, dimKey));
			}
			if (aDimKeySearchState.length > 0) {
				oDimensionKeyFilter = new sap.ui.model.Filter(aDimKeySearchState, true);
				oDimTableFilter = new sap.ui.model.Filter([oReferenceKeyFilter, oDimensionKeyFilter], true);
			} else {
				oDimTableFilter = oReferenceKeyFilter;
			}

			if (code === "RO" || code === "RA" || code === "AA") {
				this.loadScopedOrgs(this.auditPlanKey, oOrgTableFilter);
			}

			if (code === "RD" || code === "RA" || code === "AA") {
				this.loadScopedDims(this.auditPlanKey, oDimTableFilter);
			}

		},

		removeOrganizations: function () {
			var selOrgItems = this.getView().byId("orgTable").getSelectedItems(),
				removedOrgKeys = this._getRemovedOrgKeys();
			if (selOrgItems.length > 0) {
				for (var i = 0; i < selOrgItems.length; i++) {
					if (!removedOrgKeys.hasOwnProperty(selOrgItems[i].getBindingContext().getProperty("OrganizationKey"))) {
						removedOrgKeys[selOrgItems[i].getBindingContext().getProperty("OrganizationKey")] = {
							association: "Org_to_Ref",
							ReferenceKey: selOrgItems[i].getBindingContext().getProperty("ReferenceKey")
						};
					}
				}
				this.getView().byId("orgTable").removeSelections();
				this.getView().byId("orgTable").getModel().refresh();
				this.refreshScopedObjects("RO");
			} else {
				MessageUtil.showMsg("msgTypeFailed", this.getModel("i18n").getResourceBundle().getText("MSG_CREATE_AUDIT_SELECT_ONE"));
			}
		},

		removeDimensions: function () {
			var selDimItems = this.getView().byId("dimTable").getSelectedItems(),
				removedDimKeys = this._getRemovedDimKeys();
			if (selDimItems.length > 0) {
				for (var i = 0; i < selDimItems.length; i++) {
					if (!removedDimKeys.hasOwnProperty(selDimItems[i].getBindingContext().getProperty("DimensionKey"))) {
						removedDimKeys[selDimItems[i].getBindingContext().getProperty("DimensionKey")] = {
							association: "Dim_to_Ref",
							ReferenceKey: selDimItems[i].getBindingContext().getProperty("ReferenceKey")
						};
					}
				}
				this.getView().byId("dimTable").removeSelections();
				this.getView().byId("dimTable").getModel().refresh();
				this.refreshScopedObjects("RD");
			} else {
				MessageUtil.showMsg("msgTypeFailed", this.getModel("i18n").getResourceBundle().getText("MSG_CREATE_AUDIT_SELECT_ONE"));
			}
		},

		_getRemovedOrgKeys: function () {
			if (this.removedOrgKeys === undefined) {
				this.removedOrgKeys = [];
			}
			return this.removedOrgKeys;
		},

		_getRemovedDimKeys: function () {
			if (this.removedDimKeys === undefined) {
				this.removedDimKeys = [];
			}
			return this.removedDimKeys;
		}
	});

});
