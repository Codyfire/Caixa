/*
 * Copyright (C) 2009-2020 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
		"sap/grc/acs/aud/audit/controller/BaseController",
		"sap/ui/model/json/JSONModel",
		"sap/grc/acs/aud/audit/model/formatter",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator",
		"sap/ui/core/routing/History",
		"sap/grc/acs/lib/aud/utils/MessageUtil",
		"sap/grc/acs/lib/aud/doc/util/FileUploader"
	], function (BaseController, JSONModel, formatter, Filter, FilterOperator, History, MessageUtil, FileUploader) {
		"use strict"; 

		return BaseController.extend("sap.grc.acs.aud.audit.initiate.extended.controller.Worklist", {

			formatter: formatter,
			/* =========================================================== */
			/* lifecycle methods                                           */
			/* =========================================================== */

			/**
			 * Called when the worklist controller is instantiated.
			 * @public
			 */
			onInit : function () {
				var oViewModel,
					iOriginalBusyDelay,
					oTable = this.byId("table");

				// Put down worklist table's original value for busy indicator delay,
				// so it can be restored later on. Busy handling on the table is
				// taken care of by the table itself.
				iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
				this._oTable = oTable;
				// keeps the search state
				this._oTableSearchState = [];

				// Model used to manipulate control states
				oViewModel = new JSONModel({
					worklistTableTitle : this.getResourceBundle().getText("worklistTableTitle"),
					saveAsTileTitle: this.getResourceBundle().getText("worklistViewTitle"),
					shareOnJamTitle: this.getResourceBundle().getText("worklistViewTitle"),
					shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
					shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
					tableNoDataText : this.getResourceBundle().getText("tableNoDataText"),
					tableBusyDelay : 0
				});
				this.setModel(oViewModel, "worklistView");
				
				//Set app title
				var sTitle = this.getResourceBundle().getText(this.getOwnerComponent().getModel("intentConfig").getData().appTitle);
				this.getOwnerComponent().getService("ShellUIService").then(
					function (oService) {
						oService.setTitle(sTitle);
					}
				);
				
				// Make sure, busy indication is showing immediately so there is no
				// break after the busy indication for loading the view's meta data is
				// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
				oTable.attachEventOnce("updateFinished", function(){
					// Restore original busy indicator delay for worklist's table
					oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
				});
				sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.audit.EventBus","auditListRefresh", this.onRefresh,this);
			},

			/* =========================================================== */
			/* event handlers                                              */
			/* =========================================================== */

			/**
			 * Triggered by the table's 'updateFinished' event: after new table
			 * data is available, this handler method updates the table counter.
			 * This should only happen if the update was successful, which is
			 * why this handler is attached to 'updateFinished' and not to the
			 * table's list binding's 'dataReceived' method.
			 * @param {sap.ui.base.Event} oEvent the update finished event
			 * @public
			 */
			onUpdateFinished : function (oEvent) {
				// update the worklist's object counter after the table update
				var sTitle,
					oTable = oEvent.getSource(),
					iTotalItems = oEvent.getParameter("total");
				// only update the counter if the length is final and
				// the table is not empty
				if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
					sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
				} else {
					sTitle = this.getResourceBundle().getText("worklistTableTitle");
				}
				this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
			},
			
			onBeforeRebindTable: function(oEvent){
				var oBindingParams = oEvent.getParameter("bindingParams");
				var oParameters = this.getOwnerComponent().getComponentData().startupParameters;
				var oWorklistSorterConfig = this.getModel("intentConfig").getData().worklistSorter;
				var fnAddFilter = function(aParameter, sPath) {
					if(aParameter && aParameter.length > 0) {
						oBindingParams.filters.push(new sap.ui.model.Filter({
							path: sPath, 
							operator: sap.ui.model.FilterOperator.EQ, 
							value1: aParameter[0]
						}));
					}
				};
				if(oWorklistSorterConfig){
					oBindingParams.sorter.push(new sap.ui.model.Sorter(oWorklistSorterConfig.orderBy, oWorklistSorterConfig.isDescending));
				}
				fnAddFilter(oParameters.AuditGroup, "AuditGroup");
				fnAddFilter(oParameters.Quarter, "DistributedQuarter");
				fnAddFilter(oParameters.ActionYear, "ActionYear");
				fnAddFilter(oParameters.Phase, "PhaseID");
				fnAddFilter(oParameters.FinalReportCategory, "FinalReportCategory");
				fnAddFilter(oParameters.FinalReportRating, "FinalReportRating");
			},
			
			/**
			 * Event handler when a table item gets pressed
			 * @param {sap.ui.base.Event} oEvent the table selectionChange event
			 * @public
			 */
			onPress : function (oEvent) {
				// The source is the list item that got pressed
				this._showObject(oEvent.getSource());
			},

			onClick: function(oEvent) {
				var sPath = oEvent.getParameters().rowBindingContext.sPath;
				var sDBKey = sPath.substring(sPath.indexOf("'")+1,sPath.lastIndexOf("'"));
				this.getRouter().navTo("object",{
					objectId:sDBKey,
					intentService: this.getOwnerComponent().getModel("intentConfig").getData().service
				});
			},

			/**
			 * Event handler for navigating back.
			 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
			 * If not, it will navigate to the shell home
			 * @public
			 */
			onNavBack : function() {
				var sPreviousHash = History.getInstance().getPreviousHash(),
					oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

				if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
					history.go(-1);
				} else {
					oCrossAppNavigator.toExternal({
						target: {shellHash: "#Shell-home"}
					});
				}
			},
			
			onMassUpload:function(oEvent){
				var oButton = oEvent.getSource();
				// popup menu
				if (!this.oAddMenu) {
					this.oAddMenu = sap.ui.xmlfragment("menuFrag",
						"sap.grc.acs.aud.audit.fragment.MassUploadAudits",
						this);
					this.getView().addDependent(this.oAddMenu);
				}
				var eDock = this.getDock();
				this.oAddMenu.open(true, oButton, eDock.BeginTop, eDock.BeginButtom, oButton);
			},

			getDock:function(){
				return sap.ui.core.Popup.Dock;
			},
			
			onDownloadTemplate:function(){
				var oDataModel = this.getView().getModel();
				var sTemplateType = "AUD_EXL_UP";
				var sHostKey = "00000000-0000-0000-0000-000000000000";
				var sPathToTemplate = oDataModel.sServiceUrl + "/" + sap.grc.acs.aud.audit.util.constant.ObjectType.UploadTemplateSet +
				"(Template=" + "\'" + sTemplateType + "\',Variant=\'" + "" + "\',HostKey=guid\'" + sHostKey + "\')/$value";
				window.open(sPathToTemplate);
			},
			onUpload:function(){
				if (this.oAdtUploadPopup) {
					this.oAdtUploadPopup.destroy();
				}
				this.oAdtUploadPopup = sap.ui.xmlfragment("sap.grc.acs.aud.audit.block.fragment.UploadFileDialog",this);
				this.getView().addDependent(this.oAdtUploadPopup);
				var oController = this;
				delete this.oFileUploader;
				oController.oFileUploader = new FileUploader({
					read: jQuery.proxy(function (oEvt) {
						oController.sFileName = oEvt.getParameter("name");
						oController.sFileType = oEvt.getParameter("type");
						oController.sFileValue = oEvt.getParameter("value");
					}, oController)
				});
				sap.ui.getCore().byId("fileUploader").addContent(oController.oFileUploader);
				this.oAdtUploadPopup.open();
			},
			_handleConfirmUploadBtnPress:function(){
				if (!this.sFileName) {
					MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("MSG_CHOOSE_FILE_TO_UPLOAD"));
					return;
				}
				sap.ui.getCore().byId("uploadOKButton").setVisible(false);
				sap.ui.getCore().byId("uploadCancelButton").setVisible(false);
				var oLableFileName = new sap.m.Label({
					text: this.sFileName
				});
				var oSimpleForm = sap.ui.getCore().byId("fileProgress");
				oSimpleForm.insertContent(oLableFileName, 0);
				oSimpleForm.setVisible(true);
				this.oFileUploader.setVisible(false);
				this.oProgressIndicator = sap.ui.getCore().byId("uploadProgressIndicator");
				this.oProgressIndicator.setPercentValue(20);
				this.oProgressIndicator.setDisplayValue("20%");
				this._uploadAudit(this.sFileName, this.sFileType, this.sFileValue);
			},
			_uploadAudit:function(sName, sMIMEType, sContent){
				var oDataModel = this.getView().getModel();
				var sPathToCreateImportJob = "/" + sap.grc.acs.aud.audit.util.constant.ObjectType.ImportJobSet;
				var oImportJobData = {
					Name: sName,
					ObjectType: "AUDIT",
					SourceID: "FILE",
					Selections: [],
					TargetID: "DUMMY",
					Type: "S",
					PackageSize: 0
				};
				oDataModel.setUseBatch(false);
				this.oAdtUploadPopup.setBusy(true);
				oDataModel.create(
					sPathToCreateImportJob,
					oImportJobData, {
						success: jQuery.proxy(function (
							oData) {
							oDataModel.setUseBatch(true);
							this.oProgressIndicator.setPercentValue(40);
							this.oProgressIndicator.setDisplayValue("40%");
							this._updateFileNode(oData.Key, sName, sMIMEType, sContent);
						}, this),
						error: jQuery.proxy(function () {
							oDataModel.setUseBatch(true);
							this.oAdtUploadPopup.setBusy(false);
							this.oAdtUploadPopup.close();
						}, this),
						async: true
					});
			},
			_updateFileNode:function(sImportJobKey, sName, sMIMEType, sContent){
				var sPathToGetFileNode = "/" + sap.grc.acs.aud.audit.util.constant.ObjectType.ImportJobSet + "(guid\'" + sImportJobKey + "\')/" +
				"File";
				var oModel = this.getView().getModel();
				oModel.setUseBatch(false);
				oModel.read(
					sPathToGetFileNode, {
						success: jQuery.proxy(
							function (oData, oResponse) {
								this._uploadFileContent(oData, oResponse, sImportJobKey, sName, sMIMEType, sContent);
							}, this),
						error: jQuery.proxy(
							function () {
								oModel.setUseBatch(true);
								this.oAdtUploadPopup.setBusy(false);
								this.oAdtUploadPopup.close();
								MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText(
									"MSG_UPLOAD_AUDIT_FAIL"));
							}, this),
						async: true
					});
			},
			_uploadFileContent:function(oData, oResponse, sImportJobKey, sName, sMIMEType, sContent){
				var oModel = this.getView().getModel();
				var uploadUrl = oData.__metadata.media_src;
				var headerToken = "x-csrf-",
					token = "token";
				var scrfToken = oModel.oHeaders[headerToken + token];
				if (!scrfToken) {
					oModel.refreshSecurityToken(
						function (res, rep) {
							scrfToken = rep.headers[headerToken + token];
						},
						function () {},
						false);
				}
				$.ajax({
					type: "put",
					url: uploadUrl,
					data: sContent,
					contentType: sMIMEType,
					beforeSend: function (request) {
						request.setRequestHeader(headerToken + token, scrfToken);
					},
					success: jQuery.proxy(function () {
						this._excuteImportJob(sImportJobKey, sName, sMIMEType);
		
					}, this),
					error: jQuery.proxy(function () {
						this.oAdtUploadPopup.setBusy(false);
						this.oAdtUploadPopup.close();
						oModel.setUseBatch(true);
						MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText(
							"MSG_UPLOAD_AUDIT_FAIL"));
					}, this)
				});
			},
			_excuteImportJob:function(sImportJobKey){
				var oModel = this.getView().getModel();
				oModel.callFunction(
					sap.grc.acs.aud.audit.util.constant.FuncImport.ExecuteImportJob, {
						method: "POST",
						urlParameters: {
							JobKey: sImportJobKey
						},
						async: true,
						success: jQuery.proxy(function () {
							oModel.setUseBatch(true);
							this.oProgressIndicator.setPercentValue(100);
							this.oProgressIndicator.setDisplayValue("100%");
							this.oAdtUploadPopup.setBusy(false);
							this.oAdtUploadPopup.close();
							MessageUtil.showMsg("msgTypeSuccessful", this.getView().getModel("i18n").getResourceBundle().getText(
								"MSG_UPLOAD_AUDIT_SUCCESS"));
							oModel.refresh();
						}, this),
						error: jQuery.proxy(function () {
							oModel.setUseBatch(true);
							this.oAdtUploadPopup.setBusy(false);
							this.oAdtUploadPopup.close();
							MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText(
								"MSG_UPLOAD_AUDIT_FAIL"));
						}, this)
				});
			},
			_handleCancelUploadBtnPress:function(){
				this.oAdtUploadPopup.close();	
			},
			createAudit: function(){
				this.getRouter().navTo("create");
			},
			
			onSort: function() {
				this._showPersonalizationSections("Sort");
			},
			onFilter: function() {
				this._showPersonalizationSections("Filter");
			},
			onGroup: function() {
				this._showPersonalizationSections("Group");
			},
			onColumns: function() {
				this._showPersonalizationSections("Columns");
			},
			
			_showPersonalizationSections: function(sSectionName){
				var oSmartTable = this.getView().byId("smartTable");
				oSmartTable.openPersonalisationDialog(sSectionName);
			},

			/**
			 * Event handler when the share in JAM button has been clicked
			 * @public
			 */
			onShareInJamPress : function () {
				var oViewModel = this.getModel("worklistView"),
					oShareDialog = sap.ui.getCore().createComponent({
						name: "sap.collaboration.components.fiori.sharing.dialog",
						settings: {
							object:{
								id: location.href,
								share: oViewModel.getProperty("/shareOnJamTitle")
							}
						}
					});
				oShareDialog.open();
			},

			onSearch : function (oEvent) {
				if (oEvent.getParameters().refreshButtonPressed) {
					// Search field's 'refresh' button has been pressed.
					// This is visible if you select any master list item.
					// In this case no new search is triggered, we only
					// refresh the list binding.
					this.onRefresh();
				} else {
					var oTableSearchState = [];
					var sQuery = oEvent.getParameter("query");

					if (sQuery && sQuery.length > 0) {
						oTableSearchState = [new Filter("Title", FilterOperator.Contains, sQuery)];
					}
					this._applySearch(oTableSearchState);
				}

			},

			/**
			 * Event handler for refresh event. Keeps filter, sort
			 * and group settings and refreshes the list binding.
			 * @public
			 */
			onRefresh : function () {
				//m table
				if(this._oTable.getBinding("items")){
					this._oTable.getBinding("items").refresh();
				//t table
				}else{
					this._oTable.getBinding("rows").refresh();
				}
			},

			/* =========================================================== */
			/* internal methods                                            */
			/* =========================================================== */

			/**
			 * Shows the selected item on the object page
			 * On phones a additional history entry is created
			 * @param {sap.m.ObjectListItem} oItem selected Item
			 * @private
			 */
			_showObject : function (oItem) {
				this.getRouter().navTo("object", {
					objectId: oItem.getBindingContext().getProperty("DBKey"),
					intentService: this.getOwnerComponent().getModel("intentConfig").getData().service
				});
			},

			/**
			 * Internal helper method to apply both filter and search state together on the list binding
			 * @param {object} oTableSearchState an array of filters for the search
			 * @private
			 */
			_applySearch: function(oTableSearchState) {
				var oViewModel = this.getModel("worklistView");
				this._oTable.getBinding("items").filter(oTableSearchState, "Application");
				// changes the noDataText of the list in case there are no filter results
				if (oTableSearchState.length !== 0) {
					oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
				}
			},
			formatActualCost: function(sActualCost, sCurrency) {
				return sActualCost + " " + sCurrency;
			},
			onExit: function() {
				sap.ui.getCore().getEventBus().unsubscribe("sap.grc.acs.aud.audit.EventBus","auditListRefresh", this.onRefresh,this);
			}

		});
	}
);
