sap.ui.define([ "sap/ui/core/mvc/Controller",
	"sap/grc/acs/aud/audit/initiate/extended/block/util/listsUtils",
	"sap/grc/acs/aud/audit/initiate/extended/block/model/oDataGeneratorList",
	"sap/grc/acs/aud/audit/initiate/extended/block/util/Enhancements",
], function(Controller,UtilList,Model) {
	"use strict";
	return Controller.extend("sap.grc.acs.aud.audit.initiate.extended.block.controller.Personas",{
		onInit: function () {
			console.log("En personas controller");	
		},
		//Inicio PRL 31.05.2021			
		onAdd: function() {
//			var o18nmModel = new sap.ui.model.resource.ResourceModel({ bundleUrl:"sap/grc/acs/aud/audit/initiate/extended/i18n/i18n.properties" });
			var o18nmModel = this.getOwnerComponent().getModel('i18nm');
			var oController = this;
			//Preparo els filtres amb els valors
			var oModel = new sap.ui.model.json.JSONModel();
			sap.ui.getCore().setModel(oModel,"ldap");
			
			if(sap.ui.getCore().getComponent('searchComponent')) {
				sap.ui.getCore().getComponent('searchComponent').destroy();
			}
			
			var oComp  = sap.ui.getCore().createComponent({
				id: "searchComponent",
		        name: "sap.grc.acs.aud.audit.initiate.extended.block.searchComponent"
		    });
			
			// Función de añadir resultados a las tablas
			var addFunct =function() {
				var selItems = this.getParent().getContent()[1].getSelectedItems();
				
				if(selItems.length == 0) { alert(o18nmModel.getResourceBundle().getText("select_option")); }
				else {
					if(mirarPersonsaRepetides(selItems,oController.getView())){
						//Han intentat inserir una persona repetida
						var dialog = new sap.m.Dialog({
							title: o18nmModel.getResourceBundle().getText("info"),
							type: 'Message',
								content: new sap.m.Text({
									text: o18nmModel.getResourceBundle().getText("repeated_person")
								}),
							beginButton: new sap.m.Button({
								text: o18nmModel.getResourceBundle().getText("accept"),
								press: function () {
									dialog.close();
								}
							}),
							endButton: new sap.m.Button({
								text: o18nmModel.getResourceBundle().getText("cancel"),
								press: function () {
									dialog.close();
								}
							}),
							afterClose: function() {
								dialog.destroy();
							}
						});
						dialog.open();
					}else{
						//var viewName = oController.getView().getId();
			        	//var list = sap.ui.getCore().byId(viewName).listContainer;
						var viewName = oController.oView;
						//var list = sap.ui.getCore().byId(viewName).byId('tablePersonas');
						var list = viewName.byId('tablePersonas');
			        	//var listTemplate = sap.ui.getCore().byId(viewName).template;
						var listTemplate = viewName.template;
			        	
						$.each(selItems,function(i,n){
			        		var bindingContext = selItems[i].getBindingContext().sPath;
			        		var matricula = sap.ui.getCore().getModel("ldap").getProperty(bindingContext).UserId;
				        	var nombre = sap.ui.getCore().getModel("ldap").getProperty(bindingContext).FullName;
				        	var oEntity = {};
				        	oEntity.FullName = nombre;
				        	oEntity.UserId = matricula;
				        	if(list.getModel().getData().results)
				        	{
				        		list.getModel().getData().results.push(oEntity);
				        	}
				        	else {
				        		list.getModel().getData().results = [];
				        		list.getModel().getData().results.push(oEntity);
				        	}
				        	//anadirObjetoAPersonas(oEntity, list);
			        	});
			        	//byId("personas").setModel(sap.ui.getCore().getModel("personas"));
						list.bindAggregation("items","/results", viewName.templateTable);
						list.bindItems("/results/", viewName.templateTable);
			        	this.getParent().destroy();
					}
				}};
				
			var addSearchFunct = function(){
				//Agafo el valor del serchfield
				var text = this.getParent().getContent()[0].getProperty("value");
				//var url = "/InfoUsersLDAPSet";
				var url = "/RoleSet(RoleId='AUD',RoleDepId='')/Users"
				if(text != ""){
					var aFilters = [];
					aFilters.push(new sap.ui.model.Filter("FullName",sap.ui.model.FilterOperator.Contains, text.toUpperCase()));
					//Hacemos la llamada al ldap
					addPersonasLdap(url, aFilters);
				}

			}		
			// Cabecera, Binding Posiciones, Modo de Lista, Binding Aggregation, Path, Model, AddFunction
			oComp.setupInicial(["Matricula", "Nombre"],  ["{UserId}", "{FullName}"], "MultiSelect", "", "/results", "ldap", addFunct,addSearchFunct,this.oView);
			
			// Se crea un contenedor para el componente
			var oCompCont = new sap.ui.core.ComponentContainer({
				 component: oComp,
			});
/* Inicio - Botón de borrado segun si haya personas o no - ANB 31.08.2021 */
/* Código nuevo: */
			//si hay restultados en la lista de personas, se pone la tabla en modo delete para mostrar botón de borrado
			   var list = this.getView().byId("tablePersonas");
			   if(list!==undefined){
			if(list.getModel().oData.results.length>0){
				list.setMode("Delete");
			}}
			/* Fin - Botón de borrado segun si haya personas o no - ANB 31.08.2021 */
		},
		//Fin PRL 31.05.2021			
		onDeleteTable: function(oEvent){
			var o18nmModel = this.getOwnerComponent().getModel('i18nm').getResourceBundle();
		   
//		   new sap.ui.model.resource.ResourceModel({ bundleUrl:"sap/grc/acs/aud/audit/initiate/extended/i18n/i18n.properties" });
		   var bindingContext = oEvent.getParameter("listItem").getBindingContext().getPath();
		   var index = bindingContext.substr(9);
		   
		   var dialog = new sap.m.Dialog({
				title: o18nmModel.getText("warning"),// TODO: i18n-> sap.hpa.grcaud.enh_oBundle.getText("warning"),
				type: 'Message',
					content: new sap.m.Text({
						text: o18nmModel.getText("deleting_person")
					}),
				state: sap.ui.core.ValueState.Warning,
				beginButton: new sap.m.Button({
					text: o18nmModel.getText('OK'),
					press: [function () {

						//Elimino la persona del model local
						var list = this.getView().byId("tablePersonas") //this.getView().listContainer;
						//var template = this.getView().template;
						var oModel = list.getModel();
						var aEntries = oModel.getData().results;
						
						aEntries.splice(index,1);
						oModel.setData({
							results : aEntries
						});
						
						list.setModel(oModel);
						//list.bindAggregation("items","/results", template);
						dialog.close();
					}, oEvent.getSource().getParent().getParent().oController]
				}),
				endButton: new sap.m.Button({
					text: o18nmModel.getText("cancel"), 
					press: function () {
						dialog.destroy();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});
			   dialog.open();
			   /* Inicio - ANB - Botón de borrado segun si haya personas o no - 31.08.2021 */
			   /* Código nuevo: */
			   			//si hay restultados en la lista de personas, se pone la tabla en modo delete para mostrar botón de borrado
			   var list = this.getView().byId("tablePersonas");
			   if(list!==undefined){
			if(list.getModel().oData.results.length>0){
				list.setMode("Delete");
			}}
				//Fin PRL 3108 - Botón de borrado segun si haya personas o no		
		}
	})
})