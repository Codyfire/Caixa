/*
 * Copyright (C) 2009-2020 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(
	[
		"sap/grc/acs/aud/audit/block/controller/General.controller", 
		"sap/grc/acs/lib/aud/extension/utils/FieldExtensibilityUtil",
		"sap/grc/acs/aud/audit/model/formatter",
		"sap/grc/acs/lib/aud/utils/ComponentUtil",
		"sap/ui/model/json/JSONModel",
		"sap/grc/acs/lib/aud/utils/MessageUtil",		
	],
	function (Controller, FieldExtensibilityUtil, formatter, ComponentUtil, JSONModel, MessageUtil) {
		"use strict";

		return Controller.extend("sap.grc.acs.aud.audit.initiate.extended.block.GeneralCustom", {

			formatter: formatter,
			/**
			 * Called when a controller is instantiated and its View controls (if available) are already created.
			 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
			 * @memberOf sap.grc.acs.aud.finding.block.view.general
			 */
			onInit: function () {
				this.aDropDownGroupIndex = [];
				this.aDropDownEdit = [];
				this.sActualEffort = "";
				this.sEstimatedEffort = "";
				this.oViewModel = new JSONModel({
					bActualTimePeriodDisplay: true,
					bPlannedTimePeriodDisplay: true,
					bTagDisplay: true,
					bFormDisplay: true,
					bCompanyEdit: false,
					bCountryEdit: false
				});
				this.getView().setModel(this.oViewModel, "generalView");
				// this.getView().byId("actualEffort").attachInnerControlsCreated(this.setActualEffortValue, this);
				this.oMultiInput = this.getView().byId("multiinput");
				this._oComponent = ComponentUtil.getComponentById(this.getView().getId());
				this._oComponent.getModel().metadataLoaded().then(function () {
					this._createExtensionGroup();
				}.bind(this));
//PRL 17082021

/*				var oDeptModel = this.getOwnerComponent().getModel("modelDepartment");
				this.getView().setModel(this.oDeptModel, "modelDepartment");
				var zzdep = this.getView().byId('zz_department');
				zzdep.setValue(oDeptModel.oData.Text);*/

//PRL 17082021
				sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.audit.EventBus", "resetBlockToDisplayMode", this.setSmartFormToDisplayMode, this);
			},
			 
				// Incidencia Visualización grupo de auditoría INI
			   onSmartFieldInnerControlsCreated: function(oEvent) {
			    this.getView().getModel().setSizeLimit(9999);
			    var oControl = oEvent.getSource().getInnerControls()[0];
			    var sFieldName = oEvent.getSource().getBindingInfo("value").parts[0].path;
			    var sFieldTextName = sFieldName + "Text";
			    var oBindingObject = oControl.getBindingContext().getObject();
			    if(oBindingObject) {
			     oControl.setValue(oBindingObject[sFieldTextName] || oBindingObject[sFieldName]);
			    }
			   },
			   // Incidencia Visualización grupo de auditoría FIN
			
			setActualEffortValue: function(oEvent){
				if(this.getView().getModel("extensionModel").getData().EstimatedEffort.visible){
					this.getView().byId("EstimatedEffortText").setVisible(true);
				}
				if(this.getView().getModel("extensionModel").getData().ActualEffort.visible){
					this.getView().byId("ActualEffortText").setVisible(true);
				}
			},

			_createExtensionGroup: function () {
				var oExtensionGroup = this.getView().byId("extensionGroup");
				FieldExtensibilityUtil.createExtensionGroup("Audit", oExtensionGroup, this._oComponent);
			},
			
			onTypeChange: function(oEvent){ 
				var oObject = this.getView().getBindingContext().getObject(), 
					sObjectStatus = oObject.Status,
					sAuditType = oEvent.getParameter("value"),
				    sIntent = this.getOwnerComponent().getModel("intentConfig").getData().intent;
				FieldExtensibilityUtil.destoryElements(this.aDropDownEdit);
				FieldExtensibilityUtil.destoryElements(this.aDropDownGroupIndex);
				var oExtensionModel = this.getView().getModel("extensionModel");
				var oMenuItemConfigData = this.getOwnerComponent().getModel("menuItemConfig").getData();
				var bIsStatusBasedConfig = false;
				if(this.getOwnerComponent().isFromFlexibleColumnLayout && sObjectStatus === "00") {
					bIsStatusBasedConfig = true;
				}
				oExtensionModel.setData(
					FieldExtensibilityUtil.getExtensionFieldsStatus("Audit",
						sAuditType, sObjectStatus, this.getView().getModel().getServiceMetadata(), oMenuItemConfigData, this.getOwnerComponent(), sIntent, bIsStatusBasedConfig),
					true);	
				var oExtensionGroup = this.getView().byId("extensionGroup");
				this.getView().byId("extensionGroup").destroyGroupElements();
				this.aDropDownGroupIndex = [];
				this.aDropDownEdit = [];
				var	aDropDownGroupIndex = this.aDropDownGroupIndex, aDropDownEdit = this.aDropDownEdit;
				this._oComponent.oDeferred = jQuery.Deferred();
				this._oComponent.oDeferredCount = 0;
				FieldExtensibilityUtil.createExtensionGroup("Audit", oExtensionGroup, this._oComponent);
				FieldExtensibilityUtil.setCdfNonSmartFieldsStatus(oExtensionGroup, this.getView().getModel("extensionModel").getData(),"editable");
				var oExtensionModelData = this.getView().getModel("extensionModel").getData();
				this._oComponent.oDeferred.done(
					function(){
						FieldExtensibilityUtil.setValueHelpFieldsEditable(oExtensionGroup, oExtensionModelData, aDropDownGroupIndex, aDropDownEdit);
					}
				);
				var oDataModel = this.getView().getModel();
				oDataModel.setUseBatch(true);
				oDataModel.read("/GRCAUD_IV_AuditType",{
					success:jQuery.proxy(function(response){
						for(var i = 0; i < response.results.length; i++){
							if(response.results[i].AuditType === sAuditType){
								if(response.results[i].CostAssignType === "IO"){
									this.getView().byId("orderNumber").setVisible(true);
									break;
								}else{
									this.getView().byId("orderNumber").setVisible(false);
									break;
								}
							}
						}
					}, this)
				},this);

				//Se llama al método que comprueba la editabilidad del campo zz_report_id
			   this.toggleReportIdEnable(this,"zz_report_id", "A001", this.getView().byId("inputCompany"),sObjectStatus,sAuditType);
			},

			onEditFormPress: function () {
				this.getView().getModel().setDeferredGroups(["changes"]);
				if (this.getView().getModel("extensionModel").getData().PlannedStartDate.editable) {
					this.oViewModel.setProperty("/bPlannedTimePeriodDisplay", false);
				}
				if (this.getView().getModel("extensionModel").getData().Company.editable) {
					this.oViewModel.setProperty("/bCompanyEdit", true);
				}
				if (this.getView().getModel("extensionModel").getData().Country.editable) {
					this.oViewModel.setProperty("/bCountryEdit", true);
				}
				this._setButtonVisibility("EDIT");
				this.oMultiInput.addValidator(this._multiInputValidator.bind(this));
				this.resetFormFieldValueState();
				this.setValueHelpFieldsEditable();
				//non cdf smart field status change
				var oExtensionGroup = this.getView().byId("extensionGroup");
				var oExtensionModelData = this.getView().getModel("extensionModel").getData();
				FieldExtensibilityUtil.setCdfNonSmartFieldsStatus(oExtensionGroup, oExtensionModelData,"editable");
				this.oAuditDataInServer = this.getView().getBindingContext().getObject();
				this.setTokens();
				
				//INICIO UPGRADE
			    this.cdfEditable();
			    
			   },
			  
			   loadDepartmentAudit : function(oEvent){
				   
				   //Se obtienen los departamentos
				   that.getDepartments( ); 
				// INI UPGRADE							   
					
					  //var sPath = "/Findings(Key=guid'"+that.sObjectId+"')";
					   //var oModelGRCAUD = new sap.ui.model.odata.ODataModel ("/sap/opu/odata/sap/GRCAUD_SRV/", true);
					  //oModelGRCAUD.read(sPath, null, null, true, jQuery.proxy(function(oObject,oResponse) {
						  //if(oObject != undefined){
							   var aFilters = [];
							//	aFilters.push(new sap.ui.model.Filter("Objtyp",sap.ui.model.FilterOperator.EQ, "ZALRT"));
							   var oModelGRCAUD = new sap.ui.model.odata.ODataModel ("/sap/opu/odata/sap/GRCAUD_SRV/", true);
							   var sPathDept = "/AuditSet(Key=guid'"+that.sObjectId+"')";
							   oModelGRCAUD.read(sPathDept, null, null, true, jQuery.proxy(function(oData,
										oResponse) {
							   
							   if(oData.ZZ_DEPARTMENT){									   
								   
									  that.modelDepartment = [];							 
								   		 that.setModel(new sap.ui.model.json.JSONModel(that.modelDepartment), "modelDepartment")
								   		 
									  that.modelDepartment = [];							 
								   		 that.setModel(new sap.ui.model.json.JSONModel(that.modelDepartment), "modelDepartment")
								   		 var findText = $.grep(  that.getModel("modelDepartments").getData(), function(i,v){
								   		 	return i.AuditDepartment == oData.ZZ_DEPARTMENT
								   		 });
								   		 
											 	var modelDepart = {};
											 	 modelDepart.AuditDepartment =  oData.ZZ_DEPARTMENT;
											 	 modelDepart.Text = findText != undefined && findText.length > 0 ? findText[0].Text : oData.ZZ_DEPARTMENT;
												   that.getModel("modelDepartment").setData(modelDepart);
												   //that.getView().getElementBinding().refresh(); 
												   that.getModel("modelDepartment").updateBindings(); 

									 };
							   }
							   ));
						  
						 // }
				
					   //}
					  // ));
				    
//				   
//					
//
			   },
			   // Función que trata los campos de departamento y grupo de auditoría, así como si el campo zz_report_id está habilitado o no
			   cdfEditable: function (oEvent) {
				   var oObject = this.getView().getBindingContext().getObject(), 
					sObjectStatus = oObject.Status;
				//Config cdfields		     
				   var filterDropdownDep = this.aDropDownEdit.filter(function(el){
				   	return el.element.sId.indexOf('zz_department') != -1;				   
				   });
				   	// Recuperamos el dropdown para asignarle el evento change y vincularlo con la función que lo trate
				   
					   if(filterDropdownDep.length > 0){				   					   
					   var dpDepartment = filterDropdownDep[0].element.mAggregations.fields[0]
					   dpDepartment.attachChange(this.onSelectZdeptChange);
					   var oAuditGroup = this.getView().byId('auditGroup');

					   // Se obtienen los departamentos activos
					   this.getDepartments(dpDepartment);	
					   
					   // se setea el departamento y obtienen los grupos del departamento
	                    this.setDepartmentGroup(this,oAuditGroup,dpDepartment.getList().getSelectedKey(),oAuditGroup.getValue());
					   }
					   
					   // Pruebas department Izda
					    filterDropdownDep = [];
						   this.oView.mAggregations.content[0].mAggregations.content.mAggregations.formContainers[0].mAggregations.formElements.forEach(function(el){
	                        if(el.mAggregations.fields[0].sId.indexOf('departmentDisplay') != -1){
	                        el.setVisible(false)
	                        }else{
	                        	if(el.mAggregations.fields[0].sId.indexOf('vbDepartment') != -1) {
	                        		el.setVisible(true);
	                        		el.mAggregations.fields[0].setVisible(true);
	                        		 filterDropdownDep.push(el);
	                        	}
	                        }
						   });
						  
					  /**  filterDropdownDep = this.oView.mAggregations.content[0].mAggregations.content.mAggregations.formContainers[0].mAggregations.formElements.filter(function(el){
						   	if(el.mAggregations.fields.length > 0){
						   		return el.mAggregations.fields[0].sId.indexOf('vbDepartment') != -1;
						   	}
						  // 	return el.mAggregations.fields[0].sId.indexOf('zz_department') != -1;				   
						   });*/
					    if(filterDropdownDep.length > 0){				   					   
							   var dpDepartment = filterDropdownDep[0].mAggregations.fields[0]
							  // dpDepartment.attachChange(this.onSelectZdeptChange); 
							   var oAuditGroup = this.getView().byId('auditGroup');

						   // Se obtienen los departamentos activos
						   this.getDepartments(dpDepartment);	
						   
						   // se setea el departamento y obtienen los grupos del departamento
		                  //  this.setDepartmentGroup(this,oAuditGroup,dpDepartment.getList().getSelectedKey(),oAuditGroup.getValue());
						   this.setDepartmentGroup(this,oAuditGroup,oObject.zz_department,oAuditGroup.getValue());
						   }
				   //// FIN Pruebas department Izda ////
					   // Se comprueba si se habilita el campo zz_report_id
					   this.toggleReportIdEnable(this,"zz_report_id", "A001", this.getView().byId("inputCompany"),sObjectStatus,this.getView().byId("type").getContent().getSelectedKey());
				   
				   
				},
				
				getDepartments : function(oAuditDepartment) {
					
					
					var that = this;
					that.oObject = that.getView().getBindingContext().getObject();		
				// Se informa el filtro para que muestre sólo los activos
				var aFilters = [];
				 aFilters.push(new sap.ui.model.Filter("Active",sap.ui.model.FilterOperator.EQ, true));			
				 //var oSelect = this.getView().byId('inputzz_department');
				 oAuditDepartment.setBusy(true); 
			      // Cargamos los grupos de Backend
				 
			    var conModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/", false);
			    conModel.read("/InfoDepAuditSet", {

			    	// Se añade el filtro para que muestre sólo los activos en la llamada
			    	filters : aFilters,		    	 
			      async: false,
			      success : function (oData, oDataResp) {
			    					    	 

			    	  aFilters.splice(0,1);
			    	  oData.results.forEach(function(value){
			            	 
				            	aFilters.push(new sap.ui.model.Filter({ path: "value", operator: sap.ui.model.FilterOperator.EQ,value1: value.AuditDepartment})) ;
			    	  });					            
				            
			    	   var oBinding = oAuditDepartment.mBindingInfos.items.binding;
                       if(oBinding){
                    	   oBinding.filter(aFilters);    
                       }
			    	   
                           var oDepartmentsItem = [];
                        that.modelDepartment = [];							 
						   		that.oView.setModel(new sap.ui.model.json.JSONModel(that.modelDepartment), "modelDepartments");
						   		 var oModelReference = that.oView.getModel("modelDepartments");
								 $.each(oData.results, function(i,n){
									 	var modelDepart = {};
									 	modelDepart.AuditDepartmentText =  n.Text;
										modelDepart.AuditDepartment = n.AuditDepartment;
										oDepartmentsItem.push(modelDepart);	

								 });

								that.oView.setModel(new sap.ui.model.json.JSONModel(oDepartmentsItem), "modelDepartments");
								that.oView.getModel("modelDepartments").updateBindings();
								 oAuditDepartment.setSelectedKey(that.oObject.zz_department);
                       oAuditDepartment.setBusy(false);		            		            

			    	  
			         }.bind(this),
			         error: function (oError) {
			           oSelect.setBusy(false);
			         }.bind(this)
			    });

			},				
				
			//  Método que setea el grupo según el departamento
				setDepartmentGroup : function(oController, oSelect, sValue, selVaue) {
					var that = this;
				  if(sValue) {
					  var oSelect = this.getView().byId('auditGroup');
					  oSelect.setBusy(true);
//				     
					  var aFilters = [];                                        		                   
			            
			             oSelect.setBusy(false);	  
					  
//		    var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/GRCAUD_SRV/", false);
		//PRL01092021 Cambiar la llamada para filtrar grupos			
//				    oDataModel.read( "/GRCAUD_CV_AuditGroup", undefined,undefined,true,
		        var oDataModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/", false);
				    oDataModel.read( "/InfoGroupActiveSet", undefined,undefined,true,	
		//PRL01092021			 
				        jQuery.proxy(
				            function(oData,response) {
				               // Para cada uno de los resultados, se filtran los grupos que correspondan con el departamento seleccionado
				            	oData.results.forEach(function(value){
				            	if( value.AuditGroup.indexOf(sValue) !== -1 ) 
					            	aFilters.push(new sap.ui.model.Filter({ path: "AuditGroup", operator: sap.ui.model.FilterOperator.EQ,value1: value.AuditGroup})) ;
					            });
					            
				            	// Se filtra en el binding para que se muestren solo los que pertenecen al departamento
		                      var oBinding = oSelect.getContent().getBinding('items');
		                       oBinding.filter(aFilters);
				             oSelect.setBusy(false);		             
				            }, this), 
				            function() { oSelect.setBusy(false);
				        });
				  }
				},
				
				_liveChanged : function() {
		            this.uiChanged = true;
		          },
		          
		          
				cdfDisplay: function (oEvent) { 
					
					   // Pruebas department Izda
				  var  filterDropdownDep = [];
					   this.oView.mAggregations.content[0].mAggregations.content.mAggregations.formContainers[0].mAggregations.formElements.forEach(function(el){
                        if(el.mAggregations.fields[0].sId.indexOf('departmentDisplay') != -1){
                        el.setVisible(true);
                        }else{
                        	if(el.mAggregations.fields[0].sId.indexOf('vbDepartment') != -1) {
                        		el.setVisible(false);
                        		el.mAggregations.fields[0].setVisible(false);
                        		 
                        	}
                        }
					   });
				},
				// Se condiciona el grupo al seleccionar el departamento
				onSelectZdeptChange:function(oEvent) {
					// Se llama al método que se encarga en filtrar los grupos
					//this.getParent().getParent().getParent().getParent().getParent().oController.setDepartmentGroup(this,oEvent.getSource(),oEvent.getParameter('selectedItem').getKey());
					this.setDepartmentGroup(this,oEvent.getSource(),oEvent.getSource().getSelectedKey());
				},
				
				// Evento que se propaga cuando se selecciona un grupo 
				onSelectZGroup : function(oEvent){
					var oObject = this.getView().getBindingContext().getObject(), 
					sObjectStatus = oObject.Status;

               	 if( !this.getView().byId("inputCompany").getValue() == "" || !this.getView().byId("inputCompany").getValue() == undefined)
					 this.toggleReportIdEnable(this,"zz_report_id", "A001", this.getView().byId("inputCompany"),sObjectStatus,this.getView().byId("type").getContent().getSelectedKey());

			}, 
		    //Numeraci�n, notas, t�tulo y conclusiones del informe 
		    toggleReportIdEnable : function(oController, sField, sValue, sCompany, sStatusKey, sAuditType) {
                sCompany = sCompany.mAggregations.customData[0].mProperties.value;
		  				  	    // En estos estados no es necesario realizar nada
			  	    if(sStatusKey != undefined) {
			  	      var notValidStatus = ["07", "08", "09", "18"];
			  	        var status = $.grep(notValidStatus, function(n,i){ if(n == sStatusKey) return n; })
			  	        if(status.length > 0) return; 
			  	    }

			  	  
			  	      var enabled = false;

			  	      // Tipo Visita Oficina == true -> manual (habilitar)
			  	      if (sAuditType.indexOf("VO") > -1) {
			  	        enabled = true;
			  	      } else {
			  	        if(sCompany) {
			  	          if ( sCompany.toUpperCase() === sValue ) //  Sociedad A001 == true -> automatica (deshabilitar)
			  	          {
			  	            enabled = false; 

			  	          } else { // ELSE -> manual (habilitar)
			  	            enabled = true;
			  	          }
			  	        }
			  	      }

			  	      if(oController.getView().byId('smartForm') != undefined) {
			  	    	  var formContainers = oController.getView().byId('smartForm').getAggregation('content').getAggregation('formContainers');
			  	              
			  	          if(formContainers) {
			  	          $.each(formContainers,function(i,n) {
			  	            var elements = n.getFormElements();
			  	           $.each(elements, function(j,m){
			  	             var fields = m.getFields();
			  	             $.each(fields, function(k,l){
			  	               if(l.sId.indexOf(sField) != -1){
			  	                 if(enabled) {
			  	                   l.setEnabled(true);
			  	                 } else {
			  	                   l.setEnabled(false);
			  	                   if (sStatusKey == undefined || sStatusKey == null || sStatusKey == "00" )
			  	                   {
			  	                     l.setValue(""); 
			  	                   }
			  	                 }
			  	               }
			  	             });
			  	           }); 
			  	          });
			  	        }
			  	      } else {
			  	        if(enabled) {
			  	          this.getView().byId('extensionGroupElementzz_department').setEnabled(true);
			  	       } else {
			  	         if (sStatusKey == undefined || sStatusKey == null || sStatusKey == "00" )
			  	         {
			  	        	this.getView().byId('extensionGroupElementzz_department').setValue("");
			  	         }
			  	       this.getView().byId('extensionGroupElementzz_department').setEnabled(false);
			  	       }

			  	      }

			  	    //  }
			  	},			  				

			    //FIN UPGRADE

			setValueHelpFieldsEditable: function () {
				var oExtensionGroup = this.getView().byId("extensionGroup");
				var oExtensionModelData = this.getView().getModel("extensionModel").getData();
				this.aDropDownGroupIndex = [];
				FieldExtensibilityUtil.setValueHelpFieldsEditable(oExtensionGroup, oExtensionModelData, this.aDropDownGroupIndex, this.aDropDownEdit);
			},

			resetFormFieldValueState: function () {
				var aErrorField = this.getView().byId("smartForm").check();
				for (var i = 0; i < aErrorField.length; i++) {
					sap.ui.getCore().byId(aErrorField[i]).setValueState(sap.ui.core.ValueState.None);
				}
				this.getView().byId("plannedTimePeriod").setValueState(sap.ui.core.ValueState.None);
				this.getView().byId("actualTimePeriod").setValueState(sap.ui.core.ValueState.None);
			},					
			
			onSaveBtnPress: function (oEvent) {
				var bIsRequiredSelectFieldEmpty = false,
				    bIsPlannedTimePeriodRequired = false,
				  bIsRequiredCdfNonSmartField = false;
				bIsPlannedTimePeriodRequired = this._checkPlannedTimePeriodField();
                bIsRequiredSelectFieldEmpty = this._checkRequiredSelectField();
                bIsRequiredCdfNonSmartField =  this._checkRequiredCdfNonSmartField();
				if (this.getView().byId("smartForm").check().length > 0 || bIsRequiredSelectFieldEmpty || bIsPlannedTimePeriodRequired || bIsRequiredCdfNonSmartField) {
					MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("MSG_CORRECT_HIGHLIGHTED_FIELDS"));
					return;
				} else {
					this._saveGeneralData(oEvent);
				}

				var oObject = this.getView().getBindingContext().getObject(), 
				sObjectStatus = oObject.Status;
				//Se llama al método que comprueba la editabilidad del campo zz_report_id
			   
				this.toggleReportIdEnable(this,"zz_report_id", "A001", this.getView().byId("inputCompany"),sObjectStatus,this.getView().byId("type").getContent().getSelectedKey());
			},
			
			_checkPlannedTimePeriodField: function() {
				var bIsPlannedTimePeriodRequired = false;
				var oPlannedTimePeriodControl = this.getView().byId("plannedTimePeriod");
				if(this.getView().getModel("extensionModel").getData().PlannedStartDate.mandatory
					&& this.getView().getModel("extensionModel").getData().PlannedStartDate.editable){
					if(oPlannedTimePeriodControl.getDateValue() === null || 
					   oPlannedTimePeriodControl.getSecondDateValue() === null) {
						bIsPlannedTimePeriodRequired = true;
					}
				}
				if(bIsPlannedTimePeriodRequired) {
					oPlannedTimePeriodControl.setValueState(sap.ui.core.ValueState.Error);
				}
				else {
					oPlannedTimePeriodControl.setValueState(sap.ui.core.ValueState.None);
				}
				return bIsPlannedTimePeriodRequired;
			},
			
			//Check if mandatory cdf dropdown fields are empty
			_checkRequiredSelectField: function(){
				var bIsRequiredSelectFieldEmpty = false;
				for(var i = 0; i < this.aDropDownEdit.length; i++){
					var isRequired = this.aDropDownEdit[i].element.getLabel().getRequired();
					var oControl = this.aDropDownEdit[i].element.getFields()[0];
					if(isRequired && !(oControl.getSelectedKey() || oControl.getValue()) ){
						oControl.setValueState(sap.ui.core.ValueState.Error);
						bIsRequiredSelectFieldEmpty = true;
					}
					else {
						oControl.setValueState(sap.ui.core.ValueState.None);
					}
				}
				return bIsRequiredSelectFieldEmpty;
			},
			
			_checkRequiredCdfNonSmartField: function(){
				var bIsFieldRequired = false;
				var oExtensionGroup = this.getView().byId("extensionGroup");
				var oGroupElements = oExtensionGroup.getGroupElements();
				for(var k = 0;k<oGroupElements.length;k++){
					for(var j=0; j<oGroupElements[k].getFields().length;j++){
						for (var i = 0; i < oGroupElements[k].getFields()[j].getCustomData().length; i++) {
							if ( oGroupElements[k].getFields()[j].getCustomData()[i].getKey() === "richText"){
								if(oGroupElements[k].getFields()[j].getRequired()
								&& oGroupElements[k].getFields()[j].getEditable()){
								if(  oGroupElements[k].getFields()[j].getValue() === "") {
									bIsFieldRequired = true;
								}
								}
							}
						}
					}
				}
				return bIsFieldRequired;
			},

			_saveGeneralData: function () {
				
				if (this._validateUI()) {
					var oDataModel = this.getView().getModel();
					oDataModel.setUseBatch(false);
					this.getView().setBusy(true);
					var sPath = this.getView().getBindingContext().getPath();
					if (!jQuery.isEmptyObject(this.oSaveData)) {
						oDataModel.update(sPath, this.oNewAuditData,
	        				{
			                	merge:true,
			                	success:jQuery.proxy(function(){
							        oDataModel.refresh();
									oDataModel.setUseBatch(true);
									this.getView().setBusy(false);									
									MessageUtil.showMsg("msgTypeSuccessful", this.getView().getModel("i18n").getResourceBundle().getText("EDIT_AUDIT_SUCCESS"));
									this.setSmartFormToDisplayMode();
									
			                	},this),
			                	error:jQuery.proxy(function(oResponse){
			                		if( oResponse.statusCode === 412 ){
			                			MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("msgEtagCheckFail"));
			                		} else{
			                			MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("EDIT_AUDIT_FAIL"));
			                		}
									oDataModel.setUseBatch(true);
									this.getView().setBusy(false);
			                	},this),
								refreshAfterChange: false
	        				}
            			);
					} else {
						oDataModel.setUseBatch(true);
						this.getView().setBusy(false);
						this.setSmartFormToDisplayMode();
						
					}
				}

			},

			_validateUI: function () {
				var bFieldIsEmpty = false;
				this.oNewAuditData = {};
				var oSmartForm = this.getView().byId("smartForm");
				var oExtensionModelData = this.getView().getModel("extensionModel").getData();
				this.oNewAuditData = FieldExtensibilityUtil.saveSmartForm(oSmartForm, oExtensionModelData);
				
				var oFloatFormatter = sap.ui.core.format.NumberFormat.getFloatInstance({
					maxFractionDigits: 2,
					parseAsString: true
				});
				if(this.getView().byId("estimatedCost").getValue() !== null){
					this.oNewAuditData.EstimatedCost = oFloatFormatter.parse(this.getView().byId("estimatedCost").getValue());
				}
				if(this.getView().byId("actualCost").getValue() !== null){
					this.oNewAuditData.ActualCost = oFloatFormatter.parse(this.getView().byId("actualCost").getValue());
				}
				//get company
				if(this.getView().getModel("extensionModel").getData().Company.editable){
					this.oNewAuditData.Company = this.getView().byId("inputCompany").getCustomData()[0].getValue("key");
					/**
					 * INI Mod RGB Editabilidad Compañia, comprobación campo obligatorio  03/05/2021 
					 *  Se comprueba si la sociedad está vacía
					 */
					if (this.getView().byId("inputCompany").getRequired() && !this.oNewAuditData.Company ) {
						this.getView().byId("inputCompany").setValueState(sap.ui.core.ValueState.Error);
						bFieldIsEmpty = true;
					}
					
					/**
					 * FIN Mod RGB Editabilidad Compañia, comprobación campo obligatorio  03/05/2021 
					 */ 
					

				}
				//get country
				if(this.getView().getModel("extensionModel").getData().Country.editable){
					this.oNewAuditData.Country = this.getView().byId("inputCountry").getCustomData()[0].getValue("key");
				}
				//get EstimatedEffort
				if (this.getView().getModel("extensionModel").getData().EstimatedEffort.editable){
					if(this.getView().byId("esitmatedEffort").getValue() === ""){
						this.oNewAuditData.EstimatedEffort = oFloatFormatter.format(this.getView().byId("esitmatedEffort").getValue());	
					}else{
						this.oNewAuditData.EstimatedEffort = oFloatFormatter.parse(this.getView().byId("esitmatedEffort").getValue());
					}
				
				} 
				//get ActualEffort
				if (this.getView().getModel("extensionModel").getData().ActualEffort.editable){
					if(this.getView().byId("actualEffort").getValue() === ""){
						this.oNewAuditData.ActualEffort = oFloatFormatter.format(this.getView().byId("actualEffort").getValue());
					}else{
						this.oNewAuditData.ActualEffort = oFloatFormatter.parse(this.getView().byId("actualEffort").getValue());
					}
				} 
				//get Actual Time Period
				if (this.getView().getModel("extensionModel").getData().ActualStartDate.editable) 
				{
					this.oNewAuditData.ActualStartDate = this._buildDateTypeFields(this.getView().byId("actualTimePeriod").getDateValue());
					this.oNewAuditData.ActualEndDate = this._buildDateTypeFields(this.getView().byId("actualTimePeriod").getSecondDateValue());
				}
				//get Planned Time Period
				if (this.getView().getModel("extensionModel").getData().PlannedStartDate.editable) 
				{
					this.oNewAuditData.PlannedStartDate = this._buildDateTypeFields(this.getView().byId("plannedTimePeriod").getDateValue());
					this.oNewAuditData.PlannedEndDate = this._buildDateTypeFields(this.getView().byId("plannedTimePeriod").getSecondDateValue());
				}
				//get tags
				this.newTags = [];
				var aTokens = this.getView().byId("multiinput").getTokens();
				for (var i = 0; i < aTokens.length; i++) {
					this.newTags.push(aTokens[i].getText());
				}
				this.oNewAuditData.Tags = this.newTags.join(";");
				
				var that =  this;
				   // UPGRADE Se obtiene el departamento y el texto de departamento
				  this.oView.mAggregations.content[0].mAggregations.content.mAggregations.formContainers[0].mAggregations.formElements.forEach(function(el){
	                      
	                        	if(el.mAggregations.fields[0].sId.indexOf('vbDepartment') != -1) {
	                        		that.oNewAuditData.zz_department = el.mAggregations.fields[0].getSelectedKey();
	                        		that.oNewAuditData.AuditDepartmentText = el.mAggregations.fields[0].getSelectedText();
	                        	}

						   });
				
				this.oSaveData = this._compareData(this.oAuditDataInServer, this.oNewAuditData);

				if(this.getView().getModel("extensionModel").getData().Title.editable){
					if (!this.oNewAuditData.Title || this.oNewAuditData.Title === "") {
						this.getView().byId("title").setValueState(sap.ui.core.ValueState.Error);
						bFieldIsEmpty = true;
					}
				}
				
				if (bFieldIsEmpty) {
					MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("MSG_REQUIRED_FIELD"));
					return false;
				}
				return true;
			},
			
			_formatTimePeriod: function (sStartDate, sEndDate) {
				if (sStartDate !== null && sEndDate !== null) {
					sStartDate = formatter.formatRecordDate(sStartDate);
					sEndDate = formatter.formatRecordDate(sEndDate);	
					return formatter.formatDate(sStartDate) + " - " + formatter.formatDate(sEndDate);
				}
				return "";
			},
			
			_buildDateTypeFields: function (sValue) {
				if (sValue !== null) {
					var yyyy = sValue.getFullYear().toString();
					var mm = (sValue.getMonth() + 1).toString();
					var dd = sValue.getDate().toString();
					sValue = yyyy + "-" + (mm[1] ? mm : "0" + mm[0]) + "-" + (dd[1] ? dd : "0" + dd[0]) + "T00:00:00";
					return sValue;
				}
				return null;
			},

			_compareData: function (oOldData, oNewData) {
				var oReturnData = {};
				var sNew, sOld;
				if (oOldData !== undefined) {
					for (var oField in oNewData) {
						sNew = oNewData[oField];
						sOld = oOldData[oField];
						if (oNewData[oField] && oOldData[oField] && typeof oNewData[oField] === "object" && typeof oOldData[oField] === "object" &&
							oNewData[oField].toISOString() && oOldData[oField].toISOString()) {
							//Both are Time
							sNew = oNewData[oField].toISOString().substring(0, 19);
							sOld = oOldData[oField].toISOString().substring(0, 19);
						} else if (oOldData[oField] && typeof oNewData[oField] !== "object" && typeof oOldData[oField] === "object" && oOldData[oField]
							.toISOString()) {
							sOld = oOldData[oField].toISOString().substring(0, 19);
						} else if (oNewData[oField] && typeof oNewData[oField] === "object" && typeof oOldData[oField] !== "object" && oNewData[oField]
							.toISOString()) {
							sNew = oNewData[oField].toISOString().substring(0, 19);
						}
						if (sNew !== sOld) {
							oReturnData[oField] = oNewData[oField];
						}
					}
					return oReturnData;
				}
				return oNewData;
			},

			setSmartFormToDisplayMode: function () {
				this.setDropDownFieldsEditableToFalse();
				//non cdf smart field status change
				var oExtensionGroup = this.getView().byId("extensionGroup");
				var oExtensionModelData = this.getView().getModel("extensionModel").getData();
				FieldExtensibilityUtil.setCdfNonSmartFieldsStatus(oExtensionGroup, oExtensionModelData,"display");
				this._setButtonVisibility("DISPLAY");
				this.cdfDisplay();
				this.getView().getModel().resetChanges();
				
			},
			

			onCancelBtnPress: function () {
				if (this.getView().getModel("extensionModel").getData().SmartForm.editable === true) {
					this.getView().getModel().resetChanges();
					this.setDropDownFieldsEditableToFalse();
					//non cdf smart field status change
					var oExtensionGroup = this.getView().byId("extensionGroup");
					var oExtensionModelData = this.getView().getModel("extensionModel").getData();
					FieldExtensibilityUtil.setCdfNonSmartFieldsStatus(oExtensionGroup, oExtensionModelData,"display");
					this._setButtonVisibility("DISPLAY");
					this.oMultiInput.removeAllTokens();
					this.oMultiInput.setValue();
				}
				this.getView().byId("actualEffort").setValueState(sap.ui.core.ValueState.None);
				this.getView().byId("esitmatedEffort").setValueState(sap.ui.core.ValueState.None);
				this.cdfDisplay();
			},
			
			setDropDownFieldsEditableToFalse: function() {
				for (var i = 0; i < this.aDropDownGroupIndex.length; i++) {
					this.getView().byId("extensionGroup").removeGroupElement(this.getView().byId("extensionGroup").getGroupElements()[this.aDropDownGroupIndex[
						i].index]);
					this.getView().byId("extensionGroup").insertGroupElement(this.aDropDownGroupIndex[i].element, this.aDropDownGroupIndex[i].index);
				}

			},
			
			_setButtonVisibility: function (sMode) {
				if (sMode === "EDIT") {
					this.oViewModel.setProperty("/bFormDisplay", false);
					if(this.getView().getModel("extensionModel").getData().ActualStartDate.editable){
						this.oViewModel.setProperty("/bActualTimePeriodDisplay", false);
					}
					this.oViewModel.setProperty("/bTagDisplay", false);
				} else if (sMode === "DISPLAY") {
					this.oViewModel.setProperty("/bCompanyEdit", false);
					this.oViewModel.setProperty("/bCountryEdit", false);
					this.oViewModel.setProperty("/bPlannedTimePeriodDisplay", true);
					this.oViewModel.setProperty("/bActualTimePeriodDisplay", true);
					this.oViewModel.setProperty("/bTagDisplay", true);
					this.oViewModel.setProperty("/bFormDisplay", true);
				} else {
					this.oViewModel.setProperty("/bCompanyEdit", false);
					this.oViewModel.setProperty("/bCountryEdit", false);
					this.oViewModel.setProperty("/bPlannedTimePeriodDisplay", true);
					this.oViewModel.setProperty("/bActualTimePeriodDisplay", true);
					this.oViewModel.setProperty("/bTagDisplay", true);
					this.oViewModel.setProperty("/bFormDisplay", true);
				}
			},
			
			_restoreSelectFieldStatus: function(){
				for(var i = 0; i < this.aDropDownEdit.length; i++){
					var oControl = this.aDropDownEdit[i].element.getFields()[0];
					oControl.setValueState(sap.ui.core.ValueState.None);
				}
			},

			setTokens: function () {
				this.oMultiInput.removeAllTokens();
				this.oMultiInput.setValue();
				var oldTokens = this.getView().byId("tokenDisplay").getTokens();
				var oldTagData = [];
				for(var i=0; i<oldTokens.length; i++){
					oldTagData.push({
						TagName: oldTokens[i].getText(),
						TagKey: oldTokens[i].getKey()
					});	
				}
				
				var len = oldTagData.length;
				var oldTagText = [];
				for (var j = 0; j < len; j++) {
					var token = new sap.m.Token({
						text: oldTagData[j].TagName,
						key: oldTagData[j].TagKey
					});
					this.oMultiInput.addToken(token);
					oldTagText.push(oldTagData[j].TagName);
				}
				this.oAuditDataInServer.Tags = oldTagText.join(";");
			},

			_multiInputValidator: function (args) {
				var text = args.text;
				if (text.indexOf(";") !== -1) {
					MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("TAGS_MSG_FORBIDDEN_CHAR"));
					return sap.m.MultiInput.WaitForAsyncValidation;
				}
				return new sap.m.Token({
					key: text,
					text: text
				});

			},
			
			onChangeCheck: function(oEvent) {
				if(oEvent.getSource().getProperty("textLabel") === "Title" && oEvent.getParameters().newValue === ""){
					this.getView().byId("title").setValueStateText(this.getView().getModel("i18n").getResourceBundle().getText("MSG_REQUIRED_TITLE_FIELD"));
				}else if(oEvent.getSource().getProperty("textLabel") === "Title" && oEvent.getParameters().newValue !== "") {
					this.getView().byId("title").setValueState(sap.ui.core.ValueState.None);
				}
			},
			onEstimatedEffortCheck: function(oEvent) {
				this._negativeNumberCheck(oEvent, "esitmatedEffort");
			}, 
			onEstimatedCostCheck: function(oEvent) {
				this._negativeNumberCheck(oEvent, "estimatedCost");
			},
			
			onActualEffortCheck: function(oEvent) {
				this._negativeNumberCheck(oEvent, "actualEffort");
			}, 
			onActualCostCheck: function(oEvent) {
				this._negativeNumberCheck(oEvent, "actualCost");
			},
			_negativeNumberCheck: function(oEvent, fieldId){
				var fieldIdMessageKeyMap = new Map([
					["esitmatedEffort", "MSG_REQUIRED_EFFORT_FIELD"],
					["actualEffort", "MSG_REQUIRED_EFFORT_FIELD"],
					["estimatedCost", "MSG_REQUIRED_COST_FIELD"],
					["actualCost", "MSG_REQUIRED_COST_FIELD"]
				]);

				var oFloatFormatter = sap.ui.core.format.NumberFormat.getFloatInstance({
					maxFractionDigits: 2,
					parseAsString: false,
					emptyString: 0
				});
				var fieldNumber = oFloatFormatter.parse(oEvent.getParameters().newValue);
				if(Math.sign(fieldNumber) === -1 || isNaN(Math.sign(fieldNumber))){
					this.getView().byId(fieldId).setValueStateText(this.getView().getModel("i18n").getResourceBundle().getText(fieldIdMessageKeyMap.get(fieldId))).setValueState(sap.ui.core.ValueState.Error);
				}else if(Math.sign(fieldNumber) !== -1) {
					this.getView().byId(fieldId).setValueState(sap.ui.core.ValueState.None);
				}
			},
			handleCountryValueHelp: function (oEvent) {
				this.inputId = oEvent.getSource().getId();
				this._openValueHelpDialog("LAND1");
			},
	
			handleCompanyValueHelp: function (oEvent) {
				this.inputId = oEvent.getSource().getId();
				this._openValueHelpDialog("GRCAUD_COMPANY_CODE");
			},

			_openValueHelpDialog: function (sValue) {
				var sItemsBindingPath = "/DataElementSet('" + sValue + "')/NameValuePairs";
				if (this._ValueHelpDialog) {
					this._ValueHelpDialog.destroy();
				}
				this._ValueHelpDialog = new sap.m.SelectDialog({
					title: "{i18n>generalSearchDialog}",
					items: {
						path: sItemsBindingPath,
						template: new sap.m.StandardListItem({
							title: "{Name}",
							description: "{Value}"
						})
					},
					growingThreshold: 20,
					search: this.handleSearch.bind(this),
					cancel: this.handleValueHelpClose.bind(this),
					confirm: this.handleValueHelpClose.bind(this)
				});
				this.getView().addDependent(this._ValueHelpDialog);
				this._ValueHelpDialog.open();
			},
			
			onLiveChange: function(oEvent){
				var oNewValue = oEvent.getSource().getValue();
				if(oNewValue === ""){
					var oInputField = this.getView().byId(oEvent.getSource().getId());
					oInputField.setValue(oNewValue);
					oInputField.removeAllCustomData();
					oInputField.addCustomData(new sap.ui.core.CustomData({
						key : "key",
						value : oNewValue 
					}));
					oInputField.setValueState(sap.ui.core.ValueState.None);
				}
				
				// Si el campo modificado es company, se comprueba la editabilidad del campo zz_report_id
				if(oInputField.sId.indexOf('inputCompany') !== -1){
					var oObject = this.getView().getBindingContext().getObject(), 
					sObjectStatus = oObject.Status;
					this.toggleReportIdEnable(this,"zz_report_id", "A001", oInputField,sObjectStatus,this.getView().byId("type").getContent().getSelectedKey());
				}
			},
	
			// search in company and country value help dialog
			handleSearch: function (oEvent) {
				var sQuery = oEvent.getParameter("value");
				var aFilters = [];
				aFilters.push(new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, sQuery));
				aFilters.push(new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.Contains, sQuery));
				oEvent.getSource().getBinding("items").filter(aFilters, sap.ui.model.FilterType.Application);
			},
	
			// Triggered when value help dialog of field Company and Coutry close
			handleValueHelpClose: function (oEvent) {
				var oSelectedItem = oEvent.getParameter("selectedItem");
				if (oSelectedItem) {
					var oInputField = this.getView().byId(this.inputId);
					oInputField.setValue(oSelectedItem.getDescription());
					oInputField.removeAllCustomData();
					oInputField.addCustomData(new sap.ui.core.CustomData({
						key : "key",
						value : oSelectedItem.getTitle()
					}));
					oInputField.setValueState(sap.ui.core.ValueState.None);
				}
				oEvent.getSource().getBinding("items").filter([]);
				
				//Si el campo modificado es company, se comprueba el campo de informe
				if(oInputField.sId.indexOf('inputCompany') !== -1){
					var oObject = this.getView().getBindingContext().getObject(), 
					sObjectStatus = oObject.Status;
					this.toggleReportIdEnable(this,"zz_report_id", "A001", oInputField,sObjectStatus,this.getView().byId("type").getContent().getSelectedKey());
				}
			},
			
			onSuggestionItemSelected: function (oEvent) {
				var oSelectedItem = oEvent.getParameter("selectedItem");
				if (oSelectedItem) {
					oEvent.getSource().setValue(oSelectedItem.getAdditionalText());
					oEvent.getSource().removeAllCustomData();
					oEvent.getSource().addCustomData(new sap.ui.core.CustomData({
						key : "key",
						value : oSelectedItem.getKey()
					}));
					oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
				}
			},
	
			// Handler of event suggest of field company and country
			handleSuggest: function (oEvent) {
				var sTerm = oEvent.getParameter("suggestValue");
				var aFilters = [];
				var oFilter = {};
				if (sTerm) {
					aFilters.push(new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, sTerm));
					aFilters.push(new sap.ui.model.Filter("Value", sap.ui.model.FilterOperator.Contains, sTerm));
					oFilter = new sap.ui.model.Filter(aFilters, false);
				}
				oEvent.getSource().getBinding("suggestionItems").filter([oFilter]);
			},
			
			onExit: function () {
				sap.ui.getCore().getEventBus().unsubscribe("sap.grc.acs.aud.audit.EventBus", "resetBlockToDisplayMode", this.setSmartFormToDisplayMode, this);
				FieldExtensibilityUtil.destoryElements(this.aDropDownEdit);
				var oExtensionGroup = this.getView().byId("extensionGroup");
				FieldExtensibilityUtil.destoryNonSmartFieldElements(oExtensionGroup);
			}

		});
	}

);
