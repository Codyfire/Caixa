
/**
 * @class Provides enh.ancement methods
 * @static
 */

 
/***
 * Constantes utilizadas para enh.ancements
 ***/
var constants = {
    con : {
      portal : "/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/",
      enh : "/sap/opu/odata/sap/ZGRCAUD_enh._SRV/",
      std : "/sap/opu/odata/sap/GRCAUD_SRV/"
    },
    Aum0028 : {
      Employee : "Empleados",
      Client : "Clientes", 
      Center: "Centros",
      empTable : {
        Employee : "Empleado",
        Resolution : "Resolución"
      },
      clieTable: {
        Name: "Nombre",
        /**
         *  INI RTC 692322 Rafael Galán Baquero 07/03/2019
         *  Código antiguo
         * Nif: "NIF",
         * Código nuevo  
         */
        // Se cambia la etiqueta NIF
        Nif:"NIF/CIF",
        /**
         * FIN RTC 692322 Rafael Galán Baquero 07/03/2019
         */ 
        Participation : "Participación"
      },
      centerTable: {
        Id: "SAP ID",
        Title: "Título",
        Center: "Centro"
      }
    },
    Aum0002 : {
      auditGroup : "09423", // Territoriales
      auditGroup2 : "16581", // Fraude
      company : "A001",
      zfield : "ZZ_REPORT_ID",
      auditType: "VO" // Visita Oficina
    },
    Aum0010 : {
      deptUrl : "/InfoDepAuditSet",
      /**
  	 * INI MOD PPM 069908 Rafael Galán Baquero 10/02/2021
  	 * Código antiguo
  	 * grpUrl : "/DataElementSet('GRCAUD_GROUP')/NameValuePairs"
  	 * Código nuevo
  	 */   
      grpUrl : "/GRCAUD_CV_AuditGroup"      
     /**
  	 * FIN MOD PPM069908 Rafael Galán Baquero 10/02/2021
  	*/
    },
    Aum0011 : {
      temasUrl : "/InfoThemesSet",
      createTemas : "/ActionSet",
      getTemas : "/ActionSet",
      getAssignaments : "/ActionSet",
      deleteTema : "/AssignmentSet"
    }
};

if (!String.prototype.startsWith) {
    String.prototype.startsWith = function(stringBuscada, posicion) {
      posicion = posicion || 0;
      return this.indexOf(stringBuscada, posicion) === posicion;
    };
  }

if (!String.prototype.replaceAll) {
    String.prototype.replaceAll = function(search, replacement) {
      var target = this;
      return target.replace(new RegExp(search, 'g'), replacement);
    }
  }
if (!String.prototype.contains) {
  String.prototype.contains = function(it) { return this.indexOf(it) != -1; };
}

if (!String.prototype.capitalize) {
  String.prototype.capitalize =  function() {
    var str = this.toLowerCase();
    return str.replace(/(?:^\w|[A-Z]|\b\w)/g, function(letter, index) {
        return letter.toUpperCase();
      }).replace(/\s+/g, ' ');
  };
}
/**
 * AUM0002: Numeraci�n, notas, t�tulo y conclusiones del informe - U0184284 - 24/11/2016
 */
//enh.toggleReportIdEnable = function(oController, sField, sValue, sCompany, sStatusKey, sAuditType) {
function toggleReportIdEnable(oController, sField, sValue, sCompany, sStatusKey, sAuditType) {

    // En estos estados no es necesario realizar nada
    if(sStatusKey != undefined) {
      var notValidStatus = ["07", "08", "09", "18"];
        var status = $.grep(notValidStatus, function(n,i){ if(n == sStatusKey) return n; })
        if(status.length > 0) return; 
    }

  
      var enabled = false;

      // Tipo Visita Oficina == true -> manual (habilitar)
      if (sAuditType.indexOf(enh.constants.Aum0002.auditType) > -1) {
        enabled = true;
      } else {
        if(sCompany) {
          if ( sCompany.toUpperCase() === sValue ) //  Sociedad A001 == true -> automatica (deshabilitar)
          {
            enabled = false;

          } else { // ELSE -> manual (habilitar)
            enabled = true;
          }
        }
      }

      if(oController.getView().oEditForm != undefined) {
        var form = oController.getView().oEditForm.getAggregation("form");
          var formContainers = form.getAggregation("formContainers")
              
          if(formContainers) {
          $.each(formContainers,function(i,n) {
            var elements = n.getFormElements();
           $.each(elements, function(j,m){
             var fields = m.getFields();
             $.each(fields, function(k,l){
               if(l.sId.indexOf(sField) != -1){
                 if(enabled) {
                   l.setEnabled(true);
                 } else {
                   l.setEnabled(false);
                   if (sStatusKey == undefined || sStatusKey == null || sStatusKey == "00" )
                   {
                     l.setValue("");
                   }
                 }
               }
             });
           }); 
          });
        }
      } else {
        if(enabled) {
          sap.ui.getCore().byId('cdfAudit__form6ZZ_REPORT_ID').setEnabled(true);
       } else {
         if (sStatusKey == undefined || sStatusKey == null || sStatusKey == "00" )
         {
           sap.ui.getCore().byId('cdfAudit__form6ZZ_REPORT_ID').setValue("");
         }
         sap.ui.getCore().byId('cdfAudit__form6ZZ_REPORT_ID').setEnabled(false);
       }

      }

    //  }
};

/**
 * AUM0010 Condicionar campos grupo auditoria con departamento - U0184284 - 16/01/2017
 **/
//enh.getDepartmentDesc = function(deptValue) {
function getDepartmentDesc (deptValue) {
  var value = "";

  if(deptValue)
  {
    if(deptValue != "") {
      // Cargamos los grupos de Backend
      var conModel = new sap.ui.model.odata.ODataModel(enh.constants.con.portal, false);
      conModel.read( enh.constants.Aum0010.deptUrl, {
        async: false,
        success : function (oData, oDataResp) {
          var obj = $.grep(oData.results, function(n,i){
            if(n.AuditDepartment == deptValue) {
              return n
            }
          });
          if(obj.length > 0)
           //value =  obj[0].AuditDepartment + " - " + obj[0].Text; //.capitalize();
        	  value =  obj[0].Text; //.capitalize();
           }.bind(this),
           error: function (oError) {
             
           }.bind(this)
      });
    }
  }
    
  return value;
}

//enh.getDepartments = function(oSelect) {
	function getDepartments (oSelect) {
	/**
	 * INI MOD PPM 069908 Rafael Galán Baquero 10/02/2021
	 * Código nuevo
	 */
	// Se informa el filtro para que muestre sólo los activos
	var aFilters = [];
	 aFilters.push(new sap.ui.model.Filter("Active",sap.ui.model.FilterOperator.EQ, true));
	 /**
		 * FIN MOD PPM069908 Rafael Galán Baquero 10/02/2021
	*/
	 
    // Creamos el template para el searchField
    var oTemplate = new sap.ui.core.ListItem({
         key : "{AuditDepartment}" 
      }).bindProperty("text", {
        parts:["AuditDepartment", "Text"],
        formatter: function(AuditDepartment, Text){
//          return AuditDepartment + " - " + Text; //.capitalize();
        	 return Text;
        }
      })

      // Cargamos los grupos de Backend
    var conModel = new sap.ui.model.odata.ODataModel(enh.constants.con.portal, false);
    conModel.read(enh.constants.Aum0010.deptUrl, {
    	
    	/**
    	 * INI MOD PPM 069908 Rafael Galán Baquero 10/02/2021
    	 * Código nuevo
    	 */
    	// Se añade el filtro para que muestre sólo los activos en la llamada
    	filters : aFilters,
    	 /**
    		 * FIN MOD PPM069908 Rafael Galán Baquero 10/02/2021
    	*/
      async: false,
      success : function (oData, oDataResp) {
        var oModel = new sap.ui.model.json.JSONModel(oData.results);
        oSelect.setModel(oModel);
        oSelect.bindItems("/",oTemplate);
        oSelect.setBusy(false);
         }.bind(this),
         error: function (oError) {
           oSelect.setBusy(false);
         }.bind(this)
    });

}

//enh.setDepartmentGroup = function(oController, oSelect, sValue, selVaue) {
	function setDepartmentGroup(oController, oSelect, sValue, selVaue) {

  //var auditDepart = sap.ui.getCore().byId("select_department").getSelectedKey();
  if(sValue) {
    sap.ui.getCore().byId("select_group").setBusy(true);

    var oDataModel = sap.hpa.grcaud.oODataModelPool.get();
    
	
    oDataModel.read( enh.constants.Aum0010.grpUrl, undefined,undefined,true,
	 
        jQuery.proxy(
            function(oData,response) {
             var oTemplate = new sap.ui.core.ListItem(
               {
            	  /** INI MOD PPM 069908 Rafael Galán Baquero 10/02/2021
            	   * 	Código antiguo
                	text : "{Value}",
                	key : "{Name}"
                
            	   * Codigo nuevo
            	   */
                	text : "{AuditGroupText}",
                    key : "{AuditGroup}"
                  /**
            	  * FIN MOD PPM069908 Rafael Galán Baquero 10/02/2021
            	  */
               });
                  var oModel = new sap.ui.model.json.JSONModel();
                   var data = $.grep(oData.results, function(n,i){
            	 /**
            		 * INI MOD PPM 069908 Rafael Galán Baquero 10/02/2021
            		 * Código antiguo
            		 * if( n.Name.startsWith(sValue) ) return n;
            		 * Código nuevo
            		 */
                	 //if( n.AuditGroup.includes(sValue) ) return n;
               	 	if( n.AuditGroup.indexOf(sValue) !== -1 ) return n;
            	    /**
            		 * FIN MOD PPM069908 Rafael Galán Baquero 10/02/2021
            	*/
               
            });
             oModel.setData(data);
             sap.ui.getCore().byId("select_group").setModel(oModel);
             sap.ui.getCore().byId("select_group").bindItems("/",oTemplate);
             sap.ui.getCore().byId('select_group').setSelectedKey(selVaue);
             sap.ui.getCore().byId("select_group").setBusy(false);
            // this.selectNo++;
            // this.setSelectKeys();
            }, this), function() { sap.ui.getCore().byId("select_group").setBusy(false);
        });
  }
}

/***
 * AUM0011: A�adir temas a las acciones del standard.
 */

//enh.getTemasMultiInput = function(){
	function getTemasMultiInput(){
  // Cargamos los posibles temas de backend

  var conModel = new sap.ui.model.odata.ODataModel(enh.constants.con.portal, false);
  var oModel;
  conModel.read(enh.constants.Aum0011.temasUrl, {
    async: false,
    success : function (oData, oDataResp) {
      oModel = new sap.ui.model.json.JSONModel(oData);
      console.log(oModel);
       }.bind(this),
       error: function (oError) {
         
       }.bind(this)
  });

  if(sap.ui.getCore().byId("temasMultiInput"))sap.ui.getCore().byId("temasMultiInput").destroy();

  var oMultiInput = new sap.m.MultiInput("temasMultiInput",{
    width:"50%",
    visible:true,
    editable:true,
    suggestionColumns : [
      new sap.m.Column({
        styleClass : "name",
        hAlign : "Left",
        header : new sap.m.Label({
          text : "Temas"
        })
      })
    ],
    layoutData : new sap.ui.layout.ResponsiveFlowLayoutData({
      weight : 7
    })
  }).setModel(oModel).addStyleClass("temasMultiInput");

  oMultiInput.addValidator(function(args){
    if (args.suggestionObject){
      var text = args.suggestionObject.getCells()[0].getText();
      var key = args.suggestionObject.getCells()[0].getAggregation("customData")[0].getProperty("value");
      return new sap.m.Token({key: key, text: text});
    }
    return null;
  });


  var oTableItemTemplate = new sap.m.ColumnListItem({
    type : "Active",
    vAlign : "Middle",
    cells : [
      new sap.m.Label({
        text : "{Theme}",
        customData: new sap.ui.core.CustomData({value:"{Key}"})
      })
    ]
  });

  oMultiInput.bindAggregation("suggestionRows","/results",oTableItemTemplate);

  return oMultiInput;
}

//enh.getTemasHoritzontalLayout = function(){
	function getTemasHoritzontalLayout(){
  if(sap.ui.getCore().byId("hLayout"))sap.ui.getCore().byId("hLayout").destroy();
  
  return new sap.ui.layout.HorizontalLayout("hLayout",{
   layoutData : new sap.ui.layout.ResponsiveFlowLayoutData({
      weight : 7
    })
   });
}

//Funcion que guarda temas a una acci�n estandard
//enh.saveTemas = function(oData, key){
	function saveTemas(oData, key){

  var conModel = new sap.ui.model.odata.ODataModel(enh.constants.con.enh, false);
  conModel.create(enh.constants.Aum0011.createTemas + "(binary'" + key + "')/ThemeAssignments" ,oData,false,function(dataResp){

  },function(oError){

  });
}

//	enh.getTemas = function(planKey, mode){
function getTemas(planKey, mode){
	/**
	 * INI RTC 922306	AUM - No se ven los temas en los tiles estandar de SAP
	 * 16/12/2020 U0192021
	 * Codigo antiguo
	 
  var conModel = new sap.ui.model.odata.ODataModel(enh.constants.con.enh, false);

  //Inicio Modificación Upgrade - Error acceso a planes de acción desde  Mis auditorias 11.10.2018
  //  U0184284 (Rafael Galan Baquero) 
  // Cod antiguo
  //conModel.read(enh.constants.Aum0011.getTemas + "(binary'" + planKey + "')/Themes",{

  //  Cod nuevo
  // se pasa a binario para hacer la llamada
  var planKey_bin = convertKey(planKey);
  conModel.read(enh.constants.Aum0011.getTemas + "(binary'" + planKey_bin + "')/Themes",{
    //Fin Modificación Error acceso a planes de acción desde  Mis auditorias - Upgrade 11.10.2018
	 
	 *   Código nuevo
	 */
	var conModel = new sap.ui.model.odata.ODataModel(enh.constants.con.portal, false);
	  var planKey_bin = "binary'" + planKey.toUpperCase() +"'";
	  var url = "/InfoActionDetailSet?$filter=ActionKey eq " + planKey_bin + "&$expand=InfoThemes";
	  conModel.read(url,{
	/**
	 * FIN RTC 922306	AUM - No se ven los temas en los tiles estandar de SAP
	 *  16/12/2020 U0192021
	*/
	
    async: true,
        success : function (oData) {
          if(mode == "DISPLAY" || mode == undefined){
            if(sap.ui.getCore().byId("hLayout").getContent().length != 0)
              sap.ui.getCore().byId("hLayout").removeAllContent();

            /**
        	 * INI RTC 922306	AUM - No se ven los temas en los tiles estandar de SAP
        	 * 16/12/2020 U0192021
        	 * Codigo antiguo      
             * $.each(oData.results,function(i,n){
             * 
             * Código nuevo
             */ 
            if(oData.results[0].InfoThemes.results !== undefined)                        
                $.each(oData.results[0].InfoThemes.results,function(i,n){
            /**
        	 * FIN RTC 922306	AUM - No se ven los temas en los tiles estandar de SAP
        	 *  16/12/2020 U0192021
        	*/
              sap.ui.getCore().byId("hLayout").addContent(
                new sap.m.Text({
                  text: n.Theme,
                  customData: new sap.ui.core.CustomData({value: n.Key})
                }).addStyleClass("greyBackground")
              );
            });
          }else if(mode == "EDIT"){
            if(sap.ui.getCore().byId("temasMultiInput").getTokens().length != 0)
              sap.ui.getCore().byId("temasMultiInput").removeAllTokens();
            /**
        	 * INI RTC 922306	AUM - No se ven los temas en los tiles estandar de SAP
        	 * 16/12/2020 U0192021
        	 * Codigo antiguo      
             * $.each(oData.results,function(i,n){
             * 
             * Código nuevo
             */ 
            if(oData.results[0].InfoThemes.results !== undefined)                        
                $.each(oData.results[0].InfoThemes.results,function(i,n){
            /**
        	 * FIN RTC 922306	AUM - No se ven los temas en los tiles estandar de SAP
        	 *  16/12/2020 U0192021
        	*/
            sap.ui.getCore().byId("temasMultiInput").addToken(
              new sap.m.Token({
                text: n.Theme,
                key: n.Key,
                customData: new sap.ui.core.CustomData({value: "inBackend"}),
                delete: function(oEvent){
                  if(sap.ui.getCore().getModel("deletedThemes") == undefined){
                    var oModel = new sap.ui.model.json.JSONModel();
                    oModel.getData().temas = [];
                    oModel.getData().temas.push({theme: oEvent.mParameters.token.mProperties.key});
                    sap.ui.getCore().setModel(oModel,"deletedThemes");
                  }else{
                    var oModel = sap.ui.getCore().getModel("deletedThemes");
                    oModel.getData().temas.push({theme: oEvent.mParameters.token.mProperties.key});
                  }
                }
              })
            );
          });
          }
        }.bind(this),
        error: function (oError) {

        }.bind(this)
  });
}

//Funcion que hace un get de las asignaciones de temas a una accion
//enh.getAssignaments = function(actionKey){
function getAssignaments(actionKey){
  var conModel = new sap.ui.model.odata.ODataModel(enh.constants.con.enh, false);
  conModel.read(enh.constants.Aum0011.getAssignaments + "(binary'" + actionKey + "')/ThemeAssignments",{
    async: false,
        success : function (oData) {
          var oModel = new sap.ui.model.json.JSONModel();
      oModel.setData(oData);
      sap.ui.getCore().setModel(oModel,"assignamentsModel");
        }.bind(this),
        error: function (oError) {

        }.bind(this)
  });
}

//Funci�n que hace un delete de un tema en backend
//enh.deleteTheme = function(action){
function deleteTheme(action){
  var conModel = new sap.ui.model.odata.ODataModel(enh.constants.con.enh, false);
  conModel.remove(enh.constants.Aum0011.deleteTema + "(Key=binary'" + 
      convertKey(action.Key) +"',Type='ZTHEME',HostBoKey=binary'" + convertKey(action.HostBoKey) + 
      "',HostNodeKey=binary'" + convertKey(action.HostNodeKey) + "',HostKey=binary'" + convertKey(action.HostKey) + "')"
    ,false, 
    function(oDataRes, oResponse){
          
      },function(oData, oResponse){

    });
}

/***
 * end enh.acement.
 */


/***
 * Utils
 */
//enh.formatUrl = function(source, params) {
function formatUrl(source, params) {

  // source -> String con parametros {0},{1}...
  // params -> Array con los valores ["Hello","World!"]

  // Replace all params in function
  if(params) {
      $.each(params,function (i, n) {
        if(n != undefined && n != null) {
          source = source.replace(new RegExp("\\{" + i + "\\}", "g"), function () {
                  return '\'' + n + '\'';
              });
        }
      })
  }

  // Other params will be replace by ''
    source = source.replace(new RegExp("\\{[0-9]+\\}", "g"), function () {
            return '\'\'';
    });
    
    return source;
}