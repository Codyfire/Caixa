sap.ui.jsview("sap.grc.acs.aud.audit.initiate.extended.block.view.Lists", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf grcaud.lists.lists
	*/ 
	getControllerName : function() {
		return "sap.grc.acs.aud.audit.initiate.extended.block.List.controller.Lists";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf grcaud.lists.lists
	*/ 
	createContent : function(oController) {
 		return new sap.m.Page({
			title: "Title",
			content: [
			
			]
		});
	},
	
	
	_getInTeam: function(auditKey) {
		// Find current user in Team
		var inTeam = false;
		var oModel = sap.hpa.grcaud.oODataModelPool.get();
		oModel.read("/AuditSet(guid'"+ auditKey + "')/UserRoles", {	
																	async: false, 
																	success: success, 
																	error: error 
																  }
		);
		
		function success(oData,oDataRes)
		{
			var currUser = window.oShell.getUser().getId();
			var users = $.grep(oData.results,function(n){ return (n.UserID == currUser); });
			
			if(users.length>0){
				inTeam = true;
			}
		}
		
		function error(error) {
			console.log("Error retrieving Team members");
		}
		
		return inTeam;
	}

});
