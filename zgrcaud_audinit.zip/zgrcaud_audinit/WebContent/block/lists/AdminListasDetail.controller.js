sap.ui.controller("sap.grc.acs.aud.audit.initiate.extended.block.lists.AdminListasDetail", {

/**
* Called when a controller is instantiated and its controller controls (if available) are already created.
* Can be used to modify the controller before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf zportalaudit.controller.AdminListasDetail
*/
//	onInit: function() {
//	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's controller is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf zportalaudit.controller.AdminListasDetail
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the controller has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf zportalaudit.controller.AdminListasDetail
*/
	onAfterRendering: function() {
		if(this.oView.sId.indexOf('distListView'))
		setTimeout(function(){ refrescarEstilsTaula(sap.ui.getCore().byId(this.oView.sId).centros.table); }, 1000);
	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf zportalaudit.controller.AdminListasDetail
*/
//	onExit: function() {
//
//	}
	
	doSave: function(oEvent) {		
		var oController = this;
		var view = oController.getView();
		
		//Agafo els models de dades
		var oModelPersonas = view.personas.listContainer.getModel();
		//Nos han insertado los campos obligatorios
		var listaPersonas = [];
		if(oModelPersonas.getData().results != undefined){
			if(oModelPersonas.getData().results.length > 0){
				$.each(oModelPersonas.getData().results,function(i,n){

					listaPersonas.push({UserId: n.UserId});
				});
			}
		} else {
			listaPersonas = [{}];
		}
		
		/*$.each(sap.ui.getCore().byId("personasView").listContainer.getItems(),function(i,n){
			var bindingContext = n.getBindingContext().sPath;
			var item = sap.ui.getCore().byId("personasView").listContainer.getModel().getProperty(bindingContext);
			listaPersonas.push({UserId: item.Id});
		});*/
		
		
		//Cojo el modelo de datos
		var oModelDelegados = view.delegados.listContainer.getModel();
		//Nos han insertado los campos obligatorios
		var listaDelegados = [];
		if(oModelDelegados) {
			if(oModelDelegados.getData().results != undefined){
				if(oModelDelegados.getData().results.length > 0){
					$.each(oModelDelegados.getData().results,function(i,n){
						listaDelegados.push({Key: n.Key, UserId: n.UserId, UserDelegado: true, DelegadoDel: JSON.parse(n.DelegadoDel)});
					});
				}
			} else {
				listaDelegados = [{}];
			}
		} else {
			listaDelegados = [{}];
		}
		
		
		var listaCentros = [];
		if(view.centros.table.getModel().getData().centros) {
			var oModelCentros = aplanarJerarquia(view.centros.table.getModel().getData().centros);
			if(oModelCentros.getData().centros != undefined){
				if(oModelCentros.getData().centros.length > 0){
					$.each(oModelCentros.getData().centros,function(i,n){
						listaCentros.push({Company: n.Company, Department: n.Department, FirstNode: transformStringToBool(n.FirstNode),DelUserResp1: transformStringToBool(n.DelUserResp1), DelUserResp2: transformStringToBool(n.DelUserResp2)})
					});
				}
			}
		} else {
			listaCentros = [{}];
		}
		
		//Creamos la entidad lista que passaremos por parametro
		var oLista = {};
		oLista.Key = recoverKey(sap.ui.getCore().getModel("con").oData.currAudit);
		oLista.InfoUsersDeep = listaPersonas.length > 0 ? listaPersonas : [{}];
		oLista.InfoDelegatesDeep = listaDelegados.length > 0 ? listaDelegados : [{}];
		oLista.InfoDepatmentsDeep = listaCentros.length > 0 ? listaCentros : [{}];;
		
		var url = "";
		if(view.getId() == "accListView") {
			url = "/InfoAuditAccListDeepSet";
		} else if (view.getId() == "distListView") {
			url = "/InfoAuditListDeepSet";
		}
		
		if(url) {
			sap.ui.getCore().getModel("con").refreshSecurityToken();
			sap.ui.getCore().getModel("con").create(url,oLista,{async: false, success: success.bind({viewId: view.getId()}), error: error });

			function success(oData, oDataRes){
				sap.m.MessageToast.show("Datos guardados corretamente!", {duration: 800});
				var oController = sap.ui.component("component2").grcaudController;
				if(this.viewId == "accListView") {
					sap.ui.component("component2")._getAccList(oController);
				} else if (this.viewId == "distListView") {
					sap.ui.component("component2")._getDistList(oController);
				}
			}

			function error(error) {
//				sap.m.MessageToast.show("Error al guardar!", {duration: 800});
			}
		}
	},
	
	doBackToList: function() {
		
		var viewContainer = sap.ui.getCore().byId("adminListasCont");
		
		if(viewContainer.getPage("adminListasDetail"))
		{
			viewContainer.getPage('adminListasDetail').destroy();
		}
		
		viewContainer.to("adminListas");

	}
});