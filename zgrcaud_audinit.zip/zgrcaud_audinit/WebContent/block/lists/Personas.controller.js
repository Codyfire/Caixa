sap.ui.controller("sap.grc.acs.aud.audit.initiate.extended.block.lists.Personas", {

/**
* Called when a controller is instantiated and its controller controls (if available) are already created.
* Can be used to modify the controller before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf zportalaudit.controller.Personas
*/
//	onInit: function() {
//
//	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's controller is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf zportalaudit.controller.Personas
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the controller has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf zportalaudit.controller.Personas
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf zportalaudit.controller.Personas
*/
//	onExit: function() {
//
//	}

	onAdd: function() {
		
		var oController = this;
		//Preparo els filtres amb els valors
		var oModel = new sap.ui.model.json.JSONModel();
		sap.ui.getCore().setModel(oModel,"ldap");
		
		if(sap.ui.getCore().getComponent('searchComponent')) {
			sap.ui.getCore().getComponent('searchComponent').destroy();
		}
		
		var oComp  = sap.ui.getCore().createComponent({
			id: "searchComponent",
	        name: "sap.grc.acs.aud.audit.initiate.extended.block.Lists.lists.searchComponent"
	    });
		
		// Función de añadir resultados a las tablas
		var addFunct =function() {
			var selItems = this.getParent().getContent()[1].getSelectedItems();
			
			if(selItems.length == 0) { alert(sap.hpa.grcaud.enh_oBundle.getText("select_option")); }
			else {
				if(mirarPersonsaRepetides(selItems,oController.getView().getId())){
					//Han intentat inserir una persona repetida
					var dialog = new sap.m.Dialog({
						title: sap.hpa.grcaud.enh_oBundle.getText("info"),
						type: 'Message',
							content: new sap.m.Text({
								text: sap.hpa.grcaud.enh_oBundle.getText("repeated_person")
							}),
						beginButton: new sap.m.Button({
							text: sap.hpa.grcaud.enh_oBundle.getText("accept"),
							press: function () {
								dialog.close();
							}
						}),
						endButton: new sap.m.Button({
							text: sap.hpa.grcaud.enh_oBundle.getText("cancel"),
							press: function () {
								dialog.close();
							}
						}),
						afterClose: function() {
							dialog.destroy();
						}
					});
					dialog.open();
				}else{
					var viewName = oController.getView().getId();
		        	var list = sap.ui.getCore().byId(viewName).listContainer;
		        	var listTemplate = sap.ui.getCore().byId(viewName).template;
		        	
					$.each(selItems,function(i,n){
		        		var bindingContext = selItems[i].getBindingContext().sPath;
		        		var matricula = sap.ui.getCore().getModel("ldap").getProperty(bindingContext).UserId;
			        	var nombre = sap.ui.getCore().getModel("ldap").getProperty(bindingContext).FullName;

			        	oEntity = {};
			        	oEntity.FullName = nombre;
			        	oEntity.UserId = matricula;
			        	if(list.getModel().getData().results)
			        	{
			        		list.getModel().getData().results.push(oEntity);
			        	}
			        	else {
			        		list.getModel().getData().results = [];
			        		list.getModel().getData().results.push(oEntity);
			        	}
			        	//anadirObjetoAPersonas(oEntity, list);
		        	});
		        	//byId("personas").setModel(sap.ui.getCore().getModel("personas"));
					list.bindAggregation("items","/results", listTemplate);
		        	this.getParent().destroy();
				}
			}};
			
		var addSearchFunct = function(){
			//Agafo el valor del serchfield
			var text = this.getParent().getContent()[0].getProperty("value");
			//var url = "/InfoUsersLDAPSet";
			var url = "/RoleSet(RoleId='AUD',RoleDepId='')/Users"
			if(text != ""){
				var aFilters = [];
				aFilters.push(new sap.ui.model.Filter("FullName",sap.ui.model.FilterOperator.Contains, text.toUpperCase()));
				//Hacemos la llamada al ldap
				addPersonasLdap(url, aFilters);
			}

		}		
		// Cabecera, Binding Posiciones, Modo de Lista, Binding Aggregation, Path, Model, AddFunction
		oComp.setupInicial(["Matricula", "Nombre"],  ["{UserId}", "{FullName}"], "MultiSelect", "", "/results", "ldap", addFunct,addSearchFunct);
		
		// Se crea un contenedor para el componente
		var oCompCont = new sap.ui.core.ComponentContainer({
			 component: oComp,
		});

	}
});