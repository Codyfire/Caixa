sap.ui.controller("sap.grc.acs.aud.audit.initiate.extended.block.lists.ListView", {

/**
* Called when a controller is instantiated and its controller controls (if available) are already created.
* Can be used to modify the controller before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf zportalaudit.controller.ListView
*/
	onInit: function() {
		if(!sap.ui.getCore().getModel("con")) {
			var con = {};
		    con.Model = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/", false);
		    sap.ui.getCore().setModel(con.Model,"con");
		}
	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's controller is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf zportalaudit.controller.ListView
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the controller has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf zportalaudit.controller.ListView
*/
	onAfterRendering: function() {
/*
		// listas de distribución
		sap.ui.getCore().byId('centrosView3').oTable.getToolbar().setEnabled(false);
		sap.ui.getCore().byId('personasView3').listContainer.getAggregation("headerToolbar").setEnabled(false);
		
		// listas de acceso
		
		sap.ui.getCore().byId('centrosView4').oTable.getToolbar().setEnabled(false);
		sap.ui.getCore().byId('personasView4').listContainer.getAggregation("headerToolbar").setEnabled(false);
		
		// Se desactivan los botones de añadir de la lista de acceso
		byId('listView').getContent()[0].getAggregation("items")[1].getAggregation("headerToolbar").setEnabled(false);
*/		
	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf zportalaudit.controller.ListView
*/
//	onExit: function() {
//	},
	
	onEditDist: function() {
		
	},
	
	onEditAcc: function() {
		
	},
	
	onAddDist: function(oEvent) {
		
		var oController = this;
		
		if(sap.ui.getCore().getComponent('searchComponent')) {
			sap.ui.getCore().getComponent('searchComponent').destroy();
		}
		var oComp  = sap.ui.getCore().createComponent({
			id: "searchComponent",
	        name: "sap.grc.acs.aud.audit.initiate.extended.block.lists.searchComponent"
	    });
		
		// Función de añadir resultados a las tablas
		var addFunct =function() {
			var selItems = this.getParent().getContent()[1].getSelectedItems();
			
			if(selItems.length == 0) { alert(sap.hpa.grcaud.enh_oBundle.getText("select_option")); }
			else {
				var bindingContext = selItems[0].getBindingContext().sPath;
				//var id = selItems[0].getAggregation("customData")[0].getValue("Key");
				//var data = sap.ui.getCore().getModel('distList').getProperty(bindingContext);
				var data= sap.ui.component('searchComponent').table.getModel().getProperty(bindingContext);
				
				// Recuperamos las URL para el detalle de los centros
				var uriCentros = data.InfoUsersHierListSet.__deferred.uri;
				uriCentros = uriCentros.substring(uriCentros.indexOf("/InfoListsSet"));
				loadCData(uriCentros, sap.ui.getCore().byId('distListView').centros.getId());
				// Recuperamos las URL para el detalle de las personas
				var uriPersonas = data.InfoUsersListSet.__deferred.uri;
				uriPersonas = uriPersonas.substring(uriPersonas.indexOf("/InfoListsSet"));
				loadPData(uriPersonas, sap.ui.getCore().byId('distListView').personas.getId());
				// Recuperamos las URL para el detalle de los delegados
				if (data.InfoUserDelegatedListSet){ 
				//Cuando nos confirmen que han creado el campo InfoUserDelegatedListSet, borraremos el if
				var uriDelegados = data.InfoUserDelegatedListSet.__deferred.uri;
				uriDelegados = uriDelegados.substring(uriDelegados.indexOf("/InfoListsSet"));
				loadDData(uriDelegados, sap.ui.getCore().byId('distListView').delegados.getId());
				}

				
				// Getting Distribution List > Centers section
				var centros = sap.ui.getCore().byId('distListView').centros;
				var addCenterBtn = centros.table.getToolbar().getContent()[4];
				addCenterBtn.setEnabled(true);
				
				// Getting Distribution List > People section
				var personas = sap.ui.getCore().byId('distListView').personas;
				var addPeopleBtn = personas.listContainer.getHeaderToolbar().getContent()[2];
				addPeopleBtn.setEnabled(true);
				
				// Getting Distribution List > Delegates section
				var delegados = sap.ui.getCore().byId('distListView').delegados;
				var addDelegatesBtn = delegados.listContainer.getHeaderToolbar().getContent()[2];
				addDelegatesBtn.setEnabled(true);
				
				centros.table.getToolbar().setEnabled(true);
				personas.listContainer.getHeaderToolbar().setEnabled(true);
				delegados.listContainer.getHeaderToolbar().setEnabled(true);

				this.getParent().close();
			}};
			
		 //Creo ola funcio a anira al search del search field
	    var addSearchFunct = function(){
	    	//Agafo el valor del serchfield
	    	var text = this.getParent().getContent()[0].getProperty("value");
	    	if (text != ""){
	    	//Preparo els filtres amb els valors
	    	var aFilters = [];
	    		/*if(tieneNumeros(text))//Si conté numeros es que cerquen per matricula
	    			aFilters.push(new sap.ui.model.Filter("Id",sap.ui.model.FilterOperator.Contains, text));
	    		else*/
	    			aFilters.push(new sap.ui.model.Filter("ListName",sap.ui.model.FilterOperator.Contains, text));
	    		loadAddData("/InfoListsSet", aFilters);
	    	}
	    	
	    }
			
		// Cabecera, Binding Posiciones, Modo de Lista, Binding Aggregation, Path, Model, AddFunction
		oComp.setupInicial([sap.hpa.grcaud.enh_oBundle.getText("department"), sap.hpa.grcaud.enh_oBundle.getText("group"), sap.hpa.grcaud.enh_oBundle.getText("list_name")], ["{Department} - {DepartmentName}", "{AudGroup} - {GroupName}", "{ListName}"], "SingleSelect", "", "/results", "distList", addFunct, addSearchFunct);

		// Se crea un contenedor para el componente
		var oCompCont = new sap.ui.core.ComponentContainer({
			 component: oComp,
		});
	},
	
	/*onAddAcc: function() {
		if(sap.ui.getCore().getComponent('searchComponent')) {
			sap.ui.getCore().getComponent('searchComponent').destroy();
		}
		var oComp  = sap.ui.getCore().createComponent({
			id: "searchComponent",
	        name: "resources.js.enhancements.lists.searchComponent"
	    });
		
		// Función de añadir resultados a las tablas
		var addFunct =function() {
			var selItems = this.getParent().getContent()[1].getSelectedItems();
			
			if(selItems.length == 0) { alert(sap.hpa.grcaud.enh_oBundle.getText("select_option")); }
			else {
				var bindingContext = selItems[0].getBindingContext().sPath;
				var id = selItems[0].getAggregation("customData")[0].getValue("Key");
				
				// Se cargan los centros
				
				//var table = sap.ui.getCore().byId('centrosView4').oTable;
				var table = sap.ui.getCore().byId('accListView').centros;
				//var oModel = table.getModel();
				//table.setBindingContext(new sap.ui.model.Context(oModel, bindingContext+"/items"));
				
				table.setModel(sap.ui.getCore().getModel("centros"));
				table.bindRows("/results");
				table.setVisibleRowCount(10);
				
				// Se cargan las personas
				
				var listContainer = sap.ui.getCore().byId('personasView4').listContainer;
				//listContainer.bindAggregation("","/results" , itemTemplate);
				listContainer.setModel(sap.ui.getCore().getModel("personas"));
				
				sap.ui.getCore().byId('centrosView4').oTable.getToolbar().setEnabled(true);
				sap.ui.getCore().byId('personasView4').listContainer.getAggregation("headerToolbar").setEnabled(true);
				
				this.getParent().close();
			}};
			
		// Cabecera, Binding Posiciones, Modo de Lista, Binding Aggregation, Path, Model, AddFunction
		//oComp.setupInicial(tableCols.buscarListas, tableCels.buscarListas, "SingleSelect", "", "/results", "distList", addFunct);
		
		 //Creo ola funcio a anira al search del search field
	    var addSearchFunct = function(){
	    	//Agafo el valor del serchfield
	    	var text = this.getParent().getContent()[0].getProperty("value");
	    	if (text != ""){
	    	//Preparo els filtres amb els valors
	    	var aFilters = [];
	    		//if(tieneNumeros(text))//Si conté numeros es que cerquen per matricula
	    			aFilters.push(new sap.ui.model.Filter("Id",sap.ui.model.FilterOperator.Contains, text));
	    		else
	    			aFilters.push(new sap.ui.model.Filter("ListName",sap.ui.model.FilterOperator.Contains, text));
	    		loadAddData("/InfoListsSet", aFilters);
	    	}
	    	
	    }
			
		// Cabecera, Binding Posiciones, Modo de Lista, Binding Aggregation, Path, Model, AddFunction
		oComp.setupInicial([sap.hpa.grcaud.enh_oBundle.getText("department"), sap.hpa.grcaud.enh_oBundle.getText("group"), sap.hpa.grcaud.enh_oBundle.getText("list_name")], ["{Department} - {DepartmentName}", "{AudGroup} - {GroupName}", "{ListName}"], "SingleSelect", "", "/results", "distList", addFunct, addSearchFunct);
		
		// Se crea un contenedor para el componente
		var oCompCont = new sap.ui.core.ComponentContainer({
			 component: oComp,
		});
	},*/
	
	onAddAcc: function() {
		var oController = this;
		
		if(sap.ui.getCore().getComponent('searchComponent')) {
			sap.ui.getCore().getComponent('searchComponent').destroy();
		}
		var oComp  = sap.ui.getCore().createComponent({
			id: "searchComponent",
		    name: "sap.grc.acs.aud.audit.initiate.extended.block.Lists.lists.searchComponent"
		});
		
		// Función de añadir resultados a las tablas
		var addFunct =function() {
			var selItems = this.getParent().getContent()[1].getSelectedItems();
			
			if(selItems.length == 0) { alert(sap.hpa.grcaud.enh_oBundle.getText("select_option")); }
			else {
				var bindingContext = selItems[0].getBindingContext().sPath;
				//var id = selItems[0].getAggregation("customData")[0].getValue("Key");
				//var data = sap.ui.getCore().getModel('distList').getProperty(bindingContext);
				var data= sap.ui.component('searchComponent').table.getModel().getProperty(bindingContext);
				
				// Recuperamos las URL para el detalle de los centros
				var uriCentros = data.InfoUsersHierListSet.__deferred.uri;
				uriCentros = uriCentros.substring(uriCentros.indexOf("/InfoListsSet"));
				loadCData(uriCentros, sap.ui.getCore().byId('accListView').centros.getId());
				// Recuperamos las URL para el detalle de las personas
				var uriPersonas = data.InfoUsersListSet.__deferred.uri;
				uriPersonas = uriPersonas.substring(uriPersonas.indexOf("/InfoListsSet"));
				loadPData(uriPersonas, sap.ui.getCore().byId('accListView').personas.getId());
				// Recuperamos las URL para el detalle de los delegados
				var uriDelegados = data.InfoUserDelegatedListSet.__deferred.uri;
				uriDelegados = uriDelegados.substring(uriDelegados.indexOf("/InfoListsSet"));
				loadDData(uriDelegados, sap.ui.getCore().byId('accListView').delegados.getId());
				
				// Getting Distribution List > Centers section
				var centros = sap.ui.getCore().byId('accListView').centros;
				var addCenterBtn = centros.table.getToolbar().getContent()[4];
				addCenterBtn.setEnabled(true);
				
				// Getting Distribution List > People section
				var personas = sap.ui.getCore().byId('accListView').personas;
				var addPeopleBtn = personas.listContainer.getHeaderToolbar().getContent()[2];
				addPeopleBtn.setEnabled(true);
				
				// Getting Distribution List > Delegates section
				var delegados = sap.ui.getCore().byId('accListView').delegados;
				var addDelegatesBtn = delegados.listContainer.getHeaderToolbar().getContent()[2];
				addDelegatesBtn.setEnabled(true);
				
				centros.table.getToolbar().setEnabled(true);
				personas.listContainer.getHeaderToolbar().setEnabled(true);
				delegados.listContainer.getHeaderToolbar().setEnabled(true);
		
				this.getParent().close();
			}};
			
		 //Creo la funcio a anira al search del search field
		var addSearchFunct = function(){
			//Agafo el valor del serchfield
			var text = this.getParent().getContent()[0].getProperty("value");
			if (text != ""){
			//Preparo els filtres amb els valors
			var aFilters = [];
				/*if(tieneNumeros(text))//Si conté numeros es que cerquen per matricula
					aFilters.push(new sap.ui.model.Filter("Id",sap.ui.model.FilterOperator.Contains, text));
				else*/
					aFilters.push(new sap.ui.model.Filter("ListName",sap.ui.model.FilterOperator.Contains, text));
				loadAddData("/InfoListsSet", aFilters);
			}
			
		}
			
		// Cabecera, Binding Posiciones, Modo de Lista, Binding Aggregation, Path, Model, AddFunction
		oComp.setupInicial([sap.hpa.grcaud.enh_oBundle.getText("department"), sap.hpa.grcaud.enh_oBundle.getText("group"), sap.hpa.grcaud.enh_oBundle.getText("list_name")], ["{Department} - {DepartmentName}", "{AudGroup} - {GroupName}", "{ListName}"], "SingleSelect", "", "/results", "accList", addFunct, addSearchFunct);
		
		// Se crea un contenedor para el componente
		var oCompCont = new sap.ui.core.ComponentContainer({
			 component: oComp,
		});
	},
	
	onDeleteDist: function() {
		var centros = sap.ui.getCore().byId('distListView').centros;
		centros.table.unbindRows();
		centros.table.setVisibleRowCount(1);
		centros.table.getModel().getData().centros = [];
		centros.table.getToolbar().setEnabled(false);
		
		var personas = sap.ui.getCore().byId('distListView').personas;
		personas.listContainer.unbindAggregation("items");
		personas.listContainer.getModel().getData().results = [];
		personas.listContainer.getAggregation("headerToolbar").setEnabled(false);
		
		var delegados = sap.ui.getCore().byId('distListView').delegados;
		delegados.listContainer.unbindAggregation("items");
		delegados.listContainer.getModel().getData().results = [];
		delegados.listContainer.getAggregation("headerToolbar").setEnabled(false);
	},
	
	onDeleteAcc: function() {
		sap.ui.getCore().byId('centrosView4').oTable.unbindRows();
		sap.ui.getCore().byId('centrosView4').oTable.setVisibleRowCount(1);
		sap.ui.getCore().byId('personasView4').listContainer.unbindAggregation("items");
		sap.ui.getCore().byId('delegadosView4').listContainer.unbindAggregation("items");
		sap.ui.getCore().byId('centrosView4').oTable.getToolbar().setEnabled(false);
		sap.ui.getCore().byId('personasView4').listContainer.getAggregation("headerToolbar").setEnabled(false);
		sap.ui.getCore().byId('delegadosView4').listContainer.getAggregation("headerToolbar").setEnabled(false);
	},

});