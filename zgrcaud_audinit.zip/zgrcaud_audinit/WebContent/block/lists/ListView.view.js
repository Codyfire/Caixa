//jQuery.sap.registerModulePath("lists","sap.grc.acs.aud.audit.initiate.extended.block.lists");
jQuery.sap.require("sap.grc.acs.aud.audit.initiate.extended.block.lists.listsUtils");
jQuery.sap.require("sap.grc.acs.aud.audit.initiate.extended.block.lists.encodingUtils");
jQuery.sap.require("sap.grc.acs.aud.audit.initiate.extended.block.lists.oDataGenerator");
jQuery.sap.require("sap.grc.acs.aud.audit.initiate.extended.block.lists.searchComponent.Component");
jQuery.sap.require("sap.grc.acs.aud.audit.initiate.extended.block.lists.listComponent.Component");
//jQuery.sap.require("sap.grc.acs.aud.audit.initiate.extended.block.lists.stylelists.css");

jQuery.sap.require({
	modName : "sap.grc.acs.aud.audit.initiate.extended.block.lists.listView",
	type : "view"
});
jQuery.sap.require({
	modName : "sap.grc.acs.aud.audit.initiate.extended.block.lists.listView",
	type : "controller"
});
jQuery.sap.require({
	modName : "sap.grc.acs.aud.audit.initiate.extended.block.lists.Personas",
	type : "view"
});
jQuery.sap.require({
	modName : "sap.grc.acs.aud.audit.initiate.extended.block.lists.Personas",
	type : "controller"
});
jQuery.sap.require({
	modName : "sap.grc.acs.aud.audit.initiate.extended.block.lists.Centros",
	type : "view"
});
jQuery.sap.require({
	modName : "sap.grc.acs.aud.audit.initiate.extended.block.lists.Centros",
	type : "controller"
});
jQuery.sap.require({
	modName : "sap.grc.acs.aud.audit.initiate.extended.block.lists.Delegados",
	type : "view"
});
jQuery.sap.require({
	modName : "sap.grc.acs.aud.audit.initiate.extended.block.lists.Delegados",
	type : "controller"
});
jQuery.sap.require({
	modName : "sap.grc.acs.aud.audit.initiate.extended.block.lists.AdminlistasDetail",
	type : "view"
});
jQuery.sap.require({
	modName : "sap.grc.acs.aud.audit.initiate.extended.block.lists.AdminlistasDetail",
	type : "controller"
});
//jQuery.sap.includeStyleSheet("sap/grc/acs/aud/audit/initiate/extended/block/lists/stylelists.css");

sap.ui.jsview("sap.grc.acs.aud.audit.initiate.extended.block.lists.listsView", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf zportalaudit.view.listsView
	*/ 
	getControllerName : function() {
		return "sap.grc.acs.aud.audit.initiate.extended.block.lists.listView";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf zportalaudit.view.listsView
	*/ 
	createContent : function(oController) {
		
		var oComp  = sap.ui.getCore().createComponent({
			id: "component2",
	        name: "sap.grc.acs.aud.audit.initiate.extended.block.lists.listComponent"
	    });
		
		this.oComp = oComp;
		
		// Se crea un contenedor para el componente
		var oCompCont = new sap.ui.core.ComponentContainer({
			 component: oComp,
		});
		
		this.oCompCont = oCompCont;
		
		return oCompCont;
		
// 		var vBox = new sap.m.VBox({
//			height: "100%",
//			items: [
//			        new sap.m.Panel({
//			        	headerText: "listsa de Distribución",
//			        	headerToolbar: new sap.m.Toolbar({
//							content:
//								[
//							         new sap.m.Label({text:"listsa de Distribucion", design: sap.m.LabelDesign.Bold}),
//									 new sap.m.ToolbarSpacer(),
//									 //new sap.m.Button({icon: "sap-icon://edit", press: oController.onEditDist}),
//									 new sap.m.Button({icon: "sap-icon://add", press: [oController.onAddDist, oController]}),
//									 new sap.m.Button({icon: "sap-icon://delete", press: oController.onDeleteDist}),
//								 ]
//						}),
//			        	expandable: true,
//			        	expanded: true,
//			        	width: "auto",
//			        	content: [sap.ui.view({id:"distlistsView", viewName:"grcaud.lists.AdminlistsasDetail", type:sap.ui.core.mvc.ViewType.JS})]
//			        }),
//			        new sap.m.Panel({
//			        	headerText: "listsa de Acceso",
//			        	headerToolbar: new sap.m.Toolbar({
//							content:
//								[
//							         new sap.m.Label({text:"listsa de Acceso", design: sap.m.LabelDesign.Bold}),
//									 new sap.m.ToolbarSpacer(),
//									 //new sap.m.Button({icon: "sap-icon://edit", press: oController.onEditAcc}),
//									 new sap.m.Button({icon: "sap-icon://add", press: [oController.onAddAcc, oController]}),
//									 new sap.m.Button({icon: "sap-icon://delete", press: oController.onDeleteAcc}),
//								 ]
//						}),
//			        	expandable: true,
//			        	expanded: false,
//			        	width: "auto",
//			        	content: [sap.ui.view({id:"acclistsView", viewName:"grcaud.lists.AdminlistsasDetail", type:sap.ui.core.mvc.ViewType.JS})]
//			        }),
//			]
//		});
// 		
// 		this.vBox = vBox;
// 		
// 		return this.vBox;
	}

});