sap.ui.jsview("appHistoPlanesAccion.view.tablePlanesHist", {

	/**
	 * Specifies the Controller belonging to this View. In the case that it is
	 * not implemented, or that "null" is returned, this View does not have a
	 * Controller.
	 * 
	 * @memberOf view.initial
	 */
	getControllerName : function() {  
		return "appHistoPlanesAccion.controller.tablePlanesHist";
	},

	/**
	 * Is initially called once after the Controller has been instantiated. It
	 * is the place where the UI is constructed. Since the Controller is given
	 * to this method, its event handlers can be attached right away.
	 * 
	 * @memberOf view.initial
	 */
	createContent : function(oController) {
		// Se crea el template para las lineas de la tabla
		const
		C_AUDITADO = "AUDITADO", C_AUDITOR = "AUDITOR";

		// Se definen las columnas de las tablas, se indican tanto columnas de
		// auditado como auditor
		var colNames = [ [ "{i18n>criticidad}", C_AUDITADO ], [ "{i18n>numInformes}", C_AUDITADO ],
				[ "{i18n>numAccion}", C_AUDITADO ], [ "{i18n>accVencicda}", C_AUDITADO ],
				[ "{i18n>titulo}", C_AUDITADO ], [ "{i18n>departamento}", C_AUDITADO ],
				[ "{i18n>grupo}", C_AUDITADO ], [ "{i18n>responsable}", C_AUDITADO ],
				[ "{i18n>estado}", C_AUDITADO ], [ "{i18n>estadoVal}", C_AUDITADO ],
				[ "{i18n>fechaVenc}", C_AUDITADO ],

				[ "{i18n>criticidad}", C_AUDITOR ], [ "{i18n>numInformes}", C_AUDITOR ],
				[ "{i18n>tituloInforme}", C_AUDITOR ], [ "{i18n>numPlanAccion}", C_AUDITOR ],
				[ "{i18n>titulo}", C_AUDITOR ], [ "{i18n>responsable}", C_AUDITOR ],
				[ "{i18n>estado}", C_AUDITOR ], [ "{i18n>estadoVal}", C_AUDITOR ],
				[ "{i18n>fechaVenc}", C_AUDITOR ],
				
				/**
				 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020
				 * Código antiguo
				 * ];				
				 * Código nuevo
				 */
				[ "{i18n>origen}", C_AUDITOR ]];
				/**
				 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
				 */
				
		var cellTemplate = [ [ "{RankingDescr}", C_AUDITADO ], [ "{ZzReportId}", C_AUDITADO ],
				[ "{ZzReportTitle}", C_AUDITADO ], [ "{Overdue}", C_AUDITADO ],
				[ "{Title}", C_AUDITADO ], [ "{DepartmentName}", C_AUDITADO ],
				[ "{GroupText}", C_AUDITADO ], [ "{NameOrg}", C_AUDITADO ],
				[ "{StatusDescr}", C_AUDITADO ], [ "{Validated}", C_AUDITADO ],
				[ "{Deadline}", C_AUDITADO ],

				[ "{RankingDescr}", C_AUDITOR ], [ "{ZzReportId}", C_AUDITOR ],
				[ "{Overdue}", C_AUDITOR ], [ "{Title}", C_AUDITOR ],
				[ "{DepartmentName}", C_AUDITOR ], [ "{GroupText}", C_AUDITOR ],
				[ "{NameOrg}", C_AUDITOR ], [ "{StatusDescr}", C_AUDITOR ],
				[ "{Deadline}", C_AUDITOR ], 
		/**
		 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020
		 * Código antiguo
		 * ];				
		 * Código nuevo
		 */
		[ "{ZzOrigen}", C_AUDITOR ]];
		/**
		 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
		 */

		var oTemplate = new sap.m.ColumnListItem({
			type : "Navigation",
		});

		$.each(cellTemplate, function(i, n) {
			switch (n[0]) {
			case "{Validated}":
				oTemplate.addCell(new sap.m.Label({
					text : n[0],
					visible : {
						parts : [ n[0] ],
						formatter : function(fecha) {
							if (planesAccionUtilsHisto.isAuditado(this) && n[1] == C_AUDITADO)
								return true;
							else if (!planesAccionUtilsHisto.isAuditado(this) && n[1] == C_AUDITOR)
								return true;
							else
								return false;
						}
					}
				}).bindProperty("text", {
					parts : [ "Validated" ],
					formatter : function(Validated) {
						return planesAccionUtilsHisto.getStatusText(Validated, this);
					}
				}));
				break;
			case "{Deadline}" || "{FinalDate}":
				oTemplate.addCell(new sap.m.Label({
					text : n[0],
					visible : {
						parts : [ n[0] ],
						formatter : function(fecha) {
							if (planesAccionUtilsHisto.isAuditado(this) && n[1] == C_AUDITADO)
								return true;
							else if (!planesAccionUtilsHisto.isAuditado(this) && n[1] == C_AUDITOR)
								return true;
							else
								return false;
						}
					}
				}).bindProperty("text", {
					parts : [ "Deadline" ],
					formatter : function(fecha) {
						return planesAccionUtilsHisto.transformDate(fecha);
					}
				}));
				break;
			case '{Overdue}':
				oTemplate.addCell(new sap.m.HBox({
					items : [ new sap.ui.core.Icon({
						src : "sap-icon://warning",
						color : "#ff0000",
						size : "15px",
						tooltip : "{i18n>accVencicda}"
					}).bindProperty("src", {
						parts : [ n[0] ],
						formatter : function(overdue) {
							var source;
							if (overdue == "true") {
								source = "sap-icon://warning";
								this.addStyleClass("OverdueIconMargin");
							} else {
								source = "";
							}
							return source;
						}
					}), new sap.m.Text({
						text : "{Id}"
					}) ]
				}));
				break;
			default:
				oTemplate.addCell(new sap.m.Label({
					text : n[0],
					visible : {
						parts : [ n[0] ],
						formatter : function() {
							if (planesAccionUtilsHisto.isAuditado(this) && n[1] == C_AUDITADO)
								return true;
							else if (!planesAccionUtilsHisto.isAuditado(this) && n[1] == C_AUDITOR)
								return true;
							else
								return false;
						}
					},
				}));
				break;
			}
		});

		// Se crea la tabla
		var oTable = new sap.m.Table({
			mode : sap.m.ListMode.SingleSelectMaster,
			customData : [ new sap.ui.core.CustomData({
				key : "{Key}"
			}) ],
			itemPress : [ oController.showDetail, oController ],
			width : "100%",
			height : "100%",
			name : "actionhistTable",
			id : "actionhistTable"
		});

		// Se crean las columnas y se comprueba si el usuario tiene el rol
		// correspondiente.
		$.each(colNames, function(i, n) {
			oTable.addColumn(new sap.m.Column({
				vAlign : sap.ui.core.VerticalAlign.Middle,
				hAlign : sap.ui.core.TextAlign.Center,
				header : new sap.m.Label({
					text : n[0]
				}),
				visible : {
					parts : [ "RankingDescr" ],
					formatter : function() {
						if (planesAccionUtilsHisto.isAuditado(this) && n[1] == C_AUDITADO)
							return true;
						else if (!planesAccionUtilsHisto.isAuditado(this) && n[1] == C_AUDITOR)
							return true;
						else
							return false;
					}
				},
			}));
		});

		// Se le añaden los items a la tabla
		oTable.bindAggregation("items", "/results", oTemplate);

		// Se guarda la tabla en la vista para poder acceder desde el controller
		this.oTable = oTable;
		this.oTemplate = oTemplate;

		// PAGINACIÓN
		var start = 0;

		var i = 0;

		var rowCount = 7;
		var oButton1 = new sap.m.Button({
			text : ">",
			id : "Next"
		});

		var oButton2 = new sap.m.Button({
			text : "<",
			id : "Previous"
		});
		oButton1.attachPress(function() {
			start = start + rowCount;
			oController.populateData(start, rowCount);
		});

		oButton2.attachPress(function() {
			start = start - rowCount;
			oController.populateData(start, rowCount);
		});
		
		this.oButton1 = oButton1;
		this.oButton2 = oButton2;
		

		return new sap.m.Page({
			title : "{i18n>title}",
			fitContainer : true,
			subHeader : [ new sap.m.Toolbar({
				content : [
						new sap.m.ToolbarSpacer({}),
						new sap.m.Button({
							icon : "sap-icon://download",
							press : function() {
								sap.ui.getCore().getComponent("actionhistTable").exportToExcel(
										"ExportPlanesAccion", planesAccionUtilsHisto.filters,
										planesAccionUtilsHisto.sorters);
							}
						}), new sap.m.Button({
							icon : "sap-icon://drop-down-list",
							press : [ oController.onFilterPress, this ]
						}) ]
			}) ],
			content : [ this.oTable, oButton2, oButton1 ],
		});

	}

});