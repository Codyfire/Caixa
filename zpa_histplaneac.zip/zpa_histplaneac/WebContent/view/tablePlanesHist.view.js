sap.ui.jsview("appHistoPlanesAccion.view.tablePlanesHist", {

	/**
	 * Specifies the Controller belonging to this View. In the case that it is
	 * not implemented, or that "null" is returned, this View does not have a
	 * Controller.
	 * 
	 * @memberOf view.initial
	 */
	getControllerName : function() {  
		return "appHistoPlanesAccion.controller.tablePlanesHist";
	},

	/**
	 * Is initially called once after the Controller has been instantiated. It
	 * is the place where the UI is constructed. Since the Controller is given
	 * to this method, its event handlers can be attached right away.
	 * 
	 * @memberOf view.initial
	 */
	createContent : function(oController) {
		// Se crea el template para las lineas de la tabla


		var colNames = planesAccionUtilsHisto.colNames; 

		var cellTemplate = planesAccionUtilsHisto.cellTemplate;

		var oTemplate = new sap.m.ColumnListItem({
			type : "Navigation",
			customData : [ new sap.ui.core.CustomData({
				key : "{actionhis>Key}"
			}) ],
			press : [ oController.showDetail, oController ],
		});

		if (sap.ui.getCore().getComponent('tablePlanAccionesHis')) {
			sap.ui.getCore().getComponent('tablePlanAccionesHis').destroy();
		}

		// Creo la taula de paginació a partir del component creat
		oTable = new sap.ui.getCore().createComponent({
			name : "tablePaginationHis",
			id : "tablePlanAccionesHis"
		});

		this.oTable = oTable;
		// Se le añaden los items a la tabla
		// oTable.bindAggregation("items", "/results", oTemplate);
		this.oTable.addItemTemplate("", "actionhis>/results", oTemplate);

		var oCompCont = new sap.ui.core.ComponentContainer({
			component : this.oTable
		});
		// Se guarda la tabla en la vista para poder acceder desde el controller
		// this.oTable = oTable;
		this.oTemplate = oTemplate;
		var oCompCont = new sap.ui.core.ComponentContainer({
			component : this.oTable
		});

		return new sap.m.Page({
			title : "{i18n>title}",
			//fitContainer : true,
			subHeader : [ new sap.m.Toolbar({
				content : [
						new sap.m.ToolbarSpacer({}),
						new sap.m.Button({
							icon : "sap-icon://download",
							press : function() {
								sap.ui.getCore().getComponent("tablePlanAccionesHis").exportToExcel(
										"ExportPlanesAccion", planesAccionUtilsHisto.filters,
										planesAccionUtilsHisto.sorters, "");
							}
						}), new sap.m.Button({
							icon : "sap-icon://drop-down-list",
							press : [ oController.onFilterPress, this ]
						}) ]
			}) ],
			content : [ oCompCont ],
		});

	}

});