sap.ui.jsview("appHistoPlanesAccion.view.PlanesDetail", {

					/**
					 * Specifies the Controller belonging to this View. In the
					 * case that it is not implemented, or that "null" is
					 * returned, this View does not have a Controller.
					 * 
					 * @memberOf zportalaudit.view.planesAccion.PlanesDetail
					 */
					getControllerName : function() {
						return "appHistoPlanesAccion.controller.PlanesDetail";
					},


					/**
					 * Is initially called once after the Controller has been
					 * instantiated. It is the place where the UI is
					 * constructed. Since the Controller is given to this
					 * method, its event handlers can be attached right away.
					 * 
					 * @memberOf appHistoPlanesAccion.view.planesAccion.PlanesDetail
					 */
					createContent : function(oController) {
						
						/** INI MOD RTC788093 lzumarra 03.07.2020 */
						/*
						 * Se comentan las dos l�neas this.verificado =
						 * verificado; this.fechaVerificado = fechaVerificado;
						 */
						/** FIM MOD RTC788093 */	
						var header = new sap.m.ObjectHeader({
							// number: "id",
							title : {
								parts : [ {
									path : "actionPlanDetail>/Id"
								}, {
									path : "actionPlanDetail>/Title"
								} ],

								formatter : function(Id, Titles) {
									return Id + " > " + Titles;
								}
							},
							attributes : [ new sap.m.ObjectAttribute({
								text : {
									parts : [ {
										path : "FindingId"
									}, {
										path : "actionPlanDetail>/Title"
									} ],

									formatter : function(FindingId, FindingTitle) {
										return FindingId + ": " + FindingTitle;
									}
								},
								active : false
							}), new sap.m.ObjectAttribute({
								title : "{i18n>numInformes}",
								text : "{actionPlanDetail>/ZzReportId}",
								active : false
							}), new sap.m.ObjectAttribute({
								title : "{i18n>tituloInformes}",
								text : "{actionPlanDetail>/ZzReportTitle}",
								active : false
							}), new sap.m.ObjectAttribute({
								// TODO: Recuperar fecha distribuci�n
								title : "{i18n>fechaDistrInforme}",
								text : "{actionPlanDetail>/DateRepIssued}",
								active : false,
							}).bindProperty("text", {
								parts : [ "actionPlanDetail>/DateRepIssued" ],
								formatter : function(fecha) {
									return Helper.convertDate(fecha);
								}
							}), new sap.m.ObjectAttribute({
								title : "{i18n>clasRiesgo}",
								text : "{actionPlanDetail>/RankingDescr}",
								active : false,
								state : sap.ui.core.ValueState.Error
							}), 
														
							  new sap.m.ObjectAttribute({
								title : "{i18n>departamento}",
								text : "{actionPlanDetail>/DepartmentName}",
								active : false,
							}),											 									
												 			
							new sap.m.ObjectAttribute({
								title : "{i18n>grupo}",
								text : "{actionPlanDetail>/GroupText}",
								active : false,
							})
							/**
							 * INI MOD PPM040907 Rafael Gal�n Baquero 15/04/2020
							 * C�digo nuevo
							 */
							// Se a�ade la columna origen en la lista con
							// visibilidad seg�n si est� informado o no
							 , new sap.m.ObjectAttribute({}).bindProperty("text",{
				 				   parts : ["actionPlanDetail>/ZzOrigen"],			 				   
				 				   formatter: function(origen){
				 					   return planesAccionUtilsHisto.getOrigenText(origen);
				 					   }
							 }).bindProperty("title",{
				 				   parts : ["actionPlanDetail>/ZzOrigen"],	
				 				   formatter: function(origen){
				 					   return planesAccionUtilsHisto.oBundle.getText("origen")
				 				   }
				 			 }).bindProperty("visible",{
									parts : ["actionPlanDetail>/ZzOrigen"],	
									formatter: function(origen){
										return	origen != '' ? true : false;
									}
								}),								 		
							 		

								
							/**
							 * FIN MOD PPM040907 Rafael Gal�n Baquero 15/04/2020
							 */
							/** INI MOD RTC788093 lzumarra 03.07.2020 */
							// Se comenta la l�nea siguiente
							// ,verificado, fechaVerificado
							/** FIN MOD RTC788093 */	],
							firstStatus : [ new sap.m.ObjectStatus({
								// TODO: Recuperar validaci�n supervisor
								text : "{actionPlanDetail>/Validated}",
							}).bindProperty(
									"text",
									{
										parts : [ "Validated" ],
										formatter : function(validated) {
											if (validated != undefined)
												return planesAccionUtilsHisto.getStatusText(
														validated, oController)
											else
												return "";
										}
									}).bindProperty("visible", {
								parts : [ "Validated" ],
								formatter : function(validated) {
									if (validated == "")
										return false;
									else
										return true;
								}
							})]
						});
						var oForm2 = new sap.ui.layout.form.Form(
								{
									editable : false,
									layout : new sap.ui.layout.form.GridLayout(),
									formContainers : [
											new sap.ui.layout.form.FormContainer(
													{
														title : "{i18n>general}",
														formElements : [
																new sap.ui.layout.form.FormElement(
																		{
																			label : new sap.m.Label(
																					{
																						text : "{i18n>responsable}"
																					}),
																			fields : [ new sap.m.Input(
																					{
																						placeholder : "",
																						editable : false,
																						layoutData : new sap.ui.layout.form.GridElementData(
																								{
																									hCells : "auto"
																								})
																					})
																					.bindProperty(
																							"value",
																							{
																								parts : [ {
																									path : "actionPlanDetail>/NameOrg"
																								} ],
																								formatter : function(
																										nameOrg) {
																									if (nameOrg != undefined)
																										return nameOrg
																												.capitalize();
																									else
																										return "";
																								}
																							}) ]
																		}),
																		// INICIO
																		// RTC-597440
																		new sap.ui.layout.form.FormElement(
																				{
																					label : new sap.m.Label(
																							{
																								text : "{i18n>recomendaciones}"
																							}),
																					// TODO:
																					// Recuperar
																					// detalles
																					fields : [ new sap.m.TextArea(
																							{
																								value : "{actionPlanDetail>/Recommendation}",
																								rows : 5,
																								editable : false,
																								placeholder : "",
																								enabled : false,
																								layoutData : new sap.ui.layout.form.GridElementData(
																										{
																											hCells : "auto"
																										})
																							}) ]
																				}),
																				// FIN
																				// RTC-597440
																new sap.ui.layout.form.FormElement(
																		{
																			label : new sap.m.Label(
																					{
																						text : "{i18n>detalles}"
																					}),
																			// TODO:
																			// Recuperar
																			// detalles
																			fields : [ new sap.m.TextArea(
																					{
																						value : "{actionPlanDetail>/Milestone}",
																						rows : 5,
																						editable : false,
																						placeholder : "",
																						enabled : false,
																						layoutData : new sap.ui.layout.form.GridElementData(
																								{
																									hCells : "auto"
																								})
																					}) ]
																		}),
																new sap.ui.layout.form.FormElement(
																		{
																			label : new sap.m.Label(
																					{
																						text : "{i18n>estado}"
																					}),
																			fields : [
																					new sap.m.Select(
																							{
																								enabled : false,
																								items : [ new sap.ui.core.Item(
																										{
																											key : "{actionPlanDetail>/ActualStatus}",
																											text : "{actionPlanDetail>/ActualStatusDescr}"
																										}) ]
																							}),
																					new sap.m.Label(
																							{
																								text : "{i18n>fechaVenc}"
																							}),
																					new sap.m.DatePicker(
																							{
																								editable : false,
																								valueFormat : 'dd/MM/yyyy',
																								displayFormat : 'dd/MM/yyyy',
																							})
																							.bindProperty(
																									"value",
																									{
																										parts : [ {
																											path : "actionPlanDetail>/ActualDeadline"
																										} ],
																										formatter : function(
																												fecha) {
																											if (fecha == ""
																													|| fecha == undefined)
																												return "";
																											else if (fecha.lenght > 8) {
																												var año = fecha
																														.getFullYear();
																												var mes;
																												if (fecha.getMonth + 1 < 10)
																													mes = "0"
																															+ fecha
																																	.getMonth()
																															+ 1;
																												else
																													mes = fecha
																															.getMonth() + 1;
																												var dia = fecha
																														.getDate();

																												return año
																														+ "/"
																														+ mes
																														+ "/"
																														+ dia;
																											} else {
																												return fecha
																														.substring(
																																6,
																																8)
																														+ "/"
																														+ fecha
																																.substring(
																																		4,
																																		6)
																														+ "/"
																														+ fecha
																																.substring(
																																		0,
																																		4);
																											}
																										}
																									})

																			]

																		}),
																new sap.ui.layout.form.FormElement(
																		{
																			label : new sap.m.Label(
																					{
																						text : "{i18n>fechaFinal}"
																					}),
																			fields : [ new sap.m.DatePicker(
																					{
																						editable : false,
																						valueFormat : 'dd/MM/yyyy',
																						displayFormat : 'dd/MM/yyyy',
																					})
																					.bindProperty(
																							"value",
																							{
																								parts : [ {
																									path : "actionPlanDetail>/FinalDate"
																								} ],
																								formatter : function(
																										fecha) {
																									if (fecha == ""
																											|| fecha == undefined 
																											|| fecha == "00000000")
																										return "";
																									else if (fecha.lenght > 8) {
																										var año = fecha.getFullYear();
																										var mes;
																										if (fecha.getMonth + 1 < 10)
																											mes = "0" + fecha.getMonth()+ 1;
																										else
																											mes = fecha.getMonth() + 1;
																										var dia = fecha.getDate();

																										return año + "/" + mes + "/" + dia;
																									} else {
																										return fecha.substring(6,8) + "/" + fecha.substring(4,6) + "/" + fecha.substring(0,	4);
																									}
																								}
																							})

																			]

																		}) ]
													}), ]
								});

						// Creo la llista que contindr� les notes
						var commentList = new sap.m.ListBase({
							inset : false,

						});

						var itemList = new sap.m.FeedListItem({
							sender : "{CreatedByName}",
							iconDensityAware : false,
							info : "{CreatedBy}",
							timestamp : {
								parts : [ {
									path : "CreateTime"
								} ],
								formatter : function(fecha) {
									return planesAccionUtilsHisto.convertDateTime(fecha);
								}
							},
							text : "{Text}",
							senderActive : false,
							iconActive : false,
							iconInset : false,
							showIcon : false
						});

						var oForm3 = new sap.ui.layout.form.Form({
							editable : false,
							layout : new sap.ui.layout.form.GridLayout(),
							formContainers : [ new sap.ui.layout.form.FormContainer({
								title : "{i18n>comentarios}",
								formElements : [ new sap.ui.layout.form.FormElement({

									fields : [ commentList ]
								}), ]
							}), ]
						});
						//		
						var oTable = new sap.m.Table(this.createId("listAcceso"), {
							headerToolbar : new sap.m.Toolbar({
								content : [ new sap.m.Label({
									text : "{i18n>listAcceso}",
									design : sap.m.LabelDesign.Bold
								}), ]
							}),
							columns : [ new sap.m.Column({
								hAlign : "Left",
								header : new sap.m.Label({
									text : "{i18n>matricula}",
									design : sap.m.LabelDesign.Bold
								})
							}), new sap.m.Column({
								hAlign : "Left",
								header : new sap.m.Label({
									text : "{i18n>nombre}",
									design : sap.m.LabelDesign.Bold
								})
							}) ],
							width : "100%",
							height : "100%",
						});

						var itemTemplate = new sap.m.ColumnListItem({
							// type: "Inactive",
							cells : [ new sap.m.Label({
								text : "{Id}",
							}), new sap.m.Label({
								text : "{FullName}",
							}) ],

						});

						commentList.bindAggregation("items", "/", itemList);
						oTable.bindAggregation("items", "/InfoAccessList/results", itemTemplate);

						this.table = oTable;
						this.commentList = commentList;
						this.template = itemTemplate;

						var temasText = new sap.m.Text({
							text : "Temas"
						}).addStyleClass("tableTitles");

						var tokenizer = new sap.m.Tokenizer({
							editable : false
						});

						var listaThemes;

						if (sap.ui.getCore().getModel("planAccionInfo")) {

							var listaThemes = sap.ui.getCore().getModel("planAccionInfo").getData().InfoThemes.results;
							$.each(listaThemes, function(i, n) {
								tokenizer.addToken(new sap.m.Token({
									text : n.Theme,
									editable : false,
									customData : new sap.ui.core.CustomData({
										key : n.Key
									})

								}).addStyleClass("alignToken"))
							});

						} 
						var temasFlexBox = new sap.m.FlexBox({
							items : [ temasText, tokenizer ],
							direction : "Column",
							alignItems : "Start"
						});

						// Template para anexos
						var oItemTemplate = new sap.m.UploadCollectionItem({
							contributor : "{CreateByName}",
							documentId : "{DocId}",
							enableEdit : false,
							enableDelete : false,
							visibleEdit : false,
							visibleDelete : false,
							fileName : "{Name}",
							mimeType : "{MimeType}",
							uploadedDate : "{CreateTime}",
							url : "{Url}",
							customData : [ new sap.ui.core.CustomData({
								key : "{DeleteUrl}"
							}) ],
						});

						// Se rellena el uploader
						var uploader = new sap.m.UploadCollection("anexosType", {
							multiple : false,
							items : {
								path : "/",
								template : oItemTemplate
							},
							uploadEnabled : false
						});

						this.uploader = uploader;
						this.upldTemplate = oItemTemplate;
						this.header = header;
						this.oForm2 = oForm2;
						this.oForm3 = oForm3;

						this.oPage = new sap.m.Page({
							title : "{i18n>titleDetail}",
							showNavButton : true,
							showHeader : true,
							showFooter : true,
							// fitContainer : true,
							subHeader : [ new sap.m.Toolbar({
								content : [
								// new sap.m.Text({text:"Lista de
								// Informes"}).addStyleClass("boldLabel"),
								new sap.m.ToolbarSpacer({}),

								]
							}) ],
							content : [ header, oForm2, this.oTextTitle, oForm3,
									this.oContTagCloud, oTable, uploader, new sap.m.Panel({
										height : "10%"
									}) ],
							navButtonPress : [ oController.doBack, oController ],
						});
						// 		
						if (this.sId === "planesTemasDetail") {
							this.oPage.setShowNavButton(true);
							this.oPage.setTitle(planesAccionUtilsHisto.oBundle
									.getText("planAccion"));
							this.oPage.setShowHeader(true);
						}
						// 		
						return this.oPage;
					},

				});