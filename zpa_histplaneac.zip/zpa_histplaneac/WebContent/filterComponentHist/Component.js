jQuery.sap.declare("filterComponentHist.Component");
jQuery.sap.require("sap.ui.core.UIComponent");

sap.ui.core.UIComponent
		.extend(
				"filterComponentHist.Component",   
				{
					metadata : {
						properties : {
							refObject : {
								type : 'string',
								defaultValue : ''
							}
						}
					},

					init : function() {
						// define variable for control initial loading handling
						this._bInitialLoading = true;
						// execute standard control method
						sap.ui.core.UIComponent.prototype.init.apply(this, arguments);
					},

					createContent : function() {
						var that = this;
						this.dialog = new sap.m.ViewSettingsDialog({
							cancel : function(oEvent) {
							},
							resetFilters : function(oEvent) {

								var toDeleteFilters = this.getAggregation("filterItems");

								for (i = 0; i < toDeleteFilters.length; ++i) {
									if (this.getAggregation("filterItems")[i]._control) {
										toDeleteFilters[i]._control
												.getAggregation("formContainers")[0]
												.getAggregation("formElements")[0]
												.getAggregation("fields")[0].setValue("");
									}
								}
							}
						});
					},

					setRefObject : function(refObject, oController) {

						this.setProperty("refObject", refObject, true);
						var that = this;
						var oComponent = sap.ui.getCore().getComponent(this.getRefObject());

						var confirmFunction = function(oEvent) {

							var oTable = sap.ui.getCore().getComponent(refObject).table;
							var mParams = oEvent.getParameters();
							var oBinding = oTable.getBinding("");

							planesAccionUtilsHisto.grouping = false;
							planesAccionUtilsHisto.sorters = [];
							planesAccionUtilsHisto.grouper = [];
							planesAccionUtilsHisto.sortersTemas = [];
							planesAccionUtilsHisto.grouperTemas = [];
							// apply sorter
							if (mParams.sortItem) {

								var sPath = mParams.sortItem.getKey();
								// Si ordenamos por Status queremos ordenar por
								// el descriptivo, no por la key.
								if (sPath == "Status") {
									sPath = "StatusDescr";
								}

								var bDescending = mParams.sortDescending;
								if (that.mode == "NOTHEME") {
									planesAccionUtilsHisto.sorters.push(new sap.ui.model.Sorter(
											sPath, bDescending));
								} else if (that.mode == "THEME") {
									{
										planesAccionUtilsHisto.sortersTemas
												.push(new sap.ui.model.Sorter(sPath, bDescending));
									}
								}

								// apply grouping
								if (mParams.groupItem) {
									planesAccionUtilsHisto.sorters = [];
									planesAccionUtilsHisto.sortersTemas = [];
									var sPath = mParams.groupItem.getKey();
									if (sPath == "CreatedAt") {
										var bDescending = mParams.groupDescending;
										var vGroup = function(oContext) {
											var date = oContext
													.getProperty(mParams.groupItem.mProperties.key);
											var convertedDate = planesAccionUtilsHisto
													.convertDate(date);
											return {
												key : convertedDate,
												text : convertedDate
											};
										};
										planesAccionUtilsHisto.sorters
												.push(new sap.ui.model.Sorter(sPath, bDescending,
														vGroup));
									} else {
										var bDescending = mParams.groupDescending;
										var vGroup = function(oContext) {
											var name = oContext
													.getProperty(mParams.groupItem.mProperties.key);
											return {
												key : name,
												/**
												 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020
												 * Código antiguo
												text : planesAccionUtilsHisto.getStatusString(name,that.oModelControllerHist)				
												 * Código nuevo
												 */
												//Para el campo origen, se contempla el texto de origen, en caso contrario, tal como se hacía anteriormente
												text : sPath != 'ZzOrigen' ? planesAccionUtilsHisto.getStatusString(name,that.oModelControllerHist) :  planesAccionUtilsHisto.getOrigenText(name)							                 								
												/**
												 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
												 */							
												
											};
										};
										var sPathSort = mParams.groupItem.getKey();
										var bDescendingSort = mParams.groupDescending;

										planesAccionUtilsHisto.grouping = true;
										if (that.mode == "NOTHEME") {
											planesAccionUtilsHisto.grouper
													.push(new sap.ui.model.Sorter(sPath,
															bDescending, vGroup));
											// apply sorter
											planesAccionUtilsHisto.sorters
													.push(new sap.ui.model.Sorter(sPathSort,
															bDescendingSort));
										} else if (that.mode == "THEME") {
											planesAccionUtilsHisto.grouperTemas
													.push(new sap.ui.model.Sorter(sPath,
															bDescending, vGroup));
											// apply sorter
											planesAccionUtilsHisto.sortersTemas
													.push(new sap.ui.model.Sorter(sPathSort,
															bDescendingSort));
										}
									}
								}
							}

							if (that.mode == "NOTHEME") {
								// Limpio los tipos marcados anteriormente
								for (i = planesAccionUtilsHisto.filters.length - 1; i >= 0; i--) {
									if (planesAccionUtilsHisto.filters[i].sPath == "ZzReportId"
											|| planesAccionUtilsHisto.filters[i].sPath == "Id"
											|| planesAccionUtilsHisto.filters[i].sPath == "Title"
												/**
												 * INI MOD RTC 748088 Rafael Galán Baquero
												 * 11.07.2019
												* Código antiguo
//												|| planesAccionUtilsHisto.filters[i].sPath == "DepartmentName"
												* Código nuevo
												*/
												// Se modifica la key a tener en cuenta
											|| planesAccionUtilsHisto.filters[i].sPath == "ZzDepartment"
												/**
												 * FIN MOD RTC 748088 Rafael Galán Baquero
												 * 11.07.2019
												 */ 
											|| planesAccionUtilsHisto.filters[i].sPath == "GroupText"
											|| planesAccionUtilsHisto.filters[i].sPath == "NameOrg"
											|| planesAccionUtilsHisto.filters[i].sPath == "AudGroup"
											|| planesAccionUtilsHisto.filters[i].sPath == "RankingDescr"
											|| planesAccionUtilsHisto.filters[i].sPath == "Validated"											
										/**
										 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020
										 * Código antiguo
										 * 	|| planesAccionUtilsHisto.filters[i].sPath == "StatusDescr")			
										 * Código nuevo
										 * Se contempla la celda del campo origen
										 */
									       || planesAccionUtilsHisto.filters[i].sPath == "StatusDescr"	
									       || planesAccionUtilsHisto.filters[i].sPath == "ZzOrigen")
																			 		
										/**
										 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
										 */
										planesAccionUtilsHisto.filters.splice(i, 1);
								}
							} else if (that.mode == "THEME") {
								// Limpio los tipos marcados anteriormente
								for (i = planesAccionUtilsHisto.filtersTemas.length - 1; i >= 0; i--) {
									if (planesAccionUtilsHisto.filtersTemas[i].sPath == "ZzReportId"
											|| planesAccionUtilsHisto.filtersTemas[i].sPath == "Id"
											|| planesAccionUtilsHisto.filtersTemas[i].sPath == "Title"
												/**
												 * INI MOD RTC 748088 Rafael Galán Baquero
												 * 11.07.2019
												* Código antiguo
//												|| planesAccionUtilsHisto.filtersTemas[i].sPath == "DepartmentName"
												* Código nuevo
												*/ 
												// Se modifica la key a tener en cuenta
												|| planesAccionUtilsHisto.filtersTemas[i].sPath == "ZzDepartment"
												/**
												 * FIN MOD RTC 748088 Rafael Galán Baquero
												 * 11.07.2019
												 */ 
											|| planesAccionUtilsHisto.filtersTemas[i].sPath == "GroupText"
											|| planesAccionUtilsHisto.filtersTemas[i].sPath == "NameOrg"
											|| planesAccionUtilsHisto.filtersTemas[i].sPath == "AudGroup"
											|| planesAccionUtilsHisto.filtersTemas[i].sPath == "RankingDescr"
											|| planesAccionUtilsHisto.filtersTemas[i].sPath == "Validated"																															
											/**
											 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020
											 * Código antiguo
											 * 	|| planesAccionUtilsHisto.filters[i].sPath == "StatusDescr")			
											 * Código nuevo
											 * Se contempla la celda del campo origen
											 */
										       || planesAccionUtilsHisto.filters[i].sPath == "StatusDescr"	
										       || planesAccionUtilsHisto.filters[i].sPath == "ZzOrigen")
																				 		
											/**
											 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
											 */
										planesAccionUtilsHisto.filtersTemas.splice(i, 1);
								}
							}

							// apply filters
							if (that.mode == "NOTHEME") {
								var aStatusFilters = [];
								var statusFalg = false;
								$
										.each(
												oEvent.getParameters().filterItems,
												function(j, value2) {
													var field = oEvent.getParameters().filterItems[j].oParent.mProperties.key;
													if (field == "Status") {
														aStatusFilters
																.push(new sap.ui.model.Filter(
																		"Status",
																		sap.ui.model.FilterOperator.EQ,
																		planesAccionUtilsHisto
																				.getStatusCode(
																						oEvent
																								.getParameters().filterItems[j].mProperties.text,
																						that.oModelControllerHist)));
														statusFalg = true;
													} else if (field == "AudGroup") {
														planesAccionUtilsHisto.filters
																.push(new sap.ui.model.Filter(
																		field,
																		sap.ui.model.FilterOperator.EQ,
																		oEvent.getParameters().filterItems[j].mAggregations.customData["0"].mProperties.value));
													} else if (field == "Validated") {
														planesAccionUtilsHisto.filters
																.push(new sap.ui.model.Filter(
																		field,
																		sap.ui.model.FilterOperator.EQ,
																		oEvent.getParameters().filterItems[j].mAggregations.customData["0"].mProperties.value));
													
														/**
														 * INI MOD RTC 748088 Rafael Galán Baquero
														 * 11.07.2019
														 * Código nuevo
														*/
														/**
														 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020
														 * Código antiguo
													// Para departamento, se realiza la búsqueda por Key
													   }else if(field == "ZzDepartment"){				
														 * Código nuevo
														 */
														//Se incluye en la búsqueda por KEY para el campo origen
													   }else if(field == "ZzDepartment" || field == "ZzOrigen"){												
														/**
														 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
														 */

														planesAccionUtilsHisto.filters
														.push(new sap.ui.model.Filter(
																field,
																sap.ui.model.FilterOperator.EQ,
																oEvent.getParameters().filterItems[j].mProperties.key));
													
														/**
														 * FIN MOD RTC 748088 Rafael Galán Baquero
														 * 11.07.2019
														*/
													
													} else {
														if (planesAccionUtilsHisto
																.getStatusCode(
																		oEvent.getParameters().filterItems[j].mProperties.text,
																		that.oModelControllerHist) != "")
															planesAccionUtilsHisto.filters
																	.push(new sap.ui.model.Filter(
																			field,
																			sap.ui.model.FilterOperator.EQ,
																			// planesAccionUtilsHisto.getStatusCode(oEvent.getParameters().filterItems[j].mProperties.text,
																			// that.oModelControllerHist)));
																			oEvent.getParameters().filterItems[j].mProperties.text));
														else {
															planesAccionUtilsHisto.filters
																	.push(new sap.ui.model.Filter(
																			field,
																			sap.ui.model.FilterOperator.EQ,
																			oEvent.getParameters().filterItems[j].mProperties.text));							
																			
														}
													}
												});

								if (statusFalg) {
									for (i = planesAccionUtilsHisto.filters.length - 1; i >= 0; i--) {
										if (planesAccionUtilsHisto.filters[i].sPath == "Status")
											planesAccionUtilsHisto.filters.splice(i, 1);
									}
									$.each(aStatusFilters, function(i, n) {
										planesAccionUtilsHisto.filters.push(n);
									});
								} else {
									for (i = planesAccionUtilsHisto.filters.length - 1; i >= 0; i--) {
										if (planesAccionUtilsHisto.filters[i].sPath == "Status")
											planesAccionUtilsHisto.filters.splice(i, 1);
									}
									if ($.grep(planesAccionUtilsHisto.filters, function(n, i) {
										return n.sPath == "Status"
									}).length == 0) {
										planesAccionUtilsHisto.filters
												.push(new sap.ui.model.Filter("Status",
														sap.ui.model.FilterOperator.EQ, "03")); // Actualizado
										planesAccionUtilsHisto.filters
												.push(new sap.ui.model.Filter("Status",
														sap.ui.model.FilterOperator.EQ, "07")); // Obsoleto
										planesAccionUtilsHisto.filters
												.push(new sap.ui.model.Filter("Status",
														sap.ui.model.FilterOperator.EQ, "05")); // Se
										// asume
										// el
										// riesgo
										planesAccionUtilsHisto.filters
												.push(new sap.ui.model.Filter("Status",
														sap.ui.model.FilterOperator.EQ, "02")); // Finalizado
									}
								}
							} else if (that.mode == "THEME") {
								var aStatusFilters = [];
								var statusFalg = false;
								$
										.each(
												oEvent.getParameters().filterItems,
												function(j, value2) {
													var field = oEvent.getParameters().filterItems[j].oParent.mProperties.key;
													if (field == "Status") {
														aStatusFilters
																.push(new sap.ui.model.Filter(
																		"Status",
																		sap.ui.model.FilterOperator.EQ,
																		planesAccionUtilsHisto
																				.getStatusCode(
																						oEvent
																								.getParameters().filterItems[j].mProperties.text,
																						that.oModelControllerHist)));
														statusFalg = true;
													} else if (field == "AudGroup") {
														planesAccionUtilsHisto.filtersTemas
																.push(new sap.ui.model.Filter(
																		field,
																		sap.ui.model.FilterOperator.EQ,
																		oEvent.getParameters().filterItems[j].mAggregations.customData["0"].mProperties.value));
													} else if (field == "Validated") {
														planesAccionUtilsHisto.filtersTemas
																.push(new sap.ui.model.Filter(
																		field,
																		sap.ui.model.FilterOperator.EQ,
																		oEvent.getParameters().filterItems[j].mAggregations.customData["0"].mProperties.value));
														
														/**
														 * INI MOD RTC 748088 Rafael Galán Baquero
														 * 11.07.2019
														 * Código nuevo
														*/
													// Para departamento, se realiza la búsqueda por Key
													}else if(field == "ZzDepartment"){
														planesAccionUtilsHisto.filtersTemas
														.push(new sap.ui.model.Filter(
																field,
																sap.ui.model.FilterOperator.EQ,
																oEvent.getParameters().filterItems[j].mProperties.key));
													
														/**
														 * FIN MOD RTC 748088 Rafael Galán Baquero
														 * 11.07.2019
														*/
		
													} else {
														if (planesAccionUtilsHisto
																.getStatusCode(
																		oEvent.getParameters().filterItems[j].mProperties.text,
																		that.oModelControllerHist) != "")
															planesAccionUtilsHisto.filtersTemas
																	.push(new sap.ui.model.Filter(
																			field,
																			sap.ui.model.FilterOperator.EQ,
																			planesAccionUtilsHisto
																					.getStatusCode(
																							oEvent
																									.getParameters().filterItems[j].mProperties.text,
																							that.oModelControllerHist)));
														else {
															planesAccionUtilsHisto.filtersTemas
																	.push(new sap.ui.model.Filter(
																			field,
																			sap.ui.model.FilterOperator.EQ,
																			oEvent.getParameters().filterItems[j].mProperties.text));
														}
													}
												});

								// Si hi han status antics, els borra
								if (statusFalg) {
									for (i = planesAccionUtilsHisto.filtersTemas.length - 1; i >= 0; i--) {
										if (planesAccionUtilsHisto.filtersTemas[i].sPath == "Status")
											planesAccionUtilsHisto.filtersTemas.splice(i, 1);
									}
									// Afageix els status nous
									$.each(aStatusFilters, function(i, n) {
										planesAccionUtilsHisto.filtersTemas.push(n);
									});
								} else {
									for (i = planesAccionUtilsHisto.filtersTemas.length - 1; i >= 0; i--) {
										if (planesAccionUtilsHisto.filtersTemas[i].sPath == "Status")
											planesAccionUtilsHisto.filtersTemas.splice(i, 1);
									}

								}

							}

							// Extra filter text
							if (oEvent.getSource()._page2 != undefined)
							//Inicio SPAU 11/09/2018
								if(oEvent.getSource()._page2.mAggregations.content != undefined)
							//Fin SPAU 11/09/2018									
									if (oEvent.getSource()._page2.mAggregations.content["0"].mAggregations.formContainers != undefined)
										if (oEvent.getSource()._page2.mAggregations.content["0"].mAggregations.formContainers["0"] != undefined)
											if (oEvent.getSource()._page2.mAggregations.content["0"].mAggregations.formContainers["0"].mAggregations.formElements["0"].mAggregations.fields["0"].mProperties.value != "") {
												var value = oEvent.getSource()._page2.mAggregations.content["0"].mAggregations.formContainers["0"].mAggregations.formElements["0"].mAggregations.fields["0"].mProperties.value;
												var key = oEvent.getSource()._page2.mAggregations.content["0"].mAggregations.formContainers["0"].mAggregations.formElements["0"].mAggregations.label.mAggregations.customData["0"].mProperties.key;
												if (key == "Assigned") {
													if (that.mode == "NOTHEME") {
														for (i = planesAccionUtilsHisto.filters.length - 1; i >= 0; i--) {
															if (planesAccionUtilsHisto.filters[i].sPath == "Assigned")
																planesAccionUtilsHisto.filters.splice(
																		i, 1);
														}
													} else if (that.mode == "THEME") {
														for (i = planesAccionUtilsHisto.filtersTemas.length - 1; i >= 0; i--) {
															if (planesAccionUtilsHisto.filtersTemas[i].sPath == "Assigned")
																planesAccionUtilsHisto.filtersTemas
																		.splice(i, 1);
														}
													}
												}
												if (that.mode == "NOTHEME") {
													planesAccionUtilsHisto.filters
															.push(new sap.ui.model.Filter(
																	key,
																	sap.ui.model.FilterOperator.Contains,
																	value));
												} else if (that.mode == "THEME") {
													planesAccionUtilsHisto.filtersTemas
															.push(new sap.ui.model.Filter(
																	key,
																	sap.ui.model.FilterOperator.Contains,
																	value));
												}
											}
							// if(that.mode == "NOTHEME"){

							var aParameters = {
								"$skip" : 0,
								"$top" : 7
							};
							// var urlactionhisRegis =
							// "/InfoActionsSet?&$skip="+skip+"&$top="+top;
							con.Read(conHelper.params.urlactionhis, aParameters,
									planesAccionUtilsHisto.filters, planesAccionUtilsHisto.sorters,
									false, this, function(oData, oDataRes) {
										//								
										if (oData != undefined) {
											var oModelTable = newModelWithData(oData);
											// var oTable =
											// this.oController.getView().oTable;
											var component = sap.ui.getCore().getComponent(
													"tablePlanAccionesHis");
											var oTable = component.table;

											component.setDataModel(oModelTable, "actionhis");

											component.setCountFunction();
											if (planesAccionUtilsHisto.grouping) {
												var oBinding = oTable.getBinding("")
												oBinding.sort(planesAccionUtilsHisto.grouper)
											}
											component.refreshTablePaginationForFilteredItems(1, 7,
													false);
										}
										//
									}, "", null);

							// loadPlanesAccion(0, 7, , ,
							// planesAccionUtilsHisto.grouping);
							sap.ui
									.getCore()
									.getComponent("tablePlanAccionesHis")
									.createPaginationMenu("planesAccion", 7, "tablePlanAccionesHis");
							// }else if (that.mode == "THEME"){
							// loadPlanesAccionThemes(0, 7,
							// planesAccionUtilsHisto.filtersTemas,
							// planesAccionUtilsHisto.sortersTemas,
							// planesAccionUtilsHisto.grouping);
							// sap.ui.getCore().getComponent("tablePlanAccionesTema").createPaginationMenu("planesAccionTemas",7,"tablePlanAccionesTema","THEME");
							// }
							//			 
							// //Filtros estado anterior
							// planesAccionUtilsHisto.previousFilters =
							// $.parseJSON(JSON.stringify(planesAccionUtilsHisto.filters));
						};

						this.dialog.attachConfirm(confirmFunction);
					},

					// success : function(oData, oDataRes) {
					// //
					// if (oData != undefined) {
					// var oModelTable = newModelWithData(oData);
					// // var oTable = this.oController.getView().oTable;
					// var component =
					// sap.ui.getCore().getComponent("tablePlanAccionesHis");
					// var oTable = component.table;
					//
					// component.setDataModel(oModelTable, "actionhis");
					//
					// if (planesAccionUtilsHisto.grouping) {
					// var oBinding = oTable.getBinding("")
					// oBinding.sort(planesAccionUtilsHisto.grouper)
					// }
					// // component.refreshTablePaginationForFilteredItems(1,10,
					// // false);
					// }
					//
					// },
					// Funcion que a�ade todos los items al componente de
					// filtro, los agrupadores, los filtros y los ordenadores.
					addAllItems : function(sortItems, groupItems, filterItems, model, claus, table,
							mode, oController) {
						this.mode = mode;
						var dialog = this.dialog;
						var that = this;
						this.sortItems = sortItems;
						this.claus = claus;
						this.oModelControllerHist = oController.oSource;
						dialog.setSortDescending(true);

						$.each(sortItems, function(i, value) {
							var selected = (i == 1);
							
							
							/**
							 * INI MOD RTC 748088 Rafael Galán Baquero
							 * 11.07.2019
							 * Código antiguo
////                             if (claus[i] == "NameOrg")
//								dialog.addSortItem(new sap.m.ViewSettingsItem({
//									text : value,
//									key : "ZzAnOrg",
//									selected : selected
//								}));							
//								else
//								// A�adido para la b�squeda por fecha de
//								// vencimiento
//								var key = (value == planesAccionUtilsHisto.oBundle.getText("fechaVenc") ? "Deadline" : claus[i]); 
 
							* Código nuevo
							*/
							var key;
							
						     if (claus[i] == "NameOrg")
						    	 key = "ZzAnOrg";
						     																														
							
							// Para Department, se debe ordenar por departmentName
							else if(claus[i] == "ZzDepartment")
							key = 	"DepartmentName";
						     
						 	/**
						 	 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
						 	 * Código nuevo
						 	 */
						 	// se contempla origen
							else if(claus[i] == "ZzOrigen")
								key = 	"ZzOrigen";
						 	 
						 	/**
						 	 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
						 	 */	 
						     
							else
//								// Añadido para la  búsqueda por fecha de
//								// vencimiento
							 key = (value == planesAccionUtilsHisto.oBundle.getText("fechaVenc") ? "Deadline" : claus[i]);
							
							/**
							 * FIN MOD RTC 748088 Rafael Galán Baquero
							 * 11.07.2019
							*/
												
							dialog.addSortItem(new sap.m.ViewSettingsItem({
								text : value,
								key : key,
								selected : selected
							}));
						});

						$.each(groupItems, function(i, value) {
							// if(value == "Tipo" || value == "Estado"){
							/**
							 * INI MOD RTC 748088 Rafael Galán Baquero
							 * 11.07.2019
							* Código antiguo
//							 dialog.addGroupItem(new sap.m.ViewSettingsItem({
//								text : value,
//								key : claus[i],
//								selected : false
//							}));
//							// } 
							* Codigo nuevo
							*/
							var key_aux = claus[i];

							// Para Department, se debe ordenar por departmentName
							if(claus[i] == "ZzDepartment")
								key_aux = 'DepartmentName';

						 	/**
						 	 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
						 	 * Código nuevo
						 	 */
						 	// se contempla origen
							else if(claus[i] == "ZzOrigen")
								key_aux = 	"ZzOrigen";
						 	 
						 	/**
						 	 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
						 	 */	 
							
							dialog.addGroupItem(new sap.m.ViewSettingsItem({
								text : value,
								key : key_aux,
								selected : false
							}));
							
							/**
							 * FIN MOD RTC 748088 Rafael Galán Baquero
							 * 11.07.2019
							*/
							
						});

						var oModel = sap.ui.getCore().getModel(model);

						$
								.each(
										filterItems,
										function(i, value) {
											if (i < claus.length) {
												var items = [];
												var flac = false;

												if (claus[i] == "RankingDescr") {
													$
															.each(
																	that.oModelControllerHist
																			.getModel(
																					"criticidadStatus")
																			.getData().d.results,
																	function(j, n) {
																		items
																				.push(new sap.m.ViewSettingsItem(
																						{
																							text : n.Description
																						}));
																	});
													dialog
															.addFilterItem(new sap.m.ViewSettingsFilterItem(
																	{
																		setModel : oModel,
																		text : value,
																		key : claus[i],
																		items : [ items ]
																	}));
												} else if (claus[i] == "Validated") {
													$
															.each(
																	that.oModelControllerHist
																			.getModel(
																					"validatorStatus")
																			.getData().d.results,
																	function(j, n) {
																		if (n.Value != "00") { // Estado
																			// vac�o
																			// sin
																			// descripci�n
																			items
																					.push(new sap.m.ViewSettingsItem(
																							{
																								text : n.Description,
																								customData : new sap.ui.core.CustomData(
																										{
																											key : "key",
																											value : n.Value
																										})
																							}));
																		}
																	});
													dialog
															.addFilterItem(new sap.m.ViewSettingsFilterItem(
																	{
																		setModel : oModel,
																		text : value,
																		key : claus[i],
																		items : [ items ]
																	}));
												} else if (claus[i] == "StatusDescr") {
													var status = that.oModelControllerHist
															.getModel("statusPlModel").getData().d.results
															.filter(function(i) {
																return i.Objtyp == "ACTION"
																		&& i.Langu == "ES"
															});
													$
															.each(
																	status,
																	function(j, n) {
																		if (n.Status == "03"
																				|| n.Status == "07"
																				|| n.Status == "05"
																				|| n.Status == "02") {
																			items
																					.push(new sap.m.ViewSettingsItem(
																							{
																								text : n.StatusT,// planesAccionUtilsHisto.getStatusString(
																								// n.Status,
																								// that.oModelControllerHist)
																								customData : new sap.ui.core.CustomData(
																										{
																											key : "key",
																											value : n.StatusT
																										})
																							}));
																		}
																	});
													dialog
															.addFilterItem(new sap.m.ViewSettingsFilterItem(
																	{
																		setModel : oModel,
																		text : value,
																		key : claus[i],
																		items : [ items ]
																	}));
												} else if (claus[i] == "AudGroup") {
													$
															.each(
																	that.oModelControllerHist
																			.getModel(
																					"listGroupsFilter")
																			.getData().d.results,
																	function(j, n) {
																		items
																				.push(new sap.m.ViewSettingsItem(
																						{
																							text : n.GroupText,
																							customData : new sap.ui.core.CustomData(
																									{
																										key : "key",
																										value : n.GroupId
																									})
																						}));
																	});
													dialog
															.addFilterItem(new sap.m.ViewSettingsFilterItem(
																	{
																		setModel : oModel,
																		text : value,
																		key : claus[i],
																		items : [ items ]
																	}));
													
													/**
													 * INI MOD RTC 748088 Rafael Galán Baquero
													 * 11.07.2019
													* Código nuevo
													*/
													// Para el departamento, se debe añadir un campo multiselección
													// Se montan los elementos para el departamento
												}else if(claus[i]=="ZzDepartment"){
													// Se añaden los elementos desde el modelo
													$.each(getModel("DepHistActionPlan").getData().results,function(j,n){							
															items.push(
																new sap.m.ViewSettingsItem({
																	/**
																	 * INI MOD PPM 069908 Rafael Galán Baquero 10/02/2021
																	 * Código antiguo
																	 * text: n.AuditDepartment +' - '+ n.Text,
																	 * Codigo nuevo
																	*/
																	text: n.AuditDepartment +' - '+ n.Text,
																	/**
																	* FIN MOD PPM069908 Rafael Galán Baquero 10/02/2021
																	*/
																	key: n.AuditDepartment
																})
															);							
													});				
													 
													// Se añaden los items al filtro
													dialog.addFilterItem(
														new sap.m.ViewSettingsFilterItem({
															setModel: oModel,
															text:value,
															key: claus[i],
															items:[
															    items   
															],
															
														})
													);
													
													/**
													 * FIN MOD RTC 748088 Rafael Galán Baquero
													 * 11.07.2019
													*/
													
													/**
													 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
													 * Código nuevo
													 */
													//Se añade lista para el campo origen
													
												}else if(claus[i]=="ZzOrigen"){
													// Se añaden los elementos desde el modelo
													$.each(getModel("OrigenActionPlan").getData().results,function(j,n){							
															items.push(
																new sap.m.ViewSettingsItem({
																	text: n.Text,
																	key: n.Id
																})
															);							
													});				
													 
													// Se añaden los items al filtro
													dialog.addFilterItem(
														new sap.m.ViewSettingsFilterItem({
															setModel: oModel,
															text:planesAccionUtilsHisto.oBundle.getText('origen'),
															key: claus[i],
															items:[
															    items   
															],
															
														})
													);
													
													/**
													 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
													 */
													
												} else {
													dialog
															.addFilterItem(new sap.m.ViewSettingsCustomItem(
																	{
																		text : value,
																		customControl : new sap.ui.layout.form.Form(
																				{
																					editable : false,
																					width : "100%",
																					height : "100%",
																					layout : new sap.ui.layout.form.GridLayout(
																							{}),
																					formContainers : [ new sap.ui.layout.form.FormContainer(
																							{
																								formElements : [ new sap.ui.layout.form.FormElement(
																										{
																											label : new sap.m.Label(
																													{
																														text : value,
																														layoutData : new sap.ui.layout.form.GridElementData(
																																{
																																	hCells : "4"
																																}),
																														customData : new sap.ui.core.CustomData(
																																{
																																	key : claus[i]
																																})
																													})
																													.addStyleClass("lbAdUsr"),
																											fields : [
																													new sap.m.Input(
																															{
																																value : "",
																																placeholder : "Filtro",
																																editable : true,
																																required : false,
																																layoutData : new sap.ui.layout.form.GridElementData(
																																		{
																																			hCells : "auto"
																																		})
																															}), ]
																										}) ]
																							}) ]
																				})
																	}));
												}
											}
										});
					},

					// Funci�n que nos abre el filtro
					openDialog : function() {
						this.dialog.open();
					}
				});
