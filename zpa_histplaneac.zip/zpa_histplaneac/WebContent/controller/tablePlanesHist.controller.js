sap.ui.controller("appHistoPlanesAccion.controller.tablePlanesHist", {

	/**
	 * Called when a controller is instantiated and its View controls (if
	 * available) are already created. Can be used to modify the View before it
	 * is displayed, to bind event handlers and do other one-time
	 * initialization.
	 * 
	 * @memberOf zportalaudit.controller.planesAccion.PlanesAccion
	 */
	onInit : function() {  

		planesAccionUtilsHisto.filters.push(new sap.ui.model.Filter("Status",
				sap.ui.model.FilterOperator.EQ, "03")); // Obsoleto 
		planesAccionUtilsHisto.filters.push(new sap.ui.model.Filter("Status",
				sap.ui.model.FilterOperator.EQ, "07")); // Actualizado
		planesAccionUtilsHisto.filters.push(new sap.ui.model.Filter("Status",
				sap.ui.model.FilterOperator.EQ, "05")); // Se asume el riesgo
		planesAccionUtilsHisto.filters.push(new sap.ui.model.Filter("Status",
				sap.ui.model.FilterOperator.EQ, "02")); // Finalizado
		
// No se realiza filtro de verified en el front, se realiza desde el backend.
//		planesAccionUtilsHisto.filters.push(new sap.ui.model.Filter("Verified",
//				sap.ui.model.FilterOperator.EQ, "01"));
//		planesAccionUtilsHisto.filters.push(new sap.ui.model.Filter("Verified",
//				sap.ui.model.FilterOperator.EQ, "02"));		
//
		
		/**
		 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
		 * Código nuevo
		 */
		//Se obtienen los valores  disponibles en el sistema para el campo origen 
		con.Read(Helper.formatUrl(conHelper.params.urlOrigen,null),null,null,null,false, this, this.loadOrigen, "", this.getView());
		 
		/**
		 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
		 */		
		this.getView().addEventDelegate(
				{
					onBeforeShow : function(oEvent) {
						const AUDITADO = "ZSAP_GRCAUD_AUDITADO";
						const C_AUDITADO = "AUDITADO", C_AUDITOR = "AUDITOR";
						var roles;
						var component = sap.ui.getCore().getComponent("tablePlanAccionesHis");
						var oTable = component.table;

						if (oTable.mAggregations.columns == undefined) {
							oController = this.getView();
							oTemplate = this.getView().oTemplate;
							var isAuditado = planesAccionUtilsHisto.isAuditado(oController);
							$.each(planesAccionUtilsHisto.colNames, function(i, n) {
								if (isAuditado && n[1] == C_AUDITADO) {
									oColumn = new sap.m.Column({
										vAlign : sap.ui.core.VerticalAlign.Middle,
//										hAlign : sap.ui.core.TextAlign.Center,
										header : new sap.m.Text({
											text : Helper.getResourceText(n[0])
										// planesAccionUtilsHisto.oBundle.getText(n[0])
										// n[0]
										})
									});

									component.addColumns(oColumn);
								} else if (!isAuditado && n[1] == C_AUDITOR) {
									oColumn = new sap.m.Column({
										vAlign : sap.ui.core.VerticalAlign.Middle,
//										hAlign : sap.ui.core.TextAlign.Center,
										header : new sap.m.Text({
											text : Helper.getResourceText(n[0])
										// planesAccionUtilsHisto.oBundle.getText(n[0])
										// n[0]
										})
									});
									component.addColumns(oColumn);
								}
							});

							$.each(planesAccionUtilsHisto.cellTemplate, function(i, n) {
								if ((isAuditado && n[1] == C_AUDITADO)
										|| (!isAuditado && n[1] == C_AUDITOR))
									switch (n[0]) {
									case "{actionhis>Validated}":
										oTemplate.addCell(new sap.m.Text({
											text : n[0],
										}).bindProperty("text", {
											parts : [ "actionhis>Validated" ],
											formatter : function(Validated) {
												return planesAccionUtilsHisto.getStatusText(
														Validated, oController);
											}
										}));
										break;
									case "{actionhis>Deadline}" || "{actionhis>FinalDate}":
										oTemplate.addCell(new sap.m.Text({
											text : n[0]
										}).bindProperty("text", {
											parts : [ "actionhis>Deadline" ],
											formatter : function(fecha) {
												return planesAccionUtilsHisto.transformDate(fecha);
											}
										}));
										break;
								   
										/**
										 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
										 * Código nuevo
										 * Se contempla la celda del campo origen
										 */
									case "{actionhis>ZzOrigen}":
										oTemplate.addCell(new sap.m.Text({
											text : n[0]
										}).bindProperty("text", {
											parts : [ "actionhis>ZzOrigen" ],
											formatter : function(origen) {
												return planesAccionUtilsHisto.getOrigenText(origen);
											}
										}));
										break;										 		
										/**
										 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
										 */

									 /**
									 * INI MOD PPM 069908 Rafael Galán Baquero 10/02/2021				
									 * Código nuevo
									 * Se contempla la celda del campo departamento y se concatena el código de dpto al nombre
									 */
								case "{actionhis>DepartmentName}":
									oTemplate.addCell(new sap.m.Text({
										text : n[0]
									}).bindProperty("text", {
										parts : [ "actionhis>DepartmentName", "actionhis>ZzDepartment" ],
										formatter : function(departName,depart) {
											/**var oModel = sap.ui.getCore().getModel("DepHistActionPlan");
											if (oModel !== undefined)
											var findDepart = oModel.getData().results.filter(function(n,i){
												return depart === n.Text;
											});
											
											return findDepart.length > 0 ? findDepart[0].AuditDepartment +' - ' + findDepart[0].Text : depart;*/
											//return depart +' - '+ departName;
											return departName;
										}
									}));
									break;										 		
									/**
									 *  FIN MOD PPM 069908 Rafael Galán Baquero 10/02/2021				
									 */
										
										
									default:
										oTemplate.addCell(new sap.m.Text({
											text : n[0]
										}));
										break;
									}
							});

						}
						this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);

						var aParameters = {
							"$skip" : 0,
							"$top" : 7
						};
						con.Read(Helper.formatUrl(conHelper.params.urlactionhis, null),
								aParameters, planesAccionUtilsHisto.filters, planesAccionUtilsHisto.sorters, false, this,
								this.success, "", this.getView());

					}
				}, this);
		/**
		 * INI MOD RTC 748088 Rafael Galán Baquero
		 * 11.07.2019
	     * Código nuevo
		*/
		// Se obtienen los departamentos
		con.Read(Helper.formatUrl(conHelper.params.urlDep,null),null,null,null,false, this, this.loadDepartments, "", this.getView())
	},

	// Función que se encarga de obtener los departamentos
	loadDepartments: function(oData,oDataRes){
		if(oData != undefined){

		var oModel = new sap.ui.model.json.JSONModel();
		oModel.setData(oData);			
		sap.ui.getCore().setModel(oModel,"DepHistActionPlan");
		
		}
			
		/**
		 * FIN MOD RTC 748088 Rafael Galán Baquero
		 * 11.07.2019
		*/

	},
	/**
	 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
	 * Código nuevo
	 */
	//Se obtienen los valores  disponibles en el sistema para el campo origen 
	 loadOrigen: function(oData,oDataRes) {		
		 if(oData != undefined){		
					var oModel = new sap.ui.model.json.JSONModel();
					oModel.setData(oData);
					async: false,	
				sap.ui.getCore().setModel(oModel,"OrigenActionPlan");
		 }
		
	},
	 
	/**
	 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
	 */	
	
	success : function(oData, oDataRes) {
		// 
		if (oData != undefined) {
			var oModelTable = newModelWithData(oData);
			// var oTable = this.oController.getView().oTable;
			var component = sap.ui.getCore().getComponent("tablePlanAccionesHis");
			var oTable = component.table;
			// oTable.setModel(oModel);
			// oTable.getModel().updateBindings(true);

			var oModel = this.oController.getView().getModel("actionhis");
			oModel.setData(oData);
			oModel.updateBindings(true);

			component.setDataModel(oModelTable, "actionhis");

			component.setCountFunction();

			component.createPaginationMenu("planesAccion", 7, "tablePlanAccionesHis", false);

			component.refreshTablePaginationForFilteredItems(1, 10, false);
		}

	},

	/**
	 * Similar to onAfterRendering, but this hook is invoked before the
	 * controller's View is re-rendered (NOT before the first rendering!
	 * onInit() is used for that one!).
	 * 
	 * @memberOf zportalaudit.controller.planesAccion.PlanesAccion
	 */
	// onBeforeRendering: function() {
	//
	// },
	/**
	 * Called when the View has been rendered (so its HTML is part of the
	 * document). Post-rendering manipulations of the HTML could be done here.
	 * This hook is the same one that SAPUI5 controls get after being rendered.
	 * 
	 * @memberOf zportalaudit.controller.planesAccion.PlanesAccion
	 */
	// onAfterRendering: function() {
	//
	// },
	/**
	 * Called when the Controller is destroyed. Use this one to free resources
	 * and finalize activities.
	 * 
	 * @memberOf zportalaudit.controller.planesAccion.PlanesAccion
	 */
	// onExit: function() {
	//
	// }
	populateData : function(start, rowCount) {

		var view = this.getView();
		var oTable = view.oTable;
		var buttonNext = view.oButton1;
		var buttonPrev = view.oButton2;
		var items = oTable.getItems()
		buttonNext.setEnabled(true);
		buttonPrev.setEnabled(true);

		// Ponemos todas las filas ocultas para continuaci�n mostrar las que
		// correspondan
		$.each(items, function(i, n) {
			items[i].setVisible(false)
		})
		// Recorremos las filas y vamos poniendolas visibles
		for (i = start; i < start + rowCount; i++) {
			items[i].setVisible(true);
			if (i == oTable.getItems().length - 1) {
				buttonNext.setEnabled(false);
				break;
			}

		}
		// Desactivamos el bot�n de atr�s en caso de estar en la p�gina 1
		if (start == 0) {
			buttonPrev.setEnabled(false);
		}
	},
	showDetail : function(oEvent) {

		var navi = oEvent.getSource()._oItemNavigation

		var that = this;

		var oModel = oEvent.getSource().getModel("actionhis");
		var sPath = oEvent.getSource().oBindingContexts.actionhis.sPath// getSelectedItem().getBindingContext().sPath;
		var contextData = oModel.getProperty(sPath);

		var key = "binary'" + convertKey(contextData.ActionKey) + "'"

		var url = "/InfoActionDetailSet";
		this.contextData = contextData;
		
		sap.ui.getCore().setModel(new sap.ui.model.json.JSONModel(contextData),"PlanesContextData");
		var aParameters = {
			"$filter" : "ActionKey eq " + key,
			"$expand" : "InfoAccessList,InfoThemes"
		};
		con.Read(url, aParameters, null, null, true, this, this.successDetail, "", this.getView());
		// Recuperamos Adjuntos
		var keyBina = convertKey(contextData.ActionKey);
		var keyAtt = keyBina.substring(0, 8) + "-" + keyBina.substring(8, 12) + "-"
				+ keyBina.substring(12, 16) + "-" + keyBina.substring(16, 20) + "-"
				+ keyBina.substring(20);
		var url = "/Actions(guid'" + keyAtt + "')/WorkPapers";
		con2.Read(url, null, null, null, true, this, this.successAttac, "", this.getView());

			this.oRouter.navTo("PlanesDetail");


	},

	successDetail : function(oData, oDataRes) {

		// var model = new sap.ui.model.json.JSONModel();
		
		var contextData = this.oController.contextData;
		if (oData.results.length > 0) {

			$.each(contextData, function(i, n) {
				oData.results[0][i] = n;
			})
			oData.results[0].ReportId = contextData.ZzReportId;
			oData.results[0].ActualDeadline = contextData.Deadline;
			oData.results[0].ActualStatus = contextData.Status;
			oData.results[0].ActualStatusDescr = contextData.StatusDescr;
		}

		var oModel = this.oController.getView().getModel("actionPlanDetail");
		oModel.setData(oData.results[0]);
		oModel.updateBindings(true); 

		// Recuperamos Notas
		var keyConverted = "binary'" + convertKey(oData.results[0].ActionKey) + "'";
		var url = "/InfoActionDetailSet" + "(" + keyConverted
				+ ")/NoteSet?$orderby=CreateTime desc";

		var aParameters = { 
			"$orderby" : 'CreateTime desc'
		};
		con.Read(url, aParameters, null, null, false, this, this.oController.succesGetNotes, "",
				this.oController.getView());
		

	},
	succesGetNotes : function(oData, oDataRes) {
		var oModel = this.oController.oController.getView().getModel("actionPlanDetailNote");
		var isAuditado = planesAccionUtilsHisto.isAuditado(oController)		

		//ocultar los comentarios de verificaci�n con STATUS = �02� de la tabla 
		//GRCAUD_D_NOTE siempre que la acci�n asociada a la nota este verificada, 
		//es decir que el campo ZZ_VERIFIED = 01 o ZZ_VERIFIED = 02.
		//Adem�s el usuario tiene que ser auditado
		var Verified = oController.oController.contextData.Verified;
		if(isAuditado && oData.results.length > 0 && (Verified == "01" || Verified == "02") ){
			//Recuperamos todos comentarios con Status 02
			var comenSta02 = oData.results.filter(function(i) { return i.Status == "02"  });
			if (comenSta02.length > 0) {
				//REcuperamos la KEY correspondiente del �ltimo comentario, como viene ordenado del back, ser�a el primer comentario
				var key = comenSta02[0].Key;
				//Recuperamos todos los comentarios menos el correspondiente por KEY
				oData.results = oData.results.filter(function(i) { return i.Key != key  }); // filtramos			
				
			}
		}	
		
		oModel.setData(oData.results);
		oModel.updateBindings(true);
	},

	successAttac : function(oData, oDataRes) {
		// Para cada attachement debemos obtener sus datos y la URL del $value
		var data = [];
		this.oController.dataAttac = data;
		var that = this;
		//INI Ajuste SPAU 22/10/18
		// Codigo nuevo 
		// Se inicializa el modelo de ficheros adjuntos del plan
		var oModel = this.oController.getView().getModel("actionAttac");
		oModel.setData(this.oController.dataAttac);
		// Fin Ajuste SPAU 22/10/18
		$.each(oData.results, function(i, n) {
			var item = {};
			item.CreateBy = n.CreateBy;
			item.CreateByName = n.CreateByName;
			item.CreateTime = n.CreateTime;
			item.Name = n.Name;
			item.DeleteUrl = n.__metadata.uri;
			// item.ServiceURL = n.ServiceURL;
			item.Service = that.oController.getView().getModel("service2").sServiceUrl;
			let url = "/" + n.ServiceURL + "/File";
			that.item = item;
			//INI ajuste SPAU 22/10/18
			// Se añade el elemento iterado al objeto de Controlador dataAttac
			that.oController.dataAttac.push(item);
			//	FIN ajuste SPAU 22/10/18

			con2.Read(url, null, null, null, false, that, that.oController.successAttacDeta, "",
					that.oController.getView());
		});

	},
	successAttacDeta : function(oData, oDataRes) {
		// INI Ajuste SPAI 22/10/18
		//Código antiguo
		//var item = this.oController.item;
		//item.MimeType = oData.MimeTypeKey;
		//item.DocId = oData.Key;
		//item.Url = window.location.protocol + "//" + window.location.hostname + ":" + window.location.port + item.Service 
		//item.Url += "/FileSet(guid'" + oData.Key + "')/$value";
		//this.oController.oController.dataAttac.push(item);
		
		// Código nuevo
//		Se recorren los adjuntos y si coincide el nombre (que es unico por plan acción), se completa la información
		$.each(this.oController.oController.dataAttac, function(i,n){
			if(oData.Name == n.Name){
				n.MimeType = oData.MimeTypeKey;
				n.DocId = oData.Key;
				n.Url = window.location.protocol + "//" + window.location.hostname + ":" + window.location.port + n.Service 
				n.Url += "/FileSet(guid'" + oData.Key + "')/$value";
//				Salimos del $each			
				return false;
			}
		});

		// FIN Ajuste SPAI 22/10/18
		
		
		
		var oModel = this.oController.oController.getView().getModel("actionAttac");
		oModel.setData(this.oController.oController.dataAttac);
		oModel.updateBindings(true);
	},

	reloadPage : function(key) {
	},

	onFilterPress : function(oController) {
		if (!sap.ui.getCore().getComponent("planAccionFilterHist")) {
			var oFilterComp = new sap.ui.getCore().createComponent({
				name : "filterComponentHist",
				id : "planAccionFilterHist",
				settings : {
					refObject : "tablePlanAccionesHis"
				},
			});
			// var component = oController.oSource.mEventRegistry.press[0]
			var component = sap.ui.getCore().getComponent("tablePlanAccionesHis");
			var table = component.table;
			oFilterComp.addAllItems([ planesAccionUtilsHisto.oBundle.getText("criticidad"),
					planesAccionUtilsHisto.oBundle.getText("numInformes"),
					planesAccionUtilsHisto.oBundle.getText("numAccion"),
					planesAccionUtilsHisto.oBundle.getText("titulo"),
					planesAccionUtilsHisto.oBundle.getText("departamento"),
					planesAccionUtilsHisto.oBundle.getText("grupo"),
					planesAccionUtilsHisto.oBundle.getText("responsable"),
					planesAccionUtilsHisto.oBundle.getText("estado"),
					planesAccionUtilsHisto.oBundle.getText("estadoVal"),
					/**
					 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
					 * Código nuevo
					 */
					//Se contempla el campo origen
					planesAccionUtilsHisto.oBundle.getText("origen"),
					/**
					 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
					 */
					planesAccionUtilsHisto.oBundle.getText("fechaVenc"),
					
					], [
					planesAccionUtilsHisto.oBundle.getText("criticidad"),
					planesAccionUtilsHisto.oBundle.getText("numInformes"),
					planesAccionUtilsHisto.oBundle.getText("numAccion"),
					planesAccionUtilsHisto.oBundle.getText("titulo"),
					planesAccionUtilsHisto.oBundle.getText("departamento"),
					planesAccionUtilsHisto.oBundle.getText("grupo"),
					planesAccionUtilsHisto.oBundle.getText("responsable"),
					planesAccionUtilsHisto.oBundle.getText("estado"),
					planesAccionUtilsHisto.oBundle.getText("estadoVal"),
					/**
					 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
					 * Código nuevo
					 */
					//Se contempla el campo origen
					planesAccionUtilsHisto.oBundle.getText("origen"),
					/**
					 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
					 */
					planesAccionUtilsHisto.oBundle.getText("fechaVenc"),					
					], [
					planesAccionUtilsHisto.oBundle.getText("criticidad"),
					planesAccionUtilsHisto.oBundle.getText("numInformes"),
					planesAccionUtilsHisto.oBundle.getText("numAccion"),
					planesAccionUtilsHisto.oBundle.getText("titulo"),
					planesAccionUtilsHisto.oBundle.getText("departamento"),
					planesAccionUtilsHisto.oBundle.getText("grupo"),
					planesAccionUtilsHisto.oBundle.getText("responsable"),
					planesAccionUtilsHisto.oBundle.getText("estado"),
					planesAccionUtilsHisto.oBundle.getText("estadoVal"),
					/**
					 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
					 * Código nuevo
					 */
					//Se contempla el campo origen
					,planesAccionUtilsHisto.oBundle.getText("origen"),
					/**
					 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
					 */
					planesAccionUtilsHisto.oBundle.getText("fechaVenc") 	
					], [
					planesAccionUtilsHisto.oBundle.getText("criticidad"),
					planesAccionUtilsHisto.oBundle.getText("numInformes"),
					planesAccionUtilsHisto.oBundle.getText("numAccion"),
					planesAccionUtilsHisto.oBundle.getText("titulo"),
					planesAccionUtilsHisto.oBundle.getText("departamento"),
					planesAccionUtilsHisto.oBundle.getText("grupo"),
					planesAccionUtilsHisto.oBundle.getText("responsable"),
					planesAccionUtilsHisto.oBundle.getText("estado"),
					planesAccionUtilsHisto.oBundle.getText("estadoVal"),
					/**
					 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
					 * Código nuevo
					 */
					//Se contempla el campo origen
					planesAccionUtilsHisto.oBundle.getText("origen"),
					/**
					 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
					 */
					planesAccionUtilsHisto.oBundle.getText("fechaVenc"),
				
					], ["RankingDescr",
						/**
						 * INI MOD RTC 748088
						 * 11.07.2019
						 * Código antiguo
//						 "ZzReportId", "Id", "Title", "DepartmentName", "AudGroup", "NameOrg", 
						 
						 * Código nuevo
						 */
						"ZzReportId", "Id", "Title", "ZzDepartment", "AudGroup", "NameOrg",
						/**
						 * FIN  MOD RTC 748088
						 * 11.07.2019
						*/
						
					"StatusDescr", "Validated"
					
					/**
					 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
					 * Código nuevo
					 */
					//Se contempla el campo origen
					 	,"ZzOrigen",	
					/**
					 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
					 * 
					 */ 
					], table, "NOTHEME", oController);

			var oCompCont = new sap.ui.core.ComponentContainer({
				component : oFilterComp
			});

			oFilterComp.openDialog();
			component.refreshTablePaginationForFilteredItems(1, 10, false);
		} else {
			var oFilterComp = sap.ui.getCore().getComponent("planAccionFilterHist");
			var component = sap.ui.getCore().getComponent("tablePlanAccionesHis");
			var oCompCont = new sap.ui.core.ComponentContainer({
				component : oFilterComp
			});
			oFilterComp.oModelControllerHist = this
			oFilterComp.openDialog();
			component.refreshTablePaginationForFilteredItems(1, 10, false);
		}
	},

	// onAdd : function() {
	//
	// },
	//
	// doSave : function() {
	//
	// },

	doBack : function() {
		// sap.ui.getCore().byId('launchpad').to('tileContainer');
	},

// doValidateDate : function(oEvent) {
// var date = oEvent.getSource().getValue();
// },

	
	
});