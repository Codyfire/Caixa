sap.ui.controller("appHistoPlanesAccion.controller.PlanesDetail", {

	/** 
	 * Called when a controller is instantiated and its View controls (if
	 * available) are already created. Can be used to modify the View before it
	 * is displayed, to bind event handlers and do other one-time
	 * initialization.
	 * 
	 * @memberOf zportalaudit.view.planesAccion.PlanesDetail
	 */
	onInit : function() {   
		this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		// this.oRouter.attachRouteMatched(function (oEvent) {
		// debugger
		// }, this);
		this.getView().addEventDelegate({
			onBeforeShow : function(oEvent) {
				this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				// Cargamos modelos de detalles, notas y adjuntos
				var oTable = this.getView().table;
				oTable.setModel(this.getView().getModel("actionPlanDetail"));
				oTable.getModel().updateBindings(true);

				var commentList = this.getView().commentList;
				commentList.setModel(this.getView().getModel("actionPlanDetailNote"));
				commentList.getModel().updateBindings(true);

				var isAuditado = !planesAccionUtilsHisto.isAuditado(this.getView())
				var verificado = this.getView().verificado;
				var fechaVerificado = this.getView().fechaVerificado;

				//verificado.setVisible(isAuditado);
				//fechaVerificado.setVisible(isAuditado);

				var uploader = this.getView().uploader;
				uploader.setModel(this.getView().getModel("actionAttac"));
				uploader.getModel().updateBindings(true);
			}
		}, this);

	},

	/**
	 * Similar to onAfterRendering, but this hook is invoked before the
	 * controller's View is re-rendered (NOT before the first rendering!
	 * onInit() is used for that one!).
	 * 
	 * @memberOf zportalaudit.view.planesAccion.PlanesDetail
	 */
	// onBeforeRendering: function() {
	//
	// },
	/**
	 * 
	 * 
	 * 
	 * 
	 * @memberOf zportalaudit.view.planesAccion.PlanesDetail
	 */
	// success : function() {
	//
	// },
	/**
	 * Called when the View has been rendered (so its HTML is part of the
	 * document). Post-rendering manipulations of the HTML could be done here.
	 * This hook is the same one that SAPUI5 controls get after being rendered.
	 * 
	 * @memberOf zportalaudit.view.planesAccion.PlanesDetail
	 */
	// onAfterRendering : function() {
	//		
	// },
	/**
	 * Called when the Controller is destroyed. Use this one to free resources
	 * and finalize activities.
	 * 
	 * @memberOf zportalaudit.view.planesAccion.PlanesDetail
	 */
	// onExit: function() {
	//
	// }
	doBack : function(oController) {

		this.oRouter.navTo("tablePlanesHist");

	},

});