var conHelper = {};

conHelper.params = {
		urlactionhis : "/InfoActionsSet",
		urlactiondetail	: "/InfoActionDetailSet$filter=ActionKey eq {0}",
		urlrol : "/InfoUserRolSet",
		/**
		 * INI MOD RTC 748088 Rafael Galán Baquero
		 * 11.07.2019
		 * Código nuevo
		*/
			urlDep: "/InfoDepAuditSet"		
			/**
			 * FIN MOD RTC 748088 Rafael Galán Baquero
			 * 11.07.2019
			 */
				/**
				 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
				 * Código nuevo
				 */
				//Se añade el servicio para el campo origen
				,urlOrigen: "/InfoOrigenSet"	
				/**
				 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
				 */

					
}

conHelper.functionImports = {}



