// Definición Clase Helper
var Helper = {};

///////////////////////
// Funciones Strings //
///////////////////////

// Función startsWith
if (!String.prototype.startsWith) {
	  String.prototype.startsWith = function(stringBuscada, posicion) {
	    posicion = posicion || 0;
	    return this.indexOf(stringBuscada, posicion) === posicion;
	  };
}

// Función contains
if (!String.prototype.contains) {
	String.prototype.contains = function(it) { return this.indexOf(it) != -1; }
}

// Función eliminar espacios en blanco iniciales/finales
if (!String.prototype.trim) {
	String.prototype.trim = String.prototype.trim || function() {
		return this.replace(/^\s+|\s+$/,"");
	}
}

// Función reemplazar todas las ocurrencias
if (!String.prototype.replaceAll) {
	String.prototype.replaceAll = function(search, replacement) {
		var target = this;
		return target.replace(new RegExp(search, 'g'), replacement);
	}
}

// Función para capitalizar la primera letra de string
if	(!String.prototype.capitalize) {
	String.prototype.capitalize =  function() {
		var str = this.toLowerCase();
		return str.replace(/(?:^\w|[A-Z]|\b\w)/g, function(letter, index) {
			return letter.toUpperCase();
		  }).replace(/\s+/g, ' ');
	}
}

// Función para capitalizar la primera letra de string y quitar todos los espacios
if	(!String.prototype.capitalizeNoSpaces) {
	String.prototype.capitalizeNoSpaces =  function() {
		var str = this.toLowerCase();
		return str.replace(/(?:^\w|[A-Z]|\b\w)/g, function(letter, index) {
			return letter.toUpperCase();
		  }).replace(/\s+/g, '');
	}
}

// Función para capitalizar la primera letra de cada palabra de un string (excepto la primera palabra)
if	(!String.prototype.camelize) {
	String.prototype.camelize =  function() {
		return this.replace(/(?:^\w|[A-Z]|\b\w)/g, function(letter, index) {
			return index == 0 ? letter.toLowerCase() : letter.toUpperCase();
		  }).replace(/\s+/g, ' ');
	}
}

// Función para capitalizar la primera letra de cada palabra de un string y quitar todos los espacios (excepto la primera palabra)
if	(!String.prototype.camelizeNoSpaces) {
	String.prototype.camelizeNoSpaces =  function() {
		return this.replace(/(?:^\w|[A-Z]|\b\w)/g, function(letter, index) {
			return index == 0 ? letter.toLowerCase() : letter.toUpperCase();
		  }).replace(/\s+/g, '');
	}
}

// Función para convertir un boolean de oData en Boolean de JS -> En caso de no ser un boolean devuelve FALSE!!
if	(!String.prototype.toBool) {
	String.prototype.toBool = function() { try{ return JSON.parse(this) }  catch(err) { return false } }
}

// Función para comprobar si un String termina con el String del parámetro -> Nota: Case sensitive
if	(!String.prototype.endsWith) {
	String.prototype.endsWith =  function(text) { 
		var txtLen = text.length;
		var thisLen = this.length;
		
		if ( txtLen > thisLen ) return false;
		
		var subStr = this.substring( thisLen - txtLen );
		
		return substr === text ? true : false;
	}
}

//Función para obtener float a partir de un string que tenga decimales
if(!String.prototype.toFloat) {
	String.prototype.toFloat =  function() { 
		var regex = /[+-]?\d+(\.\d+)?/g;
		return parseFloat(this.match(regex));
	}
}

// Función para reemplazar parámetros en un String.
Helper.formatUrl = function(source, params) {
	// source -> String con parametros {0},{1}...
	// params -> Array con los valores ["Hello","World!"]
	
	// Replace all params in function
	if(params) {
	    $.each(params,function (i, n) {
		    if(n != undefined && n != null) {
			    source = source.replace(new RegExp("\\{" + i + "\\}", "g"), function () {
			            return '\'' + n + '\'';
			        });
		    }
	    })
	}

	// Other params will be replace by ''
    source = source.replace(new RegExp("\\{[0-9]+\\}", "g"), function () {
            return '\'\'';
    });
    
    return source;
}

// Función para recuperar el usuario conectado a Fiori
Helper.getFioriUser = function(){
	return sap.ushell.Container.getService("UserInfo").getId();
}

///////////////////////
// Funciones Formato //
///////////////////////

Helper.isEmailAddress = function(str) {
	var pattern =/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	return pattern.test(str);  // returns a boolean
}

Helper.validateEmail = function(value, input, view){ //retorn true si el formato es el correcto
	var re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	var result = re.test(value);
	
	if(input) {
		if(result) {
			input.setValueState(sap.ui.core.ValueState.None);
		} else {
			input.setValueState(sap.ui.core.ValueState.Error);
			input.setValueStateText(view.getModel("i18n").getResourceBundle().getText("errorEmail"));
		}
	} 
	
	return result;
}

//Valida NIF
Helper.validateNif = function(dni, input, showSuccess, view, errorDni) {
		if(dni != undefined && dni != ""){
		  var numero;
		  var letr;
		  var letra;
		  var expresion_regular_dni;
		 
		  expresion_regular_dni = /^\d{8}[a-zA-Z]$/;
		 
		  if(expresion_regular_dni.test(dni) == true){
		     numero = dni.substr(0,dni.length-1);
		     letr = dni.substr(dni.length-1,1);
		     numero = numero % 23;
		     letra='TRWAGMYFPDXBNJZSQVHLCKET';
		     letra=letra.substring(numero,numero+1);
		    if (letra!=letr.toUpperCase()) {
		    	//oEvent.getSource()
		    	input.setValueState(sap.ui.core.ValueState.Error); 
		     }else {
		    	 if(showSuccess) {
			    	 input.setValueState(sap.ui.core.ValueState.Success);
		    	 } else {
		    		 input.setValueState(sap.ui.core.ValueState.None);
		    	 }
		     }
		  }else {
			  input.setValueState(sap.ui.core.ValueState.Error);
			  input.setValueStateText(view.getModel("i18n").getResourceBundle().getText("errorNifCif"));
			  if(errorDni) input.setValueStateText(view.getModel("i18n").getResourceBundle().getText("errorDni"));
		   }
		 }else{
			 input.setValueState(sap.ui.core.ValueState.None); 
		 }
}

//Valida NIF y NIE
Helper.validateNie = function(dni, input, showSuccess, view) {

	  var validChars = 'TRWAGMYFPDXBNJZSQVHLCKET';
//	  var nifRexp = /^[0-9]{8}[TRWAGMYFPDXBNJZSQVHLCKET]{1}$/i;
	  var nieRexp = /^[XYZ]{1}[0-9]{7}[TRWAGMYFPDXBNJZSQVHLCKET]{1}$/i;
	  var str = dni.toString().toUpperCase();

	  if (!nieRexp.test(str)) {
		  input.setValueStateText(view.getModel("i18n").getResourceBundle().getText("errorNIF_NIE"));
		  input.setValueState(sap.ui.core.ValueState.Error);
		  return false;
	  }

	  var nie = str.replace(/^[X]/, '0').replace(/^[Y]/, '1').replace(/^[Z]/, '2');

	  var letter = str.substr(-1);
	  var charIndex = parseInt(nie.substr(0, 8)) % 23;

	  if (validChars.charAt(charIndex) === letter) {
		  if(showSuccess) {
			  input.setValueState(sap.ui.core.ValueState.Success);
		  } else {
			  input.setValueState(sap.ui.core.ValueState.None);
		  }
		  return true;
	  }

	  if(showSuccess) {
		  input.setValueState(sap.ui.core.ValueState.Success);
	  } else {
		  input.setValueState(sap.ui.core.ValueState.None);
	  }
	  return false

}

Helper.validateCIF = function(cif, input, showSuccess) {
	var regex_cif = /^([ABCDEFGHJNPQRSUVW])(\d{7})([0-9A-J])$/;
	
	  if(regex_cif.test(cif) === true){
		  
		  //First we take all digits we need
		  var initialChar = cif.substring(0,1);
		  var centralDigits = cif.substring(1,8);
		  centralDigits = centralDigits.split("");
		  var controlChar = cif.substring(8,9);
		  
		  //Second we split the central digits on odd and even.
		  var evenNumbers = [];
		  var oddNumbers = [];
		  var i = 0;
		  for(i = 1; i <= centralDigits.length; ++i) {
			  if(i % 2 === 0) {
				  evenNumbers.push(centralDigits[i-1]);
			  } else {
				  oddNumbers.push(centralDigits[i-1]);
			  }
		  }
		  
		  //Now we sum all even numbers and call it "A"
		  var A = 0;
		  for(i = 0; i < evenNumbers.length; ++i) {
			  A += JSON.parse(evenNumbers[i]);
		  }
		  
		  //For every odd digit we multiply it by 2 and sum the resultant digits. We accumulate the result for every odd number and call
		  //it B.
		  var B = 0;
		  for(i = 0; i < oddNumbers.length; ++i) {
			  
			  var multiplied = oddNumbers[i] * 2;
			  var multipliedString = multiplied.toString();
			  multipliedString = multipliedString.split("");
			  var digitSum = 0;
			  for(var j = 0; j < multipliedString.length; ++j) {
				  digitSum += JSON.parse(multipliedString[j]);
			  }
			  
			  B += digitSum;
			  
		  }
		  
		  //Then we sum A and B and get C
		  var C = A + B;
		  
		  //Now we take only the last digit of C and call it E
		  var CString = C.toString();
		  CString = CString.split("");
		  var lastDigitOfC = CString[CString.length - 1];
		  E = JSON.parse(lastDigitOfC);
		  
		  //Now, if E != 0 we calculate  10 - E = D. If E = 0 then D = 0. Then we calculate the resulting digit (controlD)
		  //depending on D.
		  var D = 0;
		  if (E !== 0) {
			  D = 10 - E;
		  }
		  
		  //Last digit must match the following relation if it's a char or be equal at D if not.
		  // ControlC in case it's a char. ControlI in case it's a integer.
		  var controlC;
		  switch(D) {
		  	case 0:
		  		controlC = "J";
		  		break
		  	case 1:
		  		controlC = "A";
		  		break
		  	case 2:
		  		controlC = "B";
		  		break
		  	case 3:
		  		controlC = "C";
		  		break
		  	case 4:
		  		controlC = "D";
		  		break
		  	case 5:
		  		controlC = "E";
		  		break
		  	case 6:
		  		controlC = "F";
		  		break
		  	case 7:
		  		controlC = "G";
		  		break
		  	case 8:
		  		controlC = "H";
		  		break
		  	case 9:
		  		controlC = "I";
		  		break
		  }
		  
		  var ControlI = D;		 
		  var control_regex = /[A-Za-z]/;
		  //Si NO es residente tiene que ser una letra
		  if(cif.substring(1,3) === "00") {
			  
			  //If regex test is passed then it's a char (ControlI === JSON.parse(controlChar)) 
			  if(control_regex.test(controlChar)) {
				  if(controlC === controlChar) {
					  if(showSuccess) {
						  input.setValueState(sap.ui.core.ValueState.Success); 
					  } else {
						  input.setValueState(sap.ui.core.ValueState.None); 
					  }
					  return true;
				  } else {
					  input.setValueState(sap.ui.core.ValueState.Error);
					  input.setValueStateText(view.getModel("i18n").getResourceBundle().getText("errorNifCif"));
					  return false;
				  }
			  } else {
				  input.setValueState(sap.ui.core.ValueState.Error);
				  input.setValueStateText(view.getModel("i18n").getResourceBundle().getText("errorNifCif"));
				  return false;
			  }
			  
		  } else {
			  
			  switch(initialChar) {
			  	case "P":
			  	case "Q":
			  	case "S":
			  	case "W":
			  		
					  //If regex test is passed then it's a char (ControlI === JSON.parse(controlChar)) 
					  if(control_regex.test(controlChar)) { 
						  if(controlC === controlChar) {
							  if(showSuccess) {
								  input.setValueState(sap.ui.core.ValueState.Success); 
							  } else {
								  input.setValueState(sap.ui.core.ValueState.None); 
							  }
							  return true;
						  } else {
							  input.setValueState(sap.ui.core.ValueState.Error);
							  input.setValueStateText(view.getModel("i18n").getResourceBundle().getText("errorNifCif"));
							  return false;
						  }
					  } else {
						  input.setValueState(sap.ui.core.ValueState.Error);
						  input.setValueStateText(view.getModel("i18n").getResourceBundle().getText("errorNifCif"));
						  return false;
					  }
			  		
			  		break;
			  		
			  	case "A":
			  	case "B":
			  	case "E":
			  	case "H":
					  //If regex test is not passed then it's an integer 
					  if(!control_regex.test(controlChar)) { 
						  if(ControlI === JSON.parse(controlChar)) {
							  if(showSuccess) {
								  input.setValueState(sap.ui.core.ValueState.Success); 
							  } else {
								  input.setValueState(sap.ui.core.ValueState.None); 
							  }
							  return true;
						  } else {
							  input.setValueState(sap.ui.core.ValueState.Error);
							  input.setValueStateText(view.getModel("i18n").getResourceBundle().getText("errorNifCif"));
							  return false;
						  }
					  } else {
						  input.setValueState(sap.ui.core.ValueState.Error);
						  input.setValueStateText(view.getModel("i18n").getResourceBundle().getText("errorNifCif"));
						  return false;
					  }
			  		
			  		break;
			  	
			  	default:

			  		if(control_regex.test(controlChar)) { 
			  			if(controlC === controlChar) {
							  if(showSuccess) {
								  input.setValueState(sap.ui.core.ValueState.Success); 
							  } else {
								  input.setValueState(sap.ui.core.ValueState.None); 
							  }
							  return true;
						  } else {
							  input.setValueState(sap.ui.core.ValueState.Error);
							  input.setValueStateText(view.getModel("i18n").getResourceBundle().getText("errorNifCif"));
							  return false;
						  }
			  		} else {
			  			if(ControlI === JSON.parse(controlChar)) {
							  if(showSuccess) {
								  input.setValueState(sap.ui.core.ValueState.Success); 
							  } else {
								  input.setValueState(sap.ui.core.ValueState.None); 
							  }
							  return true;
						  } else {
							  input.setValueState(sap.ui.core.ValueState.Error);
							  input.setValueStateText(view.getModel("i18n").getResourceBundle().getText("errorNifCif"));
							  return false;
						  }
			  		}

			  		break;
			  		
			  }
			  
		  }
  } else {
	  return false;
  }
		     
}

Helper.validateCCC = function(entidad,sucursal,dc,nCuenta){
	entidad = this.fillWithZeros(entidad,4);
	sucursal = this.fillWithZeros(sucursal,4);
	dc = this.fillWithZeros(dc,2);
	nCuenta = this.fillWithZeros(nCuenta,10);

	var concatenado = entidad+sucursal;
	var dc1 = this.calculaDCParcial(concatenado);
	var dc2 = this.calculaDCParcial(nCuenta);
	return (dc==(dc1+dc2));
}

//Método para devolver un array que contendrá la siguiente información: [entidad,sucursal,dc,nCuenta, dcCuenta] a partir
//de un IBAN (string).
Helper.splitIBAN = function(iban) {
	
	var splitIBAN = [];
	
	if(iban.split("").length > 24) return splitIBAN;
	
	splitIBAN.push(iban.substring(4,8));
	splitIBAN.push(iban.substring(8,12));
	splitIBAN.push(iban.substring(12,14));
	splitIBAN.push(iban.substring(14,22));
	splitIBAN.push(iban.substring(22,24));
	
	return splitIBAN;
	
}

Helper.fillWithZeros = function(numero,longitud){
	var ceros = '';
	var i;
	numero = numero.toString();
	for(i=0;(longitud-numero.length)>i;i++){
		ceros += '0';
	}	
	return ceros+numero;
}

Helper.calculaDCParcial = function(cadena){
	var dcParcial = 0;
	var tablaPesos = [6,3,7,9,10,5,8,4,2,1];
	var suma = 0;
	var i;
	for(i=0;i<cadena.length;i++){
		suma = suma + cadena.charAt(cadena.length-1-i)*tablaPesos[i];
	}
	dcParcial = (11-(suma % 11));
	if(dcParcial==11)
		dcParcial=0;
	else if(dcParcial==10)
		dcParcial=1;
	return dcParcial.toString();
}
	
Helper.isNotEmpty = function (str) {
	var pattern =/\S+/;
	return pattern.test(str);  // returns a boolean
}

Helper.isNumber = function(str) {
	var pattern = /^-?\d*\.?\d+$/;
	return pattern.test(str);  // returns a boolean
}

Helper.isSame = function(str1,str2){
	return str1 === str2;
}

Helper.MoneyPositiveInput = function(oEvent){ //input Currency valores positivos
	var num = oEvent.mParameters.newValue;
	
	if(isNaN(num) || num.indexOf(".") != -1){
		num = Helper.deleteTwoComa(num);
		num = Helper.deleteCharacters(num);
	}
	num = Helper.alwaysPositive(num);
	oEvent.getSource().setValue(num);
}

Helper.IntegerInput = function(oEvent){ //input de cantidad, no permite decimales
	var num = oEvent.mParameters.newValue;
	 if(isNaN(num) || num.indexOf(".") != -1){ //si es letra o decimal
		 num = num.replace(".","");
		 num = num.replace(",","");
		 num = Helper.deleteTwoComa(num);
		 num = Helper.deleteCharacters(num);
	 }
	 num = Helper.alwaysPositive(num); 
	 oEvent.getSource().setValue(num);
}

Helper.MoneyInput = function(oEvent){ //input Currency (valores positivos y negativos)
var num = oEvent.mParameters.newValue;
	
	if(isNaN(num) || num.indexOf(".") != -1){
		num = Helper.deleteTwoComa(num);
		num = Helper.deleteCharacters(num);
	}
	oEvent.getSource().setValue(num);
}

Helper.currencyLocale = function(number, currency){
	if (number != undefined && number != ""){
		var numInt = parseFloat(number);
		var numStr = numInt.toLocaleString();
		return numStr + " " + currency;
	}
}

Helper.deleteCharacters = function(word){
	var str = "01213456789,";
	var aux = word;
	var negative = false;
	for(i=0; i< word.length; i++){
		if(i==0 && word[i] === '-'){
			//Do nothing
			negative = true;
			aux = aux.replace(word[i],"");
		}else if(str.indexOf(word[i]) === -1){
			aux = aux.replace(word[i],"");
		}
	}
	if(negative) return "-" + aux;
	else return aux;
}

Helper.alwaysPositive = function(word){
	var aux = word;
	for(i=0; i< word.length; i++){
		if(word[i] === '-'){
			aux = aux.replace(word[i],"");
		}
	}
	return aux;
}

Helper.deleteCharactersPositiveOnly = function(word){
	var str = "01213456789,";
	var aux = word;
	var negative = false;
	for(i=0; i< word.length; i++){
		if(i==0 && word[i] === '-'){
			//Do nothing
			negative = true;
			aux = aux.replace(word[i],"");
		}else if(str.indexOf(word[i]) === -1){
			aux = aux.replace(word[i],"");
		}
	} 
	if(negative) return aux;
	else return aux;
}

Helper.deleteCharactersPositive = function(word){
	var str = "01213456789,";
	var aux = word;
	var negative = false;
	for(i=0; i< word.length; i++){
		if(i==0 && word[i] === '-'){
			//Do nothing
			negative = true;
			aux = aux.replace(word[i],"");
		}else if(str.indexOf(word[i]) === -1){
			aux = aux.replace(word[i],"");
		}
	}
	return aux;
}

Helper.deleteTwoComa = function(word){
	var aux = "";
	var j = 0;
	for(i=0; i< word.length; i++){
		if(word[i] === ','){
			if(j === 0 && i != 0){
				aux = aux + word[i];
				j++;	
			}
		}else{
			aux = aux + word[i];
		}
	} 
	return aux;
}

Helper.deleteDecimals = function (word){
	var aux="";
	var j=0;
	for (i=0; i<word.length;i++){
		if (word[i]===","){
			aux = aux;
			
		} else {
			aux = aux + word[i];
		}
	}
	
}

Helper.deleteTwoPoint = function(word){
	var aux = "";
	var j = 0;
	for(i=0; i< word.length; i++){
		if(word[i] === '.'){
			if(j === 0 && i != 0){
				aux = aux + word[i];
				j++;	
			}
		}else{
			aux = aux + word[i];
		}
	} 
	return aux;
}

Helper.isEmptyObject = function(obj){
	return JSON.stringify(obj) === '{}';
}

Helper.areSameObjects = function(obj1,obj2){
	return JSON.stringify(obj1) === JSON.stringify(obj2);
}

Helper.setSelectedIfOneItem = function(selects){
	for(var i = 0; i < selects.length; i++){
		if(selects[i].getItems().length === 1){
			selects[i].setSelectedItem(selects[i].getItems()[0]);
		}
	}
}

	
///////////////////////
// Funciones Fechas  //
///////////////////////

// Limpiar data
if	(!Date.prototype.toClean) {
	Date.prototype.toClean = function(){
		if(this!==null){
				var vDay = ((this.getDate())<10)?'0'+(this.getDate()):(this.getDate()),
						oMonths = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
						vMonth = oMonths[this.getMonth()],
						vYear = this.getFullYear().toString().right(2);
						
				return vDay+' '+vMonth+' \''+vYear;
		} else {
				return '[Invalid Date]';
		}
	}
}

//Convertir fecha "1987-09-23T00:00:00" a "23/09/1987"
Helper.convertDate = function(date){
	if(date != "" && date != undefined) {
		var dat = new Date(date);
		var day = dat.getDate() < 10 ? '0' + dat.getDate() : '' + dat.getDate();
		var month = dat.getMonth()+1;
		month = month < 10 ? '0' + month : '' + month;
		return day + "/" + month + "/" + dat.getFullYear();
	} else { return ""; }
}

// Convertir objeto Date a fecha String tipo "23/09/1987"
Helper.getFormattedDate = function(date){	
	if(date != undefined)
	{
		var dd = date.getDate();
		var mm = date.getMonth() + 1;
		var yyyy = date.getFullYear();

		if(dd < 10) dd = '0' + dd;
		if(mm < 10) mm = '0' + mm;
					
		return dd + '/' + mm + '/' + yyyy;	
	}
}

//Convertir objeto Date a fecha String tipo "23-09-1987"
Helper.getFormattedDateSep = function(date){	
	if(date != undefined)
	{
		var dd = date.getDate();
		var mm = date.getMonth() + 1;
		var yyyy = date.getFullYear();

		if(dd < 10) dd = '0' + dd;
		if(mm < 10) mm = '0' + mm;
					
		return dd + '-' + mm + '-' + yyyy;	
	}
}

//Convertir objeto Date a fecha String tipo "23091987"
Helper.getFormattedDateJoin = function(date){	
	if(date != undefined)
	{
		var dd = date.getDate();
		var mm = date.getMonth() + 1;
		var yyyy = date.getFullYear();

		if(dd < 10) dd = '0' + dd;
		if(mm < 10) mm = '0' + mm;
					
		return dd + mm + yyyy;	
	}
}

//Convertir objeto Date a fecha String tipo "19870923"
Helper.getFormattedFullDate = function(date){	
	if(date != undefined)
	{
		var dd = date.getDate();
		var mm = date.getMonth() + 1;
		var yyyy = date.getFullYear();

		if(dd < 10) dd = '0' + dd;
		if(mm < 10) mm = '0' + mm;
					
		return yyyy.toString() + mm.toString() + dd.toString();	
	}
}

//Convertir fecha string 23/09/1987 a fecha String tipo "19870923"
Helper.getFormatedDateString = function(date){	
	if(date != undefined)
	{
		
		var newDate = date.replaceAll("/", "");
		
		var dd = newDate.substring(0,2);
		var mm = newDate.substring(2,4);
		var yyyy = newDate.substring(4,8);

		return yyyy + mm + dd;	
	}
}

//Convertir string "20170115" a string date para oData
Helper.getFormattedDateoData = function(date){	
	if(date != undefined)
	{
		var year = date.substring(0,4);
		
		var month;
		var toCheckMonth = date.substring(4,6);
		if(toCheckMonth.startsWith("0")) {
			month = JSON.parse(toCheckMonth[1]) - 1;
		} else {
			month = JSON.parse(toCheckMonth) - 1;
		}
		
		var day = date.substring(6,8);

		return "/Date(" + new Date(year, month, day).getTime() + ")/";
	}
}

//Convertir string "dd/MM/yyyy" a string tipo "1987-09-23T12:30:45"
Helper.getFormattedDateToOdata = function(date){	
	if(date != undefined)
	{
		var date = date.split("/").join("");
		var year = date.substring(0,2);
		var month = date.substring(2,4);
		var day = date.substring(4,8);
		
		var formatedDate = year + "-" + month + "-" + day + "T00:00:00";
		return formatedDate;
	}
}

//Convertir string "DATE(X)" del oData a date.
Helper.getFormattedDateFromOData = function(date, isString){	
	if((date != undefined) && (date.indexOf("(") !== -1))
	{
		var newDate = new Date(JSON.parse(date.substring(date.indexOf("(")+1, date.indexOf(")"))));
		
		if(isString) {
			var dd = newDate.getDate();
			var mm = newDate.getMonth() + 1;
			var yyyy = newDate.getFullYear();

			if(dd < 10) dd = '0' + dd;
			if(mm < 10) mm = '0' + mm;
			
			return dd + "/" + mm + "/" + yyyy;
		} else {
			return newDate;	
		}
	} else {
		return date;
	}
}

Helper.formatDate = function(date){
		var year = date.substring(0,4);
		var month = date.substring(4,6);
		var day = date.substring(6,9);
		
		return day + "-" + month + "-" + year;
}

Helper.formatHour = function(hour){
		var hours = hour.substring(0,2);
		var minutes = hour.substring(2,4);
		var seconds = hour.substring(4,6);
		
		return hours + ":" + minutes + ":" + seconds;
}

//Convertir fecha "23/09/1987" a ISO para new Date
Helper.convertDateToISO = function(date) {
	var st = date.replaceAll("/",".");
	var pattern = /(\d{2})\.(\d{2})\.(\d{4})/;
	return new Date(st.replace(pattern,'$3-$2-$1'));
}

//Convertir fecha "1987-09-23T12:30:45" a "23/09/1987 12:30:45"
Helper.convertDateTime = function(date){
	if(date != "") {
		var dat = new Date(date);
		var day = dat.getDate() < 10 ? '0' + dat.getDate() : '' + dat.getDate();
		var month = dat.getMonth()+1;
		month =  month < 10 ? '0' + month : '' + month;
		var hour = dat.getUTCHours() < 10 ? '0' + dat.getUTCHours() : '' + dat.getUTCHours();
		var min = dat.getMinutes() < 10 ? '0' + dat.getMinutes() : '' + dat.getMinutes();
		var sec = dat.getSeconds() < 10 ? '0' + dat.getSeconds() : '' + dat.getSeconds();
		return day + "/" + month + "/" + dat.getFullYear() + " " + hour + ":" + min + ":" + sec;
	} else { return ""; }
}

// Obtener la diferencia entre dos fechas en Horas, Dias, Semanas, Meses, Años
Helper.dateDiff = function(oldDate,newDate,format) {
    var milliseconds = newDate - oldDate;
    var days = milliseconds / 86400000;
    var hours = milliseconds / 3600000;
    var weeks = milliseconds / 604800000;
    var months = milliseconds / 2628000000;
    var years = milliseconds / 31557600000;
    if (format == "h") {
        return hours;
    }
    if (format == "d") {
        return days;
    }
    if (format == "w") {
        return weeks;
    }
    if (format == "m") {
        return months;
    }
    if (format == "y") {
         return years;
    }
}

// Parsea objeto Date devuelto por oData
Helper.getDateObjectFromOData = function(date){
    if(date != undefined) return new Date(parseInt(date.substr(6)));
}

Helper.getDateObject = function(dateIn){
	var isoExp = /^\s*(\d{4})-(\d\d)-(\d\d)\s*$/,
	date = new Date(NaN), 
	month,
	parts = isoExp.exec(dateIn);

	if(parts){
	    	month =+ parts[2];
	    	date.setFullYear(parts[1], month - 1, parts[3]);
    		if(month != date.getMonth() + 1){
			    date.setTime(NaN);
		}
	}
	return date;
}

///////////////////////
// Funciones SAPUI5  //
///////////////////////

function getModel(name) {
	return sap.ui.getCore().getModel(name);
}

function getController(name) {
	return sap.ui.controller(name);
}
	
function byId(name) {
	return sap.ui.getCore().byId(name);
}

function newModel() {
	return new sap.ui.model.json.JSONModel();
}

function newModelWithData(data) {
	var oModel = new sap.ui.model.json.JSONModel();
	oModel.setData(data);
	return oModel;
}

function refreshModel(model,element){
	if(model == ""){
		return element.updateBindings(true);
	} else {
		return (element) ? element.getModel(model).updateBindings(true) : sap.ui.getCore().getModel(model).updateBindings(true);
	}
}

function showMsg (text, duration) {
	var dur = duration || 800;
	sap.m.MessageToast.show(text, {duration: dur});
}

function isPhone(){
	return sap.ui.Device.system.phone;
}

function isTablet(){
	return sap.ui.Device.system.tablet;
}

function isDesktop(){
	return sap.ui.Device.system.desktop;
}

///////////////////////////////
// Backend Error Management  //
///////////////////////////////

Helper.findValueXML = function(xml, xmlTag) {
	var parseXml = $.parseXML(xml);
	return $(parseXml).find(xmlTag).text();
}

Helper.findErrorMsg = function(xml) {
	var parseXml = $.parseXML(xml);
	var firstMessage =  $(parseXml).find("message")[0];

	return "Error: " + firstMessage.textContent;
}

Helper.findErrorMsgJSON = function(xml) {
	var parseXml = JSON.parse(xml.responseText);
	var msg =  parseXml.error? parseXml.error.message? parseXml.error.message.value? parseXml.error.message.value : "" : "": "";

	return "Error: " + msg;
}


Helper.textException = function(error){
	console.log(error.indexOf('<message xml:lang="es">'));
	console.log(error.indexOf('<message xml:lang="es">') + 23);
	return error.substring(error.indexOf('<message xml:lang="es">') + 23,error.indexOf('</message>'));
}

//////////////////////////////
// Funciones Copia Objetos  //
//////////////////////////////

// Clonar objectos sin referencia entre ellos
Helper.cloneObj = function (obj) {
	if (null == obj || "object" != typeof obj) return obj;
	var copy = obj.constructor();
	for (var attr in obj) {
		if (obj.hasOwnProperty(attr)) copy[attr] = obj[attr];
	}
	return copy;
}

// Clonar modelos sin referencia entre ellos
Helper.copyModel = function(model) {
	try {
		var modelData =  JSON.stringify(model.getData());
		var oModel = new sap.ui.model.json.JSONModel();
		oModel.setData(JSON.parse(modelData));
		return oModel;
	} catch (err) {
		return null;
	}
}

////////////
// Otras  //
////////////

// Función para realizar loop's asíncronos. Útil para ejectuar N-acciones y esperar al resultado para realizar otra acción
Helper.asyncLoop = function(o){
	var i=-1,
		length = o.length;

	var loop = function(){
		i++;
		if(i==length){o.callback(); return;}
		o.functionToLoop(loop, i);
	} 
	loop();//init
}

// ---> Ejemplo de uso

// asyncLoop({
//	length: array.length,
//	functionToLoop: function(loop, i){
//		oModel.create("/EntitySet", array[i], null,
//			function(res, oResponse){
//				loop();
//			},
//			function(error){
//				showMsg("Text");
//				loop();
//			}
//		);
//	},
//	callback: function(){
//	   $(".loading").hide();
//	   navigateTo("activitySummary","show");
//	}    
// });

Helper.showInfo = function(oEvent,texto,position){ 
	var oButton = oEvent.getSource();
	
	var oText = new sap.m.Text({ text: texto });
	
	var oPopover = new sap.m.Popover({
		content : [ oText ],
		showHeader: false,
		placement: position,
//			contentWidth: "200px",
		horizontalScrolling: false
	});
		
	oPopover.openBy(oButton);
}

Helper.getServerURL = function(){
	return location.protocol + "//" + location.hostname + ":" + location.port;
}

////////////////////////////////////////////
////// Message Dialogs
///////////////////////////////////////////

Helper.showMessageDialog = function(message, state, title, acceptfunct, oController, view, refuseFunct){
	var acceptButton = "";
	var cancelButton = "";
	
	if(!view){
		if(oController.getView().getModel("i18n") != undefined){
			acceptButton = oController.getView().getModel("i18n").getResourceBundle().getText("Accept");
			cancelButton = oController.getView().getModel("i18n").getResourceBundle().getText("Cancel");
		}else{
			acceptButton = "Accept";
			cancelButton = "Cancel";
		}
	}else{
		if(view.getModel("i18n") != undefined){
			acceptButton = view.getModel("i18n").getResourceBundle().getText("Accept");
			cancelButton = view.getModel("i18n").getResourceBundle().getText("Cancel");
		}else{
			acceptButton = "Accept";
			cancelButton = "Cancel";
		}
	}
	
	var refuseButtonPress;
	if(refuseFunct) {
		refuseButtonPress = refuseFunct;
	} else {
		refuseButtonPress = function () {
            dialog.close();
        }
	}
	
	
	var dialog = new sap.m.Dialog({
        title: title,
        type: 'Message',
        content: new sap.m.Text({
            text: message
        }).addStyleClass("dialogText"), 
        state: state,
        beginButton: new sap.m.Button({
			text: acceptButton,
			press: [acceptfunct, oController]
	       /* press: function (oEvent) {
	            acceptfunct(oEvent);
	        }*/
    	}).addStyleClass("dialogAcceptButton"),
        endButton: new sap.m.Button({
			text: cancelButton,
			press: [refuseButtonPress, oController]
//	        press: function () {
//	            dialog.close();
//	        }
        }).addStyleClass("dialogCancelButton"),
        afterClose: function() {
            dialog.destroy();
        }
     }).addStyleClass("dialog");
	
	if(refuseFunct) {
		dialog.getEndButton().attachPress(null, function() {
			dialog.close();
		})
	}
	dialog.open();
}

/*Helper.showMsg = function(text) {
	sap.m.MessageToast.show(text, {duration:3000});
}*/

Helper.showMsg = function showMsg (text, duration) {
	var dur = duration || 3000;
	sap.m.MessageToast.show(text, {duration: dur});
}

Helper.showSelectDialog = function(oTitle,oKey,oText,oSearch,data,confirmfunct){
	if(data.results.length > 0){
		
		var text = "";
		$.each(oText, function(i,n){
			if(i > 0){
				text = text + " - ";
			}
			text = text + "{" + n + "}";
    	});
		
		var oCustomData = [];
		$.each(oKey, function(i,n){
			oCustomData.push(new sap.ui.core.CustomData({ key: "{" + n + "}" }));
    	});
		
		var oSelectDialog = new sap.m.SelectDialog({
			noDataText: "No Data Found",
			title: oTitle,
			items: {
		    	path: '/results',
	   		    template: new sap.m.StandardListItem({ 
	   		    	title: text,
	   		    	customData: oCustomData
	   		    })
		    },
			search: function(oEvent){ 
				var sValue = oEvent.getSource()._sSearchFieldValue;
				var oBinding = oEvent.getSource().getBinding("items");
				
				var allFilters = [];
				$.each(oSearch, function(i,n){
					allFilters.push(new sap.ui.model.Filter(n, sap.ui.model.FilterOperator.Contains, sValue));
		    	});
				
				var oFilter = new sap.ui.model.Filter({
		            filters: allFilters,
		            and: false
		        });
				
				oBinding.filter([oFilter]);
			},
			confirm: function(oEvent){
				var selectedItem = oEvent.getSource()._oSelectedItem;
				var key = selectedItem.mAggregations.customData;
				
				confirmfunct(key);
			}
		}).addStyleClass("selectDialog");
		
		var oModel = newModelWithData(data);
		oSelectDialog.setModel(oModel);
		
		oSelectDialog.open();
	}
}

Helper.sleep = function(miliseconds) {
	var currentTime = new Date().getTime();
	while (currentTime + miliseconds >= new Date().getTime()) {
	}
}

Helper.getCurrency =  function(curr){
	var sBrowserLocale = sap.ui.getCore().getConfiguration().getLanguage();
    var oLocale = new sap.ui.core.Locale(sBrowserLocale);
    var oLocaleData = new sap.ui.core.LocaleData(oLocale);
    return oLocaleData.getCurrencySymbol(curr || "EUR");
}

Helper.changeDecimals = function(curr){
	
	if(curr.indexOf(",") === -1){ //añadimos ",00"
		curr = curr + ",00";
	} else  if(curr.length - curr.indexOf(",") < 3){
		curr = curr + "0";
	}
	return curr;
}

Helper.getCookie = function(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i <ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

Helper.excelToJSON = function(file){
	if (file && window.FileReader) {
	      var filereader = new FileReader();
	      filereader.onload = function(evt) {
	        var data = evt.target.result;
	        var arr = String.fromCharCode.apply(null, new Uint8Array(data));
	        var xlsx = XLSX.read(btoa(arr), {type: 'base64'});
	        result = xlsx.Strings;
	        result = {};
	        xlsx.SheetNames.forEach(function(sheetName) {
	          var array = XLSX.utils.sheet_to_row_object_array(xlsx.Sheets[sheetName]);
	          if(array.length > 0){
	            result[sheetName] = array;
	          }
	        });
	        console.log(result);
	        return result;
	      };
	      filereader.readAsArrayBuffer(file);
	 }
}

///////////////////////////////////////////////////////
//Funciones relacionadas con el data de los modelos  //
///////////////////////////////////////////////////////

Helper.findValueJson = function (data,key,keyValue,searchField,notRoute) {
	
	if(notRoute) {
		var obj = $.grep(data, function(n) {
			return n[key] == keyValue;
		});
		
		if(obj){
			return obj[0] ? obj[0][searchField] : "";
		} else return "";
	} else {
		// La búsqueda se realiza sobre la ruta /d/results
		if(data.d) {
			if(data.d.results) {
				var obj = $.grep(data.d.results, function(n) {
					return n[key] == keyValue;
				});
				
				if(obj){
					return obj[0] ? obj[0][searchField] : "";
				} else return "";
				
			} else return "";
		} else return "";
	}

}

//Función que nos devuelve el objeto que busquemos dentro de un array de estos a partir de un identificador.
//model = modelo donde buscar, key = identificador, keyValue = valor del identificador, notRoute = true o false según la data del modelo
//contiene la ruta d.results o no.
// Si no encuentra ningún objeto devolverá "false".
Helper.findJsonObject = function (model,key,keyValue,notRoute) {
	
	var dataToSearch;
	if(notRoute) {
		dataToSearch = model.getData();
	} else {
		dataToSearch = model.getData().d.results;
	}
	
	for(var i = 0; i < dataToSearch.length; ++i) {
		
		var currentObject = dataToSearch[i];
		if(currentObject[key] === keyValue) {
			return currentObject;
		}
			
	}

	return false;
}

///////////////////////////////////////////////////////////
//Funciones relacionadas con los resources del proyecto  //
///////////////////////////////////////////////////////////
//Funcion para recuperar resources independientemente de la vista
Helper.getResourceText = function(sKey, parameters, url) {
	  var i18nUrl = url || "/sap/bc/ui5_ui5/sap/zpa_delegados/i18n/i18n.properties";
	  jQuery.sap.require("jquery.sap.resources");
	  var sLocale = sap.ui.getCore().getConfiguration().getLanguage();
	  var oBundle = jQuery.sap.resources({
	  	url: i18nUrl,
	 	locale: sLocale
	  });
	  return parameters ? oBundle.getText(sKey, parameters) : oBundle.getText(sKey);
}
// Funcion para recuperar resources independientemente de la vista
Helper.getResourceText = function(sKey, parameters, url) {
	  var i18nUrl = url || "/sap/bc/ui5_ui5/sap/zpa_histplaneac/i18n/i18n.properties";
	  jQuery.sap.require("jquery.sap.resources");
	  var sLocale = sap.ui.getCore().getConfiguration().getLanguage();
	  var oBundle = jQuery.sap.resources({
	  	url: i18nUrl,
	 	locale: sLocale
	  });
	  return parameters ? oBundle.getText(sKey, parameters) : oBundle.getText(sKey);
}

///////////////////////////////////////////////////////////
//Funciones relacionadas con la creación de ids random   //
///////////////////////////////////////////////////////////
Helper.createFakeId = function(length, type) {
	  var text = "";
	  var possible = "";
	  
	  switch(type) {
	  		case 1:
	  			possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	  		break;
	  		case 2:
	  			possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	  		break;
	  		case 3:
	  			possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	  		break;
	  		case 4:
	  			possible = "0123456789";
	  		break;
	  }

	  for (var i = 0; i < length; i++)
	    text += possible.charAt(Math.floor(Math.random() * possible.length));

	  return text;
}