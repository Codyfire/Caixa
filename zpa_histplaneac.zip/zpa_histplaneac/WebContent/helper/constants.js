var constants = {
	cycle: {
		logText: {
			copyMasterdata: "ZKU: Copy structure information from ref. cycle",
			copyInvoice: "ZKU: Copy invoice value from ref. cycle",
			resetServices: "ZKU: Reset current services values"
		},
		procChain: {
			copyMasterdata: "ZKU_INIT_STRUCTURES",
			copyInvoice: "ZKU_INIT_VALUES",
			resetServices: "ZKU_RESET_SERVICES_VALUES"
		},
	},
	urlactionhis : "/sap/opu/odata/sap/ZGRCAUD_PORTAL_SRV/InfoActionSet"	
}

