// INI Ajuste Spau 12/11/18
var oFirst = true;

function get_oFirst(){
	return oFirst;
}

function set_oFirst(oBolean){
	oFirst = oBolean;
}
//FIN Ajuste Spau 12/11/18

// Funciones añadidas al tipo String en Javascript
String.prototype.contains = function(it) {
	return this.indexOf(it) != -1;
};

String.prototype.replaceAll = function(search, replacement) {
	var target = this;
	return target.replace(new RegExp(search, 'g'), replacement);
};

String.prototype.trim = String.prototype.trim || function() {
	return this.replace(/^\s+|\s+$/, "");
}

String.prototype.capitalize = function() {
	var str = this.toLowerCase();
	return str.replace(/(?:^\w|[A-Z]|\b\w)/g, function(letter, index) {
		return letter.toUpperCase();
	}).replace(/\s+/g, ' ');
};

String.prototype.capitalizeNoSpaces = function() {
	var str = this.toLowerCase();
	return str.replace(/(?:^\w|[A-Z]|\b\w)/g, function(letter, index) {
		return letter.toUpperCase();
	}).replace(/\s+/g, '');
};

String.prototype.camelize = function() {
	return this.replace(/(?:^\w|[A-Z]|\b\w)/g, function(letter, index) {
		return index == 0 ? letter.toLowerCase() : letter.toUpperCase();
	}).replace(/\s+/g, ' ');
};

String.prototype.camelizeNoSpaces = function() {
	return this.replace(/(?:^\w|[A-Z]|\b\w)/g, function(letter, index) {
		return index == 0 ? letter.toLowerCase() : letter.toUpperCase();
	}).replace(/\s+/g, '');
};

// Funciones añadidas al tipo Date en Javascript

Date.prototype.toClean = function() {
	if (this !== null) {
		var vDay = ((this.getDate()) < 10) ? '0' + (this.getDate()) : (this.getDate()), oMonths = [
				'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' ], vMonth = oMonths[this
				.getMonth()], vYear = this.getFullYear().toString().right(2);

		return vDay + ' ' + vMonth + ' \'' + vYear;
	} else {
		return '[Invalid Date]';
	}
}

function getModel(name) {
	return sap.ui.getCore().getModel(name);
}

function byId(name) {
	return sap.ui.getCore().byId(name);
}

var planesAccionUtilsHisto = {};

// load i18n
planesAccionUtilsHisto.oBundle = new sap.ui.model.resource.ResourceModel({
	bundleName : "appHistoPlanesAccion.i18n.i18n"
}).getResourceBundle();

// Funciones para obtener el dispositivo
planesAccionUtilsHisto.isPhone = function() {
	return sap.ui.Device.system.phone;
}

planesAccionUtilsHisto.isTablet = function() {
	return sap.ui.Device.system.tablet;
}

planesAccionUtilsHisto.isDesktop = function() {
	return sap.ui.Device.system.desktop;
}

planesAccionUtilsHisto.getCurrentUser = function() {
	return sap.ushell.Container.getService("UserInfo").getId();
}

// Convertir fecha para backend
planesAccionUtilsHisto.convertDate2Backend = function(date) {
	if (date != "") {
		// if(date.contains("/")) {
		// var dat = this.convertDate(date);
		// var splited = dat.split("/");
		// return splited[2] + splited[1] + splited[0];
		// } else {
		// return date.substring(0,4) + date.substring(4,6) +
		// date.substring(6,8);
		// }
		if (date.length == 8) {
			return date.substring(0, 4) + date.substring(4, 6) + date.substring(6, 8);
		} else {
			var dat = this.convertDate(date);
			var splited = dat.split("/");
			return splited[2] + splited[1] + splited[0];
		}

	} else {
		return "";
	}
}

// Recive un String con una fecha en formato yyyymmdd y la pasa a yyyy/mm/dd
planesAccionUtilsHisto.formatDate = function(date) {

	if (date)
		return date.substring(0, 4) + "/" + date.substring(4, 6) + "/" + date.substring(6, 8);
	else
		return "";
}

// Convertir fecha "1987-09-23T00:00:00" a "23/09/1987"
planesAccionUtilsHisto.convertDate = function(date) {
	if (date != "") {
		var dat = new Date(date);
		var day = dat.getDate() < 10 ? '0' + dat.getDate() : '' + dat.getDate();
		var month = dat.getMonth() + 1;
		month = month < 10 ? '0' + month : '' + month;
		return day + "/" + month + "/" + dat.getFullYear();
	} else {
		return "";
	}
}

// Convertir fecha "23/09/1987" a ISO para new Date
planesAccionUtilsHisto.convertDateToISO = function(date) {
	var st = date.replaceAll("/", ".");
	var pattern = /(\d{2})\.(\d{2})\.(\d{4})/;
	return new Date(st.replace(pattern, '$3-$2-$1'));
}

// Convertir fecha "1987-09-23T12:30:45" a "23/09/1987 12:30:45"
planesAccionUtilsHisto.convertDateTime = function(date) {
	if (date != "") {
		var dat = new Date(date);
		var day = dat.getDate() < 10 ? '0' + dat.getDate() : '' + dat.getDate();
		var month = dat.getMonth() + 1;
		month = month < 10 ? '0' + month : '' + month;
		var hour = dat.getUTCHours() < 10 ? '0' + dat.getUTCHours() : '' + dat.getUTCHours();
		var min = dat.getMinutes() < 10 ? '0' + dat.getMinutes() : '' + dat.getMinutes();
		var sec = dat.getSeconds() < 10 ? '0' + dat.getSeconds() : '' + dat.getSeconds();
		return day + "/" + month + "/" + dat.getFullYear() + " " + hour + ":" + min + ":" + sec;
	} else {
		return "";
	}
}

// Convertir fecha "20160215" a "15/02/2016"
planesAccionUtilsHisto.transformDate = function(date) {

	if (date != undefined)
		return date.substring(6, 8) + "/" + date.substring(4, 6) + "/" + date.substring(0, 4);
}

planesAccionUtilsHisto.dateDiff = function(oldDate, newDate, format) {
	var milliseconds = newDate - oldDate;
	var days = milliseconds / 86400000;
	var hours = milliseconds / 3600000;
	var weeks = milliseconds / 604800000;
	var months = milliseconds / 2628000000;
	var years = milliseconds / 31557600000;
	if (format == "h") {
		return hours;
	}
	if (format == "d") {
		return days;
	}
	if (format == "w") {
		return weeks;
	}
	if (format == "m") {
		return months;
	}
	if (format == "y") {
		return years;
	}
}

// Mostrar mensaje de aplicación

planesAccionUtilsHisto.showMsg = function(text) {
	sap.m.MessageToast.show(text, {
		duration : 800
	});
}

planesAccionUtilsHisto.statusDescr = function(status) {
	var found = $.grep(getModel("statusPlModel").getData().results, function(m, j) {
		return m.Status == status
	});
	return found.length > 0 ? found[0].StatusT : "";
}

planesAccionUtilsHisto.isAuditor = function(view) {
	/*const
	AUDITOR = "ZSAP_GRCAUD_AUDITOR";
	var roles = view.getModel("rol").getData().d.results;
	var array = $.grep(roles.d.results, function(n, i) {
		return n.Rol.indexOf(AUDITOR) === 0
	});
	return array.length > 0 ? true : false;*/
	/**
	 * INI MOD PPM100084365 - (BPI) - Rol auditor/auditado compatibles en BPI2 23/01/2023				
	 * Código nuevo
	 */
	var model = sap.ui.getCore().getModel("PlanesContextData");
	if(model && model.getData()){
		var data = model.getData()
		
		if(data.ZzViewAuditor){
			if(data.ZzViewAuditor === 'true'){
				return true;
			}else if(data.ZzViewAuditor === 'false'){
				return false;
			}
		}else{
			return false;
		}
//		return data.ZzViewAuditor;
	}else{
		const
		AUDITOR = "ZSAP_GRCAUD_AUDITOR";
		var roles = view.getModel("rol").getData().d.results;
		var array = $.grep(roles.d.results, function(n, i) {
			return n.Rol.indexOf(AUDITOR) === 0
		});
		return array.length > 0 ? true : false;
	}
	/**
	 * FIN MOD PPM100084365 - (BPI) - Rol auditor/auditado compatibles en BPI2 23/01/2023
	 */
}

planesAccionUtilsHisto.isValidator = function(oModel, view) {
	var validator = false
	if (oModel) {
		var company = oModel.getData().ZzAnOrg.substring(0, 5);
		var department = oModel.getData().ZzAnOrg.substring(5);
		var roles = view.getModel("rol").getData().d.results;
		$.each(roles.d.results, function(i, n) {
			if (n.Department == department && n.Company == company) {
				if (n.Validator == "true")
					validator = true;
			}
		});
	}
	return validator;
}

planesAccionUtilsHisto.isAuditado = function(oController) {
	/**
	 * INI MOD PPM100084365 - (BPI) - Rol auditor/auditado compatibles en BPI2 23/01/2023				
	 * Código nuevo
	 */
	var model = sap.ui.getCore().getModel("PlanesContextData");
	if(model && model.getData()){
		var data = model.getData();
		if(data.ZzViewAudited){
			if(data.ZzViewAudited === 'true'){
				return true;
			}else if(data.ZzViewAudited === 'false'){
				return false;
			}
		}else{
			return false;
		}
//		return data.ZzViewAudited;
	}else{
		const
		AUDITADO = "ZSAP_GRCAUD_AUDITADO";
		var roles = oController.getModel("rol").getData().d.results;
		var array = $.grep(roles, function(n, i) {
			return n.Rol == AUDITADO
		});
		//return true;
		 return array.length > 0 ? true : false;
	}
	
	/**
	 * FIN MOD PPM100084365 - (BPI) - Rol auditor/auditado compatibles en BPI2 23/01/2023
	 */
}

planesAccionUtilsHisto.findErrorMsg = function(xml) {
	var parseXml = $.parseXML(xml);
	var firstMessage = $(parseXml).find("message")[0];

	return "Error: " + firstMessage.textContent;
}

// Funcion a la que se le pasa el numero de un status de validacion, y te
// devuelve su string
planesAccionUtilsHisto.getStatusText = function(status, oController) {
	var statusText = "";
	var estados = oController.getModel("validatorStatus").getData();
	$.each(estados.d.results, function(i, n) {
		if (n.Value == status)
			statusText = n.Description;
	});
	return statusText;
}

// Función para mostrar un dialog de mensaje, se le pasa el state, el titulo y
// el mensaje
planesAccionUtilsHisto.showMessageDialog = function(message, state, title) {
	var dialog = new sap.m.Dialog({
		title : title,
		type : 'Message',
		content : new sap.m.Text({
			text : message
		}),
		state : state,
		beginButton : new sap.m.Button({
			text : 'Aceptar',
			press : function() {
				dialog.close();
			}
		}),
		afterClose : function() {
			dialog.destroy();
		}
	});
	dialog.open();
}

// Variables de filtros, agrupadors y ordenadores.
planesAccionUtilsHisto.filters = [];
planesAccionUtilsHisto.grouping = false;
planesAccionUtilsHisto.sorters = [];
planesAccionUtilsHisto.grouper = [];

// Variables de filtros, agrupadores y ordenadores para temas.
planesAccionUtilsHisto.filtersTemas = [];
planesAccionUtilsHisto.groupingTemas = false;
planesAccionUtilsHisto.sortersTemas = [];
planesAccionUtilsHisto.grouperTemas = [];

const
C_AUDITADO = "AUDITADO", C_AUDITOR = "AUDITOR";
// Variables para montar tabla
planesAccionUtilsHisto.colNames = [ [ "criticidad", C_AUDITOR ], [ "numInformes", C_AUDITOR ],
		[ "numPlanAccion", C_AUDITOR ], [ "titulo", C_AUDITOR ], [ "departamento", C_AUDITOR ],
		[ "grupo", C_AUDITOR ], [ "responsable", C_AUDITOR ], [ "estado", C_AUDITOR ],		
		
		/**
		 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
		 * Codigo antiguo
		 * [ "estadoVal", C_AUDITOR ], [ "fechaVenc", C_AUDITOR ],
		 * Código nuevo
		 */
		[ "estadoVal", C_AUDITOR ], [ "fechaVenc", C_AUDITOR ],[ "Origen", C_AUDITOR ],
		/**
		 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
		 */		
		[ "criticidad", C_AUDITADO ], [ "numInformes", C_AUDITADO ],
		[ "tituloInforme", C_AUDITADO ], [ "numPlanAccion", C_AUDITADO ], [ "titulo", C_AUDITADO ],
		[ "responsable", C_AUDITADO ], [ "estado", C_AUDITADO ],[ "fechaVenc", C_AUDITADO ],
		/**
		 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
		 * Codigo antiguo
		 * ];
		 * Código nuevo
		 */
		[ "Origen", C_AUDITADO ]];
		/**
		 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
		 */		

  
/**
 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
* Código antiguo 
		
/**
 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
 */
planesAccionUtilsHisto.cellTemplate = [ [ "{actionhis>RankingDescr}", C_AUDITOR ],
		[ "{actionhis>ZzReportId}", C_AUDITOR ], [ "{actionhis>Id}", C_AUDITOR ],		 	
		[ "{actionhis>Title}", C_AUDITOR ], [ "{actionhis>DepartmentName}", C_AUDITOR ],		
		[ "{actionhis>GroupText}", C_AUDITOR ], [ "{actionhis>NameOrg}", C_AUDITOR ],
		[ "{actionhis>StatusDescr}", C_AUDITOR ], [ "{actionhis>Validated}", C_AUDITOR ],
		/**
		 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
		 * Codigo antiguo
		 * [ "{actionhis>Deadline}", C_AUDITOR ]
		 * Código nuevo
		 */
		[ "{actionhis>Deadline}", C_AUDITOR ],[ "{actionhis>ZzOrigen}", C_AUDITOR],
/**
 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
 */		
		

		[ "{actionhis>RankingDescr}", C_AUDITADO ], [ "{actionhis>ZzReportId}", C_AUDITADO ],
		[ "{actionhis>ZzReportTitle}", C_AUDITADO ], [ "{actionhis>Id}", C_AUDITADO ],
		[ "{actionhis>Title}", C_AUDITADO ], [ "{actionhis>NameOrg}", C_AUDITADO ],
		[ "{actionhis>StatusDescr}", C_AUDITADO ], [ "{actionhis>Deadline}", C_AUDITADO ]

/**
 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
 * Codigo antiguo
 * ];
 * Código nuevo
 */
,[ "{actionhis>ZzOrigen}", C_AUDITADO ]];
/**
 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
 */
// Funcion a la que se le pasa el numero de un status, y te devuelve su string
planesAccionUtilsHisto.getStatusString = function(status, oController) {
	var statusString = "";
	$.each(oController.getModel("statusPlModel").getData().d.results, function(i, n) {
		if (n.Status == status)
			statusString = n.StatusT;
	});
	return statusString;
}

// Funcion a la que se le pasa el numero de un ranking de criticidad , y te
// devuelve su string
planesAccionUtilsHisto.getCriticidadString = function(ranking, oController) {
	var statusString = "";
	$.each(oController.getModel("criticidadStatus").getData().d.results, function(i, n) {
		if (n.Ranking == ranking)
			statusString = n.Description;
	});
	return statusString;
}

// Funcion a la que se le pasa el string de un status, y te devuelve su numero
planesAccionUtilsHisto.getStatusCode = function(statusString, oController) {
	var status = oController.getModel("statusPlModel").getData().d.results.filter(function(i) { return i.Objtyp == "ACTION" && i.Langu == "ES"  });	
	var statusCode = ""
	$.each(status, function(i, n) {
		if (n.StatusT == statusString)
			statusCode = n.Status;
	});
	return statusCode;
}

planesAccionUtilsHisto.getServerURL = function() {
	return location.protocol + "//" + location.hostname + ":" + location.port;
}

// Función que nos exporta un excel de backend
function createExportJobHist(aFilters, aSorters, atThemesTab) {

	// //Si aFilters conté "Langu" no l'afegim de nou.
	// var hasLangu = false;
	// $.each(aFilters,function(i,n){
	// if(n.sPath === "Langu"){
	// hasLangu = true;
	// return false;
	// }
	// });
	//	
	// if (!hasLangu) {
	// var sCurrentLocale = sap.ui.getCore().getConfiguration().getLanguage();
	// var language = sCurrentLocale.toUpperCase();
	// aFilters.push(new
	// sap.ui.model.Filter("Langu",sap.ui.model.FilterOperator.EQ, language));
	// }

	var oEntity = {};
	var selections = [];
	if (atThemesTab) {
		oEntity.ObjectType = "ZACTT";
	} else {
		oEntity.ObjectType = "ZACTP";

	}
	oEntity.Scenario = "LST_ACTPOR";
	oEntity.Template = "XLSX";

	$.each(aFilters, function(i, n) {
		var operator = "";
		var value = ""
		switch (n.sOperator) {
		default:
			operator = n.sOperator;
			value = n.oValue1;
			break;
		case "Contains":
			operator = "CP";
			value = "*" + n.oValue1 + "*";
			break;
		}
		selections.push({
			Field : n.sPath,
			Sign : "I",
			Opt : operator,
			Low : value
		});
	});

	// selections.length == 0 ? selections = [{}]: false;

	var sorts = [];
	$.each(aSorters, function(i, n) {
		sorts.push({
			AttributeName : n.sPath,
			Ascending : !n.bDescending
		});
	});
	// sorts.length == 0 ? sorts = [{AttributeName: "Type", Ascending: true}]:
	// false;

	if (selections.length != 0)
		oEntity.Selections = selections;
	if (sorts.length != 0)
		oEntity.Sorts = sorts;

	var url = "/ExportJobSet";
	con.model.setUseBatch(true);
	con.Create(url,
			oEntity, false, this.oController,
			function(oData, dataResp){		
				window.open(planesAccionUtilsHisto.getServerURL() + con.model.sServiceUrl
						+ "/ExportJobSet(guid'" + oData.Key + "')/File/$value", '_blank');
			}, "");
	con.model.setUseBatch(false);
//	getModel('con').create(
//			url,
//			oEntity,
//			null,
//			function(dataResp) {
//				window.open(planesAccionUtilsHisto.getServerURL() + getModel('con').sServiceUrl
//						+ "/ExportJobSet(guid'" + dataResp.Key + "')/File/$value", '_blank');
//			}, function(oError) {
//				console.log(oError);
//			});
	
	
}

/**
 * INI MOD PPM040907 Rafael Galán Baquero 15/04/2020				
 * Código nuevo
 */
//Se obtiene el texto a mostrar para el campo origen
planesAccionUtilsHisto.getOrigenText = function(origen){
////var element = sap.ui.getCore().getModel('OrigenActionPlan').getData().results.find(element => element.Id == origen );
	var element = sap.ui.getCore().getModel('OrigenActionPlan').getData().results.filter(function(item) { return item.Id == origen; });

	return element.length > 0 ? element[0].Text : '';
			
}
 		
/**
 * FIN MOD PPM040907 Rafael Galán Baquero 15/04/2020
 */