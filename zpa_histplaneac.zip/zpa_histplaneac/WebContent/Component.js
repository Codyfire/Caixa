sap.ui.define([ "sap/ui/core/UIComponent", "sap/ui/Device" ],
		

		function(UIComponent, Device, models) {
			"use strict";

			
			return UIComponent.extend("appHistoPlanesAccion.Component", {

				metadata : {
					manifest : "json"
				},

				/**
				 * The component is initialized by UI5 automatically during the
				 * startup of the app and calls the init method once.
				 * 
				 * @public
				 * @override
				 */
				
							
				init : function() {
										

					// call the base component's init function
					UIComponent.prototype.init.apply(this, arguments);

					// Se guarda el modelo de servicio para las llamadas a
					// backend
					con.model = this.getModel('service');
					con.model.setUseBatch(true);

					con.model2 = this.getModel('service2');
					con.model2.setUseBatch(true);

					// console.log("Modelo Historico Planes Accion");
					console.log(this.getModel('rol'));
					// console.log(this.getModel('validatorStatus'));

					var that = this;
					
					//	INI Ajuste SPAU 12/11/18
					// Codigo antiguo
					/**this.getModel("rol").attachRequestCompleted(function() {
						// initialize the router
						that.oRouter = this.getRouter();
						// init the router
						that.getRouter().initialize();

						that.navigate();
					}, that);
					*/
					
					// Codigo nuevo
					//if( oFirst == true && this.getModel("rol").getData().d.results.length != undefined ){
					if( oFirst == true && this.getModel("rol").getData().d != undefined ){
						//if(this.getModel("rol")){
							// initialize the router
							that.oRouter = this.getRouter();
							// init the router
							that.getRouter().initialize();

							that.navigate();
							// se indica que ya ha accedido la primera vez
							oFirst = false;

						}else{
							
							this.getModel("rol").attachRequestCompleted(function() {
								// initialize the router
								that.oRouter = this.getRouter();
								// init the router
								that.getRouter().initialize();

								that.navigate();
				
							}, that);

							
						}
						
	
					//}
					
					// FIN Ajuste SPAU 12/11/18
					

					
				},

				destroy : function() {
					sap.ui.core.UIComponent.prototype.destroy.apply(this, arguments);
				},

				navigate : function() {
					var hash = window.location.hash;

					// if ( hash.contains("ZPA_HISTPLANEACS") ){
					this.getTargets().display("tablePlanesHist");
					// }
				}

			});
		});