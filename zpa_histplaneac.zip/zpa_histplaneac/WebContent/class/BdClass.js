
//function Bd(conUrl, headers){
//	this.serviceUrl = conUrl;
//	this.con = new sap.ui.model.odata.ODataModel(this.serviceUrl, false);
//	if(headers !== null && headers !== undefined)
//		this.con.setHeaders(headers);
//	this.con.refreshSecurityToken();
//}

var con = {};

con.Read = function(url, aParams, aFilters, aSorters, async, oController, callBack, binds, view){
	con.model.read(url,{ 
		async:async,
		urlParameters: aParams,
		filters: aFilters,
		sorters: aSorters,
        success : callBack.bind({oBind: binds, oController: oController}), //this.onSuccess.bind({callBack:callBack, oController: oController}),
        error: function(oError){console.log("error"); console.log(oError);}//this.onError.bind({callBack:callBack, oController: oController, view: view})
	});
}

con.Create = function(url, oData, async, oController, callBack, binds){
	con.model.create(url,oData,{
		async: async,
		success : callBack.bind({oBind: binds, oController: oController}),// this.onSuccess.bind({callBack:callBack, oController: oController}),
        error: function(oError){
        	console.log(oError);
        	Helper.showMsg(Helper.findErrorMsgJSON(oError,10000));
        }// this.onError.bind({callBack:callBack, oController: oController})
	});
}

con.Update = function(url, oData, async, merge, oController, callBack, binds){
	con.model.update(url,oData,{
		async: async,
		merge: merge,
		success : callBack.bind({oBind: binds, oController: oController}),// this.onSuccess.bind({callBack:callBack, oController: oController}),
        error: function(oError){
        	console.log(oError);
        	Helper.showMsg(Helper.findErrorMsgJSON(oError,10000));
        }// this.onError.bind({callBack:callBack, oController: oController})
	});
}

con.Delete = function(url, async, oController, callBack, binds){
	
	debugger
	con.model.remove(url,{
		async: async,
		success : callBack.bind({oBind: binds, oController: oController}),// this.onSuccess.bind({callBack:callBack, oController: oController}),
        error: function(oError){
        	console.log(oError);
        	Helper.showMsg(Helper.findErrorMsgJSON(oError,10000));
        }// this.onError.bind({callBack:callBack, oController: oController})
	});
}

con.CallFunction = function(url, aParams, aFilters, aSorters, async, oController, callBack, binds, view){
	con.model.callFunction(url,{
		async:async,
		urlParameters: aParams,
		filters: aFilters,
		sorters: aSorters,
        success : callBack.bind({oBind: binds, oController: oController}), //this.onSuccess.bind({callBack:callBack, oController: oController}),
        error: function(oError){console.log("error"); console.log(oError);}//this.onError.bind({callBack:callBack, oController: oController, view: view})
	});
}

var con2 = {};
con2.Read = function(url, aParams, aFilters, aSorters, async, oController, callBack, binds, view){
	con.model2.read(url,{
		async:async,
		urlParameters: aParams,
		filters: aFilters,
		sorters: aSorters,
        success : callBack.bind({oBind: binds, oController: oController}), //this.onSuccess.bind({callBack:callBack, oController: oController}),
        error: function(oError){console.log("error"); console.log(oError);}//this.onError.bind({callBack:callBack, oController: oController, view: view})
	});
}
