//define a new UIComponent 
jQuery.sap.require("sap.ui.core.UIComponent");
jQuery.sap.require("sap.m.Table");
jQuery.sap.require("sap.m.VBox");
jQuery.sap.declare("tablePaginationHis.Component");

sap.ui.define([
	"sap/ui/core/UIComponent"
], function (UIComponent) {
	"use strict";

	return UIComponent.extend("tablePaginationHis.Component", {

		init : function () { 
			// call the init function of the parent
			UIComponent.prototype.init.apply(this, arguments);
		},
		
		createContent: function(){
			this.rowsForPage = 7;
			//Esto es para que funcione en IE i en Fiori
			var screenWidth = window.innerWidth || document.body.clientWidth;
			var width;
			/*if(screenWidth >= 1280){
				width = "1280px";
			}else{
				width = screenWidth + "px";
			}*/
			width = screenWidth + "px";
			
			//Creo la taula buida
			this.table = new sap.m.Table({
				width:width, //Canviar per un 100% si es vol responsive, pero no funcionara amb IE
		    });
			
			var table = this.table;
			
			this.oFlex = new sap.m.FlexBox({
				//width:width,
				height:"100%",
				direction:"Column",
				displayInline: true,
				alignItems: sap.m.FlexAlignItems.Center,
				fitContainer:true,
				items:[
				       table
				]
			});
			return new sap.m.ScrollContainer({ 
				content: [this.oFlex],
				vertical: true
			});
		},
		//En aquesta funció li passo les columnes que vull que tingui la taula en un array 
		addColumns: function(columns){
			var table = this.table;
					table.addColumn(columns);
//				}
//			});
		},
		//funcó per bindejar les dades a la taula
		addItemTemplate: function(a,b,c){
			this.table.bindAggregation(a,b,c);
			this.ruta = b;
			this.table.bindItems({path:b,template:c}); 
		},
		//funció que fica el model de dades a la taula
		setDataModel: function(oModel, model){ 
			this.model = model;			
			this.table.setModel(oModel, model);
			this.table.getModel(model).updateBindings(true);
		},
		//funció que crea el menú de paginació
		createPaginationMenu: function(model, elementsForPage, id, tabThemes){
			var numberOfRows = this.countFunc;
			var that = this;
			var numberOfPages = Math.ceil(numberOfRows / elementsForPage);
			//Un cop tinc el model ja puc saber el nombre de files que tindre, agafo el vBox i li assigno el paginador
			var oFlex = this.oFlex;
			if(oFlex.getItems()[1]){
				oFlex.getItems()[1].destroy();
			}
			if(numberOfPages > 1){
				oFlex.addItem(
				   new sap.ui.commons.Paginator({
			           numberOfPages: numberOfPages,
			    	   currentPage: 1,
			    	   page : function(oEvent) {
//			    		   if(tabThemes !== "NOTHEME") {
//			    			   sap.ui.getCore().getComponent(that.sId).refreshTableVisibility(oEvent.getParameter("targetPage"), elementsForPage, planesAccionUtilsHisto.filtersTemas,planesAccionUtilsHisto.sortersTemas, planesAccionUtilsHisto.grouperTemas);
//			    		   } else {
			    			   sap.ui.getCore().getComponent(that.sId).refreshTableVisibility(oEvent.getParameter("targetPage"), elementsForPage, planesAccionUtilsHisto.filters,planesAccionUtilsHisto.sorters, planesAccionUtilsHisto.grouper);
//			    		   }
			    	   }
			       })
				);
			}
//			sap.ui.getCore().getComponent(that.sId).refreshTableVisibility(1, elementsForPage, planesAccionUtilsHisto.filters,planesAccionUtilsHisto.sorters, planesAccionUtilsHisto.grouper);
  		  
		},
		
		refreshTableVisibility: function(pageNumber, elementsForPage, aFilters, aSorters, grouper){
			var currentPage = 1
			if(sap.ui.getCore().getComponent(this.sId).oFlex.getItems()[1] != undefined){
				currentPage = sap.ui.getCore().getComponent(this.sId).oFlex.getItems()[1].getCurrentPage();
			}
			var top = sap.ui.getCore().getComponent(this.sId).rowsForPage
			var skip = (currentPage-1) * top;
//			debugger
			var aParameters = {
					"$skip" : skip,
					"$top" : top
				};
//			var urlactionhisRegis = "/InfoActionsSet?&$skip="+skip+"&$top="+top;
			con.Read(conHelper.params.urlactionhis, 
					aParameters,aFilters, aSorters, false, this, this.success,
					"", null);
//			loadPlanesAccion(skip,top,aFilters,aSorters, grouper)
		},
		success:function(oData, oDataRes) {
			// 
			if (oData != undefined) {
				var oModelTable = newModelWithData(oData);
//				var oTable = this.oController.getView().oTable;
				var component = sap.ui.getCore().getComponent("tablePlanAccionesHis");
				var oTable = component.table;

				component.setDataModel(oModelTable, "actionhis");
				if (planesAccionUtilsHisto.grouping) {
					var oBinding = oTable.getBinding("")
					oBinding.sort(planesAccionUtilsHisto.grouper)
				}
		 		
			//component.refreshTablePaginationForFilteredItems(1,10, false);
			} 
			
		},
		
		refreshTablePaginationForFilteredItems: function(pageNumber, elementsForPage, tabThemes){
			var initialElement = elementsForPage * (pageNumber - 1); //El primer element que ha de ser visible
			var finalElement = pageNumber * elementsForPage; //L'ultim element que ha de ser visible
			var table = this.table;
			
			//Si el nombre d'elements que retorna el filtre es major al nombre d'elements per pàgina, em de crear un nou paginador
			var numberOfElements = table.getItems().length;
			if(numberOfElements > elementsForPage){
				//Obting el numero total de files
				var numberOfRows = this.table.getVisibleItems().length;
				var numberOfPages = Math.ceil(numberOfRows / elementsForPage);
				
				//refresco els items visibles de la taula
				$.each(table.getVisibleItems(),function(i, value){
					if(i >= initialElement && i < finalElement)
						value.setVisible(true);
					else
						value.setVisible(false);
				});
			}else{
				//enseño tots els items
				$.each(table.getItems(),function(i, value){
					value.setVisible(true);
				});
			}
			//Comprovem si el vBox te un paginador i si el te l'elimino
			this.createPaginationMenu(this.model,7, tabThemes);
		},
		
		setCustomToolbar: function(toolbar){
			this.table.setHeaderToolbar(toolbar);
		},
		
		setMode: function(mode){
			this.table.setMode(mode);
		},
		
		setCountFunction: function(){
//			debugger; //Comprobar count de modelo			
			this.countFunc = this.table.getModel(this.model).getData().__count;//this.oContainer.getModel(this.model).getData().d.results.length;
		},

		exportToExcel: function(fileName, filters, sorters, atThemesTab){
			createExportJobHist(filters,sorters, atThemesTab);
		},
		
		getVisibleColumnsIndexs: function() {
			var items = [];
			var table = this.table;
			$.each(table.getColumns(),function(i,n){ if(n.getVisible() == true){items.push(n._index);} });
			return items;
		}
	});
			
});