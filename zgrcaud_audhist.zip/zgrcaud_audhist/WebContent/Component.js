/*
 * Copyright (C) 2009-2020 SAP SE or an SAP affiliate company. All rights reserved.
 */
jQuery.sap.declare("sap.grc.acs.aud.audit.displayhistorical.extended.Component");
					
sap.ui.component.load({
 	name:"sap.grc.acs.aud.audit.displayhistorical",
 	url: "/sap/bc/ui5_ui5/sap/grcaud_audhist"
 		 
 });


sap.ui.define([ "sap/ui/core/UIComponent", 
				"sap/ui/Device",
				"sap/grc/acs/aud/audit/app/Component" ], 
   function(U, D, C) {
	"use strict";	
	 
	return C.extend("sap.grc.acs.aud.audit.displayhistorical.extended.Component", {
		metadata : {
			manifest : "json",
		     "customizing" : {

		    	 "sap.ui.viewReplacements" : {
						"sap.grc.acs.aud.audit.view.Object" : {
							"viewName" : "sap.grc.acs.aud.audit.displayhistorical.extended.view.Object",
							"type" : "XML"
						},												
						"sap.grc.acs.aud.audit.block.view.General": {    	                        
	                        "viewName": "sap.grc.acs.aud.audit.displayhistorical.extended.view.GeneralCustom",            
	                        "type": "XML"
	                    }    ,
						
						"sap.grc.acs.aud.audit.view.Worklist" : {
							"viewName" : "sap.grc.acs.aud.audit.displayhistorical.extended.view.Worklist",
							"type" : "XML"
						}
					},
		         "sap.ui.controllerExtensions" : {
		             
		     "sap.grc.acs.aud.audit.controller.Object" : {
					"controllerName" : "sap.grc.acs.aud.audit.displayhistorical.extended.Controller.ObjectExtended"
		
				},
				
				"sap.grc.acs.aud.audit.controller.Worklist" : {
					"controllerName" : "sap.grc.acs.aud.audit.displayhistorical.extended.Controller.Worklist"
		
				},
				
//			},
//			"sap.ui.controllerReplacements": {
				 "sap.grc.acs.aud.audit.block.controller.General" : {
					 "controllerName":"sap.grc.acs.aud.audit.displayhistorical.extended.block.generalCustom"
				 
				 }
			
			},
		          }
		}
	});
});
