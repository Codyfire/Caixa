/*
 * Copyright (C) 2009-2020 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/grc/acs/lib/aud/utils/MenuItemUtils",
	"sap/grc/acs/lib/aud/utils/ComponentUtil",
	"sap/grc/acs/lib/aud/utils/MessageUtil",
	"sap/ui/model/Sorter"
], function (Controller, Filter, MenuItemUtils, ComponentUtil, MessageUtil, Sorter) {
	"use strict";

	return Controller.extend("sap.grc.acs.aud.audit.displayhistorical.extended.findRel.controller.Finding", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf src.sap.grc.acs.aud.audit.block.view.Finding
		 */
		onInit: function () {
			this._oComponent = ComponentUtil.getComponentById(this.getView().getId());
			sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.audit.EventBus", "resetBlockToDisplayMode", this.onRefresh, this);
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf src.sap.grc.acs.aud.audit.block.view.Finding
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf src.sap.grc.acs.aud.audit.block.view.Finding
		 */
		//  onAfterRendering: function() {
		// 	this._setInitialSortOrder();
		//  },

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf src.sap.grc.acs.aud.audit.block.view.Finding
		 */
		onExit: function () {
			sap.ui.getCore().getEventBus().unsubscribe("sap.grc.acs.aud.audit.EventBus", "resetBlockToDisplayMode", this.onRefresh, this);
		},

		createHeaderButton: function (sId, oContext) {
			return MenuItemUtils.createButtonTemplate(sId, oContext, this);
		},

		onBeforeRebindTable: function (oEvent) {
			oEvent.getParameter("bindingParams").sorter.push(new Sorter("ID"));
		},

		onUpdateFinished: function () {
			if (this.changeSequenceFlag) {
				this.changeSequenceFlag = false;
				return;
			} else {
				this.changeSequenceFlag = false;
				this.getView().byId("colSequence").setVisible(false);
			}
		},

		onSearch: function (oEvent) {
			var oTableSearchState = [];
			var sQuery = oEvent.getParameter("query");
			var oTableSearchStateFilter = [];
			oTableSearchState = [
				new Filter("ID", sap.ui.model.FilterOperator.Contains, sQuery),
				new Filter("Title", sap.ui.model.FilterOperator.Contains, sQuery)
			];
			oTableSearchStateFilter = new sap.ui.model.Filter(oTableSearchState, false);
			this.getView().byId("tableFinding").getBinding("items").filter(oTableSearchStateFilter, sap.ui.model.FilterType.Application);
		},

		onPressRow: function (oEvent) {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var oFindingIntentConfig = this.getView().getModel("intentConfig").getData().findingIntent;

			var args = {
				target: {
					semanticObject: oFindingIntentConfig.semanticObject,
					action: oFindingIntentConfig.action
				},
				params: {
					"DBKey": oEvent.getSource().getBindingContext().getObject().DBKey
				}
			};
			var shref = oCrossAppNavigator.hrefForExternal(args);
			window.open(shref, "_self");

		},

		onPressPersonalization: function () {
			var oPersController  = this.getView().byId("findSmartTable")._oPersController;

			if(!oPersController._oDialog){
				oPersController.openDialog();
				var oPersDialog = oPersController._oDialog;
				var oFinding = this;
				//OK button event
				oPersDialog.attachOk(function(){
				  oFinding.getView().byId("findSmartTable").rebindTable(true);
				});
			}
		},

		FIND_SUBMIT_RISK_PROPOSAL: function () {
			var oRiskProposalModel = this.getOwnerComponent().getModel("riskProposal");
			
			//reset riskProposal model
			oRiskProposalModel.setProperty("/findings", "");
			oRiskProposalModel.setProperty("/organizationID", "");
			oRiskProposalModel.setProperty("/organizationName", "");
			oRiskProposalModel.setProperty("/organizationKey", "");
			oRiskProposalModel.setProperty("/OrgTimestamp", "");
			oRiskProposalModel.setProperty("/auditKey", "");
			oRiskProposalModel.setProperty("/findingCount", "");
			oRiskProposalModel.setProperty("/actionCount", "");
			
			var oSelectedItems = this.getView().byId("tableFinding").getSelectedItems();
			var oSelectedLen = oSelectedItems.length;
			//check select at lease one finding
			if(oSelectedLen <= 0){
				MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("msgCreateRspsSelectAtLeastOneFinding"));
				return ;
			}
			var oSelectedFinding = [];
			var oOrgCur, oOrgName, oOrgKey, oOrgTimestamp,
				oOrgTemp = oSelectedItems[0].getBindingContext().getObject("OrgID");
				
			var oFindingCount = 0;
			var oActionCount = 0;
				
			for (var i = 0; i < oSelectedItems.length; i++) {
				var oBindingContext = oSelectedItems[i].getBindingContext();
				var oOrgImported = oBindingContext.getObject("ImportedOrg");
				oOrgCur = oBindingContext.getObject("OrgID");
				oOrgName = oBindingContext.getObject("OrgName");
				oOrgKey = oBindingContext.getObject("OrgKey");
				oOrgTimestamp = oBindingContext.getObject("OrgTimestamp");
				
				//check finding assigned an imported organization
				if(oOrgCur !== "" && (oOrgImported === "" || oOrgImported === false) ){
					MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("msgCreateRspsSelectImportedOrgInFinding"));
					return ;
				}
				
				//check selected finding assigned same orgnization
				if(oOrgCur.toString() !== oOrgTemp.toString()){
					MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("msgCreateRspsSelectSameOrgFinding"));
					return ;
				}
				
				//if all selected findings all assigned same orgnization, save selected findind key
				var finding = {};
				finding.FindingKey = oBindingContext.getObject("DBKey");
				oSelectedFinding.push(finding);
				
				oFindingCount++;
				oActionCount += oBindingContext.getObject("ActionCount");
			}

			oRiskProposalModel.setProperty("/findings", oSelectedFinding);
			oRiskProposalModel.setProperty("/organizationID", oOrgCur);
			oRiskProposalModel.setProperty("/organizationName", oOrgName);
			oRiskProposalModel.setProperty("/organizationKey", oOrgKey);
			oRiskProposalModel.setProperty("/OrgTimestamp", oOrgTimestamp);
			oRiskProposalModel.setProperty("/auditKey", this.getView().getBindingContext().getObject("DBKey"));
			oRiskProposalModel.setProperty("/findingCount", oFindingCount);
			oRiskProposalModel.setProperty("/actionCount", oActionCount);
			
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("riskProposal");
		},

		FIND_CREATE_FINDING: function () {
			var oAudit = this.getView().getBindingContext().getObject();
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			var sAction = "create";
			var args = {
				target: {
					semanticObject: "Finding",
					action: sAction
				},
				params: {
					"AuditKey": oAudit.DBKey,
					"AuditType": oAudit.Type,
					"AuditGroup": oAudit.AuditGroup
				}
			};
			var shref = oCrossAppNavigator.hrefForExternal(args);
			window.open(shref, "_self");

			// var oFindingView = this.getView();
			// if (!this._oCreateFindingDialog) {
			// 	this.getView().byId("findSmartTable").setBusy(true);
			// 	this._oCreateFindingDialog = sap.ui.getCore().createComponent({
			// 		name: "sap.grc.acs.aud.finding.creation"
			// 	});
			// }
			// var sIntent = this._oComponent.getModel("intentConfig").getData().intent;
			// this._oCreateFindingDialog.open(oAudit, oFindingView, sIntent);
			// this.getView().byId("findSmartTable").setBusy(false);
		},

		FIND_UPDATE_FINDING: function (oEvent, oAdditionalInfo) {
			this._storeSequenceValue();
			//this._resetSequenceValue();
			this._setButtonVisibility("EDIT");
			this.getView().byId("colSequence").setVisible(true);
			//set input enabled=true
			this._setInputEditable(true);
		},

		FIND_DELETE_FINDING: function (oEvent, oAdditionalInfo) {
			var aSelectedItems = this.getView().byId("tableFinding").getSelectedItems();
			var sPath = "";
			var oDataModel = this.getView().getModel();
			if (aSelectedItems.length === 0) {
				MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("msgSelectOne"));
				return;
			}
			//check if there is any non-draft finding selected to be deleted.
			for (var i = 0; i < aSelectedItems.length; i++) {
				var sStatus = aSelectedItems[i].getBindingContext().getObject().Status;
				if (!(sStatus === "")) {
					MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("msgSelectDraftFinding"));
					return;
				}
			}

			oDataModel.setUseBatch(true);
			oDataModel.setDeferredGroups(["deleteFinding"]);
			for (i = 0; i < aSelectedItems.length; i++) {
				sPath = aSelectedItems[i].getBindingContext().getPath();
				oDataModel.remove(sPath, {
					async: true,
					groupId: "deleteFinding"
				});
			}

			oDataModel.submitChanges({
				groupId: "deleteFinding",
				success: jQuery.proxy(function () {
					MessageUtil.showMsg("msgTypeSuccessful", this.getView().getModel("i18n").getResourceBundle().getText(
						"msgDeleteFindingSuccess"));
					oDataModel.refresh();
					this.sFocusButton = "FIND-DELETE_FINDING";
					if (this.getView().byId("findingToolbar")) {
						this.getView().byId("findingToolbar").getContent()[3].onAfterRendering = function () {
							if (this.sFocusButton === "FIND-DELETE_FINDING") {
								this.getView().byId("findingToolbar").getContent()[3].focus();
								this.sFocusButton = "";
							}
						}.bind(this);
					}
					oDataModel.setUseBatch(false);
				}, this),
				error: jQuery.proxy(function () {
					MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("msgDeleteFindingFailed"));
				}, this)
			});
		},

		onSaveBtnPress: function () {
			var oTable = this.getView().byId("tableFinding");
			var aFindings = this.getView().byId("tableFinding").getItems();

			if (aFindings.length === 0) {
				this.getView().byId("colSequence").setVisible(false);
				this._setInputEditable(false);
				this._setButtonVisibility("DISPLAY");
				return;
			}

			// same sequence detection
			var aSeq = [];
			for (var j = 0; j < aFindings.length; j++) {
				var sSeq = aFindings[j].getCells()[1].getValue();
				if (aSeq.indexOf(sSeq) !== -1) {
					MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("msgEditFindingSequenceFailed"));
					aSeq = [];
					return;
				} else {
					aSeq.push(sSeq);
				}
			}

			//save sequence
			oTable.setBusy(true);
			for (var i = 0; i < aFindings.length; i++) {
				var sPath = aFindings[i].getBindingContext().getPath();
				var oDataModel = this.getView().getModel();
				var sStatus = aFindings[i].getBindingContext().getObject().Status;
				if (sStatus === "") {
					var sSequence = aFindings[i].getCells()[1].getValue();
					// var oColumnSeq = this.getView().byId("colSequence");
					oDataModel.update(sPath, {
						Sequence: sSequence
					}, {
						success: this._saveSuccessHandle.bind(this),
						error: this._saveErrorHandle.bind(this),
						groupId: "saveSequence",
						async: true,
						merge: true
					});
				}

			}
		},
		_saveSuccessHandle: function () {
			var oTable = this.getView().byId("tableFinding");
			var oColumnSeq = this.getView().byId("colSequence");
			MessageUtil.showMsg("msgTypeSuccessful", this.getView().getModel("i18n").getResourceBundle().getText(
				"msgEditFindingSequenceSuccess"));
			//this.getView().getModel().refresh(true);
			this._storeSequenceValue();
			oTable.setBusy(false);
			oColumnSeq.setVisible(false);
			this._setInputEditable(false);
			this._setButtonVisibility("DISPLAY");
		},
		_saveErrorHandle: function () {
			var oTable = this.getView().byId("tableFinding");
			var oColumnSeq = this.getView().byId("colSequence");
			oTable.setBusy(false);
			oColumnSeq.setVisible(true);
			this._setInputEditable(true);
			this._setButtonVisibility("EDIT");
		},
		onCancelBtnPress: function (oEvent) {
			this._resetSequenceValue();
			this._setInputEditable(false);
			this._setButtonVisibility("DISPLAY");
			this.getView().byId("colSequence").setVisible(false);
			MessageUtil.showMsg("msgTypeSuccessful", this.getView().getModel("i18n").getResourceBundle().getText("msgNothingUpdated"));
		},

		onKeyPressValidation: function (oEvent) {
			var oInput = oEvent.getSource();
			var oValue = oInput.getValue();
			var regex = /^[0-9]\d*$/;
			if (!oValue.match(regex) && oValue !== "") {
				oInput.setValueState(sap.ui.core.ValueState.Error);
				oInput.setValueStateText(this.getView().getModel("i18n").getResourceBundle().getText("msgNatualNumber"));
			} else {
				oInput.setValueState(sap.ui.core.ValueState.None);
				oInput.setValueStateText("");
			}
		},
		onUnfocusValidation: function (oEvent) {
			this.changeSequenceFlag = true;
			var oInput = oEvent.getSource();
			var oValue = oInput.getValue();
			if (oInput.getValueState() === sap.ui.core.ValueState.Error) {
				return;
			}
			if (oValue === "") {
				oInput.setValueState(sap.ui.core.ValueState.Error);
				oInput.setValueStateText(this.getView().getModel("i18n").getResourceBundle().getText("msgEmptyNotAllowed"));
				return;
			}
			if (parseInt(oValue, 10) === 0) {
				oInput.setValueState(sap.ui.core.ValueState.Error);
				oInput.setValueStateText(this.getView().getModel("i18n").getResourceBundle().getText("msgZeroNotAllowed"));
				return;
			}
			// if(oValue.length > 5){
			// 	oInput.setValueState(sap.ui.core.ValueState.Error);
			// 	oInput.setValueStateText("Length should not be larger than 5 digits");
			// 	return;
			// }
			oInput.setValueState(sap.ui.core.ValueState.None);
			oInput.setValueStateText("");
		},

		onRefresh: function () {
			this._setButtonVisibility("DISPLAY");
			//in finding edit mode, but refresh the whole model
			var oTable = this.getView().byId("tableFindRel");
			var aCurrentFindings = oTable.getItems();
			for (var i = 0; i < this._aOriginalFindSequences.length; i++) {
				aCurrentFindings[i].getCells()[1].setValue(this._aOriginalFindSequences[i].sequence);
				aCurrentFindings[i].getCells()[1].setValueState(sap.ui.core.ValueState.None);
			}
			this.getView().byId("colSequence").setVisible(false);
			this._setInputEditable(false);
		},

		_setInputEditable: function (bEditable) {
			var aFindings = this.getView().byId("tableFindRel").getItems();
			for (var i = 0; i < aFindings.length; i++) {
				//if status is draft, then sequence cell is editable;
				var sStatus = aFindings[i].getBindingContext().getObject().Status;
				if (sStatus === "") {
					aFindings[i].getCells()[1].setEditable(bEditable);
					aFindings[i].getCells()[1].setEnabled(bEditable);
				}

			}
		},
		_storeSequenceValue: function () {
			//note down sequence so that 
			//when user click cancel button after he changed some sequence, 
			//sequence value can be revert into original ones stored in this._aOriginalFindSequences
			this._aOriginalFindSequences = [];
			var aFindings = this.getView().byId("tableFindRel").getItems();
			for (var i = 0; i < aFindings.length; i++) {
				var sDbKey = aFindings[i].getBindingContext().getObject().DBKey;
				var sSeq = aFindings[i].getBindingContext().getObject().Sequence;
				this._aOriginalFindSequences.push({
					"findDbKey": sDbKey,
					"sequence": sSeq
				});
			}
		},

		_resetSequenceValue: function () {
			//reset to original value
			var aFindings = this.getView().byId("tableFindRel").getItems();
			for (var i = 0; i < this._aOriginalFindSequences.length; i++) {
				for (var j = 0; j < aFindings.length; j++) {
					if (!(aFindings[j].getBindingContext().getObject().DBKey === this._aOriginalFindSequences[i].findDbKey)) {
						continue;
					}
					aFindings[j].getCells()[1].setValue(this._aOriginalFindSequences[i].sequence);
					aFindings[j].getCells()[1].setValueState(sap.ui.core.ValueState.None);
				}

			}
		},

		_setButtonVisibility: function (sMode) {
			var oHeaderContents = this.getView().byId("findRelToolbar").getAggregation("content");
			var oEditButtonControl = null;
			var oCancelButtonControl = null;
			var oSaveButtonControl = null;
			var oAddButtonControl = null;
			var oPersButtonControl = null;
			var oDeleteButtonControl = null;
			for (var i = 0; i < oHeaderContents.length; i++) {
				switch (oHeaderContents[i].getId()) {
				case "btnSave":
					oSaveButtonControl = oHeaderContents[i];
					break;
				case "btnCancel":
					oCancelButtonControl = oHeaderContents[i];
					break;
				case "FIND-DELETE_FINDING":
					oDeleteButtonControl = oHeaderContents[i];
					break;
				case "FIND-UPDATE_FINDING":
					oEditButtonControl = oHeaderContents[i];
					break;
				case "FIND-CREATE_FINDING":
					oAddButtonControl = oHeaderContents[i];
					break;
				case "auditFindingBlockPersonalization":
					oPersButtonControl = oHeaderContents[i];
					break;
				default:
					break;
				}
			}
			if (sMode === "EDIT") {
				if (oEditButtonControl !== null && oAddButtonControl !== null) {
					oEditButtonControl.setVisible(false);
					oAddButtonControl.setVisible(true);
					oCancelButtonControl.setVisible(true);
					oSaveButtonControl.setVisible(true);
					oPersButtonControl.setVisible(false);
					oDeleteButtonControl.setVisible(false);
				}
			} else if (sMode === "DISPLAY") {
				if (oEditButtonControl !== null && oAddButtonControl !== null) {
					oEditButtonControl.setVisible(true);
					oAddButtonControl.setVisible(true);
					oCancelButtonControl.setVisible(false);
					oSaveButtonControl.setVisible(false);
					oPersButtonControl.setVisible(true);
					oDeleteButtonControl.setVisible(true);
				}
			} else {
				if (oEditButtonControl !== null && oAddButtonControl !== null) {
					oEditButtonControl.setVisible(false);
					oAddButtonControl.setVisible(false);
					oCancelButtonControl.setVisible(false);
					oSaveButtonControl.setVisible(false);
					oPersButtonControl.setVisible(true);
					oDeleteButtonControl.setVisible(true);
				}
			}
			if (this.getView().byId("findRelToolbar").getContent().length !== 0) {
				this.getView().byId("findRelToolbar").setVisible(true);
			} else {
				this.getView().byId("findRelToolbar").setVisible(false);
			}
		}

	});

});
