/*
 * Copyright (C) 2009-2020 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui
		.define(
				[ "sap/grc/acs/aud/audit/controller/BaseController",
						"sap/ui/model/json/JSONModel",
						"sap/grc/acs/aud/audit/model/formatter",
						"sap/ui/model/Filter", "sap/ui/model/FilterOperator",
						"sap/ui/core/routing/History",
						"sap/grc/acs/lib/aud/utils/MessageUtil",
						"sap/grc/acs/lib/aud/doc/util/FileUploader" ],
				function(B, J, f, F, a, H, M, b) {
					"use strict";
					return B
							.extend(
									"sap.grc.acs.aud.audit.displayhistorical.extended.controller.Worklist",
									{
										formatter : f,
										onInit : function() {
											var v, o, t = this.byId("table");
											o = t.getBusyIndicatorDelay();
											this._oTable = t;
											this._oTableSearchState = [];
											v = new J(
													{
														worklistTableTitle : this
																.getResourceBundle()
																.getText(
																		"worklistTableTitle"),
														saveAsTileTitle : this
																.getResourceBundle()
																.getText(
																		"worklistViewTitle"),
														shareOnJamTitle : this
																.getResourceBundle()
																.getText(
																		"worklistViewTitle"),
														shareSendEmailSubject : this
																.getResourceBundle()
																.getText(
																		"shareSendEmailWorklistSubject"),
														shareSendEmailMessage : this
																.getResourceBundle()
																.getText(
																		"shareSendEmailWorklistMessage",
																		[ location.href ]),
														tableNoDataText : this
																.getResourceBundle()
																.getText(
																		"tableNoDataText"),
														tableBusyDelay : 0
													});
											this.setModel(v, "worklistView");
											var T = this
													.getResourceBundle()
													.getText(
															this
																	.getOwnerComponent()
																	.getModel(
																			"intentConfig")
																	.getData().appTitle);
											this.getOwnerComponent()
													.getService(
															"ShellUIService")
													.then(function(s) {
														s.setTitle(T);
													});
											t
													.attachEventOnce(
															"updateFinished",
															function() {
																v
																		.setProperty(
																				"/tableBusyDelay",
																				o);
															});
											sap.ui
													.getCore()
													.getEventBus()
													.subscribe(
															"sap.grc.acs.aud.audit.EventBus",
															"auditListRefresh",
															this.onRefresh,
															this);
										},
										onUpdateFinished : function(e) {
											var t, T = e.getSource(), i = e
													.getParameter("total");
											if (i
													&& T.getBinding("items")
															.isLengthFinal()) {
												t = this
														.getResourceBundle()
														.getText(
																"worklistTableTitleCount",
																[ i ]);
											} else {
												t = this
														.getResourceBundle()
														.getText(
																"worklistTableTitle");
											}
											this
													.getModel("worklistView")
													.setProperty(
															"/worklistTableTitle",
															t);
										},
										onBeforeRebindTable : function(e) {
											var o = e
													.getParameter("bindingParams");
											var p = this.getOwnerComponent()
													.getComponentData().startupParameters;
											var w = this.getModel(
													"intentConfig").getData().worklistSorter;
											var A = function(P, s) {
												if (P && P.length > 0) {
													o.filters
															.push(new sap.ui.model.Filter(
																	{
																		path : s,
																		operator : sap.ui.model.FilterOperator.EQ,
																		value1 : P[0]
																	}));
												}
											};
											if (w) {
												o.sorter
														.push(new sap.ui.model.Sorter(
																w.orderBy,
																w.isDescending));
											}
											A(p.AuditGroup, "AuditGroup");
											A(p.Quarter, "DistributedQuarter");
											A(p.ActionYear, "ActionYear");
											A(p.Phase, "PhaseID");
											A(p.FinalReportCategory,
													"FinalReportCategory");
											A(p.FinalReportRating,
													"FinalReportRating");
										},
										onPress : function(e) {
											this._showObject(e.getSource());
										},
										onClick : function(e) {
											var p = e.getParameters().rowBindingContext.sPath;
											var d = p.substring(
													p.indexOf("'") + 1, p
															.lastIndexOf("'"));
											this
													.getRouter()
													.navTo(
															"object",
															{
																objectId : d,
																intentService : this
																		.getOwnerComponent()
																		.getModel(
																				"intentConfig")
																		.getData().service
															});
										},
										onNavBack : function() {
											var p = H.getInstance()
													.getPreviousHash(), c = sap.ushell.Container
													.getService("CrossApplicationNavigation");
											if (p !== undefined
													|| !c.isInitialNavigation()) {
												history.go(-1);
											} else {
												c
														.toExternal({
															target : {
																shellHash : "#Shell-home"
															}
														});
											}
										},
										onMassUpload : function(e) {
											var o = e.getSource();
											if (!this.oAddMenu) {
												this.oAddMenu = sap.ui
														.xmlfragment(
																"menuFrag",
																"sap.grc.acs.aud.audit.fragment.MassUploadAudits",
																this);
												this.getView().addDependent(
														this.oAddMenu);
											}
											var c = this.getDock();
											this.oAddMenu.open(true, o,
													c.BeginTop, c.BeginButtom,
													o);
										},
										getDock : function() {
											return sap.ui.core.Popup.Dock;
										},
										onDownloadTemplate : function() {
											var d = this.getView().getModel();
											var t = "AUD_EXL_UP";
											var h = "00000000-0000-0000-0000-000000000000";
											var p = d.sServiceUrl
													+ "/"
													+ sap.grc.acs.aud.audit.util.constant.ObjectType.UploadTemplateSet
													+ "(Template=" + "\'" + t
													+ "\',Variant=\'" + ""
													+ "\',HostKey=guid\'" + h
													+ "\')/$value";
											window.open(p);
										},
										onUpload : function() {
											if (this.oAdtUploadPopup) {
												this.oAdtUploadPopup.destroy();
											}
											this.oAdtUploadPopup = sap.ui
													.xmlfragment(
															"sap.grc.acs.aud.audit.block.fragment.UploadFileDialog",
															this);
											this.getView().addDependent(
													this.oAdtUploadPopup);
											var c = this;
											delete this.oFileUploader;
											c.oFileUploader = new b(
													{
														read : jQuery
																.proxy(
																		function(
																				e) {
																			c.sFileName = e
																					.getParameter("name");
																			c.sFileType = e
																					.getParameter("type");
																			c.sFileValue = e
																					.getParameter("value");
																		}, c)
													});
											sap.ui.getCore().byId(
													"fileUploader").addContent(
													c.oFileUploader);
											this.oAdtUploadPopup.open();
										},
										_handleConfirmUploadBtnPress : function() {
											if (!this.sFileName) {
												M
														.showMsg(
																"msgTypeFailed",
																this
																		.getView()
																		.getModel(
																				"i18n")
																		.getResourceBundle()
																		.getText(
																				"MSG_CHOOSE_FILE_TO_UPLOAD"));
												return;
											}
											sap.ui.getCore().byId(
													"uploadOKButton")
													.setVisible(false);
											sap.ui.getCore().byId(
													"uploadCancelButton")
													.setVisible(false);
											var l = new sap.m.Label({
												text : this.sFileName
											});
											var s = sap.ui.getCore().byId(
													"fileProgress");
											s.insertContent(l, 0);
											s.setVisible(true);
											this.oFileUploader
													.setVisible(false);
											this.oProgressIndicator = sap.ui
													.getCore()
													.byId(
															"uploadProgressIndicator");
											this.oProgressIndicator
													.setPercentValue(20);
											this.oProgressIndicator
													.setDisplayValue("20%");
											this._uploadAudit(this.sFileName,
													this.sFileType,
													this.sFileValue);
										},
										_uploadAudit : function(n, m, c) {
											var d = this.getView().getModel();
											var p = "/"
													+ sap.grc.acs.aud.audit.util.constant.ObjectType.ImportJobSet;
											var i = {
												Name : n,
												ObjectType : "AUDIT",
												SourceID : "FILE",
												Selections : [],
												TargetID : "DUMMY",
												Type : "S",
												PackageSize : 0
											};
											d.setUseBatch(false);
											this.oAdtUploadPopup.setBusy(true);
											d
													.create(
															p,
															i,
															{
																success : jQuery
																		.proxy(
																				function(
																						D) {
																					d
																							.setUseBatch(true);
																					this.oProgressIndicator
																							.setPercentValue(40);
																					this.oProgressIndicator
																							.setDisplayValue("40%");
																					this
																							._updateFileNode(
																									D.Key,
																									n,
																									m,
																									c);
																				},
																				this),
																error : jQuery
																		.proxy(
																				function() {
																					d
																							.setUseBatch(true);
																					this.oAdtUploadPopup
																							.setBusy(false);
																					this.oAdtUploadPopup
																							.close();
																				},
																				this),
																async : true
															});
										},
										_updateFileNode : function(i, n, m, c) {
											var p = "/"
													+ sap.grc.acs.aud.audit.util.constant.ObjectType.ImportJobSet
													+ "(guid\'" + i + "\')/"
													+ "File";
											var o = this.getView().getModel();
											o.setUseBatch(false);
											o
													.read(
															p,
															{
																success : jQuery
																		.proxy(
																				function(
																						d,
																						r) {
																					this
																							._uploadFileContent(
																									d,
																									r,
																									i,
																									n,
																									m,
																									c);
																				},
																				this),
																error : jQuery
																		.proxy(
																				function() {
																					o
																							.setUseBatch(true);
																					this.oAdtUploadPopup
																							.setBusy(false);
																					this.oAdtUploadPopup
																							.close();
																					M
																							.showMsg(
																									"msgTypeFailed",
																									this
																											.getView()
																											.getModel(
																													"i18n")
																											.getResourceBundle()
																											.getText(
																													"MSG_UPLOAD_AUDIT_FAIL"));
																				},
																				this),
																async : true
															});
										},
										_uploadFileContent : function(d, r, i,
												n, m, c) {
											var o = this.getView().getModel();
											var u = d.__metadata.media_src;
											var h = "x-csrf-", t = "token";
											var s = o.oHeaders[h + t];
											if (!s) {
												o
														.refreshSecurityToken(
																function(e, g) {
																	s = g.headers[h
																			+ t];
																}, function() {
																}, false);
											}
											$
													.ajax({
														type : "put",
														url : u,
														data : c,
														contentType : m,
														beforeSend : function(e) {
															e.setRequestHeader(
																	h + t, s);
														},
														success : jQuery
																.proxy(
																		function() {
																			this
																					._excuteImportJob(
																							i,
																							n,
																							m);
																		}, this),
														error : jQuery
																.proxy(
																		function() {
																			this.oAdtUploadPopup
																					.setBusy(false);
																			this.oAdtUploadPopup
																					.close();
																			o
																					.setUseBatch(true);
																			M
																					.showMsg(
																							"msgTypeFailed",
																							this
																									.getView()
																									.getModel(
																											"i18n")
																									.getResourceBundle()
																									.getText(
																											"MSG_UPLOAD_AUDIT_FAIL"));
																		}, this)
													});
										},
										_excuteImportJob : function(i) {
											var m = this.getView().getModel();
											m
													.callFunction(
															sap.grc.acs.aud.audit.util.constant.FuncImport.ExecuteImportJob,
															{
																method : "POST",
																urlParameters : {
																	JobKey : i
																},
																async : true,
																success : jQuery
																		.proxy(
																				function() {
																					m
																							.setUseBatch(true);
																					this.oProgressIndicator
																							.setPercentValue(100);
																					this.oProgressIndicator
																							.setDisplayValue("100%");
																					this.oAdtUploadPopup
																							.setBusy(false);
																					this.oAdtUploadPopup
																							.close();
																					M
																							.showMsg(
																									"msgTypeSuccessful",
																									this
																											.getView()
																											.getModel(
																													"i18n")
																											.getResourceBundle()
																											.getText(
																													"MSG_UPLOAD_AUDIT_SUCCESS"));
																					m
																							.refresh();
																				},
																				this),
																error : jQuery
																		.proxy(
																				function() {
																					m
																							.setUseBatch(true);
																					this.oAdtUploadPopup
																							.setBusy(false);
																					this.oAdtUploadPopup
																							.close();
																					M
																							.showMsg(
																									"msgTypeFailed",
																									this
																											.getView()
																											.getModel(
																													"i18n")
																											.getResourceBundle()
																											.getText(
																													"MSG_UPLOAD_AUDIT_FAIL"));
																				},
																				this)
															});
										},
										_handleCancelUploadBtnPress : function() {
											this.oAdtUploadPopup.close();
										},
										createAudit : function() {
											this.getRouter().navTo("create");
										},
										onSort : function() {
											this
													._showPersonalizationSections("Sort");
										},
										onFilter : function() {
											this
													._showPersonalizationSections("Filter");
										},
										onGroup : function() {
											this
													._showPersonalizationSections("Group");
										},
										onColumns : function() {
											this
													._showPersonalizationSections("Columns");
										},
										_showPersonalizationSections : function(
												s) {
											var S = this.getView().byId(
													"smartTable");
											S.openPersonalisationDialog(s);
										},
										onShareInJamPress : function() {
											var v = this
													.getModel("worklistView"), s = sap.ui
													.getCore()
													.createComponent(
															{
																name : "sap.collaboration.components.fiori.sharing.dialog",
																settings : {
																	object : {
																		id : location.href,
																		share : v
																				.getProperty("/shareOnJamTitle")
																	}
																}
															});
											s.open();
										},
										onSearch : function(e) {
											if (e.getParameters().refreshButtonPressed) {
												this.onRefresh();
											} else {
												var t = [];
												var q = e.getParameter("query");
												if (q && q.length > 0) {
													t = [ new F("Title",
															a.Contains, q) ];
												}
												this._applySearch(t);
											}
										},
										onRefresh : function() {
											if (this._oTable
													.getBinding("items")) {
												this._oTable
														.getBinding("items")
														.refresh();
											} else {
												this._oTable.getBinding("rows")
														.refresh();
											}
										},
										_showObject : function(i) {
											this
													.getRouter()
													.navTo(
															"object",
															{
																objectId : i
																		.getBindingContext()
																		.getProperty(
																				"DBKey"),
																intentService : this
																		.getOwnerComponent()
																		.getModel(
																				"intentConfig")
																		.getData().service
															});
										},
										_applySearch : function(t) {
											var v = this
													.getModel("worklistView");
											this._oTable.getBinding("items")
													.filter(t, "Application");
											if (t.length !== 0) {
												v
														.setProperty(
																"/tableNoDataText",
																this
																		.getResourceBundle()
																		.getText(
																				"worklistNoDataWithSearchText"));
											}
										},
										formatActualCost : function(A, c) {
											return A + " " + c;
										},
										onExit : function() {
											sap.ui
													.getCore()
													.getEventBus()
													.unsubscribe(
															"sap.grc.acs.aud.audit.EventBus",
															"auditListRefresh",
															this.onRefresh,
															this);
										}
									});
				});
