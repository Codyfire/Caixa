/*
 * Copyright (C) 2009-2020 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([ "sap/uxap/BlockBase" ], function(B) {
	"use strict";
	return B.extend("sap.grc.acs.aud.audit.displayhistorical.extended.block.Lists", {

		metadata : {
			views : {
				Collapsed : {
					viewName : "sap.grc.acs.aud.audit.displayhistorical.extended.block.view.Lists",
					type : "XML"
				}, 
				Expanded : {
					viewName : "sap.grc.acs.aud.audit.displayhistorical.extended.block.view.Lists",
					type : "XML"
				}
			}
		}
		
		
	});
});