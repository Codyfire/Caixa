sap.ui.define([ "sap/ui/core/mvc/Controller",
	"sap/grc/acs/aud/audit/displayhistorical/extended/block/util/listsUtils",
	"sap/grc/acs/aud/audit/displayhistorical/extended/block/util/encodingUtils",
	"sap/grc/acs/aud/audit/displayhistorical/extended/block/model/oDataGeneratorList",
	"sap/grc/acs/aud/audit/displayhistorical/extended/block/util/Enhancements",
], function(Controller,UtilList,Util,Model) {
	"use strict";
	return Controller.extend("sap.grc.acs.aud.audit.displayhistorical.extended.block.controller.AdminListasDetail",{
		onInit: function () {
			console.log("En Adminlist controller");			
		},
		
		onAfterRendering: function() {
			var centrosView = this.oView !== undefined && this.oView.mAggregations !== undefined ? this.oView.mAggregations.content[0].getItems()[0] : undefined ;
			if(this.oView.sId.indexOf('distListView') != - 1 && centrosView !== undefined  )
				setTimeout(function(){ refrescarEstilsTaula(centrosView.byId('treeTableCentros')); }, 1000);
//			setTimeout(function(){ refrescarEstilsTaula(sap.ui.getCore().byId('distListView').centros.table); }, 1000);
		},
		doSave: function(oEvent) {		
			//Inicio PRL 11.10.2021 obtener el controlador  correcto
//			var oController = this;
			var oController = oEvent.getSource().getParent().getParent().oController;
			var view = oController.getView();
			//Fin PRL 11.10.2021
			
			//Agafo els models de dades
//			var oModelPersonas = view.personas.listContainer.getModel();
			var oModelPersonas = view.mAggregations.content[0].mAggregations.items[1].byId('tablePersonas').getModel();
			//Nos han insertado los campos obligatorios
			var listaPersonas = [];
			if(oModelPersonas.getData().results != undefined){
				if(oModelPersonas.getData().results.length > 0){
					$.each(oModelPersonas.getData().results,function(i,n){

						listaPersonas.push({UserId: n.UserId});
					});
				}
			} else {
				listaPersonas = [{}];
			}
			
			/*$.each(sap.ui.getCore().byId("personasView").listContainer.getItems(),function(i,n){
				var bindingContext = n.getBindingContext().sPath;
				var item = sap.ui.getCore().byId("personasView").listContainer.getModel().getProperty(bindingContext);
				listaPersonas.push({UserId: item.Id});
			});*/
			
			
			//Cojo el modelo de datos
//			var oModelDelegados = view.delegados.listContainer.getModel();
			var oModelDelegados = view.mAggregations.content[0].mAggregations.items[2].byId('tableDelegados').getModel();
			//Nos han insertado los campos obligatorios
			var listaDelegados = [];
			if(oModelDelegados) {
//				if(oModelDelegados.getData().results != undefined){
				if(oModelDelegados.getData() !== null && oModelDelegados.getData().results != undefined){
					if(oModelDelegados.getData().results.length > 0){
						$.each(oModelDelegados.getData().results,function(i,n){
							if(n.DelegadoDel === undefined) n.DelegadoDel = false;
							listaDelegados.push({Key: n.Key, UserId: n.UserId, UserDelegado: true, DelegadoDel: JSON.parse(n.DelegadoDel)});
						});
					}
				} else {
					listaDelegados = [{}];
				}
			} else {
				listaDelegados = [{}];
			}
			
			
			var listaCentros = [];
			//if(view.centros.table.getModel().getData().centros) {
			/**
			if(view.mAggregations.content[0].mAggregations.items[0].byId('treeTableCentros').getModel().getData().centros) {
				var oModelCentros = aplanarJerarquia(view.centros.table.getModel().getData().centros);
				*/
			var oTabCentros = view.mAggregations.content[0].mAggregations.items[0].byId('treeTableCentros');
			if(oTabCentros.getModel().getData().centros) {
				var oModelCentros = aplanarJerarquia(oTabCentros.getModel().getData().centros);
				if(oModelCentros.getData().centros != undefined){
					if(oModelCentros.getData().centros.length > 0){
						$.each(oModelCentros.getData().centros,function(i,n){
							listaCentros.push({Company: n.Company, Department: n.Department, FirstNode: transformStringToBool(n.FirstNode),DelUserResp1: transformStringToBool(n.DelUserResp1), DelUserResp2: transformStringToBool(n.DelUserResp2)})
						});
					}
				}
			} else {
				listaCentros = [{}];
			}
			
			//Creamos la entidad lista que passaremos por parametro
			var oLista = {};
//			oLista.Key = recoverKey(sap.ui.getCore().getModel("con").oData.currAudit);
			
			var that = this;
			this.getOwnerComponent().mAggregations.rootControl.mAggregations.content[0].mAggregations.pages.forEach(function(e,i,a){
			if(e.sId.indexOf('object') !== -1)
		   oLista.Key = recoverKey(e.getBindingContext().getObject().DBKey);    
		});
		

			oLista.InfoUsersDeep = listaPersonas.length > 0 ? listaPersonas : [{}];
			oLista.InfoDelegatesDeep = listaDelegados.length > 0 ? listaDelegados : [{}];
			oLista.InfoDepatmentsDeep = listaCentros.length > 0 ? listaCentros : [{}];;
			
			/**
			var url = "";
			if(view.getId() == "accListView") {
				url = "/InfoAuditAccListDeepSet";
			} else if (view.getId() == "distListView") {
				url = "/InfoAuditListDeepSet";
			}*/
			var url = "";
			if (view.getId().indexOf("accListView") !== -1 ) {
				url = "/InfoAuditAccListDeepSet";
			} else if (view.getId().indexOf("distListView") !== -1 ){
				url = "/InfoAuditListDeepSet";
			}
			
			if(url) {
				sap.ui.getCore().getModel("con").refreshSecurityToken();
				sap.ui.getCore().getModel("con").create(url,oLista,{async: false, success: success.bind({viewId: view.getId()}), error: error });

				function success(oData, oDataRes){
					sap.m.MessageToast.show("Datos guardados corretamente!", {duration: 800});
					//Inicio PRL 11.10.2021 obtener el controlador  correcto
//					var oController = view.getParent().getParent().getParent().getController().grcaudController
					var oController = view.getParent().getParent().getParent().getController();
					//Fin PRL 11.10.2021
					//if(this.viewId == "accListView") {
						if (view.getId().indexOf("accListView") !== -1 ) {
						oController._getAccList(oController);
//					} else if (this.viewId == "distListView") {
				    } else if (view.getId().indexOf("distListView") !== -1 ){
						oController._getDistList(oController);
					}
				}

				function error(error) {
//					sap.m.MessageToast.show("Error al guardar!", {duration: 800});
				}
			}
		},
		doBackToList: function() {
			
			var viewContainer = sap.ui.getCore().byId("adminListasCont");
			
			if(viewContainer.getPage("adminListasDetail"))
			{
				viewContainer.getPage('adminListasDetail').destroy();
			}
			
			viewContainer.to("adminListas");

		},
		
		
//Fin PRL 04.06.2021	
})
})