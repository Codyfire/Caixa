/*
 * Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(
 [
  "sap/grc/acs/aud/finding/controller/BaseController",
  "sap/grc/acs/lib/aud/utils/MenuItemUtils",
  "sap/grc/acs/lib/aud/utils/ComponentUtil",
  "sap/grc/acs/lib/aud/utils/MessageUtil",
  "sap/grc/acs/aud/audit/displayhistorical/extended/block/util/encodingUtils"
 ],
 function(BaseController, MenuItemUtils, ComponentUtil, MessageUtil, Util) {
  "use strict";

  return BaseController.extend("sap.grc.acs.aud.audit.displayhistorical.extended.block.controller.Encuestas", { 
	  
	  
	  onInit: function() {
		  
		  // INI IRC 16/11/2022 Generamos todos los componentes de la vista en variables del controlador para evitar errores en los routing con publish/subscribe
		  // Inicializamos variables
		  this.tableEncuestas = this.getView().byId("tableEncuestas");
		  this.dbKey = this.getView().byId("dbKey");
		  this.textAreaNAA = this.getView().byId("textAreaNAA");
		  this.chk_NaEncuestasTextArea = this.getView().byId("chk_NaEncuestasTextArea");
		  this.btn_NaSave = this.getView().byId("btn_NaSave");
		  this.btn_NaDel = this.getView().byId("btn_NaDel");
		  this.chk_NaEncuestas = this.getView().byId("chk_NaEncuestas");
		  this.btn_addEncuestas = this.getView().byId("btn_addEncuestas");	
		  this.btn_SaveEncuestas = this.getView().byId("btn_SaveEncuestas");
		  // FIN IRC 16/11/2022
		  
		  this._Component = ComponentUtil.getComponentById(this.getView().getId());
		  this.modelEncuestas = this._Component.getModel("MyEncuestas");
		  this.tableEncuestas.setModel(this.modelEncuestas,"encuestas");
		  
		  this.tableContentModel = new sap.ui.model.json.JSONModel();
		  this.sModelData = {
				  EncuestasData: [],
		  	};
		  this.tableContentModel.setData(this.sModelData);
		  
		// Carga de datos necesarios
		  //this.getData();
		  
		  sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.audit.EventBus","getDataEncuestas_audhist", this.initialize, this);
		  this.initialize(this);
	  },
	  
	  initialize: function(oController) {
			
			//Inicio PRL 16.09.2021: Solo informamos el objectBinding si se ha cargado el contexto
			var that = this;
			if(this.getOwnerComponent()){
			this.getOwnerComponent().mAggregations.rootControl.mAggregations.content[0].mAggregations.pages.forEach(function(e,i,a){
				if(e.sId.indexOf('object') !== -1){
				var binding = e.getBindingContext();				
				if(binding != undefined){
					that.objectBinding = e.getBindingContext().getObject();
				}	
			//Fin PRL 16.09.2021		
          }
			})};
			this.grcaudController = oController;  
			
			// Fetching Distribution List
			this.getData();
			//sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.audit.EventBus","getInTeamLists", this._checkEnabledTeamAdd, this);
			
		},
	  
	  getData: function() {
		//Carga de la tabla principal
		  this.getDataFromOdata();
		  
		//Carga de la encuesta
		  this.getDataNA();
		  
		//Visibilidad de Botones
		  //this.onVisiblidadBotones();
	  },
	  
	  //VISIBLIDAD DE CAMPOS
	  onNA_Encuestas: function(oEvent){
		  
		  if(oEvent === "") this.tableEncuestas.setVisible(false);

		  if(this.tableEncuestas.getVisible() === true || oEvent === "activoNA")
		  {
			  this.textAreaNAA.setVisible(true);
			  this.chk_NaEncuestasTextArea.setEnabled(false);
			  this.chk_NaEncuestasTextArea.setVisible(true);
			  this.chk_NaEncuestasTextArea.setSelected(true);
			  
			  this.tableEncuestas.setVisible(false);
			  this.chk_NaEncuestas.setVisible(false);
			  this.chk_NaEncuestas.setEnabled(false);
		  }
		  else
		  {
			  this.textAreaNAA.setVisible(false);
			  this.chk_NaEncuestasTextArea.setVisible(false);
			  
			  this.tableEncuestas.setVisible(true);
			  this.chk_NaEncuestas.setVisible(true);
			  this.chk_NaEncuestas.setEnabled(false);
		  }
			  
	  },

	//FUNCIÓN DE REFRESCO DE DATOS LA TABLA PRINCIPAL
		getDataFromOdata:function(){
			
			var that = this;
			var oData = {},
				aBatchOperations = [];										
			
			var sauditKey = sap.ui.getCore().getModel("auditKeyModel").getData().id
			var url = "/GRCAUD_CV_Audit(guid'"+sauditKey+"')/to_Survey";
			
			//Realizar llamada al back para obtener el listado de encuestas
			var encuestasModel = new sap.ui.model.odata.v2.ODataModel(
					"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
				);
			
			encuestasModel.read(url, {
				success: function (data, response) {
					data.results.sort((a,b) =>b.crea_date_time - a.crea_date_time);
					if(that.tableEncuestas){
					that.tableEncuestas.removeSelections();
				}
				
						if(that.modelEncuestas) {
							that.modelEncuestas.setData(data.results);
							that.tableEncuestas.setModel(that.modelEncuestas,"encuestas");
							that.modelEncuestas.refresh();
						}
						that.editData = [];
						var modelTitleEncuestas = {};
						that.editData = [];														      			      		
		      			modelTitleEncuestas.title = that.getOwnerComponent().getModel("i18n").getResourceBundle().getText("encuestasSectionTitle");
	 					that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(modelTitleEncuestas), "encuestasTitle");
		      			that.getOwnerComponent().getModel("encuestasTitle").refresh();
		      			that.tableEncuestas.setBusy(false);
		      			
		      			//Volvemos a revisar la visibilidad de los botones e integrantes de la tabla
		      			//that.onVisiblidadBotones();
						
				},
				failed: function (oData, response) {
					alert("Failed to get InputHelpValues from service!");
				},
			});
		},
		
		//FUNCIÓN DE REFRESCO DE DATOS ZONA COMENTARIOS
		getDataNA: function()
		{
			var that = this;
			var oData = {},
				aBatchOperations = [];										
			
			var sauditKey = sap.ui.getCore().getModel("auditKeyModel").getData().id
			var url = "/GRCAUD_CV_Audit(guid'"+sauditKey+"')/to_SurveyNote";
			
			//Realizar llamada al back para obtener el listado de encuestas
			var encuestasModel = new sap.ui.model.odata.v2.ODataModel(
					"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
				);
			
			encuestasModel.read(url, {
				success: function (data, response) {
					if(data.results[0])
					{
						that.textAreaNAA.setValue(data.results[0].Text);
						that.dbKey.setText(data.results[0].DBKey);
					}else
					{
						that.textAreaNAA.setValue("");
					}
		
					/*if(data.results[0] && data.results[0].Text !== "")
					{
						that.onNA_Encuestas("activoNA");
					}*/
					let activo = (data.results[0] && data.results[0].Text !== "") ? "activoNA" : "";
					that.onNA_Encuestas(activo);
				}
			})
		},
		//FUNCION DE VISIBILIDAD PARA LOS BOTONES
		onVisiblidadBotones: function(){
			var itemsTabla = this.tableEncuestas.getItems();
			var createEnabled,deleteEnabled;
			var that = this;
			var dbKey = sap.ui.getCore().getModel("auditKeyModel").getData().id;
			//var sPath = "/GRCAUD_CV_ApproveAuditReport(guid'"+dbKey+"')/to_MenuItems";
			var sPath = "/GRCAUD_CV_ApproveAuditReport(guid'"+dbKey+"')/to_MenuItems";
			this.getOwnerComponent().getModel().read(sPath, {
			success: function (data, response) {
		
					var elements = []; 
					elements = data.results.filter( item => item.SectionID == 'SURVEY');
					
					if (elements !== undefined & elements.length > 0) {
						Array.prototype.forEach.call(elements, item=>{
							if(item.Action === 'CRE_USER_SURVEY_TO_AUDIT_ASMNT'){
								
									createEnabled = item.Enable;																
								
							}else if(item.Action === 'DEL_USER_SURVEY_TO_AUDIT_ASMNT'){
								deleteEnabled = item.Enable;
							}													
						});													
					}
					
					if(that.btn_addEncuestas){					
						if( createEnabled == "X"){
							that.btn_addEncuestas.setVisible(true);
							that.btn_addEncuestas.setEnabled(true);
							that.btn_SaveEncuestas.setVisible(true);
							that.btn_SaveEncuestas.setEnabled(true);
						}else{
							that.btn_addEncuestas.setVisible(false);
							that.btn_addEncuestas.setEnabled(false);
							that.btn_SaveEncuestas.setVisible(false);
							that.btn_SaveEncuestas.setEnabled(false);
							that.textAreaNAA.setEnabled(false);
							that.btn_NaSave.setEnabled(false);
							that.btn_NaDel.setEnabled(false);
							that.chk_NaEncuestasTextArea.setEnabled(false);
							that.chk_NaEncuestas.setEnabled(false);
							for(var i = 0; i < that.tableEncuestas.getItems().length; i++)
							{
								if(that.tableEncuestas.getItems()[i] && that.tableEncuestas.getItems()[i] !== undefined)
								{
									that.tableEncuestas.getItems()[i].getCells()[3].setEnabled(false);
								}
							}
						};
						
						//Como no se realizan cambios no exite la columna Encuestas Del
						/*if( deleteEnabled == "X"){
							that.getView().byId("colEncuestasDel").setVisible(true);
						}else{
							that.getView().byId("colEncuestasDel").setVisible(false);
						};*/
					};

				},
				failed: function (oData, response) {
					that.tableEncuestas.setBusy(false)
				}
		
			});
		}
  
  });
  })