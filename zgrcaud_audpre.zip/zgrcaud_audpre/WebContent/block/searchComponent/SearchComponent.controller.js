sap.ui.controller("sap.grc.acs.aud.audit.prepare.extended.block.searchComponent.SearchComponent", {
	
	setupInicial: function(columns, cells, listMode, bindAggregation, path, oModel, addFunct, addSearchFunct) {
		this.setListMode(listMode);
		this.addModel(oModel);
		this.setAddFunction(addFunct); 
		this.setSerchFunction(addSearchFunct);
	},
	// Se indica el modo de selecci�n de la tabla
	setListMode: function(mode) {
		var listContainer = this.getView().byId("searchResults");	
		listContainer.setMode(mode);
	},
	

	addModel: function(oModel) {
		var listContainer = this.getView().byId("searchResults");
		listContainer.setModel(sap.ui.getCore().getModel(oModel));   
	},
	
	setAddFunction: function( funct ) {	
		var addBtn = this.getView().byId("addBtn");
		addBtn.attachPress( funct );
	},
	
	setSerchFunction: function(funct){
		var oSearchField = this.getView().byId("searchField");
		oSearchField.attachSearch(funct);
	},
	
//Funcion de cierre
	onCancel: function( ){
	var dialog = this.getView().byId("popup");
	dialog.close( );	
	}
});