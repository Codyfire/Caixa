/*
 * Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(["sap/uxap/BlockBase"],
 function (BlockBase) {
  "use strict";

  return BlockBase.extend("sap.grc.acs.aud.action.display.extended.block.Limitations", {
   metadata: {
    views: {
     Collapsed: {
      viewName: "sap.grc.acs.aud.action.display.extended.block.view.Limitations",

      type: "XML"
     },
     Expanded: {
      viewName: "sap.grc.acs.aud.action.display.extended.block.view.Limitations",

      type: "XML"
     }
    }
   }
  });

 });