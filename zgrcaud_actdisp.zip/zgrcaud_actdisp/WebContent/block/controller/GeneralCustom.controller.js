/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(
 [
  "sap/ui/core/mvc/Controller",
  "sap/grc/acs/aud/action/model/formatter",
  "sap/grc/acs/lib/aud/extension/utils/FieldExtensibilityUtil",
  "sap/grc/acs/lib/aud/userRole/utils/UserRoleFieldUtil",
  "sap/grc/acs/lib/aud/utils/ComponentUtil",
  "sap/grc/acs/lib/aud/utils/MessageUtil"
 ],
 function(Controller, formatter, FieldExtensibilityUtil, UserRoleFieldUtil, ComponentUtil, MessageUtil) {
  "use strict";

  return Controller.extend("sap.grc.acs.aud.action.display.extended.block.controller.GeneralCustom", {
   formatter: formatter,

   onInit: function() {
    this.oActionDataInServer = {};
    this.aUsersInBackendList = [];
    this.aUsersNewList = [];
    this._oComponent = ComponentUtil.getComponentById(this.getView().getId());
    this._oComponent.getModel().metadataLoaded().then(function() {
     this._createExtensionGroup();
    }.bind(this));
    if(this._oComponent.getModel("intentConfig").getData().intent === "Action-myAction"
     || this._oComponent.getModel("intentConfig").getData().intent === "Action-displayActionByMyFinding"
     || this._oComponent.getModel("intentConfig").getData().intent === "Action-trackActionByMyFinding"
     || this._oComponent.getModel("intentConfig").getData().intent === "Action-updateActionByMyFinding"){
     this._bDisplayMode = true; 
     this.getView().byId("auditIdTitle").attachInnerControlsCreated(this.setAuditAttributeValue, this);
    }
    else{
     this.getView().byId("auditIdTitle").attachPress(this.handleAuditAttributePress, this);
    }
    this.aDropDownGroupIndex = [];
    this.aDropDownEdit = [];
    sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.action.EventBus", "userRoleModelDataUpdateFinished", this._createActionUserRoleFields,
     this);
    sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.action.EventBus", "resetBlockToDisplayMode", this.onRefresh, this);
    sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.action.EventBus", "extensionModelDataUpdateFinished", this.setHeaderToolBarVisibility, this);
   },

   _createExtensionGroup: function() {
    var oExtensionGroup = this.getView().byId("extensionGroup");
    FieldExtensibilityUtil.createExtensionGroup("Action", oExtensionGroup, this._oComponent);
   },

   setValueHelpFieldsEditable: function() {
    var oExtensionGroup = this.getView().byId("extensionGroup");
    var oExtensionModelData = this.getView().getModel("extensionModel").getData();
    this.aDropDownGroupIndex = [];
    FieldExtensibilityUtil.setValueHelpFieldsEditable(oExtensionGroup,oExtensionModelData,this.aDropDownGroupIndex,this.aDropDownEdit);
   },

   _createActionUserRoleFields: function(){
    var oSmartForm = this.getView().byId("smartForm");
    var oGroup = this.getView().byId("basicDataGroup");
    if(this.getView().getBindingContext()){
     var sPath = this.getView().getBindingContext().getPath();
     UserRoleFieldUtil.createDisplayUserRoleFields(sPath, oGroup, this._oComponent, 3, oSmartForm, null);
    }
   },

   setDropDownFieldsEditableToFalse: function() {
    for (var i = 0; i < this.aDropDownGroupIndex.length; i++) {
     this.getView().byId("extensionGroup").removeGroupElement(this.getView().byId("extensionGroup").getGroupElements()[this.aDropDownGroupIndex[
      i].index]);
     this.getView().byId("extensionGroup").insertGroupElement(this.aDropDownGroupIndex[i].element, this.aDropDownGroupIndex[i].index);
    }

   },

   openBusinessCard: function(oEvent) {
    if (this._oPersonQuickView) {
     this._oPersonQuickView.destroy();
    }
    var oControl = oEvent.getSource();
    var oBusinessCard = sap.ui.xmlfragment("sap.grc.acs.lib.aud.person.quickView", this);
    this._oPersonQuickView = oBusinessCard;
    oBusinessCard.attachAfterClose(function() {
     oBusinessCard.destroy();
    });
    oControl.addDependent(oBusinessCard);
    jQuery.sap.delayedCall(0, this, function() {
     this._oPersonQuickView.openBy(oControl);
    });
   },

   setSmartFormToDisplayMode: function() {
    if (this.getView().getModel("extensionModel").getData().Responsible.editable) {
     this._createActionUserRoleFields();
    }
    this.setDropDownFieldsEditableToFalse();
    this._setButtonVisibility("DISPLAY");
    this.getView().byId("smartForm").setEditable(false);
    var oExtensionGroup = this.getView().byId("extensionGroup");
    var oExtensionModelData = this.getView().getModel("extensionModel").getData();
    FieldExtensibilityUtil.setCdfNonSmartFieldsStatus(oExtensionGroup, oExtensionModelData,"display");
   },

   _saveGeneralData: function(oEvent) {
    this.aUsersInBackendList = [];
    this.aUsersNewList = [];
    var oDataModel = this.getView().getModel();
    this.oUpdateDataModel = this.getView().getModel();
    var oData = {};
    var oSmartForm = this.getView().byId("smartForm");
    var oExtensionModelData = this.getView().getModel("extensionModel").getData();
    var oController = this;

    var sActionKey = this.getView().getBindingContext().getProperty("DBKey");
    var sPath = this.getView().getBindingContext().getPath();
    var bHaveUserRoleChanges = false;
    var bHaveGeneralInfoChanges = false;

    var sGroupId = "saveAction";

    this.oUpdateDataModel.setDeferredGroups(this.oUpdateDataModel.getDeferredGroups().concat([sGroupId]));

    if (this.getView().getModel("extensionModel").getData().Responsible.editable) {
     var oGroup = this.getView().byId("basicDataGroup");
     bHaveUserRoleChanges = UserRoleFieldUtil.prepareBatchOperation(sPath, sActionKey, oGroup, this._oComponent, sGroupId, null);
    } 

    oData = FieldExtensibilityUtil.saveSmartForm(oSmartForm, oExtensionModelData);
    var oSaveData = this._compareData(this.oActionDataInServer,oData);
    if(!jQuery.isEmptyObject(oSaveData)){
     bHaveGeneralInfoChanges = true;
     this.oUpdateDataModel.update(sPath, oData, {
      groupId: sGroupId,
      refreshAfterChange: false
     });
//PRL 31.08 Si guardamos en estado diferente a finalizado, limpiamos la fecha    
     if(oSaveData.zz_act_status !== undefined){
    	 if(oSaveData.zz_act_status !== "02"){
        	 oSmartForm.getSmartFields()[14].setValue("");
         }
//Si no se modifica el status, usamos el actual para comprobar la fecha    	 
     } else if(this.oActionDataInServer.zz_act_status !=="02"){
    	 oSmartForm.getSmartFields()[14].setValue(""); 
    	 }
    }
//PRL 31.08
    if(bHaveGeneralInfoChanges || bHaveUserRoleChanges){
     this.oUpdateDataModel.submitChanges({
      groupId: sGroupId,
      success: jQuery.proxy(function(oResponseData/* , oResponse*/) {
         if(oResponseData.__batchResponses[0].message){
          if(oResponseData.__batchResponses[0].response.statusCode === "412"){
           MessageUtil.showODataErrorMsg(oResponseData.__batchResponses[0].response, 
            this.getView().getModel("i18n").getResourceBundle().getText("msgEtagCheckFail"));
          }
          return;
         }else{        
          oDataModel.setUseBatch(false);
          oDataModel.refresh();
          oDataModel.setUseBatch(true);
          oController.oUpdateDataModel.setDeferredGroups(["changes"]); 
          MessageUtil.showMsg("msgTypeSuccessful", this.getView().getModel("i18n").getResourceBundle().getText("EDIT_ACTION_SUCCESS"));
          oController.setSmartFormToDisplayMode();
         }
        }, this),
      error:  jQuery.proxy(function(oError){
         MessageUtil.showODataErrorMsg(oError, this.getView().getModel("i18n").getResourceBundle().getText(
             "EDIT_ACTION_FAIL"));
         oController.oUpdateDataModel.setDeferredGroups(["changes"]); 
        }, this)
     });
    }
    else {
     oController.setSmartFormToDisplayMode();
    }
   },

   resetFormFieldValueState:function(){
    var aErrorField = this.getView().byId("smartForm").check();
    for(var i = 0 ; i < aErrorField.length ; i++){
     sap.ui.getCore().byId(aErrorField[i]).setValueState(sap.ui.core.ValueState.None);
    }
   },

   _compareData:function(oOldData, oNewData){
    var oReturnData = {};
    var sNew, sOld;
    for(var oField in oNewData){
     sNew = oNewData[oField];
     sOld = oOldData[oField];
     if(oNewData[oField] && oOldData[oField] && typeof oNewData[oField] === "object" && typeof oOldData[oField] === "object"
      && oNewData[oField].toISOString() && oOldData[oField].toISOString()){
      //Both are Time
      sNew = oNewData[oField].toISOString().substring(0,19);
      sOld = oOldData[oField].toISOString().substring(0,19);
     }else if(oOldData[oField] && typeof oNewData[oField] !== "object" && typeof oOldData[oField] === "object" && oOldData[oField].toISOString()){
      sOld = oOldData[oField].toISOString().substring(0,19);                 
     }else if(oNewData[oField] && typeof oNewData[oField] === "object" && typeof oOldData[oField] !== "object" && oNewData[oField].toISOString()){
      sNew = oNewData[oField].toISOString().substring(0,19);
     }
     if(sNew !== sOld){
      oReturnData[oField] = oNewData[oField];
     }
    }
    return oReturnData;
   },

   formatDeadLine: function(sTimeStamp) {
    var oDateFormatter = sap.ui.core.format.DateFormat
     .getDateTimeInstance({
      pattern: "yyyy.MM.dd"
     });
    sTimeStamp = oDateFormatter.format(new Date(sTimeStamp));
    return sTimeStamp;
   },

   _formatInfo: function(sID, sTitle) {
    return sID + "\t" + sTitle;
   },

   handleAuditAttributePress: function(oEvent) {
    var sAuditKey = this.getView().getBindingContext().getObject().AuditKey;
    var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
    var args = {
     target: {
      semanticObject: "AuditEngagement",
      action: "display"
     },
     params: {
      "DBKey": sAuditKey
     }
    };
    var shref = oCrossAppNavigator.hrefForExternal(args);
    window.open(shref,"_self");
   },

   setAuditAttributeValue: function(oEvent){
    var oAuditField = this.getView().byId("auditIdTitle");
    if (oAuditField.getInnerControls() && oAuditField.getInnerControls()[0]) {
     oAuditField.getInnerControls()[0].setText(oAuditField.getValue());
    }
   },

   handleFindingAttributePress: function(oEvent) {
    var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
    var args = {
     target: {
      semanticObject: "Finding",
      action: "displayAuditFollowUp"
     },
     params: {
      "DBKey": this.getView().getBindingContext().getObject().FindingKey
     }
    };
    if(this._oComponent.getModel("intentConfig").getData().intent === "Action-myAction"){
     args.target.action = "displayFindingByMyAction";
    }
    else if(this._oComponent.getModel("intentConfig").getData().intent === "Action-displayActionByMyFinding"
     || this._oComponent.getModel("intentConfig").getData().intent === "Action-trackActionByMyFinding"
     || this._oComponent.getModel("intentConfig").getData().intent === "Action-updateActionByMyFinding"){
     args.target.action = "myFinding";
    }
    else if(this._oComponent.getModel("intentConfig").getData().intent === "Action-execute"){
     args.target.action = "execute";
    }
    else if(this._oComponent.getModel("intentConfig").getData().intent === "Action-display"){
     args.target.action = "display";
    }
    else{
     args.target.action = "displayAuditFollowUp";
    }
    var shref = oCrossAppNavigator.hrefForExternal(args);
    window.open(shref,"_self");
   },

   _setButtonVisibility: function(sMode) {
    if (sMode === "EDIT") {
     this.getView().byId("btnEdit").setVisible(false);
     this.getView().byId("btnSave").setVisible(true);
     this.getView().byId("btnCancel").setVisible(true);
    } else if (sMode === "DISPLAY") {
     this.getView().byId("btnEdit").setVisible(true);
     this.getView().byId("btnSave").setVisible(false);
     this.getView().byId("btnCancel").setVisible(false);
    } else {
     this.getView().byId("btnEdit").setVisible(false);
     this.getView().byId("btnSave").setVisible(false);
     this.getView().byId("btnCancel").setVisible(false);
    }
   },

   onRefresh: function() {
    this.onCancelBtnPress();
   },

   setHeaderToolBarVisibility: function() {
    if (this.getView().getModel("extensionModel").getData().SmartForm.editable) {
     this.getView().byId("smartFormToolbar").setVisible(true);
    }
    if (this._bDisplayMode) {
     this.getView().getModel().resetChanges();
     this.setAuditAttributeValue();
    }
   },

   onCancelBtnPress: function(oEvent) {
    this.getView().byId("smartForm").setEditable(false);
    if(this.getView().byId("smartForm").getEditable() === false) {
     if (!this._bDisplayMode) {
      this.getView().getModel().resetChanges();
     }
     this.setDropDownFieldsEditableToFalse();
     // this.getView().byId("labelResponsible").setRequired(false);
     if (this.getView().getModel("extensionModel").getData().Responsible.editable) {
      this._createActionUserRoleFields();
     }
     this._setButtonVisibility("DISPLAY");
     var oExtensionGroup = this.getView().byId("extensionGroup");
     var oExtensionModelData = this.getView().getModel("extensionModel").getData();
     FieldExtensibilityUtil.setCdfNonSmartFieldsStatus(oExtensionGroup, oExtensionModelData,"display");
    }
   },

   onSaveBtnPress: function(oEvent) {
    // var bIsActionResponsibleRequired = false;
    // bIsActionResponsibleRequired = this._checkActionResponsibleField();
    var bIsRequiredCdfNonSmartField =  this._checkRequiredCdfNonSmartField();
    var oGroup = this.getView().byId("basicDataGroup");
    if(this.getView().getModel("extensionModel").getData().Responsible.editable){
     if( !UserRoleFieldUtil.validateUserFieldInput(oGroup) ){
      return;
     }
    }
    if( this.getView().byId("smartForm").check().length > 0 || bIsRequiredCdfNonSmartField) {
     MessageUtil.showMsg("msgTypeFailed", this.getView().getModel("i18n").getResourceBundle().getText("MSG_CORRECT_HIGHLIGHTED_FIELDS"));
     return;
    }
    //Save action
    this._saveGeneralData(oEvent);
   },

   _checkRequiredCdfNonSmartField: function(){
    var bIsFieldRequired = false;
    var oExtensionGroup = this.getView().byId("extensionGroup");
    var oGroupElements = oExtensionGroup.getGroupElements();
    for(var k = 0;k<oGroupElements.length;k++){
     for(var j=0; j<oGroupElements[k].getFields().length;j++){
      for (var i = 0; i < oGroupElements[k].getFields()[j].getCustomData().length; i++) {
       if ( oGroupElements[k].getFields()[j].getCustomData()[i].getKey() === "richText"){
        if(oGroupElements[k].getFields()[j].getRequired()
        && oGroupElements[k].getFields()[j].getEditable()){
        if(  oGroupElements[k].getFields()[j].getValue() === "") {
         bIsFieldRequired = true;
        }
        }
       }
      }
     }
    }
    // if(bIsFieldRequired){
    //  oRichTextAreaControl.setValueState(sap.ui.core.ValueState.Error);
    // }
    // else{
    //  oRichTextAreaControl.setValueState(sap.ui.core.ValueState.None);
    // }
    return bIsFieldRequired;
   },

   onEditFormPress: function(oEvent) {
    this._setButtonVisibility("EDIT");
    this.getView().byId("smartForm").setEditable(true);
    this.oActionDataInServer = this.getView().getBindingContext().getObject();
    if (this.getView().getModel("extensionModel").getData().Responsible.editable) {
     var sActionKey = this.getView().getBindingContext().getProperty("DBKey");
     var oGroup = this.getView().byId("basicDataGroup");
     var sPath = this.getView().getBindingContext().getPath();
     UserRoleFieldUtil.createEditUserRoleFields(sPath, sActionKey, oGroup, this._oComponent, null);
    }
    this.setValueHelpFieldsEditable();
    this.resetFormFieldValueState();
    var oExtensionGroup = this.getView().byId("extensionGroup");
    var oExtensionModelData = this.getView().getModel("extensionModel").getData();
    FieldExtensibilityUtil.setCdfNonSmartFieldsStatus(oExtensionGroup, oExtensionModelData,"editable");
   },

   onExit: function() {
    var oBasicGroup = this.getView().byId("basicDataGroup");
    UserRoleFieldUtil.destroyFields(oBasicGroup);
    FieldExtensibilityUtil.destoryElements(this.aDropDownEdit);
    sap.ui.getCore().getEventBus().unsubscribe("sap.grc.acs.aud.action.EventBus", "userRoleModelDataUpdateFinished", this._createActionUserRoleFields, this);
    sap.ui.getCore().getEventBus().unsubscribe("sap.grc.acs.aud.action.EventBus", "resetBlockToDisplayMode", this.onRefresh, this);
    sap.ui.getCore().getEventBus().unsubscribe("sap.grc.acs.aud.action.EventBus", "extensionModelDataUpdateFinished", this.setHeaderToolBarVisibility, this);
   }

  });
 }

);
