/*
 * Copyright (C) 2009-2022 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(
 [
  "sap/grc/acs/aud/action/controller/BaseController",
  "sap/grc/acs/lib/aud/utils/ComponentUtil",
  "sap/grc/acs/lib/aud/utils/MenuItemUtils",
  "sap/grc/acs/lib/aud/utils/MessageUtil"
 ],
 function(BaseController, ComponentUtil, MenuItemUtils, MessageUtil) {
  "use strict";

  return BaseController.extend("sap.grc.acs.aud.action.display.extended.block.controller.Limitations", {

   onInit: function() {
	   
    this._Component = ComponentUtil.getComponentById(this.getView().getId());
    this.modelLimitations = this._Component.getModel("MyLimitations");
	this.getView().byId("tableLimitations").setModel(this.modelLimitations,"limitations");
    
    sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.find.EventBus", "resetBlockToDisplayMode", this.onRefresh, this);
    
    //Llamada de carga de datos de la tabla principal
    this.getDataFromOdata();
   },

   onExit: function() {
    sap.ui.getCore().getEventBus().unsubscribe("sap.grc.acs.aud.find.EventBus", "resetBlockToDisplayMode", this.onRefresh, this);
   },
   
   //FUNCION DE AÑADIR TEXTO EN LA TABLA PRINCIPAL
   Limitations_ADD: function(){

	   var that = this;
	   
	   //Valor introducidot
	   var inputLimitations = this.getView().byId("inputLimitations").getValue();
	   this.limitationKey = this.getView().getBindingContext().getObject().DBKey;
	   
	 //Realizar llamada al back para obtener el listado de findinds relacionados
		var limitationsModel = new sap.ui.model.odata.v2.ODataModel(
				"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
			);
		
		var Objecto = [];
		var aux = {};
		aux.db_key = this.limitationKey;
		aux.parent_key = this.limitationKey;
		aux.limitation = inputLimitations;
		Objecto.push(aux);
		
		//Vaciamos el input de limitaciones
		this.getView().byId("inputLimitations").setValue("");
		
		//Comprobamos que el input está relleno para no meter valores vacios
		if(inputLimitations !== "")
		{
			limitationsModel.create("/ZGRCAUD_CV_LIMIT", aux, {
				async: true,
				success : function (oData) {
					//Refrescamos tabla principal de Limitaciones
					that.getDataFromOdata();
		       }.bind(this),
		       error: function (oError) {

		    	   
		    	   //Refrescamos tabla principal de Limitaciones
		    	   that.getDataFromOdata();
		       }.bind(this)
			});	
		}
	   
   },
   
   //FUNCIÓN DE EDICIÓN DE LOS TEXTO DE LA TABLA PRINCIPAL
   Limitations_EDIT: function(oEvent){
	   var aSelectedItems = this.getView().byId("tableLimitations").getSelectedItems();
	   
	   if(aSelectedItems.length === 0)
	   {
		   return;
	   }
	   else
	   {
		   this.getView().byId("btn_EditLimitations").setVisible(false);
		   this.getView().byId("btn_SaveLimitations").setVisible(true);
		   
		   for(var i = 0; i < aSelectedItems.length; i++)
		   {
			  aSelectedItems[i].getCells()[0].setEditable(true);
		   } 
	   }
	   
	   
   },
   	
   //FUNCIÓN DE GUARDADO PARA DESPUÉS DE EDITAR
   Limitations_SAVE: function(oEvent, Contador)
   {
	   var that = this;
	   var aSelectedItems = this.getView().byId("tableLimitations").getSelectedItems();
	   var SelectedItemsTotales = this.getView().byId("tableLimitations").getSelectedItems();
	   this.limitationKey = this.getView().getBindingContext().getObject().DBKey;
	   
		 //Realizar llamada al back para obtener el listado de findinds relacionados
			var limitationsModel = new sap.ui.model.odata.v2.ODataModel(
					"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
				);
		
		if(Contador === undefined || Contador === "")
			var Contador = [];
		else
			Contador = Contador;
			
			
		for(var i = 0; i < aSelectedItems.length; i++)
		{	
			for(var j = 0; j <= Contador.length; j++)
			{
				if(aSelectedItems[i] !== undefined)
				{
					if(Contador[j] === aSelectedItems[i].getCells()[2].getText())
					{
						//aSelectedItems[i].remove();
						   function removeItemFromArr ( arr, item ) {
							    var i = arr.indexOf( item );
							 
							    if ( i !== -1 ) {
							        arr.splice( i, 1 );
							    }
							}
						   removeItemFromArr( aSelectedItems, aSelectedItems[i] );
						
					}
					else if(aSelectedItems[i] !== undefined)
					{
						var sKeySeleccionado = aSelectedItems[i].getCells()[2].getText();
						var inputLimitations = aSelectedItems[i].getCells()[0].getValue();
						var aux = {};
						aux.db_key = sKeySeleccionado;
						aux.parent_key = this.limitationKey;
						aux.limitation = inputLimitations;
						break;
					}
				}
			}

		}		
		
		
		
		   limitationsModel.update("/ZGRCAUD_CV_LIMIT(guid'"+sKeySeleccionado+"')", aux, {
				async: true,
				success : function (oData) {
					
					Contador.push(aux.db_key);
					
					if(Contador.length !== SelectedItemsTotales.length)
						that.Limitations_SAVE(oEvent, Contador)
					else
					{
						for(var k = 0; k < SelectedItemsTotales.length; k++)
					   {
							SelectedItemsTotales[k].getCells()[0].setEditable(false);
					   }
						
						that.getView().byId("btn_EditLimitations").setVisible(true);
						that.getView().byId("btn_SaveLimitations").setVisible(false);
						
						that.getDataFromOdata();
					}
			  		
		       }
			});	
			
		
		
		/*var sKeySeleccionado = this.getView().byId("tableLimitations").getSelectedItems()[0].getCells()[1].getText()
		var inputLimitations = aSelectedItems[0].getCells()[0].getValue();
			
		var aux = {};
		aux.db_key = sKeySeleccionado;
		aux.parent_key = this.limitationKey;
		aux.limitation = inputLimitations;
	   
	   //limitationsModel.update("/ZGRCAUD_CV_LIMIT", aux, {
	   limitationsModel.update("/ZGRCAUD_CV_LIMIT(guid'"+sKeySeleccionado+"')", aux, {
			async: true,
			success : function (oData) {
				that.getDataFromOdata();
		  		aSelectedItems[0].getCells()[0].setEditable(false);
		  		
	       }.bind(this),
	       error: function (oError) {
	    	   that.getDataFromOdata();
	       }.bind(this)
		});	*/
   },

   
   	//FUNCION DE BORRAR TEXTO EN LA TABLA PRINCIPAL
   	Limitations_DEL: function(oEvent){
   		
   		var that = this;
  		
   		//ID de la línea seleccionada
   		var id = oEvent.getParameters().id;
   		//Nos quedamos con el número de línea
   		var numTabla = id.substr(id.length - 1);
   		//Nos quedamos con la Key de la Línea
   		var sKeySeleccionado = this.getView().byId("tableLimitations").getItems()[numTabla].getCells()[2].getText()
   		var oDataModel = new sap.ui.model.odata.v2.ODataModel(
   				"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",
   				false
   			);
   		
   		var url = "/ZGRCAUD_CV_LIMIT(guid'"+sKeySeleccionado+"')";	
   		oDataModel.remove(url, {
			success : function (oData) {					
				//Refrescamos tabla principal de Limitaciones
				that.getDataFromOdata();
	       }
		});
   		

   	},
   
	//FUNCIÓN DE REFRESCO DE DATOS LA TABLA PRINCIPAL LIMITATIONS
	getDataFromOdata: function(){
		
		var that = this;		
		this.getView().byId("tableLimitations").setBusy(true)
		var oData = {},
			aBatchOperations = [];												
		var slimitationsKey = sap.ui.getCore().getModel("limitationsModel").getData().id
		var url = "/GRCAUD_CV_Action(guid'"+slimitationsKey+"')/to_Limitations";
		
		//Realizar llamada al back para obtener el listado de findinds relacionados
		var limitationsModel = new sap.ui.model.odata.v2.ODataModel(
				"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
			);
		
		limitationsModel.read(url, {
			success: function (data, response) {
				data.results.sort((a,b) =>b.crea_date_time - a.crea_date_time);
				if(that.getView().byId("tableLimitations")){
				that.getView().byId("tableLimitations").removeSelections();
			}
			
					if(that.modelLimitations) {
						that.modelLimitations.setData(data.results);
						that.getView().byId("tableLimitations").setModel(that.modelLimitations,"limitations");
						that.modelLimitations.refresh();
					}
					that.editData = [];
					var modelTitleLimitations = {};
					that.editData = [];														      			      		
	      			modelTitleLimitations.title = that.getOwnerComponent().getModel("i18n").getResourceBundle().getText("limitationsSectionTitle");
 					that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(modelTitleLimitations), "limitationsTitle");
	      			that.getOwnerComponent().getModel("limitationsTitle").refresh();
	      			that.getView().byId("tableLimitations").setBusy(false)
					
			},
			failed: function (oData, response) {
				alert("Failed to get InputHelpValues from service!");
			},
		});
	},
   
  });
 }

);
