/*
 * Copyright (C) 2009-2022 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(["sap/uxap/BlockBase"],
 function (BlockBase) {
  "use strict";

  return BlockBase.extend("sap.grc.acs.aud.action.display.extended.block.SubActionPlan", {
   metadata: {
    views: {
     Collapsed: {
      viewName: "sap.grc.acs.aud.action.display.extended.block.view.SubActionPlan",
      type: "XML"
     },
     Expanded: {
      viewName: "sap.grc.acs.aud.action.display.extended.block.view.SubActionPlan",
      type: "XML"
     }
    }
   }
  });

 });
