/*
 * Copyright (C) 2009-2022 SAP SE or an SAP affiliate company. All rights reserved.
 */
/*global location*/
sap.ui.define([
  "sap/grc/acs/aud/action/controller/BaseController",
  "sap/ui/model/json/JSONModel",
  "sap/ui/core/routing/History",
  "sap/grc/acs/aud/action/model/formatter",
  "sap/grc/acs/lib/aud/utils/MenuItemUtils",
  "sap/grc/acs/lib/aud/utils/MessageUtil",
  "sap/grc/acs/lib/aud/extension/utils/FieldExtensibilityUtil"
 ], function (
  BaseController,
  JSONModel,
  History,
  formatter,
  MenuItemUtil,
  MessageUtil,
  FieldExtensibilityUtil
 ) {
  "use strict";

  return BaseController.extend("sap.grc.acs.aud.action.display.extended.controller.Object", {

   formatter: formatter,
   // INI PPM100076801 29/07/2022 ESTO SON LAS PESTAÑAS
   _aValidSectionIds : ["generalSection", "documentSection", "subActionSection", "limitationsSection", "activitySection", "commentSection"],
   // FIN PPM100076801 29/07/2022
   
   /* =========================================================== */
   /* lifecycle methods                                           */
   /* =========================================================== */

   /**
    * Called when the worklist controller is instantiated.
    * @public
    */
   onInit : function () {
    // Model used to manipulate control states. The chosen values make sure,
    // detail page is busy indication immediately so there is no break in
    // between the busy indication for loading the view's meta data
    var iOriginalBusyDelay,
     oViewModel = new JSONModel({
      busy : true,
      delay : 0
     });
    this.oMenuItemModelData = {
    MenuItem: []
    };
    this.bIsNavToNotFound = true;
    this.oMenuItemModel = this.getOwnerComponent().getModel("menu");
    this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

    //Extension model
    var oExtensionModel = new sap.ui.model.json.JSONModel();
    this.setModel(oExtensionModel, "extensionModel");

    //Set app title
    var sTitle = this.getResourceBundle().getText("objectTitle");
    this.getView().byId("objectPage").setTitle(sTitle);

    // Store original busy indicator delay, so it can be restored later on
    iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
    this.setModel(oViewModel, "objectView");
    this.getOwnerComponent().getModel().metadataLoaded().then(function () {
      // Restore original busy indicator delay for the object view
      oViewModel.setProperty("/delay", iOriginalBusyDelay);
     }
    );
   },

   onExit : function () {
    this.getView().byId("actionPlanSubSection").removeAllAggregation();
   },
   /* =========================================================== */
   /* event handlers                                              */
   /* =========================================================== */

   /**
    * Event handler  for navigating back.
    * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
    * If not, it will replace the current entry of the browser history with the worklist route.
    * @public
    */
   onNavBack : function() {
    var sPreviousHash = History.getInstance().getPreviousHash(),
     oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
    if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation() || this.getOwnerComponent().isAppToAppNavigation()) {
     history.go(-1);
    } else {
     this.getRouter().navTo("worklist", {}, true);
    }
   sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.action.EventBus", "resetBlockToDisplayMode");

   },

   /* =========================================================== */
   /* internal methods                                            */
   /* =========================================================== */

   /**
    * Binds the view to the object path.
    * @function
    * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
    * @private
    */
   ppp_onObjectMatched : function (oEvent) {
	   
    var sObjectId = oEvent.getParameter("arguments").objectId;
    this.sObjectId = sObjectId;
    sap.ui.getCore().setModel(new sap.ui.model.json.JSONModel({id : this.sObjectId}), "limitationsModel")
    var oObjectPage = this.byId("objectPage");
    if(!this.isNavButtonPressHandlerAttached){
		oObjectPage.attachNavButtonPress(this.onNavBack.bind(this));
		oObjectPage.setShowNavButton(true);
		this.isNavButtonPressHandlerAttached = true;
	}
    
    var oQuery = oEvent.getParameter("arguments")["?query"];
	if(oQuery && oQuery.section){
		
		if (oQuery && this._aValidSectionIds.indexOf(oQuery.section) > -1){
			this.getModel("objectView").setProperty("/selectedSection", oQuery.section);
			// if(oQuery.subSection && this._aValidSubsectionIds.indexOf(oQuery.subSection)){
			// 	this.getModel("objectView").setProperty("/selectedSubSection", oQuery.subSection);
			// 	this.getView().byId("generalSection").setSelectedSubSection(this.getView().byId(this.getView().getId() + "--" + oQuery.subSection));
			// }
			if(oQuery.wpaPhase){
				this.getModel("objectView").setProperty("/wpaPhase", oQuery.wpaPhase);
				if(oQuery.workPackageKey){
					this.getModel("objectView").setProperty("/workPackageKey", oQuery.workPackageKey);
				}
			}
			this.getView().byId("ObjectPageLayout").setSelectedSection(this.getView().byId(this.getView().getId() + "--" + oQuery.section));
			if(this.getModel("objectView").getProperty("/isSectionNavigation")){
				this.getView().setBusy(false);
				this.getModel("objectView").setProperty("/isSectionNavigation", false);
				return;
			}
		} else {
			//If section id does not exist, display general section by default 
			this.getRouter().navTo("object", {
				objectId: sObjectId,
				intentService: this.getOwnerComponent().getModel("intentConfig").getData().service,
				query: {
					section : this._aValidSectionIds[0]
				}
			},true /*no history*/);
			return;
		}
	}
    
    var sIntentService = this.getOwnerComponent().getModel("intentConfig").getData().service;
    
    //DESCOMENTAR CUANDO TENGAMOS LA LLAMADA DEL BACK PARA LOS TITULOS
    	//Realizar llamada al back para obtener el listado de accion relacionados
		/*var actionModel = new sap.ui.model.odata.v2.ODataModel(
				"/sap/opu/odata/sap/ZGRCAUD_ENH_SRV/",false
			);
		
		var sAuditKey = this.sObjectId;
		var url = "/ZGRCAUD_CV_ACTIONRELBYFINDING(p_find=guid'" + sAuditKey + "')/Set";

		var that = this;
		var data = [];
		var modelTitleActionRel = {};
		that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(data),"limitationsRel");      			      			
		modelTitleActionRel.title = that.getModel("i18n").getResourceBundle().getText("limitationsSectionTitle");	
		that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(data), "limitationsTitle");
		modelTitleActionRel.count = '0';                   			
		 
		actionModel.read(url, {
			success: function (data, response) { 
				
				if (data && data.results && data.results.length > 0) {
					
					that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(data.results),"limitationsRel");
					modelTitleActionRel.count = data.results.length;
					  
				}
				modelTitleActionRel.title = modelTitleActionRel.title +'('+modelTitleActionRel.count+')';
				that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(modelTitleActionRel), "limitationsTitle");
				
			},
			failed: function (oData, response) {
				alert("Failed to get InputHelpValues from service!");
			},
			
			
		});	*/
    
    
    
    
    
    
    
    this.getModel().metadataLoaded().then( function() {
     var sObjectPath = this.getModel().createKey(sIntentService, {
      DBKey :  sObjectId
     });
     sObjectPath = "/" + sObjectPath;
     this._bindView(sObjectPath);
    }.bind(this));
    //this.getView().getModel().refresh();
   },
   
   _onObjectMatched : function (oEvent) {
	    var sObjectId         =  oEvent.getParameter("arguments").objectId;
	    
	    // INI PPM100076801
	    var that = this;
	    this.sObjectId = sObjectId;
	    sap.ui.getCore().setModel(new sap.ui.model.json.JSONModel({id : this.sObjectId}), "limitationsModel")
	    
	    var data = [];
		var modelTitleLimitations = {};
		that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(data),"MyLimitations");      			      			
		modelTitleLimitations.title = that.getModel("i18n").getResourceBundle().getText("limitationsSectionTitle");	
		that.getOwnerComponent().setModel(new sap.ui.model.json.JSONModel(data), "limitationsTitle");
	    // FIN PPM100076801
	    
	    
	    
	    var sIntentService = this.getOwnerComponent().getModel("intentConfig").getData().service;
	    this.getModel().metadataLoaded().then( function() {
	     var sObjectPath = this.getModel().createKey(sIntentService, {
	      DBKey :  sObjectId
	     });
	     sObjectPath = "/" + sObjectPath;
	     this._bindView(sObjectPath);
	    }.bind(this));
	    //this.getView().getModel().refresh();
	   },
   
   
   /**
    * Binds the view to the object path.
    * @function
    * @param {string} sObjectPath path to the object to be bound
    * @private
    */
   _bindView : function (sObjectPath) {
    var oViewModel = this.getModel("objectView"),
     oDataModel = this.getModel();

    var sIntent = this.getOwnerComponent().getModel("intentConfig").getData().intent;
    var sExpandString = "to_Audit,to_Finding,to_AuditManagerPerson,to_AuditLeadPerson,to_ResponsiblePerson,to_Escalation,to_Count,to_RoleConfig";
    if( !this.getOwnerComponent().getModel("intentConfig").getData().IsMenuItemFromEntitySet ){
     sExpandString = sExpandString + ",to_MenuItems";
    }
    if(sIntent === "Action-displayAuditFollowUp") {
     sExpandString = "to_Audit,to_Finding,to_AuditManagerPerson,to_AuditLeadPerson,to_ResponsiblePerson,to_Escalation,to_Count,to_RoleConfig";
    }

    this.getView().bindElement({
     path: sObjectPath,
     parameters: {
      expand: sExpandString
     },
     events: {
      change: this._onBindingChange.bind(this),
      dataRequested: function () {
       oDataModel.metadataLoaded().then(function () {
        // Busy indicator on view should only be set if metadata is loaded,
        // otherwise there may be two busy indications next to each other on the
        // screen. This happens because route matched handler already calls '_bindView'
        // while metadata is loaded.
        oViewModel.setProperty("/busy", true);
       });
      },
      dataReceived: function () {
       oViewModel.setProperty("/busy", false);
      }
     }
    });
   },

   /*set subAction section visibility.*/
   setActionSectionVisibility : function(sValue){
    if(sValue === sap.grc.acs.aud.action.util.constant.InitialGUID) {
     return true;
    }
    else {
     return false;
    }
   },
   _onBindingChange : function () {

    sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.action.EventBus", "userRoleModelDataUpdateFinished");

    var oView = this.getView(),
     oViewModel = this.getModel("objectView"),
     oExtensionModel = this.getModel("extensionModel"),
     oElementBinding = oView.getElementBinding();

    // No data for the binding
    if (!oElementBinding.getBoundContext()) {
     if(this.bIsNavToNotFound === true) {
      this.getRouter().getTargets().display("objectNotFound");
     }
     return;
    }

    var oObject = oView.getBindingContext().getObject(),
     sObjectStatus = oObject.Status,
     sObjectId    = oObject.DBKey,
     sAuditType = oView.getBindingContext().getProperty("to_Audit/Type"),
        sIntent = this.getOwnerComponent().getModel("intentConfig").getData().intent;

    //get Menu Item related data 
    var oMenuItemList = this.getView().getBindingContext().getProperty("to_MenuItems");
    var sPath = "";
    var oMenuItemsList = [];
    var oMenuItemDetail = {};
    if(oMenuItemList){
     for(var i = 0; i < oMenuItemList.length; i++){
      sPath = "/" + oMenuItemList[i];
      oMenuItemDetail = this.getView().getBindingContext().getObject(sPath);
      oMenuItemsList.push(oMenuItemDetail);
     }
    }
    this.oMenuItemsList = oMenuItemsList;


    //call acs library menu item utility to set menu model data.
    var oI18nModel    =  this.getOwnerComponent().getModel("i18n");
    var sObjectType   =  sap.grc.acs.aud.action.util.constant.ObjectType.Action;
    var oMenuItemConfigData = this.getOwnerComponent().getModel("menuItemConfig").getData();
    var oAdditionalInfo = {
       "documentSection":{
        bIsToolBarRequired: true,
        bIsTitleRequired: false,
        titleText: "",
        id:"documentToolBarSpacer"
       },
       "commentSection":{
        bIsToolBarRequired: true,
        bIsTitleRequired: false,
        titleText: "",
        id:"commentToolBarSpacer"
       },
       "actionSection":{
        bIsToolBarRequired: true,
        bIsTitleRequired: false,
        titleText: "",
        id:"actionToolBarSpacer"
       }
    };

    if( this.getOwnerComponent().getModel("intentConfig").getData().IsMenuItemFromEntitySet ){
     var aFilters = [],
      oDataModel = this.getModel();
     aFilters.push(new sap.ui.model.Filter("DBKey",
      sap.ui.model.FilterOperator.EQ,
      oObject.DBKey));
     aFilters.push(new sap.ui.model.Filter("ScenarioID",
      sap.ui.model.FilterOperator.EQ,
      this.getOwnerComponent().getModel("intentConfig").getData().intent));
     var sMenuItemPath = "/" + sap.grc.acs.aud.action.util.constant.MenuItemSet;

     oDataModel.read(sMenuItemPath, {
      success: jQuery.proxy(function(oData) {
       oMenuItemsList = oData.results;
       this.oMenuSetItemsList = oMenuItemsList;
       this.oMenuItemModelData = MenuItemUtil.setMenuItemModelData(oMenuItemsList, oI18nModel, sObjectId, sObjectType, oMenuItemConfigData,
        this.oMenuItemModel, oAdditionalInfo);

       //set extensibility model data
       oExtensionModel.setData(
        FieldExtensibilityUtil.getExtensionFieldsStatus("Action",
         sAuditType, sObjectStatus, this.getModel().getServiceMetadata(), oMenuItemConfigData, this.getOwnerComponent(), sIntent),
        true);

       //INI ASE MMM 12/09/2022
       var Limits = [];
       Limits["Create"] = {Enable:false};
       Limits["Delete"] = {Enable:false};
       Limits["Edit"] = {Enable:false};
       
       for (var i = 0; i < oMenuItemsList.length; i++) {
    	   if(oMenuItemsList[i].SectionID === 'LIMIT' && oMenuItemsList[i].ActionText === 'Crear'){
    		   if(oMenuItemsList[i].Enable === 'X'){ 
    			   oMenuItemsList[i].Enable = true;
    		   }else{
    			   oMenuItemsList[i].Enable = false;
    		   }
    		   Limits["Create"] = oMenuItemsList[i];
    	   }else if(oMenuItemsList[i].SectionID === 'LIMIT' && oMenuItemsList[i].ActionText === 'Borrar'){
    		   if(oMenuItemsList[i].Enable === 'X'){ 
    			   oMenuItemsList[i].Enable = true;
    		   }else{
    			   oMenuItemsList[i].Enable = false;
    		   }
    		   Limits["Delete"] = oMenuItemsList[i];
    	   }else if(oMenuItemsList[i].SectionID === 'LIMIT' && oMenuItemsList[i].ActionText === 'Tratar'){
    		   if(oMenuItemsList[i].Enable === 'X'){ 
    			   oMenuItemsList[i].Enable = true;
    		   }else{
    			   oMenuItemsList[i].Enable = false;
    		   }
    		   Limits["Edit"] = oMenuItemsList[i];
    	   }
       }
     //FIN ASE MMM 12/09/2022
       oExtensionModel.setData(Limits, true);
       
       sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.action.EventBus", "extensionModelDataUpdateFinished");
      }, this),
      filters: aFilters
     });
    }else{

     this.oMenuItemModelData = MenuItemUtil.setMenuItemModelData(oMenuItemsList, oI18nModel, sObjectId, sObjectType, oMenuItemConfigData,
                      this.oMenuItemModel, oAdditionalInfo);
     //set extensibility model data
     oExtensionModel.setData(
      FieldExtensibilityUtil.getExtensionFieldsStatus("Action",
       sAuditType, sObjectStatus, this.getModel().getServiceMetadata(), oMenuItemConfigData, this.getOwnerComponent(), sIntent),
      true);                 

     sap.ui.getCore().getEventBus().publish("sap.grc.acs.aud.action.EventBus", "extensionModelDataUpdateFinished");                 
    }
    // Everything went fine.
    oViewModel.setProperty("/busy", false);
   },


   createHeaderButton: function(sId, oContext){
    return MenuItemUtil.createButtonTemplate(sId, oContext, this,"","to_MenuItems",this.oMenuSetItemsList, true);                    
   },

   setEsclationLevelText: function(sEsclationLevelNum, sEsclationLevelText){
    if(sEsclationLevelNum === "000"){
     return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("labelNoEscalation");
    }
    else {
     return sEsclationLevelText;
    }
   },

   formatChildActionSectionHeaderWithCount: function(sChildActionSectionCount){
    return this.getView().getModel("i18n").getResourceBundle().getText("labelActionPlanTitleWithNumber", [sChildActionSectionCount]);
   },

   formatDocumentSectionHeaderWithCount: function(sDocumentSectionCount){
    return this.getView().getModel("i18n").getResourceBundle().getText("labelDocumentTitleWithNumber", [sDocumentSectionCount]);
   },

   _getDeleteActionPlanMessage:function(){
    var sParentActionPlanKey = "";
    sParentActionPlanKey = this.getView().getBindingContext().getObject().ParentActionKey;                         
    if(sParentActionPlanKey === sap.grc.acs.aud.action.util.constant.InitialGUID){
     return this.getResourceBundle().getText("msgConfirmDeleteParentAction");
    }else{
     return this.getResourceBundle().getText("msgConfirmDeleteAction");
    }
   },

   ACTION_DELETE_ROOT: function() {
       var oController = this;
    var sMessage = this._getDeleteActionPlanMessage();
    MessageUtil.showMsg("msgTypeConfirm", sMessage,
    this.getResourceBundle().getText("labelDeleteActionPlanTitle"), 
    jQuery.proxy(function(oReturn) {
     if (oReturn === "OK") {
      oController.deleteActionPlan(oController);
     }
    }, this));
   },

   deleteActionPlan: function() {
    var oDataModel = this.getView().getModel();
    var sDeletePath = this.getView().getBindingContext().getPath();
    var oController = this;

    oDataModel.remove(sDeletePath, {
          success: jQuery.proxy(function(oData, oResponse) {
             MessageUtil.showMsg("msgTypeSuccessful", this.getResourceBundle().getText("msgDeleteActionPlanSuccess"));
       oController.onNavBack();
          }, this),
          error: jQuery.proxy(function(oError) {
            MessageUtil.showMsg("msgTypeFailed", this.getResourceBundle().getText("msgDeleteActionPlanFail"));
          }, this),
          async: true
        });
   },

   handleHeaderButtonPress: function(oData){

    var sSuccessTextID = "MSG_EXE_ACT_ACTION_"+ oData.sActionName.toUpperCase() + "_SUCCESS";
    var sErrorTextID =  "MSG_EXE_ACT_ACTION_"+ oData.sActionName.toUpperCase() + "_FAIL";
    //get Delegatee
    var oParameter = {};
     oParameter.Delegatee = "";
    var oMenuItemsList = this.oMenuItemsList.length !== 0? this.oMenuItemsList: this.oMenuSetItemsList;
    for(var i = 0; i < oMenuItemsList.length; i++){
     if(oMenuItemsList[i].Action === oData.sActionName){
      oParameter.Delegatee = oMenuItemsList[i].Delegatee;
      break;
     }
    }
    this.getModel().setUseBatch(false);
    this.getView().setBusy(true);
    this.getModel().create("/MenuItemExecutionSet", {
     Key: oData.sKey,
     ObjectType: sap.grc.acs.aud.action.util.constant.ObjectType.Action,
     ActionName: oData.sActionName,
     Comment: oData.sComment,
     Parameter: encodeURI(JSON.stringify(oParameter))
    }, {
     success: jQuery
          .proxy(
            function() {
            MessageUtil.showMsg("msgTypeSuccessful", this.getResourceBundle().getText(sSuccessTextID));
            sap.ui.getCore().getEventBus().publish(
          "sap.grc.acs.aud.action.EventBus", "actionListRefresh");
          this.getView().getModel().refresh();
          this.getView().setBusy(false);
          this.getModel().setUseBatch(true);
          this.bIsNavToNotFound = false;
          this.onNavBack();
            }, this),
     error: jQuery
          .proxy(
            function(oError) {
            this.getModel().setUseBatch(true);
            if (oError.responseText) {
           var oJsonError = JSON.parse(oError.responseText);
           var errorMessage = oJsonError.error.message.value;
             MessageUtil.showMsg("msgTypeFailed", this.getResourceBundle().getText(sErrorTextID) + "\r\n" + errorMessage);
             this.getView().getModel().refresh();
             this.getView().setBusy(false);
            }
            }, this)
    });
   }

  });

 }
);
