/*
 * Copyright (C) 2009-2020 SAP SE or an SAP affiliate company. All rights reserved.
 */
jQuery.sap.declare("sap.grc.acs.aud.action.display.extended.Component");
					
sap.ui.component.load({
 	name:"sap.grc.acs.aud.action.display",
 	url: "/sap/bc/ui5_ui5/sap/grcaud_actdisp"
 		 
 });
 
sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"sap/grc/acs/aud/action/app/Component"
], function(UIComponent, Device, ActionComponent) {
	"use strict";

	return ActionComponent.extend("sap.grc.acs.aud.action.display.extended.Component",
		{
			metadata: {
				manifest: "json",
				"customizing" : {
			    	 "sap.ui.viewReplacements" : {
			                 "sap.grc.acs.aud.action.block.view.SubActionPlan": {    
			                     "viewName": "sap.grc.acs.aud.action.display.extended.block.view.SubActionPlan",            
			                     "type": "XML"
			                 },
			                 "sap.grc.acs.aud.action.view.Object": {    
			                     "viewName": "sap.grc.acs.aud.action.display.extended.view.Object",            
			                     "type": "XML"
			                 },	       
			                 /*"sap.grc.acs.aud.action.view.Worklist": {    
			                     "viewName": "sap.grc.acs.aud.action.display.extended.view.Worklist",            
			                     "type": "XML"
			                 },*/	
						},
			         "sap.ui.controllerExtensions" : {

					 "sap.grc.acs.aud.action.block.controller.SubActionPlan" : {
						 "controllerName":"sap.grc.acs.aud.action.display.extended.block.controller.SubActionPlan"
					 
					 },
					 "sap.grc.acs.aud.action.controller.Object" : {
						 "controllerName":"sap.grc.acs.aud.action.display.extended.controller.Object"
					 
					 },		
					 /*"sap.grc.acs.aud.action.controller.Worklist" : {
						 "controllerName":"sap.grc.acs.aud.action.display.extended.controller.Worklist"
					 
					 },*/
					 },
						"sap.ui.controllerReplacements" : {
					 "sap.grc.acs.aud.action.controller.Create":{
						 "controllerName":"sap.grc.acs.aud.action.display.extended.block.controller.Create"
					 },
					 "sap.grc.acs.aud.action.block.controller.General" : {						 
							"controllerName":"sap.grc.acs.aud.action.display.extended.block.controller.GeneralCustom"
						 
						 }
					 
				}
				}
			}
		}
	);

});