/*
 * Copyright (C) 2009-2021 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
 "sap/grc/acs/aud/finding/controller/BaseController",
 "sap/ui/model/json/JSONModel",
 "sap/ui/core/routing/History",
 //"sap/grc/acs/lib/aud/extension/utils/FieldExtensibilityUtil",
  "sap/grc/acs/aud/finding/execute/extended/util/FieldExtensibilityUtil",
 "sap/grc/acs/lib/aud/utils/CommonUtil",
 "sap/grc/acs/lib/aud/utils/MessageUtil" 
], function (
 BaseController, JSONModel, History, FieldExtensibilityUtil, CommonUtil, MessageUtil) {

 "use strict";

 return BaseController.extend("sap.grc.acs.aud.finding.execute.extended.controller.Create", {

  /**
   * Called when a controller is instantiated and its View controls (if available) are already created.
   * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
   * @memberOf src.sap.grc.acs.aud.audit.view.Create
   */
//	 onAfterRendering:function(){
//		 var oExtensionGroup = this.getView().byId("extensionGroup");
//	 },
//  onInit: function () {
//
//   if (this.getRouter() && this.getRouter().getRoute("create")) {
//    this.getRouter().getRoute("create").attachPatternMatched(this._onRoutePatterMatched, this);
//   }
//
//   var oThreeColumnLayoutData = {
//     labelSpanS:12, labelSpanM:12, labelSpanL:12, labelSpanXL:12,
//     columnsM: 3, columnsL: 3, columnsXL: 3
//    },
//    oTwoColumnLayoutData = {
//     labelSpanS:12, labelSpanM:12, labelSpanL:12, labelSpanXL:12,
//     columnsM: 2, columnsL: 2, columnsXL: 2
//    };
//   this._oThreeColumnsLayout = new sap.ui.comp.smartform.Layout(oThreeColumnLayoutData);
//   this._oTwoColumnsLayout = new sap.ui.comp.smartform.Layout(oTwoColumnLayoutData);
//
//   var oExtensionModel = new sap.ui.model.json.JSONModel();
//   this.setModel(oExtensionModel, "extensionModel");
//
//   this.aTextTypedField = ["Title", "Description", "Type", "Category", "Ranking", "Recommendation", 
//         "Criteria", "ConditionDescription", "CauseDescription", "ConsequenceDescription"];
//
//   this.getView().byId("inputTags").addValidator(this._validateTag.bind(this));
//
//  },
//
//  /**
//   * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
//   * @memberOf src.sap.grc.acs.aud.audit.view.Object
//   */
//  onExit: function () {
//   if (this.getView().getBindingContext()) {
//    this._destoryFields();
//   }
//  },
//
//  /**
//   * Binds the view to the create path.
//   * @function
//   * @param {sap.ui.base.Event} oEvent pattern match event in route 'create'
//   * @private
//   */
//  _onRoutePatterMatched: function (oEvent) {
//
//   this.sAuditKey =  oEvent.getParameter("arguments").auditKey;
//   this.sAuditGroup =  oEvent.getParameter("arguments").auditGroup;
//   this.sAuditType =   oEvent.getParameter("arguments").auditType;
//   this.sTaskKey = "";
//   this.sObjectType = "";
//   this.sIntent = this.getOwnerComponent().getModel("intentConfig").getData().intent;
//
//   var oQuery = oEvent.getParameter("arguments")["?query"];
//   if(oQuery){
//    this.sTaskKey = oQuery.TaskKey;
//    this.sObjectType = oQuery.ObjectType;
//   }
//
//   this.getModel().metadataLoaded().then(this._bindView.bind(this));
//  },
//
//  /**
//   * Binds the view to the object path.
//   * @function
//   * @param {string} sObjectPath path to the object to be bound
//   * @private
//   */
//  _bindView: function () {
//
//   this.getModel().setDeferredGroups(["createFinding", "createFindingData"]);
//
//   this.bEstimatedFieldError = false;
//
//   this.createBindingContext();
//   this.getView().setModel(this.getExtensionModel(this.sAuditType), "extensionModel");
//   this.createExtensionGroup();
//   this.bindOrganization(this.sAuditKey);
//   this.bindReference(this.sAuditKey);
//   this.bindFindingExecutiveResponsible(this.sAuditKey);
//
//  },
//
//  onNavBack: function () {
//   this._destoryFields();
//   this._resetUIState();
//   this._clearFieldValueStatus();
//
//   var sPreviousHash = History.getInstance().getPreviousHash(),
//    oCrossAppNavigator = this.getOwnerComponent().getCrossAppNavigator();
//   if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation() || this.getOwnerComponent().isAppToAppNavigation()) {
//    history.go(-1);
//   }
//
//  },
//
//  onCreateBtnPress: function(){
//   if (this._validateUI()) {
//    this.getView().setBusy(true);
//    this._createFinding();
//   }
//  },
//
//  onCancelBtnPress: function() {
//   this.onNavBack();
//  },
//
//  handleSuggest: function(oEvent){
//   var sTerm = oEvent.getParameter("suggestValue");
//   var aFilters = [];
//   if (sTerm) {
//    aFilters.push(new sap.ui.model.Filter("TagName", sap.ui.model.FilterOperator.Contains, sTerm));
//   }
//   oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
//  },
//
//  onChangeResetUI: function(oEvent) {
//   oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
//  },
//
//  createBindingContext: function () {
//   var oBindingContext = this.getModel().createEntry("GRCAUD_CV_Finding", {
//    groupId: "createFindingData"
//   });
//   this.getView().setBindingContext(oBindingContext);
//  },
//
//  getExtensionModel: function (sAuditType) {
//   var oExtensionModel = new sap.ui.model.json.JSONModel();
//   var sObjectStatus = "";
//   var oMenuItemConfigData = {
//    SmartForm: undefined
//   };
//   oExtensionModel.setData(
//    FieldExtensibilityUtil.getExtensionFieldsStatus("Finding",
//     sAuditType, sObjectStatus, this.getModel().getServiceMetadata(), oMenuItemConfigData, this.getOwnerComponent(), this.sIntent),
//    true);
//   return oExtensionModel;
//  },
//
//  createExtensionGroup: function () {
//   var oExtensionGroup = this.getView().byId("extensionGroup");
//   FieldExtensibilityUtil.createExtensionGroup("Finding", oExtensionGroup, this.getOwnerComponent(), sap.grc.acs.lib.aud.utils.Constant.Mode.CREATE);
//   if (oExtensionGroup.getVisible()) {
//    this.getView().byId("smartForm").setLayout(this._oThreeColumnsLayout);
//   } else {
//    this.getView().byId("smartForm").setLayout(this._oTwoColumnsLayout);
//   }
//  },
//
//  _destoryFields: function() {
//   this.getView().getModel().deleteCreatedEntry(this.getView().getBindingContext());
//   var oExtensionGroup = this.getView().byId("extensionGroup");
//   oExtensionGroup.destroyGroupElements();
//  },
//
//  _validateTag: function (args) {
//   var sText = args.text;
//   if (sText.indexOf(";") !== -1) {
//    MessageUtil.showMsg("msgTypeFailed", this.getModel("i18n").getResourceBundle().getText("MSG_TAGS_FORBIDDEN_CHAR"));
//    return sap.m.MultiInput.WaitForAsyncValidation;
//   } else {
//    return new sap.m.Token({
//     key: sText,
//     text: sText
//    });
//   }
//  },
//
//  _bindSelectField: function (sControlId, sPath, sSelectionKey, sSelectionText, aFilters, aSorters, sAdditionalText, bShowEmptyItem) {
//   var oDataModel = this.getModel();
//   var oSelect = this.getView().byId(sControlId);
//   oSelect.setBusy(true);
//   oDataModel.read(sPath, {
//    filters: aFilters,
//    sorters: aSorters,
//    success: jQuery.proxy(function(data, response) {
//     var oTemplate;
//     var aItemList = data.results;
//     if (bShowEmptyItem) {
//      var oEmptyResult = {};
//      oEmptyResult[sSelectionKey] = null;
//      oEmptyResult[sSelectionText] = "";
//      oEmptyResult[sAdditionalText] = "";
//      var aEmptyResult = [oEmptyResult];
//      aItemList = aEmptyResult.concat(data.results);
//     }
//     if (sAdditionalText) {
//      oTemplate = new sap.ui.core.ListItem({
//       key: "{" + sSelectionKey + "}",
//       text: "{" + sSelectionText + "}",
//       additionalText: "{" + sAdditionalText + "}"
//      });
//     } else {
//      oTemplate = new sap.ui.core.ListItem({
//       key: "{" + sSelectionKey + "}",
//       text: "{" + sSelectionText + "}"
//      });
//     }
//     var oModel = new sap.ui.model.json.JSONModel(aItemList);
//     oSelect.setModel(oModel);
//     oSelect.bindItems("/", oTemplate);
//     oSelect.setBusy(false);
//    } ,this),
//    async: true
//   });
//  },
//
//  bindOrganization: function (sAuditKey) {
//   var sPath = "/GRCAUD_CV_OrganizationByAudit",
//    sControlId = "inputOrganization",
//    sSelectionKey = "OrgKey",
//    sSelectionText = "OrgID",
//    sAdditionalText = "OrgName";
//
//   var aFilters = [new sap.ui.model.Filter("DBKey",
//    sap.ui.model.FilterOperator.EQ,
//    sAuditKey)];
//   var aSorters = [new sap.ui.model.Sorter("OrgID")];
//   this._bindSelectField(sControlId, sPath, sSelectionKey, sSelectionText, aFilters, aSorters, sAdditionalText, true);
//  },
//
//  bindReference: function (sAuditKey) {
//   var sPath = "/GRCAUD_CV_AssignedScopeHier",
//    sControlId = "inputReference",
//    sSelectionKey = "DBKey",
//    sSelectionText = "Code",
//    sAdditionalText = "Name";
//
//   var aFilters = [new sap.ui.model.Filter("AuditKey",
//     sap.ui.model.FilterOperator.EQ,
//     sAuditKey),
//    new sap.ui.model.Filter("DrillState",
//     sap.ui.model.FilterOperator.EQ,
//     "leaf")
//   ];
//   var aSorters = [new sap.ui.model.Sorter("Code")];
//   this._bindSelectField(sControlId, sPath, sSelectionKey, sSelectionText, aFilters, aSorters, sAdditionalText, true);
//  },
//
//  bindFindingExecutiveResponsible: function (sAuditKey) {
//   var sPath = "/GRCAUD_CV_AuditUserRole",
//    sControlId = "inputExecutiveResponsible",
//    sSelectionKey = "UserID",
//    sSelectionText = "FullName",
//    sAdditionalText = "FullName";
//
//   var aFilters = [new sap.ui.model.Filter("HostKey",
//     sap.ui.model.FilterOperator.EQ,
//     sAuditKey),
//    new sap.ui.model.Filter("RoleID",
//     sap.ui.model.FilterOperator.EQ,
//     "EXE_RESP")
//   ];
//   var aSorters = [new sap.ui.model.Sorter("UserID")];
//   this._bindSelectField(sControlId, sPath, sSelectionKey, sSelectionText, aFilters, aSorters, sAdditionalText, true);
//  },
//
//  _createFinding: function () {
//   var oDataModel = this.getModel();
//   var oData = this.oFindingNewData;
//   var sFindingPath = ""; //create finding - fiori
//   var sFindingKey = "";
//
//   if ( this.sObjectType === "QTASK" ){
//       sFindingPath = "/GRCAUD_CV_FindingByQTask";
//       oData.DBKey = this.sTaskKey;
//       oData.FindingKey = CommonUtil.generateGuid();
//       sFindingKey = oData.FindingKey;
//      }else if ( this.sObjectType === "MTASK" ){
//       sFindingPath = "/GRCAUD_CV_FindingByManualTask";
//       oData.DBKey = this.sTaskKey;
//       oData.FindingKey = CommonUtil.generateGuid();
//       sFindingKey = oData.FindingKey;
//      }else if ( this.sObjectType === "CTASK" ){
//       sFindingPath = "/GRCAUD_CV_FindingByCCMTask";
//       oData.DBKey = this.sTaskKey;
//       oData.FindingKey = CommonUtil.generateGuid();
//       sFindingKey = oData.FindingKey;
//      }else{
//       sFindingPath = "/GRCAUD_CV_Finding";
//       oData.DBKey = CommonUtil.generateGuid();
//       sFindingKey = oData.DBKey;
//      }
//
//   oData = this._cleanFindingData(oData);
//   oDataModel.setUseBatch(true);
//
//   oDataModel.create(sFindingPath, oData, {
//    groupId: "createFinding"
//   });
//   this._createFindingExecutiveResponsible(sFindingKey);
//   this._createFindingReference(sFindingKey);
//   this._createFindingOrganizationAssignment(sFindingKey);
//   // this._createFindingTags(oData.DBKey);
//
//   oDataModel.submitChanges({
//    groupId: "createFinding",
//    success: jQuery.proxy(function (oDataNew, oResponse) {
//     if (oDataNew.__batchResponses[0].message) {
//      this.getView().setBusy(false);
//     } else {
//      MessageUtil.showMsg("msgTypeSuccessful", this.getModel("i18n").getResourceBundle().getText("CREATE_FINDING_SUCCESS"));
//      this.getView().setBusy(false);
//      oDataModel.refresh();
//      this.onNavBack();
//     }
//    }, this),
//    error: jQuery.proxy(function () {
//     this.getView().setBusy(false);
//     MessageUtil.showMsg("msgTypeFailed", this.getModel("i18n").getResourceBundle().getText("CREATE_FINDING_FAILED"));
//    }, this)
//   });
//  },
//
//  _createFindingExecutiveResponsible: function (sFindingDBKey) {
//   var oDataModel = this.getModel();
//   //no responsible preson
//   if (this.aExecutiveResponsible.length === 0) {
//    return;
//   } else {
//    var sPath = "/" + oDataModel.createKey("GRCAUD_CV_Finding", {
//     DBKey: sFindingDBKey
//    }) + "/to_ExecutiveResponsible";
//    // var sPath = "/GRCAUD_CV_Finding(guid" + "'" + sFindingDBKey + "')/to_ExecutiveResponsible";
//    // for (var i = 0; i < this.aExecutiveResponsible.length; i++) {
//     var oUser = {
//      UserID: this.aExecutiveResponsible[0].UserID,
//      RoleID: "EXE_RESP",
//      HostKey: sFindingDBKey,
//      userSequence: 0 + ""
//     };
//     oDataModel.create(sPath, oUser, {
//      groupId: "createFinding"
//     });
//    }
//   // }
//  },
//
//  _createFindingReference: function (sFindingDBKey) {
//   var oDataModel = this.getModel();
//   if (this.oReference.DBKey) {
//    var sPath = "/GRCAUD_CV_ScopeReference";
//    var oReference = {
//     ScopeKey: this.oReference.DBKey,
//     ParentKey: sFindingDBKey,
//     RootKey: this.sAuditKey
//    };
//    oDataModel.create(sPath, oReference, {
//     groupId: "createFinding"
//    });
//   } else {
//    return;
//   }
//  },
//
//  _createFindingOrganizationAssignment: function (sFindingDBKey) {
//   var oDataModel = this.getModel();
//   if (this.oAssignedOrganization.DBKey) {
//    var sPath = "/GRCAUD_CV_OrgByFinding";
//    var oOrgAssignment = {
//     OrgKey: this.oAssignedOrganization.OrgKey,
//     ParentKey: sFindingDBKey,
//     RootKey: this.sAuditKey
//    };
//    oDataModel.create(sPath, oOrgAssignment, {
//     groupId: "createFinding"
//    });
//   } else {
//    return;
//   }
//  },
//
//  //reset ui to initial status
//  _clearFieldValueStatus: function () {
//   this.getView().byId("inputType").setSelectedItem(null);
//   this.getView().byId("inputCategory").setSelectedItem(null);
//   this.getView().byId("inputRanking").setSelectedItem(null);
//   this.getView().byId("inputTags").removeAllTokens();
//  },
//
//  // Restore field value state before checking
//  _resetUIState: function () {
//   this.getView().byId("inputTitle").setValueState(sap.ui.core.ValueState.None);
//   this.getView().byId("inputType").setValueState(sap.ui.core.ValueState.None);
//   this.getView().byId("inputCategory").setValueState(sap.ui.core.ValueState.None);
//   this.getView().byId("inputRanking").setValueState(sap.ui.core.ValueState.None);
//   this.getView().byId("inputCriteria").setValueState(sap.ui.core.ValueState.None);
//   this.getView().byId("inputConditionDescription").setValueState(sap.ui.core.ValueState.None);
//   this.getView().byId("inputCauseDescription").setValueState(sap.ui.core.ValueState.None);
//   this.getView().byId("inputConsequenceDescription").setValueState(sap.ui.core.ValueState.None);
//   this.getView().byId("inputRecommendation").setValueState(sap.ui.core.ValueState.None);
//  },
//
//  _validateTextTypedField: function (sFieldName) {
//   var sLableId = "label" + sFieldName,
//    sInputId = "input" + sFieldName;
//   if (this.getView().byId(sLableId).getRequired() && (!this.oFindingNewData[sFieldName] || this.oFindingNewData[sFieldName] === "")) {
//    this.getView().byId(sInputId).setValueState(sap.ui.core.ValueState.Error);
//    this.bFieldIsEmpty = true;
//   }
//  },
//
//  //input validation
//  _validateUI: function () {
//   this._collectFindingData();
//   this._resetUIState();
//
//   this.bFieldIsEmpty = false;
//   this.bFieldError = false;
//
//   for (var i = 0; i < this.aTextTypedField.length; i++) {
//    this._validateTextTypedField(this.aTextTypedField[i]);
//   }
//
//   // validate cdf fields
//   this._validateCDF();
//
//   if (this.bFieldIsEmpty) {
//    MessageUtil.showMsg("msgTypeFailed", this.getModel("i18n").getResourceBundle().getText("MSG_REQUIRED_FIELD"));
//    return false;
//   }
//   if (this.bFieldError) {
//    MessageUtil.showMsg("msgTypeFailed", this.getModel("i18n").getResourceBundle().getText("MSG_ERROR_NOT_HANDLE"));
//    return false;
//   }
//
//   return true;
//  },
//
//  _validateCDF: function(){
//   for (var i = 0; i < this.getOwnerComponent().aFields.length; i++) {
//    var bCDFError = false;
//    if (this.getOwnerComponent().aFields[i].isExtensionField) {
//     var sExtensionLabelIdPrefix = sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud.utils.Constant.DIALOGID
//      .EXTENSION_LABEL;
//     var sExtensionInputIdPrefix = sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud.utils.Constant.DIALOGID
//      .EXTENSION_INPUT;
//     if(sap.ui.getCore().byId(sExtensionInputIdPrefix + this.getOwnerComponent().aFields[i].name).getValueState){
//      if (sap.ui.getCore().byId(sExtensionInputIdPrefix + this.getOwnerComponent().aFields[i].name).getValueStateText() 
//       && sap.ui.getCore().byId(sExtensionInputIdPrefix + this.getOwnerComponent().aFields[i].name).getValueStateText() !== ""
//       && sap.ui.getCore().byId(sExtensionInputIdPrefix + this.getOwnerComponent().aFields[i].name).getValueState() === sap.ui.core.ValueState.Error) {
//       this.bFieldError = true;
//       bCDFError = true;
//      }
//     }
//
//     if (this._validateRequiredCDF(sExtensionLabelIdPrefix, sExtensionInputIdPrefix, this.getOwnerComponent().aFields[i].name)) {
//      this.bFieldIsEmpty = true;
//     }
//
//     if(bCDFError){
//      sap.ui.getCore().byId(sExtensionInputIdPrefix + this.getOwnerComponent().aFields[i].name).setValueState(sap.ui.core.ValueState.Error);
//     }
//    }
//   }
//  },
//
//  _validateRequiredCDF: function (sLabelId, sInputId, sFieldName) {
//   var sFieldCDFIsEmpty = false;
//   if(sap.ui.getCore().byId(sInputId + sFieldName).setValueState){
//    sap.ui.getCore().byId(sInputId + sFieldName).setValueState(sap.ui.core.ValueState.None);
//   }
//   if (sap.ui.getCore().byId(sLabelId + sFieldName).getRequired() && (!this.oFindingNewData[sFieldName] || this.oFindingNewData[
//     sFieldName] === "")) {
//    if(sap.ui.getCore().byId(sInputId + sFieldName).setValueState){
//     sap.ui.getCore().byId(sInputId + sFieldName).setValueState(sap.ui.core.ValueState.Error);
//    }
//    sFieldCDFIsEmpty = true;
//   }
//   return sFieldCDFIsEmpty;
//  },
//
//  _collectFindingData: function () {
//   this.oFindingNewData = {};
//
//   this.oFindingNewData.AuditKey = this.sAuditKey;
//   this.oFindingNewData.AuditGroup = this.sAuditGroup;
//
//   //** get non-cdf field value
//   // Title
//   this.oFindingNewData.Title = this.getView().byId("inputTitle").getValue();
//   // Description
//   this.oFindingNewData.Description = this.getView().byId("inputDescription").getValue();
//   this.oFindingNewData.Recommendation = this.getView().byId("inputRecommendation").getValue();
//   this.oFindingNewData.Criteria = this.getView().byId("inputCriteria").getValue();
//   this.oFindingNewData.ConditionDescription = this.getView().byId("inputConditionDescription").getValue();
//   this.oFindingNewData.CauseDescription = this.getView().byId("inputCauseDescription").getValue();
//   this.oFindingNewData.ConsequenceDescription = this.getView().byId("inputConsequenceDescription").getValue();
//
//   // FindingType
//   if (this.getView().byId("inputType").getSelectedItem()) {
//    this.oFindingNewData.Type = this.getView().byId("inputType").getSelectedItem().getKey();
//   }
//   // Finding Category
//   if (this.getView().byId("inputCategory").getSelectedItem()) {
//    this.oFindingNewData.Category = this.getView().byId("inputCategory").getSelectedItem().getKey();
//   }
//   // Finding Ranking
//   if (this.getView().byId("inputRanking").getSelectedItem()) {
//    this.oFindingNewData.Ranking = this.getView().byId("inputRanking").getSelectedItem().getKey();
//   }
//
//   // collect responsible preson
//   this.aExecutiveResponsible = [];
//   if (this.getView().byId("inputExecutiveResponsible").getSelectedKey() && this.getView().byId(
//     "inputExecutiveResponsible").getSelectedKey() !== "") {
//    this.aExecutiveResponsible.push(this.getView().byId("inputExecutiveResponsible").getSelectedItem().getBindingContext()
//     .getObject());
//   }
//   // collect organization
//   this.oAssignedOrganization = {};
//   if (this.getView().byId("inputOrganization").getSelectedKey() && this.getView().byId(
//     "inputOrganization").getSelectedKey() !== "") {
//    this.oAssignedOrganization = this.getView().byId("inputOrganization").getSelectedItem().getBindingContext().getObject();
//   }
//
//   // collect reference
//   this.oReference = {};
//   if (this.getView().byId("inputReference").getSelectedKey() && this.getView().byId(
//     "inputReference").getSelectedKey() !== "") {
//    this.oReference = this.getView().byId("inputReference").getSelectedItem().getBindingContext().getObject();
//   }
//
//   // collect tags
//   this.aTags = [];
//   var aTokens = this.getView().byId("inputTags").getTokens();
//   for (var i = 0; i < aTokens.length; i++) {
//    this.aTags.push(aTokens[i].getText());
//   }
//   this.oFindingNewData.Tags = this.aTags.join(";");
//
//   this._setFindingCDFData();
//
//   return this.oFindingNewData;
//  },
//
//  _setFindingCDFData: function(){
//   //get cdf field value
//   this.aFields = this.getOwnerComponent().aFields;
//   var oCDFData = FieldExtensibilityUtil.saveCDFInCreateMode(this.aFields);              
//   for (var key in oCDFData) {
//       this.oFindingNewData[key] = oCDFData[key];
//   }
//  },
//
//  //delete undefined attribute
//  _cleanFindingData: function (obj) {
//   for (var propName in obj) {
//    if (obj[propName] === null || obj[propName] === undefined) {
//     delete obj[propName];
//    }
//   }
//   return obj;
//  }
// });
//
//});

	  /**
	   * Called when a controller is instantiated and its View controls (if available) are already created.
	   * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
	   * @memberOf src.sap.grc.acs.aud.audit.view.Create
	   */
	  onInit: function () {

	   if (this.getRouter() && this.getRouter().getRoute("create")) {
	    this.getRouter().getRoute("create").attachPatternMatched(this._onRoutePatterMatched, this);
	   }

	   var oThreeColumnLayoutData = {
	     labelSpanS:12, labelSpanM:12, labelSpanL:12, labelSpanXL:12,
	     columnsM: 3, columnsL: 3, columnsXL: 3
	    },
	    oTwoColumnLayoutData = {
	     labelSpanS:12, labelSpanM:12, labelSpanL:12, labelSpanXL:12,
	     columnsM: 2, columnsL: 2, columnsXL: 2
	    };
	   this._oThreeColumnsLayout = new sap.ui.comp.smartform.Layout(oThreeColumnLayoutData);
	   this._oTwoColumnsLayout = new sap.ui.comp.smartform.Layout(oTwoColumnLayoutData);

	   var oExtensionModel = new sap.ui.model.json.JSONModel();
	   this.setModel(oExtensionModel, "extensionModel");

	   this.aTextTypedField = ["Title", "Description", "Type", "Category", "Ranking", "Recommendation", 
	         "Criteria", "ConditionDescription", "CauseDescription", "ConsequenceDescription"];

	   this.getView().byId("inputTags").addValidator(this._validateTag.bind(this));

	  },

	  /**
	   * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
	   * @memberOf src.sap.grc.acs.aud.audit.view.Object
	   */
	  onExit: function () {
	   if (this.getView().getBindingContext()) {
	    this._destoryFields();
	   }
	  },

	  /**
	   * Binds the view to the create path.
	   * @function
	   * @param {sap.ui.base.Event} oEvent pattern match event in route 'create'
	   * @private
	   */
	  _onRoutePatterMatched: function (oEvent) {

	   this.sAuditKey =  oEvent.getParameter("arguments").auditKey;
	   this.sAuditGroup =  oEvent.getParameter("arguments").auditGroup;
	   this.sAuditType =   oEvent.getParameter("arguments").auditType;
	   this.sTaskKey = "";
	   this.sObjectType = "";
	   this.sIntent = this.getOwnerComponent().getModel("intentConfig").getData().intent;

	   var oQuery = oEvent.getParameter("arguments")["?query"];
	   if(oQuery){
	    this.sTaskKey = oQuery.TaskKey;
	    this.sObjectType = oQuery.ObjectType;
	   }

	   this.getModel().metadataLoaded().then(this._bindView.bind(this));
	  },

	  /**
	   * Binds the view to the object path.
	   * @function
	   * @param {string} sObjectPath path to the object to be bound
	   * @private
	   */
	  _bindView: function () {

	   this.getModel().setDeferredGroups(["createFinding", "createFindingData"]);

	   this.bEstimatedFieldError = false;

	   this.createBindingContext();
	   this.getView().setModel(this.getExtensionModel(this.sAuditType), "extensionModel");
	   this.createExtensionGroup();
	   this.bindOrganization(this.sAuditKey);
	   this.bindReference(this.sAuditKey);
	   this.bindFindingExecutiveResponsible(this.sAuditKey);
	   this.bindFindingRanking(this.sAuditType);
	  },

	  onNavBack: function () {
	   this._destoryFields();
	   this._resetUIState();
	   this._clearFieldValueStatus();

	   var sPreviousHash = History.getInstance().getPreviousHash(),
	    oCrossAppNavigator = this.getOwnerComponent().getCrossAppNavigator();
	   if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation() || this.getOwnerComponent().isAppToAppNavigation()) {
	    history.go(-1);
	   }

	  },

	  onCreateBtnPress: function(){
	   if (this._validateUI()) {
	    this.getView().setBusy(true);
	    this._createFinding();
	   }
	  },

	  onCancelBtnPress: function() {
	   this.onNavBack();
	  },

	  handleSuggest: function(oEvent){
	   var sTerm = oEvent.getParameter("suggestValue");
	   var aFilters = [];
	   if (sTerm) {
	    aFilters.push(new sap.ui.model.Filter("TagName", sap.ui.model.FilterOperator.Contains, sTerm));
	   }
	   oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
	  },

	  onChangeResetUI: function(oEvent) {
	   oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
	  },

	  createBindingContext: function () {
	   var oBindingContext = this.getModel().createEntry("GRCAUD_CV_Finding", {
	    groupId: "createFindingData"
	   });
	   this.getView().setBindingContext(oBindingContext);
	  },

	  getExtensionModel: function (sAuditType) {
	   var oExtensionModel = new sap.ui.model.json.JSONModel();
	   var sObjectStatus = "";
	   var oMenuItemConfigData = {
	    SmartForm: undefined
	   };
	   oExtensionModel.setData(
	    FieldExtensibilityUtil.getExtensionFieldsStatus("Finding",
	     sAuditType, sObjectStatus, this.getModel().getServiceMetadata(), oMenuItemConfigData, this.getOwnerComponent(), this.sIntent),
	    true);
	   return oExtensionModel;
	  },

	  createExtensionGroup: function () {
	   var oExtensionGroup = this.getView().byId("extensionGroup");
	   FieldExtensibilityUtil.createExtensionGroup("Finding", oExtensionGroup, this.getOwnerComponent(), sap.grc.acs.lib.aud.utils.Constant.Mode.CREATE);
	   if (oExtensionGroup.getVisible()) {
	    this.getView().byId("smartForm").setLayout(this._oThreeColumnsLayout);
	   } else {
	    this.getView().byId("smartForm").setLayout(this._oTwoColumnsLayout);
	   }
	  },

	  _destoryFields: function() {
	   this.getView().getModel().deleteCreatedEntry(this.getView().getBindingContext());
	   var oExtensionGroup = this.getView().byId("extensionGroup");
	   oExtensionGroup.destroyGroupElements();
	  },

	  _validateTag: function (args) {
	   var sText = args.text;
	   if (sText.indexOf(";") !== -1) {
	    MessageUtil.showMsg("msgTypeFailed", this.getModel("i18n").getResourceBundle().getText("MSG_TAGS_FORBIDDEN_CHAR"));
	    return sap.m.MultiInput.WaitForAsyncValidation;
	   } else {
	    return new sap.m.Token({
	     key: sText,
	     text: sText
	    });
	   }
	  },

	  _bindSelectField: function (sControlId, sPath, sSelectionKey, sSelectionText, aFilters, aSorters, sAdditionalText, bShowEmptyItem) {
	   var oDataModel = this.getModel();
	   var oSelect = this.getView().byId(sControlId);
	   oSelect.setBusy(true);
	   oDataModel.read(sPath, {
	    filters: aFilters,
	    sorters: aSorters,
	    success: jQuery.proxy(function(data, response) {
	     var oTemplate;
	     var aItemList = data.results;
	     if (bShowEmptyItem) {
	      var oEmptyResult = {};
	      oEmptyResult[sSelectionKey] = null;
	      oEmptyResult[sSelectionText] = "";
	      oEmptyResult[sAdditionalText] = "";
	      var aEmptyResult = [oEmptyResult];
	      aItemList = aEmptyResult.concat(data.results);
	     }
	     if (sAdditionalText) {
	      oTemplate = new sap.ui.core.ListItem({
	       key: "{" + sSelectionKey + "}",
	       text: "{" + sSelectionText + "}",
	       additionalText: "{" + sAdditionalText + "}"
	      });
	     } else {
	      oTemplate = new sap.ui.core.ListItem({
	       key: "{" + sSelectionKey + "}",
	       text: "{" + sSelectionText + "}"
	      });
	     }
	     var oModel = new sap.ui.model.json.JSONModel(aItemList);
	     oSelect.setModel(oModel);
	     oSelect.bindItems("/", oTemplate);
	     oSelect.setBusy(false);
	    } ,this),
	    async: true
	   });
	  },

	  bindOrganization: function (sAuditKey) {
	   var sPath = "/GRCAUD_CV_OrganizationByAudit",
	    sControlId = "inputOrganization",
	    sSelectionKey = "OrgKey",
	    sSelectionText = "OrgID",
	    sAdditionalText = "OrgName";

	   var aFilters = [new sap.ui.model.Filter("DBKey",
	    sap.ui.model.FilterOperator.EQ,
	    sAuditKey)];
	   var aSorters = [new sap.ui.model.Sorter("OrgID")];
	   this._bindSelectField(sControlId, sPath, sSelectionKey, sSelectionText, aFilters, aSorters, sAdditionalText, true);
	  },

	  bindReference: function (sAuditKey) {
	   var sPath = "/GRCAUD_CV_AssignedScopeHier",
	    sControlId = "inputReference",
	    sSelectionKey = "DBKey",
	    sSelectionText = "Code",
	    sAdditionalText = "Name";

	   var aFilters = [new sap.ui.model.Filter("AuditKey",
	     sap.ui.model.FilterOperator.EQ,
	     sAuditKey),
	    new sap.ui.model.Filter("DrillState",
	     sap.ui.model.FilterOperator.EQ,
	     "leaf")
	   ];
	   var aSorters = [new sap.ui.model.Sorter("Code")];
	   this._bindSelectField(sControlId, sPath, sSelectionKey, sSelectionText, aFilters, aSorters, sAdditionalText, true);
	  },
	  bindFindingRanking: function (sAuditType) {
	   var sPath = "/FindingRankingByAuditTypeSet",
	    sControlId = "inputRanking",
	    sSelectionKey = "Ranking",
	    sSelectionText = "Description",
	    sAdditionalText = "";

	   var aFilters = [new sap.ui.model.Filter("AuditType",
	     sap.ui.model.FilterOperator.EQ,
	     sAuditType)
	   ];
	   var aSorters = [new sap.ui.model.Sorter("Ranking")];
	   this._bindSelectField(sControlId, sPath, sSelectionKey, sSelectionText, aFilters, aSorters, sAdditionalText, true);
	  },

	  bindFindingExecutiveResponsible: function (sAuditKey) {
	   var sPath = "/GRCAUD_CV_AuditUserRole",
	    sControlId = "inputExecutiveResponsible",
	    sSelectionKey = "UserID",
	    sSelectionText = "FullName",
	    sAdditionalText = "FullName";

	   var aFilters = [new sap.ui.model.Filter("HostKey",
	     sap.ui.model.FilterOperator.EQ,
	     sAuditKey),
	    new sap.ui.model.Filter("RoleID",
	     sap.ui.model.FilterOperator.EQ,
	     "EXE_RESP")
	   ];
	   var aSorters = [new sap.ui.model.Sorter("UserID")];
	   this._bindSelectField(sControlId, sPath, sSelectionKey, sSelectionText, aFilters, aSorters, sAdditionalText, true);
	  },

	  _createFinding: function () {
	   var oDataModel = this.getModel();
	   var oData = this.oFindingNewData;
	   var sFindingPath = ""; //create finding - fiori
	   var sFindingKey = "";

	   if ( this.sObjectType === "QTASK" ){
	       sFindingPath = "/GRCAUD_CV_FindingByQTask";
	       oData.DBKey = this.sTaskKey;
	       oData.FindingKey = CommonUtil.generateGuid();
	       sFindingKey = oData.FindingKey;
	      }else if ( this.sObjectType === "MTASK" ){
	       sFindingPath = "/GRCAUD_CV_FindingByManualTask";
	       oData.DBKey = this.sTaskKey;
	       oData.FindingKey = CommonUtil.generateGuid();
	       sFindingKey = oData.FindingKey;
	      }else if ( this.sObjectType === "CTASK" ){
	       sFindingPath = "/GRCAUD_CV_FindingByCCMTask";
	       oData.DBKey = this.sTaskKey;
	       oData.FindingKey = CommonUtil.generateGuid();
	       sFindingKey = oData.FindingKey;
	      }else{
	       sFindingPath = "/GRCAUD_CV_Finding";
	       oData.DBKey = CommonUtil.generateGuid();
	       sFindingKey = oData.DBKey;
	      }

	   oData = this._cleanFindingData(oData);
	   oDataModel.setUseBatch(true);

	   oDataModel.create(sFindingPath, oData, {
	    groupId: "createFinding"
	   });
	   this._createFindingExecutiveResponsible(sFindingKey);
	   this._createFindingReference(sFindingKey);
	   this._createFindingOrganizationAssignment(sFindingKey);
	   // this._createFindingTags(oData.DBKey);

	   oDataModel.submitChanges({
	    groupId: "createFinding",
	    success: jQuery.proxy(function (oDataNew, oResponse) {
	     if (oDataNew.__batchResponses[0].message) {
	      this.getView().setBusy(false);
	     } else {
	      MessageUtil.showMsg("msgTypeSuccessful", this.getModel("i18n").getResourceBundle().getText("CREATE_FINDING_SUCCESS"));
	      this.getView().setBusy(false);
	      oDataModel.refresh();
	      this.onNavBack();
	     }
	    }, this),
	    error: jQuery.proxy(function () {
	     this.getView().setBusy(false);
	     MessageUtil.showMsg("msgTypeFailed", this.getModel("i18n").getResourceBundle().getText("CREATE_FINDING_FAILED"));
	    }, this)
	   });
	  },

	  _createFindingExecutiveResponsible: function (sFindingDBKey) {
	   var oDataModel = this.getModel();
	   //no responsible preson
	   if (this.aExecutiveResponsible.length === 0) {
	    return;
	   } else {
	    var sPath = "/" + oDataModel.createKey("GRCAUD_CV_Finding", {
	     DBKey: sFindingDBKey
	    }) + "/to_ExecutiveResponsible";
	    // var sPath = "/GRCAUD_CV_Finding(guid" + "'" + sFindingDBKey + "')/to_ExecutiveResponsible";
	    // for (var i = 0; i < this.aExecutiveResponsible.length; i++) {
	     var oUser = {
	      UserID: this.aExecutiveResponsible[0].UserID,
	      RoleID: "EXE_RESP",
	      HostKey: sFindingDBKey,
	      userSequence: 0 + ""
	     };
	     oDataModel.create(sPath, oUser, {
	      groupId: "createFinding"
	     });
	    }
	   // }
	  },

	  _createFindingReference: function (sFindingDBKey) {
	   var oDataModel = this.getModel();
	   if (this.oReference.DBKey) {
	    var sPath = "/GRCAUD_CV_ScopeReference";
	    var oReference = {
	     ScopeKey: this.oReference.DBKey,
	     ParentKey: sFindingDBKey,
	     RootKey: this.sAuditKey
	    };
	    oDataModel.create(sPath, oReference, {
	     groupId: "createFinding"
	    });
	   } else {
	    return;
	   }
	  },

	  _createFindingOrganizationAssignment: function (sFindingDBKey) {
	   var oDataModel = this.getModel();
	   if (this.oAssignedOrganization.DBKey) {
	    var sPath = "/GRCAUD_CV_OrgByFinding";
	    var oOrgAssignment = {
	     OrgKey: this.oAssignedOrganization.OrgKey,
	     ParentKey: sFindingDBKey,
	     RootKey: this.sAuditKey
	    };
	    oDataModel.create(sPath, oOrgAssignment, {
	     groupId: "createFinding"
	    });
	   } else {
	    return;
	   }
	  },

	  //reset ui to initial status
	  _clearFieldValueStatus: function () {
	   this.getView().byId("inputType").setSelectedItem(null);
	   this.getView().byId("inputCategory").setSelectedItem(null);
	   this.getView().byId("inputRanking").setSelectedItem(null);
	   this.getView().byId("inputTags").removeAllTokens();
	  },

	  // Restore field value state before checking
	  _resetUIState: function () {
	   this.getView().byId("inputTitle").setValueState(sap.ui.core.ValueState.None);
	   this.getView().byId("inputType").setValueState(sap.ui.core.ValueState.None);
	   this.getView().byId("inputCategory").setValueState(sap.ui.core.ValueState.None);
	   this.getView().byId("inputRanking").setValueState(sap.ui.core.ValueState.None);
	   this.getView().byId("inputCriteria").setValueState(sap.ui.core.ValueState.None);
	   this.getView().byId("inputConditionDescription").setValueState(sap.ui.core.ValueState.None);
	   this.getView().byId("inputCauseDescription").setValueState(sap.ui.core.ValueState.None);
	   this.getView().byId("inputConsequenceDescription").setValueState(sap.ui.core.ValueState.None);
	   this.getView().byId("inputRecommendation").setValueState(sap.ui.core.ValueState.None);
	  },

	  _validateTextTypedField: function (sFieldName) {
	   var sLableId = "label" + sFieldName,
	    sInputId = "input" + sFieldName;
	   if (this.getView().byId(sLableId).getRequired() && (!this.oFindingNewData[sFieldName] || this.oFindingNewData[sFieldName] === "")) {
	    this.getView().byId(sInputId).setValueState(sap.ui.core.ValueState.Error);
	    this.bFieldIsEmpty = true;
	   }
	  },

	  //input validation
	  _validateUI: function () {
	   this._collectFindingData();
	   this._resetUIState();

	   this.bFieldIsEmpty = false;
	   this.bFieldError = false;

	   for (var i = 0; i < this.aTextTypedField.length; i++) {
	    this._validateTextTypedField(this.aTextTypedField[i]);
	   }

	   // validate cdf fields
	   this._validateCDF();

	   if (this.bFieldIsEmpty) {
	    MessageUtil.showMsg("msgTypeFailed", this.getModel("i18n").getResourceBundle().getText("MSG_REQUIRED_FIELD"));
	    return false;
	   }
	   if (this.bFieldError) {
	    MessageUtil.showMsg("msgTypeFailed", this.getModel("i18n").getResourceBundle().getText("MSG_ERROR_NOT_HANDLE"));
	    return false;
	   }

	   return true;
	  },

	  _validateCDF: function(){
	   for (var i = 0; i < this.getOwnerComponent().aFields.length; i++) {
	    var bCDFError = false;
	    if (this.getOwnerComponent().aFields[i].isExtensionField) {
	     var sExtensionLabelIdPrefix = sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud.utils.Constant.DIALOGID
	      .EXTENSION_LABEL;
	     var sExtensionInputIdPrefix = sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud.utils.Constant.DIALOGID
	      .EXTENSION_INPUT;
	     if(sap.ui.getCore().byId(sExtensionInputIdPrefix + this.getOwnerComponent().aFields[i].name).getValueState){
	      if (sap.ui.getCore().byId(sExtensionInputIdPrefix + this.getOwnerComponent().aFields[i].name).getValueStateText() 
	       && sap.ui.getCore().byId(sExtensionInputIdPrefix + this.getOwnerComponent().aFields[i].name).getValueStateText() !== ""
	       && sap.ui.getCore().byId(sExtensionInputIdPrefix + this.getOwnerComponent().aFields[i].name).getValueState() === sap.ui.core.ValueState.Error) {
	       this.bFieldError = true;
	       bCDFError = true;
	      }
	     }

	     if (this._validateRequiredCDF(sExtensionLabelIdPrefix, sExtensionInputIdPrefix, this.getOwnerComponent().aFields[i].name)) {
	      this.bFieldIsEmpty = true;
	     }

	     if(bCDFError){
	      sap.ui.getCore().byId(sExtensionInputIdPrefix + this.getOwnerComponent().aFields[i].name).setValueState(sap.ui.core.ValueState.Error);
	     }
	    }
	   }
	  },

	  _validateRequiredCDF: function (sLabelId, sInputId, sFieldName) {
	   var sFieldCDFIsEmpty = false;
	   if(sap.ui.getCore().byId(sInputId + sFieldName).setValueState){
	    sap.ui.getCore().byId(sInputId + sFieldName).setValueState(sap.ui.core.ValueState.None);
	   }
	   if (sap.ui.getCore().byId(sLabelId + sFieldName).getRequired() && (!this.oFindingNewData[sFieldName] || this.oFindingNewData[
	     sFieldName] === "")) {
	    if(sap.ui.getCore().byId(sInputId + sFieldName).setValueState){
	     sap.ui.getCore().byId(sInputId + sFieldName).setValueState(sap.ui.core.ValueState.Error);
	    }
	    sFieldCDFIsEmpty = true;
	   }
	   return sFieldCDFIsEmpty;
	  },

	  _collectFindingData: function () {
	   this.oFindingNewData = {};

	   this.oFindingNewData.AuditKey = this.sAuditKey;
	   this.oFindingNewData.AuditGroup = this.sAuditGroup;

	   //** get non-cdf field value
	   // Title
	   this.oFindingNewData.Title = this.getView().byId("inputTitle").getValue();
	   // Description
	   this.oFindingNewData.Description = this.getView().byId("inputDescription").getValue();
	   this.oFindingNewData.Recommendation = this.getView().byId("inputRecommendation").getValue();
	   this.oFindingNewData.Criteria = this.getView().byId("inputCriteria").getValue();
	   this.oFindingNewData.ConditionDescription = this.getView().byId("inputConditionDescription").getValue();
	   this.oFindingNewData.CauseDescription = this.getView().byId("inputCauseDescription").getValue();
	   this.oFindingNewData.ConsequenceDescription = this.getView().byId("inputConsequenceDescription").getValue();

	   // FindingType
	   if (this.getView().byId("inputType").getSelectedItem()) {
	    this.oFindingNewData.Type = this.getView().byId("inputType").getSelectedItem().getKey();
	   }
	   // Finding Category
	   if (this.getView().byId("inputCategory").getSelectedItem()) {
	    this.oFindingNewData.Category = this.getView().byId("inputCategory").getSelectedItem().getKey();
	   }
	   // Finding Ranking
	   if (this.getView().byId("inputRanking").getSelectedItem()) {
	    this.oFindingNewData.Ranking = this.getView().byId("inputRanking").getSelectedItem().getKey();
	   }

	   // collect responsible preson
	   this.aExecutiveResponsible = [];
	   if (this.getView().byId("inputExecutiveResponsible").getSelectedKey() && this.getView().byId(
	     "inputExecutiveResponsible").getSelectedKey() !== "") {
	    this.aExecutiveResponsible.push(this.getView().byId("inputExecutiveResponsible").getSelectedItem().getBindingContext()
	     .getObject());
	   }
	   // collect organization
	   this.oAssignedOrganization = {};
	   if (this.getView().byId("inputOrganization").getSelectedKey() && this.getView().byId(
	     "inputOrganization").getSelectedKey() !== "") {
	    this.oAssignedOrganization = this.getView().byId("inputOrganization").getSelectedItem().getBindingContext().getObject();
	   }

	   // collect reference
	   this.oReference = {};
	   if (this.getView().byId("inputReference").getSelectedKey() && this.getView().byId(
	     "inputReference").getSelectedKey() !== "") {
	    this.oReference = this.getView().byId("inputReference").getSelectedItem().getBindingContext().getObject();
	   }

	   // collect tags
	   this.aTags = [];
	   var aTokens = this.getView().byId("inputTags").getTokens();
	   for (var i = 0; i < aTokens.length; i++) {
	    this.aTags.push(aTokens[i].getText());
	   }
	   this.oFindingNewData.Tags = this.aTags.join(";");

	   this._setFindingCDFData();

	   return this.oFindingNewData;
	  },

	  _setFindingCDFData: function(){
	   //get cdf field value
	   this.aFields = this.getOwnerComponent().aFields;
	   var oCDFData = FieldExtensibilityUtil.saveCDFInCreateMode(this.aFields);              
	   for (var key in oCDFData) {
	       this.oFindingNewData[key] = oCDFData[key];
	   }
	  },

	  //delete undefined attribute
	  _cleanFindingData: function (obj) {
	   for (var propName in obj) {
	    if (obj[propName] === null || obj[propName] === undefined) {
	     delete obj[propName];
	    }
	   }
	   return obj;
	  }
	 });

	});