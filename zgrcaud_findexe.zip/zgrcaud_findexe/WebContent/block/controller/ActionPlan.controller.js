/*
 * Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(
 [
  "sap/grc/acs/aud/finding/controller/BaseController",
  "sap/grc/acs/lib/aud/utils/MenuItemUtils",
  "sap/grc/acs/lib/aud/utils/ComponentUtil",
  "sap/grc/acs/lib/aud/utils/MessageUtil"
 ],
 function(BaseController, MenuItemUtils, ComponentUtil, MessageUtil) {
  "use strict";

  return BaseController.extend("sap.grc.acs.aud.finding.extended.block.controller.ActionPlan", {

   /**
    * Called when a controller is instantiated and its View controls (if available) are already created.
    * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
    * @memberOf sap.grc.acs.aud.finding.block.view.general
    */
   onInit: function() {
    this._Component = ComponentUtil.getComponentById(this.getView().getId());
    sap.ui.getCore().getEventBus().subscribe("sap.grc.acs.aud.find.EventBus", "resetBlockToDisplayMode", this.onRefresh, this);
   },

   /**
    * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
    * (NOT before the first rendering! onInit() is used for that one!).
    * @memberOf sap.grc.acs.aud.finding.block.view.general
    */
   // onBeforeRendering: function() {
   //
   // },

   /**
    * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
    * This hook is the same one that SAPUI5 controls get after being rendered.
    * @memberOf sap.grc.acs.aud.finding.block.view.general
    */
   // onAfterRendering: function() {
   //
   // },

   /**
    * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
    * @memberOf sap.grc.acs.aud.finding.block.view.general
    */
   onExit: function() {
    sap.ui.getCore().getEventBus().unsubscribe("sap.grc.acs.aud.find.EventBus", "resetBlockToDisplayMode", this.onRefresh, this);
   },

   onUpdateFinished: function() {
    if (this.changeSequenceFlag) {
     this.changeSequenceFlag = false;
     return;
    } else {
     this.changeSequenceFlag = false;
     this.onRefresh();
    }
   },

   _createActionPlanSequence: function() {
    var aActions = this.getView().byId("tableActionPlan").getItems();
    for (var i = 0; i < aActions.length; i++) {
     var sKey = aActions[i].getBindingContext().getObject().DBKey;
     var sSeq = aActions[i].getBindingContext().getObject().Sequence;
     var sStatus = aActions[i].getBindingContext().getObject().Status;
     if (sStatus === "") {
      aActions[i].getCells()[2].setEditable(true);
     } else {
      aActions[i].getCells()[2].setEditable(false);
     }
     this.aExistActionSequence.push({
      "actionKey": sKey,
      "sequence": sSeq
     });
     this.aOriginalActionSequence.push({
      "actionKey": sKey,
      "sequence": sSeq
     });
    }
   },

   //navigate to the action app
   onPressRow: function(oEvent) {
    var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
    var iStatus = "";
    var sAction = "displayAuditFollowUp";
    iStatus = oEvent.getSource().getBindingContext().getObject().Status;
    if (this._Component.getModel("intentConfig").getData().intent === "Finding-myFinding") {
     var oNavigationConfig = this._Component.getModel("navigationConfig").getData();
     sAction = oNavigationConfig[iStatus];
     if (sAction === undefined) {
      sAction = oNavigationConfig.default;
     }
    } else if (this._Component.getModel("intentConfig").getData().intent === "Finding-displayFindingByMyAction") {
     sAction = "myAction";
    } else {
     if (iStatus === "") {
      sAction = "updateAuditFollowUp";
     }
    }

    var oExternalTarget = {
     target: {
      semanticObject: "Action",
      action: sAction
     },
     params: {
      "DBKey": oEvent.getSource().getBindingContext().getObject().DBKey
     }
    };
    var sHref = oCrossAppNavigator.hrefForExternal(oExternalTarget);
    window.open(sHref, "_self");
   },

   createHeaderButton: function(sId, oContext) {
    return MenuItemUtils.createButtonTemplate(sId, oContext, this);
   },

   ACTION_CREATE_ROOT: function() {
    var oAudit = this.getView().getBindingContext().getProperty("to_Audit");
    var oFindingView = this.getView();
    if (!this._oCreateActionDialog) {
     this._oCreateActionDialog = sap.ui.getCore().createComponent({
      name: "sap.grc.acs.aud.action.creation"
     });
    }
    var sIntent = this.getModel("intentConfig").getData().intent;
    this._oCreateActionDialog.open(oAudit, oFindingView, sIntent);
   },

   ACTION_UPDATE_ROOT: function() {
    this._setButtonVisibility("EDIT");
    this.aExistActionSequence = [];
    this.aOriginalActionSequence = [];
    this._createActionPlanSequence();
    var oColumnSeq = this.getView().byId("colSequence");
    oColumnSeq.setVisible(true);
    this.aChangedData = [];
    this.aChangedAction = [];
    this.editActionFlag = true;
   },

   _updateEntity: function(oDataModel, oTable, oColumnSeq, oEntityType, i){
    var sPath = "/" + oEntityType + "(guid'" + this.aChangedData[i].DBKey + "')";
    oDataModel.update(sPath, {
     Sequence: this.aChangedData[i].Sequence
    }, {
     success: jQuery.proxy(function() {
      this._setButtonVisibility("DISPLAY");
      oTable.setBusy(false);
      MessageUtil.showMsg("msgTypeSuccessful", this.getModel("i18n").getResourceBundle().getText("EDIT_ACTION_SUCCESS"));
      this.saveActionFlag = true;
      this.getView().getModel().refresh(true);
      oColumnSeq.setVisible(false);
     }, this),
     error: jQuery.proxy(function() {
      this._setButtonVisibility("DISPLAY");
      oTable.setBusy(false);
      oColumnSeq.setVisible(false);
     }, this),
     groupId: "saveSequence",
     async: true,
     merge: true
    });
   },
   onSaveBtnPress: function() {
    var oTable = this.getView().byId("tableActionPlan");
    var oEntityType = "GRCAUD_CV_ActionByFinding";
    if(this._Component.getModel("intentConfig").getData().intent === "Finding-myFinding"){
     oEntityType = "GRCAUD_CV_ActionByMyFinding";
    }
    if (this._validationDuplicateSequenceAndError(oTable)) {
     var oColumnSeq = this.getView().byId("colSequence");
     //save sequence
     var oDataModel = this.getView().getModel();
     if (this.aChangedData.length > 0) {
      oTable.setBusy(true);
      for (var i = 0; i < this.aChangedData.length; i++) {
       this._updateEntity(oDataModel, oTable, oColumnSeq, oEntityType, i);
      }
     } else {
      this._setButtonVisibility("DISPLAY");
      oColumnSeq.setVisible(false);
     }

    }
   },

   onCancelBtnPress: function() {
    var oTable = this.getView().byId("tableActionPlan");
    var aCurrentActions = oTable.getItems();
    // reset table
    for (var i = 0; i < this.aOriginalActionSequence.length; i++) {
     aCurrentActions[i].getCells()[2].setValue(this.aOriginalActionSequence[i].sequence);
     aCurrentActions[i].getCells()[2].setValueState(sap.ui.core.ValueState.None);
    }
    MessageUtil.showMsg("msgTypeSuccessful", this.getModel("i18n").getResourceBundle().getText("NOTHING_UPDATED"));
    var oColumnSeq = this.getView().byId("colSequence");
    this._setButtonVisibility("DISPLAY");
    // this.getView().getModel().refresh(true);
    oColumnSeq.setVisible(false);
   },

   onRefresh: function() {
    this._setButtonVisibility("DISPLAY");
    //in action plan edit mode, but refresh the whole model
    if (this.editActionFlag && !this.saveActionFlag) {
     var oTable = this.getView().byId("tableActionPlan");
     var aCurrentActions = oTable.getItems();
     for (var i = 0; i < this.aOriginalActionSequence.length; i++) {
      aCurrentActions[i].getCells()[2].setValue(this.aOriginalActionSequence[i].sequence);
      aCurrentActions[i].getCells()[2].setValueState(sap.ui.core.ValueState.None);
     }
    }
    this.saveActionFlag = false;
    this.editActionFlag = false;
    this.getView().byId("colSequence").setVisible(false);
   },

   _setButtonVisibility: function(sMode) {
    var oHeaderContents = this.getView().byId("actionToolbar").getAggregation("content");
    var oEditButtonControl = null;
    var oCancelButtonControl = null;
    var oSaveButtonControl = null;
    var oAddButtonControl = null;
    for (var i = 0; i < oHeaderContents.length; i++) {
     switch (oHeaderContents[i].getId()) {
      case "btnSave":
       oSaveButtonControl = oHeaderContents[i];
       break;
      case "btnCancel":
       oCancelButtonControl = oHeaderContents[i];
       break;
      case "ACTION-UPDATE_ROOT":
       oEditButtonControl = oHeaderContents[i];
       break;
      case "ACTION-CREATE_ROOT":
       oAddButtonControl = oHeaderContents[i];
       break;
      default:
       break;
     }
    }
    if (sMode === "EDIT") {
     if (oEditButtonControl !== null && oAddButtonControl !== null) {
      oEditButtonControl.setVisible(false);
      oAddButtonControl.setVisible(false);
      oCancelButtonControl.setVisible(true);
      oSaveButtonControl.setVisible(true);
     }
    } else if (sMode === "DISPLAY") {
     if (oEditButtonControl !== null && oAddButtonControl !== null) {
      oEditButtonControl.setVisible(true);
      oAddButtonControl.setVisible(true);
      oCancelButtonControl.setVisible(false);
      oSaveButtonControl.setVisible(false);
     }
    } else {
     if (oEditButtonControl !== null && oAddButtonControl !== null) {
      oEditButtonControl.setVisible(false);
      oAddButtonControl.setVisible(false);
      oCancelButtonControl.setVisible(false);
      oSaveButtonControl.setVisible(false);
     }
    }
    if (this.getView().byId("actionToolbar").getContent().length !== 0) {
     this.getView().byId("actionToolbar").setVisible(true);
    } else {
     this.getView().byId("actionToolbar").setVisible(false);
    }
   },

   _setChange: function(sActionKey, i, aExistActionSequence, aChangedAction){
    aExistActionSequence[i].sequence = null;
    var oChangedAction = {
     "index": i,
     "actionKey": sActionKey
    };
    var found = aChangedAction.some(function(el){
     return el.actionKey === sActionKey; 
    });
    if (!found) {
     aChangedAction.push(oChangedAction);
    }
   },
   editActionSeq: function(oEvent) {
    this.changeSequenceFlag = true;
    var sActionKey = oEvent.getSource().getBindingContext().getObject().DBKey;
    this.saveConfirmTag = true;
    var oInput = oEvent.getSource();
    var oValue = oInput.getValue();
    oInput.setValueState(sap.ui.core.ValueState.None);
    var sNumberMatch = /^[0-9]\d*$/;
    if (!oValue.match(sNumberMatch)) {
     oInput.setValueState(sap.ui.core.ValueState.Error);
     oInput.setValueStateText(this.getModel("i18n").getResourceBundle().getText("ERROR_NUMBER_INPUT"));
     this.saveConfirmTag = false;
     return;
    }
    if (oValue === "00000" || oValue === "0000" || oValue === "000" || oValue === "00" || oValue === "0") {
     oInput.setValueState(sap.ui.core.ValueState.Error);
     this.saveConfirmTag = false;
     oInput.setValueStateText(this.getModel("i18n").getResourceBundle().getText("MSG_SEEQUENCE_ZERO"));
     return;
    }
    if (oInput.getValueState() === sap.ui.core.ValueState.None) {
     oInput.setValueStateText("");
    }

    for (var i = 0; i < this.aExistActionSequence.length; i++) {
     if (this.aExistActionSequence[i].actionKey === sActionKey) {
      this._setChange(sActionKey, i, this.aExistActionSequence, this.aChangedAction);
      break;
     }
    }

    for (var j = 0; j < this.aExistActionSequence.length; j++) {
     if (this.aExistActionSequence[j].actionKey !== sActionKey) {
      //Duplicated sequence;
      if (this.aExistActionSequence[j].sequence !== null && parseInt(this.aExistActionSequence[j].sequence, 10) === parseInt(oValue, 10)) {
       oInput.setValueState(sap.ui.core.ValueState.Error);
       oInput.setValueStateText(this.getModel("i18n").getResourceBundle().getText("ERROR_SAME_SEQUENCE"));
       break;
      }
     }
    }

    this._resetNoMoreDuplicateInput(this.aChangedAction, sActionKey);

    //if no error, save the new input sequence
    var bIsUpdated = false;
    for (var k = 0; k < this.aChangedData.length; k++) {
     if (this.aChangedData[k].DBKey === sActionKey) {
      this.aChangedData[k].Sequence = oValue;
      bIsUpdated = true;
      break;
     }
    }
    if (!bIsUpdated) {
     this.aChangedData.push({
      "DBKey": sActionKey,
      "Sequence": oValue
     });
    }
   },

   //after input change, if other input value is not duplicate any more, reset their input state.
   _resetNoMoreDuplicateInput: function(aChangedAction, sCurrentActionKey) {
    for (var i = 0; i < aChangedAction.length; i++) {
     if (aChangedAction[i].actionKey !== sCurrentActionKey) {
      var oChangedInput = this.getView().byId("tableActionPlan").getItems()[aChangedAction[i].index].getCells()[2];
      if (oChangedInput.getValueStateText() === this.getModel("i18n").getResourceBundle().getText("ERROR_SAME_SEQUENCE")) {
       for (var j = 0; j < this.aExistActionSequence.length; j++) {
        if (aChangedAction[i].actionKey !== this.aExistActionSequence[j].actionKey) {
         oChangedInput.setValueState();
         oChangedInput.setValueStateText("");
         //still error
         if (this.aExistActionSequence[j].sequence !== null &&
          parseInt(this.aExistActionSequence[j].sequence, 10) === parseInt(oChangedInput.getValue(), 10)) {
          oChangedInput.setValueState(sap.ui.core.ValueState.Error);
          oChangedInput.setValueStateText(this.getModel("i18n").getResourceBundle().getText("ERROR_SAME_SEQUENCE"));
          break;
         }
        }
       }
      }
     }
    }
   },

   _validationDuplicateSequenceAndError: function(oTable) {
    var aCurrentActions = oTable.getItems();
    var aValues = [];
    for (var i = 0; i < aCurrentActions.length; i++) {
     var sCurrentValue = aCurrentActions[i].getCells()[2].getValue();
     if (aCurrentActions[i].getCells()[2].getValueState() === sap.ui.core.ValueState.Error) {
      MessageUtil.showMsg("msgTypeFailed", this.getModel("i18n").getResourceBundle().getText("INCORRECT_NUMBER_INPUT"));
      return false;
     }
     if (aValues.indexOf(sCurrentValue) === -1) {
      aValues.push(sCurrentValue);
     }
    }
    if (aCurrentActions.length === aValues.length) {
     return true;
    } else {
     MessageUtil.showMsg("msgTypeFailed", this.getModel("i18n").getResourceBundle().getText("ERROR_SAME_SEQUENCE"));
     return false;
    }
   }
  });
 }
);
