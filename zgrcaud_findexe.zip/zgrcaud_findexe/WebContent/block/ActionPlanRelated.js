/*
 * Copyright (C) 2009-2019 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define(["sap/uxap/BlockBase"],
 function (BlockBase) {
  "use strict";

  return BlockBase.extend("sap.grc.acs.aud.finding.execute.extended.block.ActionPlanRelated", {
   metadata: {
    views: {
     Collapsed: {
      viewName: "sap.grc.acs.aud.finding.execute.extended.block.view.ActionPlansRelated",

      type: "XML"
     },
     Expanded: {
      viewName: "sap.grc.acs.aud.finding.execute.extended.block.view.ActionPlansRelated",

      type: "XML"
     }
    }
   }
  });

 });
