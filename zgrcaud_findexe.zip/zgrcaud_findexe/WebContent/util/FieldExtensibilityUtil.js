/*
 * Copyright (C) 2009-2022 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
 "sap/ui/comp/smartform/GroupElement",
 "sap/ui/comp/smartfield/SmartField",
 "sap/ui/comp/smartfield/SmartLabel",
 "sap/ui/richtexteditor/RichTextEditor"
], function(SmartGroupElement, SmartField, SmartLabel,RichTextEditor) {
 "use strict";

 jQuery.sap.require("sap.grc.acs.lib.aud.utils.Constant");
 return {
  _extensionMapping: {
   "AuditableItem": "Adtbl",
   "QuestionTask": "QTask" 
  },

  _decimalFormatMapping: {
   " ": {
    decimalSeparator: ",",
    groupingSeparator:"."
   },
   X: {
    decimalSeparator: ".",
    groupingSeparator:","
   },
   Y:{
    decimalSeparator: ",",
    groupingSeparator:" "
   }
  },

  getExtensionType: function(sEntity) {
   if (this._extensionMapping[sEntity]) {
    sEntity = this._extensionMapping[sEntity];
   }
   return "GRCAUD_EV_" + sEntity + "ExtensionType";
  },

  getEntityType: function(sEntity) {
   if(sEntity === "Risk"){
    // this cds view will be updated to GRCAUD_CV_RiskVersionByViewType when it's avaliable for FRD
    return "GRCAUD_CV_RiskRegisterType";
    //return "GRCAUD_CV_RiskVersionByViewType";
   }else{
    return "GRCAUD_CV_" + sEntity + "Type";}
  },

  _getAnnotationTarget: function(sEntity, oMetadata) {
   return oMetadata.dataServices.schema[0].namespace + "." + this.getEntityType(sEntity);
  },

  _find: function(aArray, sAttribute, sValue) {
   if (!aArray) {
    return null;
   }
   for (var i = 0; i < aArray.length; i++) {
    if (aArray[i][sAttribute] === sValue) {
     return aArray[i];
    }
   }
  },

  getExtensionFields: function(sEntity, oMetadata, oComponent) {
   var aFields = [];
   var sExtentionType = this.getExtensionType(sEntity);
   var oExtenionType = this._find(oMetadata.dataServices.schema[0].entityType, "name", sExtentionType);
   for (var i = 0; i < oExtenionType.property.length; i++) {
    var sDisplayFormat = "";
    if (oExtenionType.property[i].name === "DBKey") {
     continue;
    }
    for (var j = 0; j < oExtenionType.property[i].extensions.length; j++) {
     if (oExtenionType.property[i].extensions[j].name === "display-format") {
      sDisplayFormat = oExtenionType.property[i].extensions[j].value;
     }
    }
    aFields.push({
     name: oExtenionType.property[i].name,
     isExtensionField: true,
     type: oExtenionType.property[i].type,
     maxLength: oExtenionType.property[i].maxLength,
     displayFormat: sDisplayFormat
    });
   }
   if (oComponent) {
    oComponent.aFields = aFields;
   }
   return aFields;
  },

  getStandarFields: function(sEntity, oComponent, sStatus, bIsStatusBasedConfig) {
   var aFields = [];
   var key = null;

   if (!oComponent.getMetadata().getConfig().fieldExtensibility) {
    return aFields;
   }
   if (!oComponent.getMetadata().getConfig().fieldExtensibility.standardFieldStatus) {
    return aFields;
   }
   if (bIsStatusBasedConfig) {
    for (key in oComponent.getMetadata().getConfig().fieldExtensibility.standardFieldStatus[sStatus]) {
     aFields.push(key);
    }
   } else {
    for (key in oComponent.getMetadata().getConfig().fieldExtensibility.standardFieldStatus) {
     aFields.push(key);
    }
   }
   return aFields;
  },

  getSpeicalStandardFields: function(sEntity, oComponent, sIntent) {
   var aFields = [];
   if (oComponent.getMetadata().getConfig().intents && oComponent.getMetadata().getConfig().intents[sIntent]) {
    for (var key in oComponent.getMetadata().getConfig().intents[sIntent].standardFieldStatus) {
     aFields.push(key);
    }
   }
   return aFields;
  },

  _setExtensionFieldsDefaultStatus: function(sBusinessType, sStatus, oFieldExtensibilityAnnotation, oExtensionFields, oFieldsStatus) {
   for (var i = 0; i < oExtensionFields.length; i++) {
    //set CDF to default status
    oFieldsStatus[oExtensionFields[i].name] = {
     visible: true,
     editable: true,
     mandatory: false
    };

    this._setFieldStatus(oFieldsStatus, oFieldExtensibilityAnnotation, oExtensionFields[i].name, sBusinessType, sStatus);
   }
  },

  _setDefaultFieldsStatus: function(sEntity, sBusinessType, sStatus, oComponent, bIsStatusBasedConfig, oFieldExtensibilityAnnotation,
   oFieldsStatus) {
   var oStandardFields = this.getStandarFields(sEntity, oComponent, sStatus, bIsStatusBasedConfig);
   for (var k = 0; k < oStandardFields.length; k++) {
    //create property for standard field
    if (!oFieldsStatus[oStandardFields[k]]) {
     oFieldsStatus[oStandardFields[k]] = {};
    }
    //get standrd configuration
    var oStandardConfig = {};
    if (bIsStatusBasedConfig) {
     oStandardConfig = oComponent.getMetadata().getConfig().fieldExtensibility.standardFieldStatus[sStatus][oStandardFields[k]];
    } else {
     oStandardConfig = oComponent.getMetadata().getConfig().fieldExtensibility.standardFieldStatus[oStandardFields[k]];
    }
    for (var key in oStandardConfig) {
     oFieldsStatus[oStandardFields[k]][key] = oStandardConfig[key];
    }
    //set status according to annotation
    this._setFieldStatus(oFieldsStatus, oFieldExtensibilityAnnotation, oStandardFields[k], sBusinessType, sStatus);
   }
  },

  _setSpecialFieldsStatus: function(sEntity, sBusinessType, sStatus, oComponent, sIntent, bIsStatusBasedConfig,
   oFieldExtensibilityAnnotation, oFieldsStatus) {
   var oSpecialStandardFields = this.getSpeicalStandardFields(sEntity, oComponent, sIntent);
   for (var p = 0; p < oSpecialStandardFields.length; p++) {
    var aSpecialAttributes = [];
    var bIsIgnoreAnnotation = false;
    //create property for standard field
    if (!oFieldsStatus[oSpecialStandardFields[p]]) {
     oFieldsStatus[oSpecialStandardFields[p]] = {};
    }
    //get speical standrd configuration
    var oSpeicalStandardConfig = oComponent.getMetadata().getConfig().intents[sIntent].standardFieldStatus[oSpecialStandardFields[p]];
    for (var key in oSpeicalStandardConfig) {
     oFieldsStatus[oSpecialStandardFields[p]][key] = oSpeicalStandardConfig[key];
     if (key !== "IgnoreAnnotation") {
      aSpecialAttributes.push(key);
     }
    }
    if (oSpeicalStandardConfig && oSpeicalStandardConfig.IgnoreAnnotation) {
     bIsIgnoreAnnotation = true;
    }
    //set status according to annotation
    if (bIsIgnoreAnnotation) {
     this._setFieldStatus(oFieldsStatus, oFieldExtensibilityAnnotation, oSpecialStandardFields[p], sBusinessType, sStatus,
      aSpecialAttributes);
    } else {
     this._setFieldStatus(oFieldsStatus, oFieldExtensibilityAnnotation, oSpecialStandardFields[p], sBusinessType, sStatus);
    }
   }
  },

  _setSmartFormFieldStatus: function(sSmartFormSection, oSmartFormMenuData, oMenuItemConfigData, oFieldsStatus) {
   var bSmartFormFieldsEditable = false;
   var bSmartFormEditable = false;
   //check whether fields are editable in the fieldsStatus
   for (var j = 0; j < Object.keys(oFieldsStatus).length; j++) {
    if (oFieldsStatus[Object.keys(oFieldsStatus)[j]].editable) {
     bSmartFormFieldsEditable = true;
     break;
    }
   }

   //check whether menu item data contains editable action.
   if (!(sSmartFormSection === "" && Object.keys(oSmartFormMenuData).length === 0)) {
    for (var o = 0; o < oSmartFormMenuData.length; o++) {
     if (oMenuItemConfigData.SmartForm === undefined && oMenuItemConfigData.SmartForm.editableActionName === undefined) {
      bSmartFormEditable = false;
     } else {
      if (oSmartFormMenuData[o].actionName === oMenuItemConfigData.SmartForm.editableActionName && oSmartFormMenuData[o].Enable !== "") {
       bSmartFormEditable = true;
      }
     }
    }
   }

   oFieldsStatus.SmartForm = {};
   oFieldsStatus.SmartForm.editable = {};
   if (bSmartFormFieldsEditable && bSmartFormEditable) {
    oFieldsStatus.SmartForm.editable = true;
   } else {
    oFieldsStatus.SmartForm.editable = false;
   }
  },

  getExtensionFieldsStatus: function(sEntity, sBusinessType, sStatus, oMetadata, oMenuItemConfigData, oComponent, sIntent,
   bIsStatusBasedConfig) {
   var sAnnotationTarget = this._getAnnotationTarget(sEntity, oMetadata);
   var sTerm = "sap.grc.aud.FieldExtensibility";
   var oAnnotationTarget = this._find(oMetadata.dataServices.schema[0].annotations, "target", sAnnotationTarget);
   var oFieldExtensibilityAnnotation = this._find(oAnnotationTarget.annotation, "term", sTerm);
   //by defaut, extension field status is {visible: true, editable: true, mandatory: false}
   var oFieldsStatus = {};
   var oSmartFormMenuData = {};
   //get extension fields
   var oExtensionFields = this.getExtensionFields(sEntity, oMetadata, oComponent);
   var sSmartFormSection = "";

   if (!(oMenuItemConfigData.SmartForm === undefined || (oMenuItemConfigData.SmartForm !== undefined && oMenuItemConfigData.SmartForm.section ===
     undefined))) {
    sSmartFormSection = oMenuItemConfigData.Section[oMenuItemConfigData.SmartForm.section];
    if (!(oComponent.getModel("menu").getData()[sSmartFormSection] === undefined || oComponent.getModel("menu").getData()[
      sSmartFormSection].actions === undefined)) {
     oSmartFormMenuData = oComponent.getModel("menu").getData()[sSmartFormSection].actions;
    }
   }

   this._setExtensionFieldsDefaultStatus(sBusinessType, sStatus, oFieldExtensibilityAnnotation, oExtensionFields, oFieldsStatus);
   this._setDefaultFieldsStatus(sEntity, sBusinessType, sStatus, oComponent, bIsStatusBasedConfig, oFieldExtensibilityAnnotation,
    oFieldsStatus);
   this._setSpecialFieldsStatus(sEntity, sBusinessType, sStatus, oComponent, sIntent, bIsStatusBasedConfig,
    oFieldExtensibilityAnnotation, oFieldsStatus);
   this._setSmartFormFieldStatus(sSmartFormSection, oSmartFormMenuData, oMenuItemConfigData, oFieldsStatus);

   return oFieldsStatus;
  },

  _setFieldStatus: function(oFieldsStatus, oAnnotatioin, sField, sBusinessType, sStatus, aSpecialAttributes) {
   var sDefault = "sap.grc.aud.FieldExensiblity.Standard";
   var bIsIgnoreProperty = false;
   //find record for field
   var oFieldRecord = this._find(oAnnotatioin.collection.record, "type", sField);

   //field not found
   if (!oFieldRecord) {
    return;
   }

   //if business type is not specifed, fallback to default
   var sCurrentBusinessType = sBusinessType;
   if (!sCurrentBusinessType) {
    sCurrentBusinessType = sDefault;
   }

   var oStatusRecord = this._getStatusRecord(oFieldRecord, sBusinessType, sStatus);

   if (!oStatusRecord) {
    oStatusRecord = this._getStatusRecord(oFieldRecord, sDefault, "");
   }

   if (oStatusRecord) {
    for (var j = 0; j < oStatusRecord.propertyValue.length; j++) {
     if (aSpecialAttributes) {
      for (var k = 0; k < aSpecialAttributes.length; k++) {
       if (oStatusRecord.propertyValue[j].property === aSpecialAttributes[k]) {
        bIsIgnoreProperty = true;
        break;
       }
      }
     }
     if (bIsIgnoreProperty === false) {
      oFieldsStatus[sField][oStatusRecord.propertyValue[j].property] = (oStatusRecord.propertyValue[j].bool === "true");
     }
    }
   }
  },

  _getStatusRecord: function(oFieldRecord, sBusinessType, sStatus) {
   var oBusinessTypeRecord = this._find(oFieldRecord.propertyValue, "property", sBusinessType);
   if (oBusinessTypeRecord) {
    for (var i = 0; i < oBusinessTypeRecord.collection.record.length; i++) {
     var oCurrentRecord = oBusinessTypeRecord.collection.record[i];
     if (sStatus === "") {
      if (oCurrentRecord.type === undefined) {
       return oCurrentRecord;
      }
     } else {
      if (oCurrentRecord.type === sStatus) {
       return oCurrentRecord;
      }
     }
    }
   }

  },

  //sMode: "create/edit"
  createExtensionGroup: function(sEntity, oGroup, oComponent, sMode) {
   var oMetadata = oComponent.getModel().getServiceMetadata();
   var aExtensionFields = this.getExtensionFields(sEntity, oMetadata);
   var aEntityType;
   if (sMode === undefined) {
    aEntityType = oComponent.getModel("intentConfig").getData().type;
   }
   var oEntityType;

   if (aExtensionFields.length === 0) {
    oGroup.setVisible(false);
    return;
   }
   for (var i = 0; i < aExtensionFields.length; i++) {
    if (sMode === undefined) {
     for (var k = 0; k < oComponent.getModel().getServiceMetadata().dataServices.schema[0].entityType.length; k++) {
      if (oComponent.getModel().getServiceMetadata().dataServices.schema[0].entityType[k].name === aEntityType) {
       oEntityType = oComponent.getModel().getServiceMetadata().dataServices.schema[0].entityType[k];
       for (var j = 0; j < oEntityType.property.length; j++) {
        if (oEntityType.property[j].name === aExtensionFields[i].name) {
         this._createField(oGroup, sEntity, aExtensionFields[i], aExtensionFields[i].type, oComponent, oMetadata, sMode, i);
         break;
        }
       }
       break;
      }
     }
    } else {
     this._createField(oGroup, sEntity, aExtensionFields[i], aExtensionFields[i].type, oComponent, oMetadata, sMode);
    }
   }
  },

  _createTimeStampFieldGroupInCreateMode: function(oGroup, sEntity, sFieldName, oComponent) {
   var oGroupElement, sExtensionType, oLabel, oField;
   if (!sap.ui.getCore().byId(sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud
     .utils.Constant.DIALOGID.EXTENSION_GROUP_ELEMENT + sFieldName)) {
    oGroupElement = new sap.ui.comp.smartform.GroupElement(sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud
     .utils.Constant.DIALOGID.EXTENSION_GROUP_ELEMENT + sFieldName);
    sExtensionType = this.getExtensionType(sEntity);
    oLabel = new sap.ui.comp.smartfield.SmartLabel(sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud.utils
     .Constant.DIALOGID.EXTENSION_LABEL + sFieldName, {
      text: "{" + jQuery.sap.formatMessage("/#{0}/{1}/@sap:label", sExtensionType, sFieldName) + "}",
      visible: "{extensionModel>/" + sFieldName + "/visible}",
      required: "{extensionModel>/" + sFieldName + "/mandatory}"
     });
    oGroupElement.setLabel(oLabel);
    oField = new sap.m.DateTimePicker({
     id: sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud.utils
      .Constant.DIALOGID.EXTENSION_INPUT + sFieldName,
     value: {
      path: sFieldName,
      formatter: function(sDate) {
       var sResult = "";
       if (sDate) {
        var oDate = new Date(sDate);
        var oDateFormatter = sap.ui.core.format.DateFormat.getDateTimeInstance({
         style: "medium"
        });
        sResult = oDateFormatter.format(oDate, false);
       }
       return sResult;
      }
     },
     change: oComponent._onChangeDateTime? oComponent._onChangeDateTime:this._onChangeDateTime,
     visible: "{extensionModel>/" + sFieldName + "/visible}"
    });
    oField.addCustomData(new sap.ui.core.CustomData({
     key: "isTimeStampField",
     value: sFieldName
    }));
    oGroupElement.insertElement(oField);
    oLabel.setLabelFor(oField);
    oGroup.addGroupElement(oGroupElement);
    return oGroupElement;
   }
  },
  _getCDFHideReadOnlyFieldInCreate: function(sField, oMetadata, sEntity) {
   var oPropertyRecord = this._find(oMetadata.dataServices.schema[0].entityType, "name", this.getExtensionType(sEntity));
   var oFieldRecord  = this._find(oPropertyRecord.property, "name", sField);
   for(var i = 0; i < oFieldRecord.extensions.length; i++ ){
    if(oFieldRecord.extensions[i].name === "creatable")
    {
     if(oFieldRecord.extensions[i].value === "false"){
      return true;
     }
    }
   }
   return false;
  },
  _getCDFMultiLineFieldInCreate: function(sField, oMetadata, sEntity) {
   var sAnnotationTarget = this._getAnnotationTargetForField(sEntity, oMetadata, sField);
   var oAnnotationTarget = this._find(oMetadata.dataServices.schema[0].annotations, "target", sAnnotationTarget);
   var sTerm = "com.sap.vocabularies.UI.v1.MultiLineText";
   if(oAnnotationTarget) {
    var oMultiLineAnnotation = this._find(oAnnotationTarget.annotation, "term", sTerm);
    if(oMultiLineAnnotation){
     return true;
    }
   }
   return false;
  },
  _getAnnotationTargetForField:function(sEntity, oMetadata, sField) {
   return oMetadata.dataServices.schema[0].namespace + "." + this.getEntityType(sEntity) + "/" + sField;
  },
  _createField: function(oGroup, sEntity, oExtensionFields, sType, oComponent, oMetadata, sMode, index) {
   var sFieldName = oExtensionFields.name;
   //if no value help, use smart field
   var sValueHelpType = this._getValueHelpType(sFieldName, oMetadata, sEntity);
   var sSemantics = this._getSemantics(sFieldName, oMetadata, sEntity);
   var aValueSet = [];
   if (this._isValueHelpField(sFieldName, oComponent)) {
    var oValueHelpConfig = oComponent.getMetadata().getConfig().fieldExtensibility.cdfValueHelp[sFieldName];
    var oModel = oComponent.getModel(oValueHelpConfig.model);
    if (oModel) {
     oModel.read("/" + oValueHelpConfig.service, {
      success: jQuery.proxy(function(oData) {
       //add value set to configuration
       for (var i = 0; i < oData.results.length; i++) {
        aValueSet.push({
         "value": oData.results[i][oValueHelpConfig.valueField],
         "text": oData.results[i][oValueHelpConfig.textField]
        });
       }
       if (sMode === sap.grc.acs.lib.aud.utils.Constant.Mode.CREATE) {
        this._createValueHelpFieldGroupInCreateMode(oGroup, sEntity, sFieldName, oComponent, aValueSet);
       } else {
        this._createValueHelpFieldGroup(oGroup, sEntity, sFieldName, oComponent, aValueSet, index);
       }

      }, this),
      error: function() {

      }
     });
    }

   } else if (sValueHelpType) {
    oComponent.oDeferred = jQuery.Deferred();
    oComponent.oDeferredCount = oComponent.oDeferredCount + 1;
    var oDataModel = oComponent.getModel();
    if (oDataModel) {
     oDataModel.callFunction("/GetValueSet", {
      method: "GET",
      urlParameters: {
       Entity: this.getEntityType(sEntity),
       Field: sFieldName
      },
      success: jQuery.proxy(function(oData) {
       //add value set to configuration
       for (var i = 0; i < oData.results.length; i++) {
//        aValueSet.push({
//         "value": oData.results[i].Name,
//         "text": oData.results[i].Value
//        });
         if(sFieldName !== 'zz_comp_proj' || ( sFieldName === 'zz_comp_proj' && oData.results[i].Name !== 'NA')){
    	   aValueSet.push({
    	         "value": oData.results[i].Name, 
    	         "text": oData.results[i].Value
    	        });
       } 
    	   
       }
       if (sValueHelpType === "valueHelp" || sValueHelpType === "drop-down") {
        if (sMode === sap.grc.acs.lib.aud.utils.Constant.Mode.CREATE) {
         this._createDropDownFieldGroupInCreateMode(oGroup, sEntity, sFieldName, oComponent, aValueSet, sValueHelpType, oMetadata);
        } else {
         this._createDropDownFieldGroup(oGroup, sEntity, sFieldName, oComponent, aValueSet, sValueHelpType, index);
        }

       }
      }, this),
      error: function() {

      }
     });
    }

   } else {
    if (sMode === sap.grc.acs.lib.aud.utils.Constant.Mode.CREATE) {
     var sHideInCreate = this._getCDFHideReadOnlyFieldInCreate(sFieldName, oMetadata, sEntity);
     var sMultiLine = this._getCDFMultiLineFieldInCreate(sFieldName, oMetadata, sEntity);
     if (sType === "Edm.DateTimeOffset"){
      this._createTimeStampFieldGroupInCreateMode(oGroup, sEntity, sFieldName, oComponent);
     }
     else if( sSemantics === "g"){
      this._createRichTextAreaGroupInCreateMode(oGroup, sEntity, oExtensionFields, index);
     }
     else{
      this._createSmartFieldGroupInCreateMode(oGroup, oExtensionFields, sEntity, sType, oComponent,sSemantics,sHideInCreate, sMultiLine);
     }
    } else {
     if ( sSemantics === "l" ) {
      this._createLinkFieldGroup(oGroup, sEntity, oExtensionFields, index);
     }
     else if( sSemantics === "g"){
      this._createRichTextAreaGroup(oGroup, sEntity, oExtensionFields, index);
     }
     else {
      this._createSmartFieldGroup(oGroup, sEntity, oExtensionFields, index);
     }
    }
   }
  },
  _onChangeDecimal: function(oEvent) {
   var iNumberLength = parseInt("29", 10);
   oEvent.getSource().setValueStateText().setValueState(sap.ui.core.ValueState.None);
   var sValue = oEvent.getParameter("value");
   if (sValue === "") {
    return;
   }
   var rootPath = jQuery.sap.getModulePath("sap.grc.acs.lib");
   var oI18nModel = new sap.ui.model.resource.ResourceModel({
    bundleUrl: rootPath + "/aud/i18n/i18n.properties"
   });
   var fValue = this._decimalNumberParse(sValue, false);
   if (isNaN(fValue)) {
    oEvent.getSource().setValueStateText(oI18nModel.getResourceBundle().getText("ERROR_NUMBER_INPUT"))
     .setValueState(sap.ui.core.ValueState.Error);
   } else {
    var sStringFormatValue = this._decimalNumberParse(sValue, true);
    if (sStringFormatValue.split(".")[0].length > iNumberLength) {
     oEvent.getSource().setValueStateText(oI18nModel.getResourceBundle().getText("ERROR_NUMBER_INPUT",
      iNumberLength)).setValueState(sap.ui.core.ValueState.Error);
    }
    if (sStringFormatValue.split(".")[1] && sStringFormatValue.split(".")[1].length >
     2) {
     oEvent.getSource().setValueStateText(oI18nModel.getResourceBundle().getText("ERROR_NUMBER_INPUT",
      iNumberLength)).setValueState(sap.ui.core.ValueState.Error);
    }
   }
  },
  _decimalNumberParse: function (sValue, isParseAsString) {
   var sFormat = sap.ui.getCore().getConfiguration().getFormatSettings().getLegacyNumberFormat();
   if (sFormat) {
    sFormat = this._decimalFormatMapping[sFormat];
   } else {
    sFormat = this._decimalFormatMapping.X;
   }
   var oFloatFormatter = sap.ui.core.format.NumberFormat.getFloatInstance({
    parseAsString: isParseAsString,
    decimalSeparator: sFormat.decimalSeparator,
    groupingSeparator: sFormat.groupingSeparator
   });
   return oFloatFormatter.parse(sValue);
  },
  _onChangeDate: function(oEvent) {
   var rootPath = jQuery.sap.getModulePath("sap.grc.acs.lib");
   var oI18nModel = new sap.ui.model.resource.ResourceModel({
    bundleUrl: rootPath + "/aud/i18n/i18n.properties"
   });
   var oDateFormatter = sap.ui.core.format.DateFormat.getDateInstance();
   var oInput = oEvent.getSource();
   if (oInput.getValue() === "") {
    oInput.setValueState(sap.ui.core.ValueState.None);
    return;
   }
   if (!oEvent.getParameter("valid") || oDateFormatter.parse(oInput.getValue()) === null) {
    oInput.setValueState(sap.ui.core.ValueState.Error);
    oInput.setValueStateText(oI18nModel.getResourceBundle().getText("ERROR_TIME_INPUT"));
    return;
   }
   oInput.setValueState(sap.ui.core.ValueState.None);
  },

  _onChangeDateTime: function(oEvent) {
   var rootPath = jQuery.sap.getModulePath("sap.grc.acs.lib");
   var oI18nModel = new sap.ui.model.resource.ResourceModel({
    bundleUrl: rootPath + "/aud/i18n/i18n.properties"
   });
   var oDateFormatter = sap.ui.core.format.DateFormat.getDateTimeInstance();
   var oInput = oEvent.getSource();
   if (oInput.getValue() === "") {
    oInput.setValueState(sap.ui.core.ValueState.None);
    return;
   }
   if (!oEvent.getParameter("valid") || oDateFormatter.parse(oInput.getValue()) === null) {
    oInput.setValueState(sap.ui.core.ValueState.Error);
    oInput.setValueStateText(oI18nModel.getResourceBundle().getText("ERROR_TIME_INPUT"));
    return;
   }
   oInput.setValueState(sap.ui.core.ValueState.None);
  },
  _checkDateTimeField: function(oEvent) {
   var rootPath = jQuery.sap.getModulePath("sap.grc.acs.lib");
   var oI18nModel = new sap.ui.model.resource.ResourceModel({
    bundleUrl: rootPath + "/aud/i18n/i18n.properties"
   });
   var oInput = oEvent.getSource();
   var oDate = oInput.getDateValue();
   if (!oEvent.getParameter("valid") || (oDate === null)) {
    oInput.setValueState(sap.ui.core.ValueState.Error);
    oInput.setValueStateText(oI18nModel.getResourceBundle().getText("ERROR_TIME_INPUT"));
    return;
   } else {
    oInput.setValueState(sap.ui.core.ValueState.None);
    oInput.setValueStateText("");
   }
  },

  _createValueHelpFieldGroupInCreateMode: function(oGroup, sEntity, sFieldName, oComponent, aValueSet) {
   if (!sap.ui.getCore().byId(sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud.utils.Constant
     .DIALOGID.EXTENSION_GROUP_ELEMENT + sFieldName)) {
    var oGroupElement = new SmartGroupElement(sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud.utils.Constant
     .DIALOGID.EXTENSION_GROUP_ELEMENT + sFieldName);
    var sExtensionType = this.getExtensionType(sEntity);
    var oLabel = new SmartLabel(sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud.utils.Constant.DIALOGID.EXTENSION_LABEL +
     sFieldName, {
      text: "{" + jQuery.sap.formatMessage("/#{0}/{1}/@sap:label", sExtensionType, sFieldName) + "}",
      visible: "{extensionModel>/" + sFieldName + "/visible}",
      required: "{extensionModel>/" + sFieldName + "/mandatory}"
     });
    oGroupElement.setLabel(oLabel);
    var oJSModel = new sap.ui.model.json.JSONModel(aValueSet);
    var oField = new sap.m.Input(sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud.utils.Constant.DIALOGID
     .EXTENSION_INPUT +
     sFieldName, {
      visible: "{extensionModel>/" + sFieldName + "/visible}",
      editable: false,
      type: sap.m.InputType.Text,
      showValueHelp: true,
      showSuggestion: true,
      valueHelpRequest: [{
       model: oJSModel
      }, this._valueHelp, this]
     });
    // oField.addCustomData(new sap.ui.core.CustomData({
    //  key: "valueHelp",
    //  value: sFieldName
    // }));
    oGroupElement.insertElement(oField);
    oLabel.setLabelFor(oField);
    oGroup.addGroupElement(oGroupElement);
    return oGroupElement;
   }
  },

  _createValueHelpFieldGroup: function(oGroup, sEntity, sFieldName, oComponent, aValueSet, index) {
   var oGroupElement = new SmartGroupElement("extensionGroupElement" + sFieldName);
   var sExtensionType = this.getExtensionType(sEntity);
   var oLabel = new SmartLabel("extensionSmartFieldLabel" + sEntity + sFieldName, {
    text: "{" + jQuery.sap.formatMessage("/#{0}/{1}/@sap:label", sExtensionType, sFieldName) + "}",
    visible: "{extensionModel>/" + sFieldName + "/visible}"
   });
   oGroupElement.setLabel(oLabel);
   var oField = new sap.m.Text("extensionSmartField" + sEntity + sFieldName, {
    text: {
     path: sFieldName,
     formatter: this._formatValueHelp
    },
    visible: "{extensionModel>/" + sFieldName + "/visible}",
    editable: false,
    mandatory: "{extensionModel>/" + sFieldName + "/mandatory}"
   });
   oField.addCustomData(new sap.ui.core.CustomData({
    key: "valueHelpConfig",
    value: oComponent.getMetadata().getConfig().fieldExtensibility.cdfValueHelp[sFieldName]
   }));
   oField.addCustomData(new sap.ui.core.CustomData({
    key: "component",
    value: oComponent
   }));
   oField.addCustomData(new sap.ui.core.CustomData({
    key: "valueSet",
    value: aValueSet
   }));
   oGroupElement.insertElement(oField);
   oLabel.setLabelFor(oField);
   oGroup.insertGroupElement(oGroupElement, index);
   return oGroupElement;
  },

  _createDropDownFieldGroupInCreateMode: function(oGroup, sEntity, sFieldName, oComponent, aValueSet, sValueHelpType, oMetadata) {
   if (!sap.ui.getCore().byId(sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud.utils.Constant
     .DIALOGID.EXTENSION_GROUP_ELEMENT + sFieldName)) {
    var sExtensionType = this.getExtensionType(sEntity);
    var oGroupElement, oLabel, oField;
    oGroupElement = new SmartGroupElement(sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud.utils.Constant
     .DIALOGID.EXTENSION_GROUP_ELEMENT + sFieldName);
    oLabel = new SmartLabel(sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud.utils.Constant.DIALOGID
     .EXTENSION_LABEL + sFieldName, {
      text: "{" + jQuery.sap.formatMessage("/#{0}/{1}/@sap:label", sExtensionType, sFieldName) + "}",
      visible: "{extensionModel>/" + sFieldName + "/visible}",
      required: "{extensionModel>/" + sFieldName + "/mandatory}"
     });
    oGroupElement.setLabel(oLabel);

    var oJSModel = new sap.ui.model.json.JSONModel(aValueSet);
    // oJSModel.setSizeLimit(500); // Enforce number of available suggestions to 500

    if (sValueHelpType === "drop-down") {
     oField = new sap.m.Select(sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud.utils.Constant.DIALOGID
      .EXTENSION_INPUT + sFieldName, {
       forceSelection: false,
       visible: "{extensionModel>/" + sFieldName + "/visible}"
      });
     var sAnnotationTarget = this._getAnnotationTarget(sEntity, oMetadata);
              var oAnnotationTarget = this._find(oMetadata.dataServices.schema[0].annotations, "target", sAnnotationTarget);
           var oFieldExtensibilityAnnotation = this._find(oAnnotationTarget.annotation, "term", "sap.grc.aud.FieldExtensibility");
           var oFieldRecord = this._find(oFieldExtensibilityAnnotation.collection.record, "type", sFieldName);
                    var oPropertyRecord = this._find(oFieldRecord.propertyValue, "property", "sap.grc.aud.FieldExensiblity.Standard");
        var aPropertyRecord =  oPropertyRecord.collection.record[0];
        var bIsMandatory = this._find(aPropertyRecord.propertyValue,"property","mandatory").bool;
        var sValue = "value";
        var sText = "text";
        var oItemList = oJSModel;
              if(bIsMandatory === "false"){
            var oEmptyResult = {};
               oEmptyResult[sValue] = null;
      oEmptyResult[sText] = "";
         var aEmptyResult = [oEmptyResult];
            var aItemList = aEmptyResult.concat(oJSModel.getData());
        oItemList = new sap.ui.model.json.JSONModel(aItemList);
     }
           oField.setModel(oItemList);
     oField.bindItems({
      path: "/",
      template: new sap.ui.core.Item({
       key: "{value}",
       text: "{text}"
      })
     });
    } else {
     oField = new sap.m.Input(sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud.utils.Constant.DIALOGID
      .EXTENSION_INPUT + sFieldName, {
       visible: "{extensionModel>/" + sFieldName + "/visible}",
       mandatory: "{extensionModel>/" + sFieldName + "/mandatory}",
       type: sap.m.InputType.Text,
       showValueHelp: true,
       showSuggestion: true,
       textFormatMode: "Value",
       suggest: this._onInputSuggest,
       suggestionItems: {
        path: "/",
        template: new sap.ui.core.Item({
          key: "{value}",
          text: "{text}"
         })
       },
       valueHelpRequest: [{
        model: oJSModel
       }, this._valueHelp, this]
      });
     oField.setModel(oJSModel);
    }
    oGroupElement.insertElement(oField);
    oLabel.setLabelFor(oField);
    oGroup.addGroupElement(oGroupElement);
    return oGroupElement;
   }
  },

  _onInputSuggest: function (oEvent) {
   var sTerm = oEvent.getParameter("suggestValue");
   var aFilters = [];
   if (sTerm) {
    aFilters.push(new sap.ui.model.Filter("text", sap.ui.model.FilterOperator.StartsWith, sTerm));
   }
   oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
  },

  _createDropDownFieldGroup: function(oGroup, sEntity, sFieldName, oComponent, aValueSet, sValueHelpType, index) {
   var sExtensionType = this.getExtensionType(sEntity);
   var oGroupElementdis, oLabelDisplay, oFieldDisplay;

   //Display mode
   oGroupElementdis = new SmartGroupElement("extensionGroupElement" + sEntity + sFieldName + "Display");
   oLabelDisplay = new SmartLabel("extensionSmartFieldLabel" + sEntity + sFieldName + "Display", {
    text: "{" + jQuery.sap.formatMessage("/#{0}/{1}/@sap:label", sExtensionType, sFieldName) + "}",
    visible: "{extensionModel>/" + sFieldName + "/visible}"
   });
   oGroupElementdis.setLabel(oLabelDisplay);
   oFieldDisplay = new sap.m.Text("extensionSmartField" + sEntity + sFieldName + "dis", {
    text: {
     parts: [{path: sFieldName}, {path: sFieldName + "Text"}],
     formatter: function(name, text) {
      for (var i = 0; i < aValueSet.length; i++) {
       if (aValueSet[i].text === name) {
        return aValueSet[i].text;
       }
      }
      for (var j = 0; j < aValueSet.length; j++) {
       if (aValueSet[j].value === name) {
        return aValueSet[j].text;
       }
      }
      return text || name;
     }
    },
    visible: "{extensionModel>/" + sFieldName + "/visible}",
    mandatory: "{extensionModel>/" + sFieldName + "/mandatory}"
   });
   oFieldDisplay.addCustomData(new sap.ui.core.CustomData({
    key: sValueHelpType,
    value: {
     parts: [{path: sFieldName}, {path: sFieldName + "Text"}],
     formatter: function(name, text) {
      return {
       fieldName: sFieldName,
       valueKey: name,
       valueText: text
      };
     }
    }
   }));
   oFieldDisplay.addCustomData(new sap.ui.core.CustomData({
    key: "valueSet",
    value: aValueSet
   }));

   oFieldDisplay.addCustomData(new sap.ui.core.CustomData({
    key: "entity",
    value: sEntity
   }));

   oGroupElementdis.insertElement(oFieldDisplay);
   oLabelDisplay.setLabelFor(oFieldDisplay);
   oGroup.insertGroupElement(oGroupElementdis, index);
   oComponent.oDeferredCount = oComponent.oDeferredCount - 1;
   if(oComponent.aFields !== undefined &&  oComponent.oDeferredCount === 0){
    oComponent.oDeferred.resolve();
   }
   return oGroupElementdis;
  },

  _formatValueHelp: function(sValue) {
   var aValueSet = this.getCustomData()[2].getValue();
   for (var i = 0; i < aValueSet.length; i++) {
    if (aValueSet[i].value === sValue) {
     return aValueSet[i].text;
    }
   }
   //if the text is not found, use the key
   return sValue;
  },

  _isValueHelpField: function(sField, oComponent) {
   if (oComponent.getMetadata().getConfig().fieldExtensibility &&
    oComponent.getMetadata().getConfig().fieldExtensibility.cdfValueHelp &&
    oComponent.getMetadata().getConfig().fieldExtensibility.cdfValueHelp[sField]) {
    return true;
   } else {
    return false;
   }
  },

  _getValueHelpType: function(sField, oMetadata, sEntity) {
   var aAnnotations = oMetadata.dataServices.schema[0].annotations;
   for (var i = 0; i < aAnnotations.length; i++) {
    if (aAnnotations[i].target === oMetadata.dataServices.schema[0].namespace + "." + this.getEntityType(sEntity) + "/" +
     sField) {
     if (aAnnotations[i].annotation[0].term === "sap.grc.aud.FieldExensiblity.ValueHelpType.F4") {
      return "valueHelp";
     } else if (aAnnotations[i].annotation[0].term === "sap.grc.aud.FieldExensiblity.Drop-downList") {
      return "drop-down";
     } else {
      return null;
     }
    }
   }
   return null;
  },

  _getSemantics: function(sField, oMetadata, sEntity) {
   var aEntityType = oMetadata.dataServices.schema[0].entityType;
   var aProperty = [];
   var aExtensions = [];
   for (var i = 0; i < aEntityType.length; i++) {
    if (aEntityType[i].name === this.getEntityType(sEntity) ) {
     aProperty = aEntityType[i].property;
     break;
    }
   }

   for (var k = 0; k < aProperty.length; k++) {
    if (aProperty[k].name === sField ) {
     aExtensions = aProperty[k].extensions;
     break;
    }
   }

   for (var j = 0; j < aExtensions.length; j++) {
    if (aExtensions[j].name === "semantics" ) {
     return aExtensions[j].value;
    }
   }

   return null;
  },


  setValueHelpFieldsEditable: function(oExtensionGroup, oExtensionModelData, aDropDownGroupIndex, aDropDownEdit) {
   var oGroupElements = oExtensionGroup.getGroupElements();
   var bIsEditable = true;
   var bIsMandatory = false;
   var sFieldName = "";
   for (var k = 0; k < oGroupElements.length; k++) {
    for (var j = 0; j < oGroupElements[k].getElements().length; j++) {
     for (var i = 0; i < oGroupElements[k].getElements()[j].getCustomData().length; i++) {
      if (oGroupElements[k].getElements()[j].getCustomData()[i].getKey() === "drop-down") {
       if (oGroupElements[k].getElements()[j].getVisible() === true) {
        sFieldName = oGroupElements[k].getElements()[j].getCustomData()[i].getValue().fieldName;
        bIsEditable = oExtensionModelData[sFieldName].editable;
        bIsMandatory = oExtensionModelData[sFieldName].mandatory;
        if (bIsEditable) {
         aDropDownGroupIndex.push({
          index: k,
          element: oGroupElements[k]
         });
         var oCustomValue = oGroupElements[k].getElements()[j].getCustomData()[i].getValue();
         var sValue = oCustomValue.valueKey;
         this.setEditGroupElement(oExtensionGroup, k, aDropDownEdit, oGroupElements[k].getElements()[j]
          .getCustomData(),bIsMandatory);
         var oTempObject = {
          valueKey: sValue,
          valueText: oCustomValue.valueText
         };
         var oSelect = oExtensionGroup.getGroupElements()[k].getElements()[j];
         oSelect.setSelectedItem(null);
         oSelect.setSelectedKey(sValue);
         oSelect.addEventDelegate({
          onAfterRendering: function (oEvent) {
           if(!oEvent.srcControl.getSelectedItem()) {
            oEvent.srcControl.setValue(this.valueText || this.valueKey);
           }
          }.bind(oTempObject)
         });
        }

       }
      } else if (oGroupElements[k].getElements()[j].getCustomData()[i].getKey() === "valueHelp") {
       if (oGroupElements[k].getElements()[j].getVisible() === true) {
        sFieldName = oGroupElements[k].getElements()[j].getCustomData()[i].getValue().fieldName;
        bIsEditable = oExtensionModelData[sFieldName].editable;
        if (bIsEditable) {
         aDropDownGroupIndex.push({
          index: k,
          element: oGroupElements[k]
         });
         var sValuet = oGroupElements[k].getElements()[j].getText();
         this.setValueHelpEditGroupElement(oExtensionGroup, k, aDropDownEdit, oGroupElements[k].getElements()[j]
          .getCustomData());
         oExtensionGroup.getGroupElements()[k].getElements()[j].setValue(sValuet);
         var sName = oGroupElements[k].getElements()[j].getCustomData()[i].getValue().valueKey;
         oExtensionGroup.getGroupElements()[k].getElements()[j].setName(sName);
         var oItem = new sap.ui.core.Item();
         oItem.setKey(sName);
         oItem.setText(sValuet);
         oExtensionGroup.getGroupElements()[k].getElements()[j].addSuggestionItem(oItem);
        }

       }
      }
     }
    }

   }
  },

  setEditGroupElement: function(oGroup, iIndex, aDropDownEdit, customData, bIsMandatory) {
   var aValueSet = [];
   var sFieldName = "";
   var sEntity = "";
   for (var i = 0; i < customData.length; i++) {
    if (customData[i].getKey() === "drop-down") {
     sFieldName = customData[i].getValue().fieldName;
    }
    if (customData[i].getKey() === "valueSet") {
     aValueSet = customData[i].getValue();
    }
    if (customData[i].getKey() === "entity") {
     sEntity = customData[i].getValue();
    }
   }

   var oGroupElements = oGroup.getGroupElements();
   oGroup.removeGroupElement(oGroupElements[iIndex]);
   for (var j = 0; j < aDropDownEdit.length; j++) {
    if (aDropDownEdit[j].index === iIndex) {
     oGroup.insertGroupElement(aDropDownEdit[j].element, iIndex);
     return;
    }
   }

   var oGroupElement = new SmartGroupElement("extensionGroupElement" + sFieldName);
   var sExtensionType = this.getExtensionType(sEntity);
   //Edit mode
   var oLabel = new SmartLabel("extensionSmartFieldLabel" + sFieldName, {
    text: "{" + jQuery.sap.formatMessage("/#{0}/{1}/@sap:label", sExtensionType, sFieldName) + "}",
    visible: "{extensionModel>/" + sFieldName + "/visible}",
    required: "{extensionModel>/" + sFieldName + "/mandatory}"
   });
   oGroupElement.setLabel(oLabel);
   var oField = new sap.m.Select("extensionSmartField" + sFieldName, {
    visible: "{extensionModel>/" + sFieldName + "/visible}",
    forceSelection: false,
    mandatory: "{extensionModel>/" + sFieldName + "/mandatory}"
   });
   oField.addCustomData(new sap.ui.core.CustomData({
    key: "drop-down",
    value: sFieldName
   }));

   var sValue = "value";
   var sText = "text";
   var oJSModel = new sap.ui.model.json.JSONModel(aValueSet);
   var oItemList = oJSModel;
   if(bIsMandatory === false){
    var oEmptyResult = {};
    oEmptyResult[sValue] = null;
    oEmptyResult[sText] = "";
    var aEmptyResult = [oEmptyResult];
       var aItemList = aEmptyResult.concat(oJSModel.getData());
       oItemList = new sap.ui.model.json.JSONModel(aItemList);
   }
   oField.setModel(oItemList);
   oField.bindItems({
    path: "/",
    template: new sap.ui.core.Item({
     key: "{value}",
     text: "{text}"
    })
   });
   oGroupElement.insertElement(oField);
   oLabel.setLabelFor(oField);
   oGroup.insertGroupElement(oGroupElement, iIndex);
   aDropDownEdit.push({
    index: iIndex,
    element: oGroupElement
   });
  },

  setValueHelpEditGroupElement: function(oGroup, iIndex, aDropDownEdit, customData) {
   var aValueSet = [];
   var sFieldName = "";
   var sEntity = "";
   for (var i = 0; i < customData.length; i++) {
    if (customData[i].getKey() === "valueHelp") {
     sFieldName = customData[i].getValue().fieldName;
    }
    if (customData[i].getKey() === "valueSet") {
     aValueSet = customData[i].getValue();
    }
    if (customData[i].getKey() === "entity") {
     sEntity = customData[i].getValue();
    }
   }
   var oJSModel = new sap.ui.model.json.JSONModel(aValueSet);

   var oGroupElements = oGroup.getGroupElements();
   oGroup.removeGroupElement(oGroupElements[iIndex]);
   for (var j = 0; j < aDropDownEdit.length; j++) {
    if (aDropDownEdit[j].index === iIndex) {
     oGroup.insertGroupElement(aDropDownEdit[j].element, iIndex);
     return;
    }
   }

   var oGroupElement = new SmartGroupElement("extensionGroupElement" + sFieldName);
   var sExtensionType = this.getExtensionType(sEntity);
   //Edit mode
   var oLabel = new SmartLabel("extensionSmartFieldLabel" + sFieldName, {
    text: "{" + jQuery.sap.formatMessage("/#{0}/{1}/@sap:label", sExtensionType, sFieldName) + "}",
    visible: "{extensionModel>/" + sFieldName + "/visible}",
    required: "{extensionModel>/" + sFieldName + "/mandatory}"
   });
   oGroupElement.setLabel(oLabel);
   var oField = new sap.m.Input("extensionSmartField" + sFieldName, {
    visible: "{extensionModel>/" + sFieldName + "/visible}",
    mandatory: "{extensionModel>/" + sFieldName + "/mandatory}",
    type: sap.m.InputType.Text,
    showValueHelp: true,
    showSuggestion: true,
    textFormatMode: "Value",
    suggestionItems: {
     path: "/",
     template: new sap.ui.core.Item({
       key: "{value}",
       text: "{text}"
      })
    },
    valueHelpRequest: [{
     model: oJSModel
    }, this._valueHelp, this]
   });
   oField.setModel(oJSModel);
   oField.addCustomData(new sap.ui.core.CustomData({
    key: "valueHelp",
    value: sFieldName
   }));
   // var oField = new sap.m.Select("extensionSmartField" + sFieldName, {
   //  visible: "{extensionModel>/" + sFieldName + "/visible}",
   //  forceSelection: false,
   //  mandatory: "{extensionModel>/" + sFieldName + "/mandatory}"
   // });
   oGroupElement.insertElement(oField);
   oLabel.setLabelFor(oField);
   oGroup.insertGroupElement(oGroupElement, iIndex);
   aDropDownEdit.push({
    index: iIndex,
    element: oGroupElement
   });
  },

  setCdfNonSmartFieldsStatus: function(oExtensionGroup, oExtensionModelData, fieldStatus){
   var oGroupElements = oExtensionGroup.getGroupElements();
   for(var k = 0;k<oGroupElements.length;k++){
    for(var j=0; j<oGroupElements[k].getFields().length;j++){
     for (var i = 0; i < oGroupElements[k].getFields()[j].getCustomData().length; i++) {
      if ( oGroupElements[k].getFields()[j].getCustomData()[i].getKey() === "richText"){
       switch(fieldStatus){
        case "editable":
         this._setRichTextAreaEditableStatus(oGroupElements[k].getFields()[j], true);
         break;
        case "display":
         this._setRichTextAreaEditableStatus(oGroupElements[k].getFields()[j], false);
         break;
       }

      }
     }
    }
   }
  },

  _setRichTextAreaEditableStatus: function(oRichTextArea, status){
   oRichTextArea.setEditable(status);  
   oRichTextArea.setShowGroupStructure(status);
   oRichTextArea.setShowGroupUndo(status);
   oRichTextArea.setShowGroupFontStyle(status);
   // if(!status){
   //  oRichTextArea.getNativeApi().container.style.borderWidth = "0px";
   //  oRichTextArea.getNativeApi().contentAreaContainer.style.borderWidth = "0px";
   // }
   // else{
   //  oRichTextArea.getNativeApi().container.style.borderWidth = "1px";
   //  oRichTextArea.getNativeApi().contentAreaContainer.style.borderWidth = "1px";
   // }
  },

  _valueHelp: function(oEvent, oData) {
   oData.control = oEvent.getSource();
   // if (!this.oValueHelpDialog || this.oValueHelpDialog.bIsDestroyed === true) {
   this._createSearchDialog(oData);
   // }
   this.oValueHelpDialog.open();
  },

  _createSearchDialog: function(oData) {
   var that = this;
   var rootPath = jQuery.sap.getModulePath("sap.grc.acs.lib");
   var oI18nModel = new sap.ui.model.resource.ResourceModel({
    bundleUrl: rootPath + "/aud/i18n/i18n.properties"
   });

   this.oValueHelpDialog = new sap.m.Dialog({
    title: oI18nModel.getResourceBundle().getText("labelValueHelp"),
    stretchOnPhone: true,
    contentWidth: "600px",
    contentHeight: "300px",
    horizontalScrolling: false,
    rightButton: new sap.m.Button({
     text: oI18nModel.getResourceBundle().getText("btn_cancel"),
     press: jQuery.proxy(function() {
      this.oValueHelpDialog.close();
     }, this)
    }),
    beforeOpen: function(oEvent) {
     oEvent.getSource().getContent()[0].getHeaderToolbar().getContent()[0].setValue(oData.control.getValue());
     var filter = new sap.ui.model.Filter("text", sap.ui.model.FilterOperator.Contains, oData.control.getValue());
     oEvent.getSource().getContent()[0].bindItems({
      path: "/",
      template: new sap.m.ColumnListItem({
       cells: [new sap.m.Text({
        text: "{text}"
       }), new sap.m.Text({
        text: "{value}"
       })]
      }),
      filters: [filter]
     });
    },
    afterClose: function() {

    },
    content: [
     new sap.m.Table({
      inset: true,
      mode: sap.m.ListMode.SingleSelectMaster,
      growing: true,
      growingThreshold: 50,
      growingScrollToLoad: true,
      headerToolbar: new sap.m.Toolbar({
       content: [new sap.m.Input({
        // id: "cdf_search_help",
        width: "300px",
        placeholder: oI18nModel.getResourceBundle().getText("labelSearch"),
        value: oData.control.getValue()
       }), new sap.m.ToolbarSpacer({
        width: "1em"
       }), new sap.m.Button({
        type: sap.m.ButtonType.Emphasized,
        text: oI18nModel.getResourceBundle().getText("btn_search"),
        press: function(oEvent) {
         var sInput = oEvent.getSource().getParent().getContent()[0].getValue();
         var filter = new sap.ui.model.Filter("text", sap.ui.model.FilterOperator.Contains, sInput);
         var oTable = oEvent.getSource().getParent().getParent();
         oTable.bindItems({
          path: "/",
          template: new sap.m.ColumnListItem({
           cells: [new sap.m.Text({
            text: "{text}"
           }), new sap.m.Text({
            text: "{value}"
           })]
          }),
          filters: [filter]
         });
        }
       })]
      }),
      columns: [new sap.m.Column({
       width: "35%",
       vAlign: sap.ui.core.VerticalAlign.Middle,
       header: new sap.m.Label({
        text: oI18nModel.getResourceBundle().getText("labelName")
       })
      }), new sap.m.Column({
       width: "65%",
       vAlign: sap.ui.core.VerticalAlign.Middle,
       header: new sap.m.Label({
        text: oI18nModel.getResourceBundle().getText("labelValue")
       })
      })],
      selectionChange: function(oEvent) {
       var oInfo = oEvent.getParameters().listItem.getBindingContext().getObject();
       oData.control.setSelectedKey(oInfo.value);
       oData.control.setValue(oInfo.text);
       that.oValueHelpDialog.close();
      }
     }).setModel(oData.model).bindItems({
      path: "/",
      template: new sap.m.ColumnListItem({
       cells: [new sap.m.Text({
        text: "{text}"
       }), new sap.m.Text({
        text: "{value}"
       })]
      })
     })
    ]
   });
  },

  _createSmartFieldGroupInCreateMode: function(oGroup, oExtensionFields, sEntity, sType, oComponent, sSemantics, sHideInCreate, sMultiLine) {
   var sFieldName = oExtensionFields.name;
   if (!sap.ui.getCore().byId(sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud.utils.Constant
     .DIALOGID.EXTENSION_GROUP_ELEMENT + sFieldName)) {
    var oGroupElement = new sap.ui.comp.smartform.GroupElement(sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib
     .aud.utils.Constant.DIALOGID.EXTENSION_GROUP_ELEMENT + sFieldName);
    var sExtensionType = this.getExtensionType(sEntity);
    var oLabel = new sap.ui.comp.smartfield.SmartLabel(sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud
     .utils.Constant.DIALOGID.EXTENSION_LABEL + sFieldName, {
      text: "{" + jQuery.sap.formatMessage("/#{0}/{1}/@sap:label", sExtensionType, sFieldName) + "}",
      visible: "{extensionModel>/" + sFieldName + "/visible}",
      required: "{extensionModel>/" + sFieldName + "/mandatory}"
     });
    var oInput;
    var rootPath = jQuery.sap.getModulePath("sap.grc.acs.lib");
    var oI18nModel = new sap.ui.model.resource.ResourceModel({
     bundleUrl: rootPath + "/aud/i18n/i18n.properties"
    });
    if (sType === "Edm.Decimal") {
     var oController = this;
     oInput = new sap.m.Input(sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud
       .utils.Constant.DIALOGID.EXTENSION_INPUT + sFieldName, {
        value: "{" + sFieldName + "}",
        visible: "{extensionModel>/" + sFieldName + "/visible}"
       });
     oInput.attachChange(function(oEvent) {
      oController._onChangeDecimal(oEvent);
      });
    } else if (sType === "Edm.DateTime") {
     oInput = new sap.m.DatePicker(sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud
      .utils.Constant.DIALOGID.EXTENSION_INPUT + sFieldName, {
       value: "{" + sFieldName + "}",
       visible: "{extensionModel>/" + sFieldName + "/visible}",
       change: oComponent._onChangeDate? oComponent._onChangeDate:this._onChangeDate
      });
    } else {
     if(sMultiLine){
      oInput = new sap.m.TextArea(sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud
       .utils.Constant.DIALOGID.EXTENSION_INPUT + sFieldName, {
        value: "{" + sFieldName + "}",
        visible: "{extensionModel>/" + sFieldName + "/visible}"
      });
      if (sSemantics === "l"){
       oInput.attachChange(function(oEvent) {
        var oControl = oEvent.getSource();
        var oValue = oControl.getValue();
        var sPattern = /(((http|https|ftp):\/\/)|(www))(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%!\-\/]))?/;

        if (oValue === "") {
         oInput.setValueState(sap.ui.core.ValueState.None);
         oInput.setValueStateText("");
        } else {
         if (!sPattern.test(oValue)) {
          oInput.setValueState(sap.ui.core.ValueState.Error);
          oInput.setValueStateText(oI18nModel.getResourceBundle().getText("MSG_URL_FAIL"));
          return;
         }
            else{
             oInput.setValueState(sap.ui.core.ValueState.None);
          oInput.setValueStateText("");
         }
        }
       });

      }
     } else {
      oInput = new sap.m.Input(sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud
       .utils.Constant.DIALOGID.EXTENSION_INPUT + sFieldName, {
        value: "{" + sFieldName + "}",
        visible: "{extensionModel>/" + sFieldName + "/visible}"
       });
      if (oExtensionFields.displayFormat === "NonNegative") {
       oInput.attachLiveChange(function(oEvent) {
        var oControl = oEvent.getSource();
        var oValue = oControl.getValue();
        var sNumberMatch = /^[0-9]\d*$/;

        //reset
        oInput.setValueState(sap.ui.core.ValueState.None);
        oInput.setValueStateText("");

        if (oValue === "") {
         oControl.setValueState(sap.ui.core.ValueState.None);
         oControl.setValueStateText("");
        } else {
         if (!oValue.match(sNumberMatch)) {
          oControl.setValueState(sap.ui.core.ValueState.Error);
          oControl.setValueStateText(oI18nModel.getResourceBundle().getText("MSG_NUMC_FAIL"));
          return;
         } else {
          if (oValue.length > oExtensionFields.maxLength) {
           oInput.setValueState(sap.ui.core.ValueState.Error);
           oInput.setValueStateText(oI18nModel.getResourceBundle().getText("MSG_ERROR_INPUT_NUMBER_TOO_LARGE", [oExtensionFields.maxLength]));
           return;
          } else {
           oInput.setValueState(sap.ui.core.ValueState.None);
           oInput.setValueStateText("");
          }
         }
        }

       });
      }
     }
    }

    oGroupElement.setLabel(oLabel);
    oGroupElement.insertElement(oInput);
    oLabel.setLabelFor(oInput);
    if(sHideInCreate){
     oGroupElement.setVisible(false);
    }
    oGroup.addGroupElement(oGroupElement);
    return oGroupElement;
   }
  },
  _createSmartFieldGroup: function(oGroup, sEntity, oExtensionFields, index) {
   var sFieldName = oExtensionFields.name;
   var oGroupElement = new SmartGroupElement("extensionGroupElement" + sEntity + sFieldName);
   var oField = new SmartField("extensionSmartField" + sEntity + sFieldName, {
     value: "{" + sFieldName + "}",
     width: "100%",
     visible: "{extensionModel>/" + sFieldName + "/visible}",
     editable: "{extensionModel>/" + sFieldName + "/editable}",
     mandatory: "{extensionModel>/" + sFieldName + "/mandatory}"
    });
   var rootPath = jQuery.sap.getModulePath("sap.grc.acs.lib");
   var oI18nModel = new sap.ui.model.resource.ResourceModel({
    bundleUrl: rootPath + "/aud/i18n/i18n.properties"
   });
   if (oExtensionFields.displayFormat === "NonNegative") {
    oField.attachChange(function(oEvent) {
     var oInput = oEvent.getSource();
     var oValue = oInput.getValue();
     var sNumberMatch = /^[0-9]\d*$/;

     if (oValue === "") {
      oInput.setValueState(sap.ui.core.ValueState.None);
      oInput.setValueStateText("");
     } else {
      if (!oValue.match(sNumberMatch)) {
       oInput.setValueState(sap.ui.core.ValueState.Error);
       oInput.setValueStateText(oI18nModel.getResourceBundle().getText("MSG_NUMC_FAIL"));
       return;
      } else {
       if (oValue.length > oExtensionFields.maxLength) {
        oInput.setValueState(sap.ui.core.ValueState.Error);
        oInput.setValueStateText(oI18nModel.getResourceBundle().getText("MSG_ERROR_INPUT_NUMBER_TOO_LARGE", [oExtensionFields.maxLength]));
        return;
       } else {
        oInput.setValueState(sap.ui.core.ValueState.None);
        oInput.setValueStateText("");
       }
      }
     }

    });
   }
   oGroupElement.addElement(oField);
   oGroup.insertGroupElement(oGroupElement, index);
   return oGroupElement;
  },

  _createLinkFieldGroup: function(oGroup, sEntity, oExtensionFields, index) {

   var sFieldName = oExtensionFields.name;
   var oGroupElement = new SmartGroupElement("extensionGroupElement" + sEntity + sFieldName);
   var oField = new SmartField("extensionSmartField" + sEntity + sFieldName, {
    value: "{" + sFieldName + "}",
    url: {
     path : sFieldName,
     formatter : function(fValue) {
      if(fValue === null || fValue === undefined){
       return fValue;
      }
      var sUpValue = fValue.toUpperCase();
      if (sUpValue.startsWith("WWW")){
       fValue = "ht" + "tp" + "://" + fValue;
      }
      return fValue;
     }
    },
    width: "100%",
    visible: "{extensionModel>/" + sFieldName + "/visible}",
    editable: "{extensionModel>/" + sFieldName + "/editable}",
    mandatory: "{extensionModel>/" + sFieldName + "/mandatory}"
   });
   var rootPath = jQuery.sap.getModulePath("sap.grc.acs.lib");
   var oI18nModel = new sap.ui.model.resource.ResourceModel({
    bundleUrl: rootPath + "/aud/i18n/i18n.properties"
   });

   oField.attachChange(function(oEvent) {
    var oInput = oEvent.getSource();
    var oValue = oInput.getValue();
    var sPattern = /(((http|https|ftp):\/\/)|(www))(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%!\-\/]))?/;

    if (oValue === "") {
     oInput.setValueState(sap.ui.core.ValueState.None);
     oInput.setValueStateText("");
    } else {
     if (!sPattern.test(oValue)) {
      oInput.setValueState(sap.ui.core.ValueState.Error);
      oInput.setValueStateText(oI18nModel.getResourceBundle().getText("MSG_URL_FAIL"));
      return;
     }
        else{
         oInput.setValueState(sap.ui.core.ValueState.None);
      oInput.setValueStateText("");
     }
    }
   });

   oGroupElement.addElement(oField);
   oGroup.insertGroupElement(oGroupElement, index);
   return oGroupElement;
  },

  _createRichTextAreaGroup: function(oGroup, sEntity, oExtensionFields, index){
   var oGroupElement = new SmartGroupElement("extensionGroupElement" + sEntity + oExtensionFields.name);
   var sExtensionType = this.getExtensionType(sEntity);
   var oLabel = new SmartLabel("extensionSmartFieldLabel" + sEntity +  oExtensionFields.name + "Display", {
    text: "{" + jQuery.sap.formatMessage("/#{0}/{1}/@sap:label", sExtensionType,  oExtensionFields.name) + "}",
    visible: "{extensionModel>/" +  oExtensionFields.namme + "/visible}"
   });
   var oRichTextArea = new RichTextEditor("extensionSmartField" + oExtensionFields.name, {
    value: {
     path : oExtensionFields.name,
     formatter : function(value) {
      var sText = "";
       if (value) {
        sText = decodeURIComponent(value);
       }
      return sText;
     }
    },
    editorType : sap.ui.richtexteditor.EditorType.TinyMCE4,
    visible: "{extensionModel>/" + oExtensionFields.name + "/visible}",
    editable: false,
    required: "{extensionModel>/" + oExtensionFields.name + "/mandatory}",
    width: "100%",
    height: "1.5%",
       customToolbar: false,
    showGroupFont: false,
    showGroupLink: false,
    showGroupInsert: false,
    showGroupTextAlign: false,
    showGroupClipboard:false,
    showGroupFontStyle:false,
    showGroupUndo:false,
    showGroupStructure:false,
    layoutData : new sap.ui.layout.ResponsiveFlowLayoutData({
     weight : 7
    })
   });
   oRichTextArea.attachReady(function(oEvent){
    oRichTextArea.getNativeApi().container.style.borderWidth = "0px";
    oRichTextArea.getNativeApi().contentAreaContainer.style.borderWidth = "0px";
   });
   oRichTextArea.tinyMCEReady = function() {
    var iframe = jQuery.sap.domById(this._iframeId);
    if (iframe) {
     iframe
       .setAttribute(
         "style",
         iframe.getAttribute("style")
           + "height:"
           + iframe.contentDocument
             .getElementsByTagName("html")[0].offsetHeight
           + "px");
    }
    return !!iframe;
   };
   oRichTextArea.addCustomData(new sap.ui.core.CustomData({
    key: "richText",
    value: oExtensionFields.name
   }));
   oGroupElement.setLabel(oLabel);
   oGroupElement.addElement(oRichTextArea);
   oGroup.insertGroupElement(oGroupElement, index);
   return oGroupElement;
  },

  _createRichTextAreaGroupInCreateMode: function(oGroup, sEntity, oExtensionFields, index){
   var oGroupElement = new sap.ui.comp.smartform.GroupElement(sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud
     .utils.Constant.DIALOGID.EXTENSION_GROUP_ELEMENT + oExtensionFields.name);
   var sExtensionType = this.getExtensionType(sEntity);
   var oLabel = new sap.ui.comp.smartfield.SmartLabel(sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud.utils
     .Constant.DIALOGID.EXTENSION_LABEL + oExtensionFields.name, {
      text: "{" + jQuery.sap.formatMessage("/#{0}/{1}/@sap:label", sExtensionType, oExtensionFields.name) + "}",
      visible: "{extensionModel>/" + oExtensionFields.name + "/visible}",
      required: "{extensionModel>/" + oExtensionFields.name + "/mandatory}"
     });
   var oRichTextArea = new RichTextEditor(sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud.utils
      .Constant.DIALOGID.EXTENSION_INPUT + oExtensionFields.name, {
    value: {
     path : oExtensionFields.name,
     formatter : function(value) {
      var sText = "";
       if (value) {
        sText = decodeURIComponent(value);
       }
      return sText;
     }
    },
    editorType : sap.ui.richtexteditor.EditorType.TinyMCE4,
    visible: "{extensionModel>/" + oExtensionFields.name + "/visible}",
    editable: true,
    required: "{extensionModel>/" + oExtensionFields.name + "/mandatory}",
    width: "100%",
    height: "1.5%",
       customToolbar: false,
    showGroupFont: false,
    showGroupLink: false,
    showGroupInsert: false,
    showGroupTextAlign: false,
    showGroupClipboard:false,
    showGroupFontStyle:true,
    showGroupUndo:true,
    showGroupStructure:true
   });
   oRichTextArea.addCustomData(new sap.ui.core.CustomData({
    key: "richText",
    value: oExtensionFields.name
   }));
   oGroupElement.setLabel(oLabel);
   oGroupElement.addElement(oRichTextArea);
   oGroup.insertGroupElement(oGroupElement, index);
   return oGroupElement;
  },

  _buildDateTypeFields: function(sValue) {
   var oDateFormatter = sap.ui.core.format.DateFormat.getDateInstance();
   var sDate = oDateFormatter.parse(sValue);
   if(sDate){
    var yyyy = sDate.getFullYear().toString();
    var mm = (sDate.getMonth() + 1).toString();
    var dd = sDate.getDate().toString();
    sValue = yyyy + "-" + (mm[1] ? mm : "0" + mm[0]) + "-" + (dd[1] ? dd : "0" + dd[0]) + "T00:00:00";
    return sValue;
   }
   return null;
  },

  _handleSmartField: function(oField, oExtensionModelData, oData) {
   var sKey = oField.getDataProperty().typePath;
   if (sKey === "to_ExecutiveResponsible") {
    return;
   }
   var sValue = oField.getValue();

   switch (oField.getDataProperty().property.type) {
    case "Edm.DateTime":
     //Special Function to Handle DateTime Field.
     if (sValue !== "") {
      oData[sKey] = this._buildDateTypeFields(sValue);
     }else{
      oData[sKey] = null;
     }
     break;
    case "Edm.DateTimeOffset":
     if (sValue !== "") {
      oData[sKey] = oField.getInnerControls()[0].getDateValue();
     }else{
      oData[sKey] = null;
     }
     break;
     case "Edm.Decimal":
      var oBinding = oField.getBindingInfo("value").binding;
      var sDecimalValue = oField.getInnerControls()[0].getValue();
      if( sDecimalValue === ""){
       sDecimalValue = "0";
      }
      var sNewValue = this._formatNumber(sDecimalValue);
      var sOrginalValue = parseFloat(oBinding.vOriginalValue).toString();
      if (sValue !== "" && sNewValue !== sOrginalValue) {
       oData[sKey] = sNewValue;
      }
      break;
     case "Edm.Int32":
      if (sValue !== "") {
       oData[sKey] = this._formatNumber(oField.getInnerControls()[0].getValue(), true);
      }
      break;
    default:
     var sNumcFlag = false;
     for (var j = 0; j < oField.getDataProperty().property.extensions.length; j++) {
         if (oField.getDataProperty().property.extensions[j].name === "display-format") {
          var sDisplayFormat =  oField.getDataProperty().property.extensions[j].value;
          if(sDisplayFormat === "NonNegative"){
           sNumcFlag = true;
          }
         }
        }
        if(sNumcFlag){
         oData[sKey] = oField.getProperty("value");
        }else{
         oData[sKey] = sValue;
        }
   }
  },

  _formatNumber: function(sValue, bInteger){
   var sFormat = sap.ui.getCore().getConfiguration().getFormatSettings().getLegacyNumberFormat(),
    oFloatFormat;
   if(sFormat){
    oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance(this._decimalFormatMapping[sFormat]);
   }
   else{
    oFloatFormat = sap.ui.core.format.NumberFormat.getFloatInstance(this._decimalFormatMapping.X);
   }
   var result = oFloatFormat.parse(sValue);
   if(!bInteger){
    result = result.toString();
   }
   return result;
  },


  _handleValueHelp: function(oField, oExtensionModelData, oData) {
   var sKey = oField.getId().split("extensionSmartField")[1];
   if (sKey) {
    var bIsMandatory = false;
    var sMandatory = "mandatory";
    var oCustomData = oField.getCustomData();
    if(oCustomData.length > 0 && oExtensionModelData !== undefined){
     var sFieldName = oCustomData[0].getValue();
     bIsMandatory = oExtensionModelData[sFieldName][sMandatory];
    }
    if(bIsMandatory){
     if(oField.getSelectedKey() === ""){
      oData[sKey] = oField.getName();
     }
     else{
      oData[sKey] = oField.getSelectedKey();
     }
    }
    else{
     oData[sKey] = oField.getSelectedKey();
    }

   }
  },

  _handleRichTextData: function(oField, oExtensionModelData, oData){
   var sKey = oField.getId().split("extensionSmartField")[1];
   if(sKey){
    oData[sKey]=encodeURIComponent(oField.getValue());
   }
  },

  _saveSmartFormGroupElementField: function(oField, oExtensionModelData, oData) {
   //field should be editable
   if (!oField || (oField.getMetadata().getName() !== "sap.m.Select" &&oField.getMetadata().getName() !== "sap.ui.richtexteditor.RichTextEditor"&& !(oField.getEditable)) || (oField.getMetadata().getName() !== "sap.m.Select" && oField.getEditable() === false) || !oField.getMetadata || (oField.getItems && oField.getSelectedItem ===
     undefined) //special handle logic for vbox control.
    || oField.getTokens //speicial handle logic for multiinput control
    || oField.getDateValue) //speicial handle logic for datePicker control
   {
    return;
   }

   switch (oField.getMetadata().getName()) {
    case "sap.ui.richtexteditor.RichTextEditor":
     this._handleRichTextData(oField, oExtensionModelData, oData);
     break;
    case "sap.ui.comp.smartfield.SmartField":
     this._handleSmartField(oField, oExtensionModelData, oData);
     break;
    case "sap.m.Select":
     this._handleValueHelp(oField, oExtensionModelData, oData);
     break;
    case "sap.m.Input":
     this._handleValueHelp(oField, oExtensionModelData, oData);
     break;
   }
  },

  _saveSmartFormGroupElement: function(oSmartFormGroupElement, oExtensionModelData, oData) {
   if (!oSmartFormGroupElement || !oSmartFormGroupElement.getFields()) {
    return;
   }

   var aFields = oSmartFormGroupElement.getFields();
   for (var k = 0; k < aFields.length; k++) {
    this._saveSmartFormGroupElementField(aFields[k], oExtensionModelData, oData);
   }
  },

  _saveSmartFormGroup: function(oSmartFormGroup, oExtensionModelData, oData) {
   if (!oSmartFormGroup || !oSmartFormGroup.getFormElements()) {
    return;
   }
   var aFormElements = oSmartFormGroup.getFormElements();
   for (var i = 0; i < aFormElements.length; i++) {
    this._saveSmartFormGroupElement(aFormElements[i], oExtensionModelData, oData);
   }
  },

  saveSmartForm: function(oSmartForm, oExtensionModelData) {
   var oData = {};
   if (!oSmartForm || !oSmartForm.getGroups()) {
    return oData;
   }
   for (var i = 0; i < oSmartForm.getGroups().length; i++) {
    this._saveSmartFormGroup(oSmartForm.getGroups()[i], oExtensionModelData, oData);
   }
   return oData;
  },

  _bindDropDownExtension: function(oDropDown) {
   var aValueSet = [];
   var aCustomerData = oDropDown.getCustomData();
   for (var j = 0; j < aCustomerData.length; j++) {
    if (aCustomerData[j].getKey() === "valueSet") {
     aValueSet = aCustomerData[j].getValue();
    }
   }
   var oJSModel = new sap.ui.model.json.JSONModel(aValueSet);
   oDropDown.setModel(oJSModel);
   oDropDown.bindItems({
    path: "/",
    template: new sap.ui.core.Item({
     key: "{text}",
     text: "{value}"
    })
   });
  },

  _checkFiledTypeIsNumc: function(sField, oMetadata, sEntity) {
   var aAnnotations = oMetadata.dataServices.schema[0].annotations;
   for (var i = 0; i < aAnnotations.length; i++) {
    if (aAnnotations[i].target === oMetadata.dataServices.schema[0].namespace + "." + this.getEntityType(sEntity) + "/" +
     sField) {
     if (aAnnotations[i].annotation[0].term === "sap.grc.aud.fieldType.NUMC") {
      return true;
     } else {
      return false;
     }
    }
   }
   return false;
  },

  destoryElements: function(aDropDownEdit) {
   if (this.oValueHelpDialog) {
    this.oValueHelpDialog.destroy();
    this.oValueHelpDialog = null;
   }
   for (var i = 0; i < aDropDownEdit.length; i++) {
    aDropDownEdit[i].element.destroyElements();
    aDropDownEdit[i].element.destroy();
   }
  },

  destoryNonSmartFieldElements: function(oExtensionGroup){
   var oGroupElements = oExtensionGroup.getGroupElements();
   for(var k = 0;k<oGroupElements.length;k++){
    for(var j=0; j<oGroupElements[k].getFields().length;j++){
     for (var i = 0; i < oGroupElements[k].getFields()[j].getCustomData().length; i++) {
      if ( oGroupElements[k].getFields()[j].getCustomData()[i].getKey() === "richText"){
       oGroupElements[k].destroyElements();
       oGroupElements[k].destroy();
       break;
      }
     }
    }
   }
  },

  saveCDFInCreateMode: function(aFields) {
   var oCDFData = {};
   if (!aFields) {
    return oCDFData;
   }
   var sExtensionLabelIdPrefix = sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud.utils.Constant.DIALOGID
    .EXTENSION_LABEL;
   var sExtensionInputIdPrefix = sap.grc.acs.lib.aud.utils.Constant.DIALOGID.CREATE + sap.grc.acs.lib.aud.utils.Constant.DIALOGID
    .EXTENSION_INPUT;
   for (var j = 0; j < aFields.length; j++) {
    if (aFields[j].isExtensionField) {
     var sCDFFieldName = aFields[j].name;
     var sCDFFieldType = aFields[j].type;
     if (sap.ui.getCore().byId(sExtensionLabelIdPrefix + sCDFFieldName).getVisible()) {
      if(sCDFFieldType === "Edm.Decimal") {
        var sExtensionDecimal = sap.ui.getCore().byId(sExtensionInputIdPrefix + sCDFFieldName).getValue();
        if(!sExtensionDecimal){
          sExtensionDecimal="0";
        }
        oCDFData[sCDFFieldName] = sExtensionDecimal;
      } else if (sCDFFieldType === "Edm.DateTime") {
       var sExtensionDate = sap.ui.getCore().byId(sExtensionInputIdPrefix + sCDFFieldName).getValue();
       var oDateValue = this._buildDateTypeFields(sExtensionDate);
       if (oDateValue) {
        oCDFData[sCDFFieldName] = oDateValue;
       }
      } else if (sCDFFieldType === "Edm.DateTimeOffset") {
       var oDateTimeFormatter = sap.ui.core.format.DateFormat.getDateTimeInstance();
       var sDateTime = sap.ui.getCore().byId(sExtensionInputIdPrefix + sCDFFieldName).getValue();
       oCDFData[sCDFFieldName] = oDateTimeFormatter.parse(sDateTime);
      } else if (sCDFFieldType === "Edm.Int32"){
       if (sap.ui.getCore().byId(sExtensionInputIdPrefix + sCDFFieldName).getValue) {
         var oInteger= sap.ui.getCore().byId(sExtensionInputIdPrefix + sCDFFieldName).getValue();
         oCDFData[sCDFFieldName] = parseInt(oInteger,10);
       }
      } else {
       //control input
       if (sap.ui.getCore().byId(sExtensionInputIdPrefix + sCDFFieldName).getValue) {
        if(sap.ui.getCore().byId(sExtensionInputIdPrefix + sCDFFieldName).getShowValueHelp){
         if(sap.ui.getCore().byId(sExtensionInputIdPrefix + sCDFFieldName).getShowValueHelp() === true){
          oCDFData[sCDFFieldName] = sap.ui.getCore().byId(sExtensionInputIdPrefix + sCDFFieldName).getSelectedKey();
         }else{
          oCDFData[sCDFFieldName] = sap.ui.getCore().byId(sExtensionInputIdPrefix + sCDFFieldName).getValue();
         }
        }else{
         oCDFData[sCDFFieldName] = sap.ui.getCore().byId(sExtensionInputIdPrefix + sCDFFieldName).getValue();
        }
        //control select
       } else {
        if (sap.ui.getCore().byId(sExtensionInputIdPrefix + sCDFFieldName).getSelectedItem() === null) {
         oCDFData[sCDFFieldName] = undefined;
        } else {
         oCDFData[sCDFFieldName] = sap.ui.getCore().byId(sExtensionInputIdPrefix + sCDFFieldName).getSelectedItem().getKey();
        }
       }
      }
     }
    }
   }
   return oCDFData;
  }
 };
});


