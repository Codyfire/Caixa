/*
 * Copyright (C) 2009-2020 SAP SE or an SAP affiliate company. All rights reserved.
 */
jQuery.sap.declare("sap.grc.acs.aud.finding.execute.extended.Component");
					
sap.ui.component.load({
 	name:"sap.grc.acs.aud.finding.execute",
 	url: "/sap/bc/ui5_ui5/sap/grcaud_findexe"
 		 
 });
sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"sap/grc/acs/aud/finding/app/Component"
], function(UIComponent, Device, FindingComponent) {
	"use strict";

	return FindingComponent.extend("sap.grc.acs.aud.finding.execute.extended.Component",
		{
			metadata: {
				manifest: "json",
				"customizing" : {
			    	 "sap.ui.viewReplacements" : {
			                 "sap.grc.acs.aud.finding.block.view.ActionPlan": {    
			                     "viewName": "sap.grc.acs.aud.finding.execute.extended.block.view.ActionPlan",            
			                     "type": "XML"
			                 },
			                 "sap.grc.acs.aud.finding.view.Object": {    
			                     "viewName": "sap.grc.acs.aud.finding.execute.extended.view.Object",            
			                     "type": "XML"
			                 }
						},
			         "sap.ui.controllerExtensions" : {

					 "sap.grc.acs.aud.finding.block.controller.ActionPlan" : {
						 "controllerName":"sap.grc.acs.aud.finding.execute.extended.block.controller.ActionPlan"
					 
					 },
					 "sap.grc.acs.aud.finding.controller.Object" : {
						 "controllerName":"sap.grc.acs.aud.finding.execute.extended.controller.Object"
					 
					 }
					 
					 },
						"sap.ui.controllerReplacements" : {
					 "sap.grc.acs.aud.finding.controller.Create":{
						 "controllerName":"sap.grc.acs.aud.finding.execute.extended.block.controller.Create"
					 },
					 "sap.grc.acs.aud.finding.block.controller.General" : {						 
							"controllerName":"sap.grc.acs.aud.finding.execute.extended.block.controller.GeneralCustom"
						 
						 }
					 
				}
				}
			}
		}
	);

});